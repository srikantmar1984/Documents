<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">  <!--disable compatible button-->
	<title>Workshop Portal</title>
    <link rel="stylesheet" type="text/css" href="css/common.css">
	<link rel="stylesheet" type="text/css" href="themes/default/easyui.css">
	<link rel="stylesheet" type="text/css" href="themes/icon.css">
    <link rel="stylesheet" type="text/css" href="css/Login/style.css" />
	<!--<script type="text/javascript" src="js/jquery.min.js"></script>-->
    <script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
	<script type="text/javascript" src="js/jquery.kksui.min.js"></script>
    <script src="js/jquery.json-2.4.min.js"></script>
	<script src="js/validations.js"></script>
    
    <script type="text/javascript">
   $(document).ready(function() 
	{
		$('#btnSubmit').click(function(){
			
			 $.ajax({
					   type: "POST",
					   url: 'login_auth.php',
					   data: $("#loginform").serialize(),
					   success: function(data)
					   {
                                                
                        console.log(data); //return false;                     
						var str=data.indexOf("Error");
				  	 	if(str=='-1')
				   		{
							if(data.indexOf("Login")!='-1')
							{
								window.location = 'home.php';
							}
							else
							{
								alert('Invalid Credentials');

							}

						}
				   		else
				   		{
					  		alert('Invalid Credentials');

				   		}

						   //alert(data);
						  //if (data === 'Login') {
							//window.location = 'home.php';
						  //}
						  //else {
							//alert('Invalid Credentials');
						  //}
					   }
				   });
		
		});

});
</script>

</head>
<body class="kks-layout">
<div id="spinner">
     <span style="font-size:10px">Please Wait...</span>
</div>
<?php include 'header.php'; ?>
    		
     <!--footer-->
	<div data-options="region:'south',border:false" id="footer">
         <p style="border-top:1px #E9F1FF solid">Copyright: MSD CAD Jamshedpur. All Rights Reserved.  <br />Best viewed in Chrome , Firfox Mozilla and IE 9+ with 1024 X 768 resolution.</p>
    </div>
    <!--footer end-->
    
    <!--main container-->
	<div data-options="region:'center',title:' '" id="content">
    <div style="padding:10%;">
    	 <section class="main">
		  <form id="loginform" class="form-2" method="post" action="">
					<h1><span class="log-in">Log in</span></h1>
					<p class="float">
						<label for="login">Domain ID</label>
						<input type="text"  name="username" placeholder="Domain ID">
					</p>
					<p class="float">
						<label for="password">Password</label>
						<input type="password" name="password" placeholder="Password" class="showpassword">
					</p>
					<p class="clearfix"> 
						<input id="btnSubmit" type="submit"  name="submit" value="Log in">
					</p>
				</form>​​
			</section>
     </div>       
    </div>
    <!--main container end-->

</body>
</html>
















