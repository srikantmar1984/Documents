<?php

	if(isset($_REQUEST['userid'])&& $_REQUEST['userid']!="" && isset($_REQUEST['menuid'])&& $_REQUEST['menuid']!="")
	{
		header("location: validate_redirection.php?userid=".$_REQUEST['userid']."&menuid=".$_REQUEST['menuid']." ");
	}
	else
	{
		if(!isset($_SESSION))
		{
			@session_start();
		}
		$userid="";
		$menuid=$_REQUEST['menuid'];
		if(isset($_SESSION['Pno']))
		{
			$userid=$_SESSION['Pno'];
		}			   
		/* echo "<script>document.location.href='http://10.15.10.72/safetytest/redirectpage.aspx?userid=$userid&menuid=$menuid'</script>";*/
		 echo "<script>document.location.href='http://172.27.128.81/tmlsafety/redirectpage.aspx?userid=$userid&menuid=$menuid'</script>";
	}

?>