<?php  
				$ref='on';
				include("db_classes/commanvar.php");
				include("db_classes/class.db.php");
    
  				$sql ="SELECT "; 
                $sql .="t1.tus_pno PNo ";
                $sql .=", INITCAP(t1.tus_name) UserName ";
                $sql .=", t1.tus_email_id EmailID ";
                $sql .=", t2.tdp_dept_id DeptID ";
                $sql .=", t2.tdp_dept_name DeptName ";
                $sql .=", t3.tdg_desg_id DesgID ";
                $sql .=", t3.tdg_desg_name DesgName ";
                $sql .=", t4.tol_level_id OrgID ";
                $sql .=", t4.tol_level_name OrgName ";
                $sql .=", t5.tbu_id UnitID ";
                $sql .=", t5.tbu_unit_name UnitName ";
                $sql .=", t6.tlc_id LocnID ";
                $sql .=", t6.tlc_locn_name LocnName ";
                $sql .=", t1.tus_act_flg UserStatus ";
                $sql .=", t2.tdp_act_flg DeptStatus ";
                $sql .=", t3.tdg_act_flg DesgStatus ";
                $sql .=", t4.tol_act_flg OrgStatus ";
                $sql .=", t5.tbu_act_flg UnitStatus ";
                $sql .=", t6.tlc_act_flg LocnStatus ";
                $sql .=", CASE NVL(t7.tua_pno,'InActive') WHEN 'InActive' THEN 'InActive' ELSE 'Active' END UserAppStatus ";
                $sql .=", CASE NVL(t8.tus_pno,'InActive') WHEN 'InActive' THEN 'InActive' ELSE 'Active' END UserAppAssignStatus ";
                $sql .=" FROM ";
                $sql .=" t_sos_users t1 ";
                $sql .=", t_sos_departments t2 ";
                $sql .=", t_sos_designations t3 ";
                $sql .=", t_sos_organisation_levels t4 ";
                $sql .=", t_sos_business_unit t5 ";
                $sql .=", t_sos_locations t6 ";
                $sql .=", (SELECT DISTINCT tua_pno FROM  t_sos_users_apps WHERE  tua_act_flg = 'Active' ) t7 ";
                $sql .=", ( SELECT DISTINCT  tus_pno FROM ";
				$sql .="		  ( 
                            ( 
                                SELECT tus_pno FROM t_sos_app_assign, t_sos_users WHERE tlp_id = tus_org_id AND tlp_idtype = 'ORG' AND tlp_act_flg = 'Active' 
                            ) 
                            UNION 
                            ( 
                                SELECT tus_pno FROM t_sos_app_assign, t_sos_users WHERE tlp_id = tus_unit_id AND tlp_idtype = 'UNIT' AND tlp_act_flg = 'Active' 
                            ) 
                            UNION 
                            ( 
                                SELECT tus_pno FROM t_sos_app_assign, t_sos_users WHERE tlp_id = tus_locn_id AND tlp_idtype = 'LOCN' AND tlp_act_flg = 'Active' 
                            ) 
                            UNION 
                            ( 
                                SELECT tus_pno FROM t_sos_app_assign, t_sos_users_roles, t_sos_users WHERE tlp_id = tur_role_id AND tur_pno = tus_pno AND tlp_idtype = 'ROLE'
								AND tlp_act_flg = 'Active' 
                            ) 
                            UNION 
                            ( 
                                SELECT tus_pno FROM t_sos_app_assign, t_sos_org_locn, t_sos_users WHERE tlp_id = tpl_id AND tpl_org_id = tus_org_id AND tpl_unit_id = tus_unit_id 
								AND tpl_locn_id = tus_locn_id AND tpl_act_flg = 'Active' AND tlp_idtype = 'AOBL' AND tlp_act_flg = 'Active' 
                            ) 
                            UNION 
                            ( 
                                SELECT tus_pno FROM t_sos_app_assign, t_sos_roles_locn, t_sos_users_roles, t_sos_users WHERE tlp_id = trl_id AND trl_org_id = tus_org_id AND
								trl_unit_id = tus_unit_id AND trl_locn_id = tus_locn_id AND trl_role_id = tur_role_id AND tur_pno = tus_pno AND tur_act_flg = 'Active' AND
								trl_act_flg = 'Active' AND tlp_idtype = 'ROBL' AND tlp_act_flg = 'Active' 
                            ) 
                            UNION 
                            ( 
                                SELECT tus_pno FROM t_sos_app_assign, t_sos_users WHERE tlp_id = tus_pno AND tlp_idtype = 'USER' AND tlp_act_flg = 'Active' 
                            ) 
                        ) 
                  ) t8 ";
                $sql .=" WHERE ";
                $sql .=" t1.tus_dept_id = t2.tdp_dept_id ";
                $sql .=" AND t1.tus_desg_id = t3.tdg_desg_id ";
                $sql .=" AND t1.tus_org_id = t4.tol_level_id ";
                $sql .=" AND t1.tus_unit_id = t5.tbu_id ";
                $sql .=" AND t1.tus_locn_id = t6.tlc_id ";
                $sql .=" AND t1.tus_pno = t7.tua_pno(+) ";
                $sql .=" AND t1.tus_pno = t8.tus_pno(+) ";
                $sql .=" AND t1.tus_pno = '".$_REQUEST['userid']."' ";
				
				$obj=new db_connect;
				$obj->db_query($sql);
				$result="";
				while($row=$obj->db_fetch_array()) 
				{

				  	$_SESSION['Pno']=$row[0];
				 	$_SESSION['user_name'] = $row[1];
				  	$_SESSION['Locn'] = $row[11];
				  	$_SESSION['Unit'] = $row[9];
				  	$_SESSION['Org'] = $row[7];
					
					$_SESSION['Dept'] = $row[4];
					$_SESSION['Desg'] = $row[6];
					$_SESSION['OrgName'] = $row[8];
					$_SESSION['UnitName'] = $row[10];
					$_SESSION['LocnName'] = $row[12];
					
					$sql="SELECT tlc_sht_name from t_sos_locations Where tlc_id=".$_SESSION['Locn'];
					$obj->db_query($sql);
					if($row=$obj->db_fetch_array()) 
					{
						$_SESSION["LocnShtName"] =	$row[0];
					}

				  	$sql="SELECT tbu_sht_name from t_sos_business_unit Where tbu_id=".$_SESSION['Unit'];
					$obj->db_query($sql);
					if($row=$obj->db_fetch_array()) 
					{
						 $_SESSION["UnitShtName"] =	$row[0];
					}
					
					$sql="SELECT tol_sht_name from t_sos_organisation_levels Where tol_level_id=".$_SESSION['Org'];
					$obj->db_query($sql);
				   	if($row=$obj->db_fetch_array())
					{
						 $_SESSION["OrgShtName"] =	$row[0];
					}
					$sql="SELECT TUR_ROLE_ID from T_SOS_USERS_ROLES Where TUR_PNO='".$_SESSION['Pno']."' and tur_act_flg='Active' ";
					$obj->db_query($sql);
					$role=array();
				   	while($row=$obj->db_fetch_array())
					{
						 	$role[]=$row[0];
					}
					$_SESSION["Roles"] =$role;
					
				 	 $result="Login";
				}
				$obj->free(); 

				if($result=="Login")
				{
					header("location: home.php?menuid=".$_REQUEST['menuid']." ");
				}
				else
				{
					//header("location: index.php");
					echo 'Sorry...! Invalid User ID , Authentication failed.';
				}
?>				