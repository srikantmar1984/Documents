<?php include 'session_check.php'; 
//error_reporting(0); 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Workshop Safety Report Portal</title>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">  <!--disable compatible button-->
    <link rel="SHORTCUT ICON" href="images/safetyReporting.ico">
	<link rel="stylesheet" type="text/css" href="css/common.css">
    <link rel="stylesheet" type="text/css" href="css/redmond.datepick.css">
	<link rel="stylesheet" type="text/css" href="themes/default/easyui.css">
	<link rel="stylesheet" type="text/css" href="themes/icon.css">
  
    <script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
    <script type="text/javascript" src="js/jquery.datepick.js"></script>
	<script type="text/javascript" src="js/jquery.kksui.min.js"></script>
    <script src="js/jquery.json-2.4.min.js"></script>
	<script src="js/ie-fix.js"></script>
	<script src="js/validations.js"></script>
	<script src="js/exportToExcel1.js" type="text/javascript"></script>
	<script src="js/jquery.upload.js" type="text/javascript"></script>
	<script src="js/math-parser.js"></script>
	<script type="text/javascript" src="js/graphics.js"></script>
	<script src="js/amcharts/amcharts.js" type="text/javascript"></script>
	<script src="js/amcharts/serial.js" type="text/javascript"></script>
	<script src="js/amcharts/pie.js" type="text/javascript"></script>
	<script src="js/amcharts/exporting/amexport.js" type="text/javascript"></script>
	<script src="js/amcharts/exporting/rgbcolor.js" type="text/javascript"></script>
	<script src="js/amcharts/exporting/canvg.js" type="text/javascript"></script>
	<script src="js/amcharts/exporting/jspdf.js" type="text/javascript"></script>
	<script src="js/amcharts/exporting/filesaver.js" type="text/javascript"></script>
	<script src="js/amcharts/exporting/jspdf.plugin.addimage.js" type="text/javascript"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$(".layout-panel-center").css("text-align", "center");
		getList();
		//javascript export to excel

			
			//Server Side
			$('#exportToExcel').die('click').live('click',function()
			 {
					var obj=$("div").find(".Grid");
					id=obj.find("Table").attr("id");
					var output =$("#"+id).html().replace(/<\s*img[^>]*>|<input(\s+[^>]*)?>|<textarea(\s+[^>]*)?>|<select(\s+[^>]*)?>(.|\n)*?<\/select(\s+[^>]*)?>/gi,'');
					  $("#htmlData").val('<table border="1">'+output+'</table>');
					 $("#act").val("Excel");
					 document.forms["excel"].submit();	
					
			 });
			 $('#exportToDoc').die('click').live('click',function()
			 {
					var obj=$("div").find(".Grid");
					id=obj.find("Table").attr("id");
					var output =$("#"+id).html().replace(/<\s*img[^>]*>|<input(\s+[^>]*)?>|<textarea(\s+[^>]*)?>|<select(\s+[^>]*)?>(.|\n)*?<\/select(\s+[^>]*)?>/gi,'');
					  $("#htmlData").val('<table border="1">'+output+'</table>');
					 $("#act").val("Doc");
					 document.forms["excel"].submit();
						
			 });
		
	});	
function openUrl(vUrl)
	{
			
			$("#display_content").empty();
			$("#display_content").html('');
			var screen_id="";
			   $.post(vUrl, function(data)
				{
						$("#display_content").html('');
				 		$("#display_content").html(data);
					
						var title=$("#hfPageTitle").val();
						screen_id=$("#hfPageTitle").attr('screen_id');
                                                $(".panel.layout-panel.layout-panel-center .panel-header .panel-title").html("");
						$(".panel.layout-panel.layout-panel-center .panel-header .panel-title").html(title);
                                                $(".panel.layout-panel.layout-panel-center .panel-header .panel-title").append('<div width="20" style="float:right"><a id="exportToExcel" href="#"><img src="images/excel_icon.png" title="Export To Excel"></a></div><div width="20" style="float:right"><a id="exportToDoc" href="#"><img src="images/doc.png" title="Export To Doc" width="20" hight="20"></a> &nbsp; </div>');
					
				 		$('.kks-tabs').tabs({});
						$('.kks-linkbutton').linkbutton({});
						$('.kks-datebox').datebox({});
						$('.kks-panel').panel({});
						$('#tt').tree({});
						$('#tt1').tree({});
					
				$('.txtFieldTextBox').bind("keypress", (function (e) {
							
							var keynum
							var keychar
							var numcheck
							// For Internet Explorer
							if (window.event) {
								keynum = e.keyCode;
							}
							// For Netscape/Firefox/Opera
							else if (e.which) {
								keynum = e.which;
							}
							keychar = String.fromCharCode(keynum);
							//List of special characters you want to restrict
							if (keychar == "'" || keychar == "`" || keychar =="!" || keychar =="#" || keychar =="$" || keychar =="%" || keychar =="^" || keychar =="&" || keychar =="*" || keychar =="(" || keychar ==")"  || keychar =="+" || keychar =="=" || keychar =="~" || keychar =="<" || keychar ==">" || keychar =="," || keychar ==";" || keychar ==":" || keychar =="|" || keychar =="?" || keychar =="{" || keychar =="}" || keychar =="[" || keychar =="]" || keychar =="¬" || keychar =="£" || keychar =='"' || keychar =="\\") 
							{
								return false;
							} else
							{
								return true;
							}
						
	
					}));

					
			   });
			
		

			   
			
	}

function loadData()
	{
		var menuid = GetParameterValues('menuid');
		if(typeof(menuid)!= "undefined")
		{
			var dUrl=$("a[menuid="+menuid+"]").attr("menuUrl");
			openUrl(dUrl);
		}
	}
function GetParameterValues(param) 
	{
		var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
		for (var i = 0; i < url.length; i++) 
		{
			var urlparam = url[i].split('=');
			if (urlparam[0] == param) 
			{
				return urlparam[1];
			}
		}
	}
/*==================================== Get Graph Data===================================*/
function getList(){
 
	var date = new Date();
    var lastDay= '31-Dec-'  + date.getFullYear();
    var firstDay = '01-Jan-'  + date.getFullYear();;
	
    graph_arr = new Array();

    $.post("/workshopportal/homecontent.php",
            {	
            fromdt  : firstDay,
            todt : lastDay,
            act : 'getList'
            },function(data){
			//	console.log(data);return false;
             

                var obj = $.parseJSON(data);
                var monthlist = obj.pop(); 

                var obj = $.parseJSON(data);
                var cnt=0;
                

				$.each(monthlist,function(mbody,mnthbody){

					var Incident=0;
					var Quaterly=0;
					var mom=0;
					var monthly=0;
					var critical=0;	

					$.each(obj,function(ibody,itembody){
						cnt++;
						if(mnthbody['MONTHSID'] ==itembody['LOGMONTHID'] ){
						
							switch(itembody['RPTTYPE'])
							{
								case "Incident":Incident++;
									break;
								case "Quaterly Audit":Quaterly++;
									break;
								case "MOM":mom++;
									break;
								case "Monthly SHE":monthly++;
									break;
								case "Critical Safety":critical++;
									break;
								
							}
						}
	
					});
				
                graph_arr.push({'month':mnthbody['MONTHS'],'Incident':Incident,'Quaterly':Quaterly,'Minutes':mom,'Monthly':monthly,'Critical':critical});

				});
               
                
                hdgraph(graph_arr);
            });
}
	
	
        
        
        
function hdgraph(data){
     
	var chartData =data;
	//console.table(data);
	var chart =AmCharts.makeChart("chartdiv",
				{
					"type": "serial",
					"categoryField": "month",
					"columnWidth": 0,
					"marginBottom": 10,
					"marginLeft": 10,
					"marginRight": 10,
					"marginTop": 10,
					"startDuration": 1,
					"startEffect": "easeOutSine",
					"borderAlpha": 0.03,
					"handDrawn": true,
					"handDrawScatter": 0,
					"handDrawThickness": 0,
					"categoryAxis": {
					"gridPosition": "start"
					},
					"trendLines": [],
					"graphs": [
						{
							"bullet": "triangleUp",
							"bulletSize": 10,
							"fixedColumnWidth": 0,
							"id": "AmGraph-1",
							"lineColor": "#C90B0A",
							"title": "Incident",
							"valueField": "Incident"
						},
						{
							"bullet": "triangleDown",
							"bulletSize": 10,
							"id": "AmGraph-2",
							"lineColor": "#090AFF",
							"title": "Quaterly SHE Audit",
							"valueField": "Quaterly"
						},
						{
							"bullet": "triangleRight",
							"bulletSize": 10,
							"columnWidth": 0,
							"cornerRadiusTop": 1,
							"dashLength": 4,
							"fixedColumnWidth": 0,
							"fontSize": 1,
							"id": "AmGraph-3",
							"lineColor": "#F90A0A",
							"title": "Monthly SHE",
							"valueField": "Monthly"
						},
						{
							"behindColumns": true,
							"bullet": "round",
							"bulletAlpha": 0,
							"bulletBorderAlpha": 0.61,
							"bulletBorderColor": "#057C99",
							"bulletSize": 10,
							"columnWidth": 0,
							"cornerRadiusTop": 29,
							"cursorBulletAlpha": 0,
							"fixedColumnWidth": 3,
							"id": "AmGraph-4",
							"lineColor": "#C0C0C0",
							"title": "Minutes of Meeting",
							"valueField": "Minutes"
						},
						{
							"bullet": "square",
							"bulletAlpha": 0,
							"bulletBorderAlpha": 1,
							"bulletBorderColor": "#057C99",
							"bulletBorderThickness": 1,
							"bulletSize": 10,
							"columnWidth": 0,
							"dashLength": 4,
							"fixedColumnWidth": 3,
							"id": "AmGraph-5",
							"lineColor": "#33FF00",
							"title": "Critical Safety",
							"valueField": "Critical"
						}
					],
					"guides": [],
					"valueAxes": [
						{
							"id": "ValueAxis-1",
							"title": "No of Logs"
						}
					],
					"allLabels": [],
					"balloon": {},
					"legend": {
						"useGraphSettings": true
					},
					"titles": [
						{
							"id": "Title-1",
							"size": 15,
							"text": "Yearly Analysis "
						}
					],
					"dataProvider": chartData
				}); 
	
	

		
}	

		//==================================================================================================
	 </script>
	<style>
	 	.round2corners {
		box-shadow: 0 15px 20px rgba(0, 0, 0, 0.3);
		border-radius: 15px 15px;
		background: rgba(79, 124, 192, 0.92) ;/*#4f7cc0;  #3c8dbc; #39cccc;*/
		margin:1%;
		width:31%;
		height: 100px;
		float: left;
    	display: block;
		vertical-align: middle;
		}
		.round1corners{
			box-shadow: 0 15px 20px rgba(0, 0, 0, 0.3);
			
			background: rgb(253, 247, 203);
			margin:1%;
			width:97%;
			height: 50%;
			float: left;
			display: block;
			vertical-align: middle;
		}
		h2{
			color:white;
		}
		h1{
			color:white;
		}
	 </style>
</head>
<body class="kks-layout">
            <?php   include 'header.php';?>
   <!-- menu Section-->
	<div data-options="region:'west',split:true,title:'Menu'" style="width:231px;">
             <?php include 'menus.php'; ?> 
    </div>
  
     <!--footer-->
	<div data-options="region:'south',border:true" id="footer">
    	<p>Copyright: MSD CAD Jamshedpur. All Rights Reserved.  <br />Best viewed in Chrome , Firfox Mozilla and IE 9+ with 1024 X 768 resolution.</p>
            
            <form id="excel" target="iframe" action="Export.php" method="post">
                <input id="htmlData" name="Content" type="hidden" value="">
                <input id="act" name="act" type="hidden" value="">
            <iframe id="iframe" style="display:none" >
            </iframe>
            </form>
    </div>
    <!--footer end-->
    
    <!--main container-->
	<div data-options="region:'center',title:'Home Page'" id="content">
    	<div id="spinner" style="height:50px">
    		<span style="font-size:10px">Please Wait...</span>
	</div>
    
        <div id="display_content">
			<?php include 'homecontent.php'; ?> 
		</div>
       
    </div>
    <!--main container end-->
</body>
<?php echo "<script>loadData();</script>" ?>
</html>