<?php
	$ref='on';
	include("db_classes/commanvar.php");
	include("db_classes/class.db.php");
	
	if(!isset($_SESSION['Pno']))
	{
		echo "<script>document.location.href='index.php'</script>";
	}
	function Accordion($pno,$org,$unit,$locn)
	{
			$sql="SELECT 
					  t1.tmt_menu_name MenuName , t1.tmt_menu_id MenuID , t1.tmt_slno 
				 FROM 
					   t_wsr_menu_tabs t1 
					 , ( 
						 ( 
							 SELECT DISTINCT 
								   tmt_menu_id 
							 FROM 
								   t_wsr_menu_tabs A1 
								 , t_wsr_menu_access A2 
								 , t_wsr_users_apps A3 
								 , t_wsr_users_roles A4 
								 , t_wsr_applications A5 
							 WHERE 
								   A1.tmt_menu_id = A2.tma_menu_id 
								 AND A2.tma_act_flg = 'Active' 
								 AND A1.tmt_app_id IS NOT NULL 
								 AND A1.tmt_app_id = A3.tua_app_id 
								 AND A3.tua_act_flg = 'Active' 
								 AND A2.tma_role_id = A4.tur_role_id 
								 AND A4.tur_act_flg = 'Active' 
								 AND A3.tua_pno = A4.tur_pno 
								 AND A4.tur_pno = '$pno' 
								 AND A2.tma_org_id = '$org' 
								 AND A2.tma_unit_id = '$unit' 
								 AND A2.tma_locn_id = '$locn' 
								 AND A5.tap_id = A1.tmt_app_id 
								 AND A5.tap_act_flg = 'Active' 
						 ) 
						 UNION 
						 ( 
							 SELECT DISTINCT 
								   tmt_menu_id 
							 FROM 
								   t_wsr_menu_tabs A1 
								 , t_wsr_menu_access A2 
								 , t_wsr_users_roles A3 
							 WHERE 
								   A1.tmt_menu_id = A2.tma_menu_id 
								 AND A2.tma_act_flg = 'Active' 
								 AND A1.tmt_app_id IS NULL 
								 AND A2.tma_role_id = A3.tur_role_id 
								 AND A3.tur_act_flg = 'Active' 
								 AND A3.tur_pno = '$pno' 
								 AND A2.tma_org_id = '$org' 
								 AND A2.tma_unit_id = '$unit' 
								 AND A2.tma_locn_id = '$locn' 
						 ) 
					   ) t2 
				 WHERE 
					   t1.tmt_menu_id = t2.tmt_menu_id 
					 AND t1.tmt_mas_id IS NULL 
					 AND t1.tmt_act_flg = 'Active' 
				 ORDER BY 
					   t1.tmt_slno ASC ";
		
		$obj=new db_connect;
		$obj->db_query($sql);

		$result="<div class=\"kks-accordion\" data-options=\"border:false\">";
		while($row=$obj->db_fetch_array()) 
		{
			$result.='<div class="t" title="'.$row[0].'" style="padding:2px;" >';
			$result.='<ul id="menuTree" class="kks-tree" data-options="animate:true,lines:true">';
				$result.=Menu($row[1],$pno,$org,$unit,$locn);
			$result.='</ul>';
			$result.="</div>";
		}
		$result.="</div>";
		$obj->free();
		return $result;
	}

	function Menu($strMasterId,$pno,$org,$unit,$locn)
	{
		$sql="  SELECT 
					   t1.tmt_menu_name MenuName 
					 , t1.tmt_menu_id MenuID 
					 , t1.TMT_REL_PATH MenuPath 
					 
					 , t1.tmt_slno 
				 FROM 
					   t_wsr_menu_tabs t1 
					 , ( 
						 ( 
							 SELECT DISTINCT 
								   tmt_menu_id 
							 FROM 
								   t_wsr_menu_tabs A1 
								 , t_wsr_menu_access A2 
								 , t_wsr_users_apps A3 
								 , t_wsr_users_roles A4 
								 , t_wsr_applications A5 
							 WHERE 
								   A1.tmt_menu_id = A2.tma_menu_id 
								 AND A2.tma_act_flg = 'Active' 
								 AND A1.tmt_app_id IS NOT NULL 
								 AND A1.tmt_app_id = A3.tua_app_id 
								 AND A3.tua_act_flg = 'Active' 
								 AND A2.tma_role_id = A4.tur_role_id 
								 AND A4.tur_act_flg = 'Active' 
								 AND A3.tua_pno = A4.tur_pno 
								 AND A4.tur_pno = '$pno' 
								 AND A2.tma_org_id = '$org' 
								 AND A2.tma_unit_id = '$unit' 
								 AND A2.tma_locn_id = '$locn' 
								 AND A5.tap_id = A1.tmt_app_id 
								 AND A5.tap_act_flg = 'Active' 
						 ) 
						 UNION 
						 ( 
							 SELECT DISTINCT 
								   tmt_menu_id 
							 FROM 
								   t_wsr_menu_tabs A1 
								 , t_wsr_menu_access A2 
								 , t_wsr_users_roles A3 
							 WHERE 
								   A1.tmt_menu_id = A2.tma_menu_id 
								 AND A2.tma_act_flg = 'Active' 
								 AND A1.tmt_app_id IS NULL 
								 AND A2.tma_role_id = A3.tur_role_id 
								 AND A3.tur_act_flg = 'Active' 
								 AND A3.tur_pno = '$pno' 
								 AND A2.tma_org_id = '$org' 
								 AND A2.tma_unit_id = '$unit' 
								 AND A2.tma_locn_id = '$locn' 
						 ) 
					   ) t2 
				 WHERE 
					   t1.tmt_menu_id = t2.tmt_menu_id 
					 AND t1.tmt_mas_id = '" .$strMasterId. "'  
					 AND t1.tmt_act_flg = 'Active' 
				 ORDER BY 
					   t1.tmt_slno ASC ";
			
			$obj=new db_connect;		   
			$obj->db_query($sql);
			$res="";	
			while($row=$obj->db_fetch_array()) 
			{
				$submenu=SubMenu($row[1],$pno,$org,$unit,$locn);
				if($submenu=="<ul></ul>")
				{
					$res.='<li><span><a id="lnkmenu" href="#" attr="'.$row[2].'" menuid="'.$row[1].'" menuUrl="'.HOST_PATH.$row[2].'" onclick=openUrl("'.HOST_PATH.$row[2].'?menuid='.$row[1].'")>'.$row[0].'</a></span>';
				}
				else
				{
					$res.='<li state="closed"><span><a id="lnkmenu"  href="#" attr="'.$row[2].'">'.$row[0].'</a></span>';
					$res.=$submenu;
				}
				$res.='</li>';
				
			}
			$obj->free();
			return $res;		   
	}

function SubMenu($strMasterId,$pno,$org,$unit,$locn)
{
	
	$sql=" SELECT 
                   t1.tmt_menu_name MenuName 
                 , t1.tmt_menu_id MenuID 
                 , t1.TMT_REL_PATH MenuPath 
                 , t1.tmt_slno 
             FROM 
                   t_wsr_menu_tabs t1 
                 , ( 
                     ( 
                         SELECT DISTINCT 
                               tmt_menu_id 
                         FROM 
                               t_wsr_menu_tabs A1 
                             , t_wsr_menu_access A2 
                             , t_wsr_users_apps A3 
                             , t_wsr_users_roles A4 
                             , t_wsr_applications A5 
                         WHERE 
                               A1.tmt_menu_id = A2.tma_menu_id 
                             AND A2.tma_act_flg = 'Active' 
                             AND A1.tmt_app_id IS NOT NULL 
                             AND A1.tmt_app_id = A3.tua_app_id 
                             AND A3.tua_act_flg = 'Active' 
                             AND A2.tma_role_id = A4.tur_role_id 
                             AND A4.tur_act_flg = 'Active' 
                             AND A3.tua_pno = A4.tur_pno 
                             AND A4.tur_pno = '$pno' 
                             AND A2.tma_org_id = '$org' 
                             AND A2.tma_unit_id = '$unit' 
                             AND A2.tma_locn_id = '$locn' 
                             AND A5.tap_id = A1.tmt_app_id 
                             AND A5.tap_act_flg = 'Active' 
                     ) 
                     UNION 
                     ( 
                         SELECT DISTINCT 
                               tmt_menu_id 
                         FROM 
                               t_wsr_menu_tabs A1 
                             , t_wsr_menu_access A2 
                             , t_wsr_users_roles A3 
                         WHERE 
                               A1.tmt_menu_id = A2.tma_menu_id 
                             AND A2.tma_act_flg = 'Active' 
                             AND A1.tmt_app_id IS NULL 
                             AND A2.tma_role_id = A3.tur_role_id 
                             AND A3.tur_act_flg = 'Active' 
                             AND A3.tur_pno = '$pno' 
                             AND A2.tma_org_id = '$org' 
                             AND A2.tma_unit_id = '$unit' 
                             AND A2.tma_locn_id = '$locn' 
                     ) 
                   ) t2 
             WHERE 
                   t1.tmt_menu_id = t2.tmt_menu_id 
                 AND t1.tmt_mas_id = '" .$strMasterId. "'  
                 AND t1.tmt_act_flg = 'Active' 
             ORDER BY 
                   t1.tmt_slno ASC ";
                
        
		$obj1=new db_connect;		   
		$obj1->db_query($sql);
		$res='<ul>';
		while($row1=$obj1->db_fetch_array()) 
		{
			$submenu=SubMenu($row1[1],$pno,$org,$unit,$locn);
			if($submenu=="<ul></ul>")
			{
				$res.='<li><span><a id="lnkmenu" href="#" attr="'.$row1[2].'" menuid="'.$row1[1].'" menuUrl="'.HOST_PATH.$row1[2].'" onclick=openUrl("'.HOST_PATH.$row1[2].'?menuid='.$row1[1].'") >'.$row1[0].'</a></span>';
			}
			else
			{
				$res.='<li state="closed"><span><a id="lnkmenu"  href="#" attr="'.$row1[2].'">'.$row1[0].'</a></span>';
				$res.=$submenu;
			}
			$res.='</li>';
		}
		$res.='</ul>';
        
		$obj1->free();
		return $res;	
		
}

	echo Accordion($_SESSION["Pno"],$_SESSION["Org"],$_SESSION["Unit"],$_SESSION["Locn"]);
	echo '<script>$(".t:last").attr("selected","true");</script>';

?>