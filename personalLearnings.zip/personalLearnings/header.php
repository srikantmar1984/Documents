<?php


 $head="<div data-options=\"region:'north',border:false\">

			<div style= \"width:100%;background: #4F7CC0; padding: 0; color:#FFF; height:50px;text-align:center;\">
    			<div style=\"float:left; padding:5px; width:15%\"><img src= \"images/tatamotorhead.JPG \" height= \"40 \" width= \"159 \" /></div>
				<div style=\"float:left; text-align:center; width:70%; padding-top:5px;\">
					<div style= \"font-weight: bold; font-family:Verdana; font-size:large;  text-shadow:0 -1px 2px #036, #9cf 0 1px 2px\" >
						Workshop Portal  <span style= \"font-weight: bold; font-family:Verdana; font-size:9px;\" >(v 1.0)</span>
					</div>
					<div style= \"font-family:Verdana; font-size:XX-Small; color:#FFFFCC; text-shadow:0 -1px 2px #036, #9cf 0 1px 2px\" >
						Integrated Workshop Management System for Tata Motors </div>
					</div>
					<div style=\"float:left; padding:5px;width:12%\"><img src= \"images/tatahead.JPG \" height= \"40 \" width= \"122 \" /></div>
				</div>
   				<div style=\"clear:both\"></div>";
				if(isset($_SESSION["Pno"]))
				{
					
					$head.="<div id=\"topmenu\">
								<div style=\"float:left\"><a href=\"home.php\" class=\"kks-linkbutton\" data-options=\"iconCls:'icon-home', plain:true\"><b>Welcome : </b>".$_SESSION["user_name"]."</a></div>
								<div style=\"float:left; padding-left:3%; margin-top:2px; width:70%\"><table width=100%>
								<tr>
								<td><b>Department : </b>".$_SESSION["Dept"]."</td>
								
								<td><b>Location : </b>".$_SESSION["LocnName"]."</td>
								<td><b>Organisation : </b>".$_SESSION["OrgName"]."</td>
								<td><b>Unit : </b>".$_SESSION["UnitName"]."</td>
								<tr></table></div>
								
								<div style=\"float:right\"><a id=\"btn-edit\" class=\"kks-menubutton\" data-options=\"menu:'#mm1',iconCls:'icon-user'\"></a></div>
								<div id=\"mm1\" style=\"width:150px;\">
										<div data-options=\"iconCls:'icon-profile'\"><a href=\"javascript:void(0);\" onclick=\"openUrl('http://".$_SERVER['SERVER_NAME'].":9090/workshopportal/admin/profile.php')\" style=\"text-decoration:none; color:black; \" >Profile</a></div>
										<div data-options=\"iconCls:'icon-exit'\"><a href=\"logout.php\" style=\"text-decoration:none; color:black; \" >Logout</a></div>
									</div>	
							</div>";
				}				   
			$head.="</div>";
			//<td><b>Designation : </b>".$_SESSION["Desg"]."</td>
			echo $head;
?>
