<?php
	$ref='on';
	include 'wsr_class.php'; 
        
	if(isset($_REQUEST['act']))
	{
            
		if($_REQUEST['act']=="Delete")
		{
				$sql="Delete FROM t_wsr_inc_details WHERE tid_inc_id='".$_REQUEST['trans_id']."' ";
				$obj=new db_connect;
				$obj->db_insert($sql);
				$obj->free();
		}
		else
		{
                                
                                $sql=" SELECT tid_inc_id, tid_file_name, tid_file_path,TID_SLNO FROM t_wsr_inc_details WHERE tid_crt_by='".$_SESSION['Pno']."' AND tid_act_flg='TempSave' AND TID_CAT_TYPE = 'File' ";
				$obj=new db_connect;
				$obj->db_query($sql);
				$result=""; 
				while($row=$obj->db_fetch_array()) 
				{
			  		$result.='<div style="float:left"><a href="'.$row[2].'" style="color:black" target="_blank"><u>'.$row[1].'</u></a>&nbsp;<a id="DelFile" href="#"  attr="'.$row[0].'" slno="'.$row[3].'" style="color:red">X</a> &nbsp; </div>'; 
			  	}
                                
				$obj->free();
				echo $result;
		}
	}
	else
	{
            
			 $UploadDirectory		= '../uploads/';
			 $RandNumber   		= rand(0, 9999999999);		
			 $FileName			= strtolower($_FILES['mFile']['name']); //uploaded file name
			 $ImageExt			= substr($FileName, strrpos($FileName, '.')); //file extension
			 $FileType			= $_FILES['mFile']['type']; //file type
			 $FileSize				= $_FILES['mFile']["size"]; //file size
			 $RandNumber   		= rand(0, 9999999999); //Random number to make each filename unique.
			 $uploaded_date		= date("Y-m-d H:i:s");
	
			 $NewFileName = preg_replace(array('/\s/', '/\.[\.]+/', '/[^\w_\.\-]/'), array('_', '.', ''), strtolower('IIRDoc'));
			 $NewFileName = $NewFileName.'_'.$RandNumber.$ImageExt;
	

			if(move_uploaded_file($_FILES['mFile']["tmp_name"], $UploadDirectory . $NewFileName ))
		   	{
                                $slno = '1';
			   	$trans_id		=	date("YmdHis").$_SESSION['Pno'];
                                $slno = $wsr->gen_slNo('T_WSR_INC_DETAILS','tid_slno',1,'') ;
                                
				$url			=	'http://'.$_SERVER['SERVER_NAME'].'/workshopportal/uploads/'. $NewFileName;
				$sql		=	"INSERT INTO 
								t_wsr_inc_details 
								(tid_inc_id,tid_cat_type,tid_slno,tid_file_name, tid_file_path, tid_act_flg, tid_crt_by, tid_crt_ts, tid_upd_by, tid_upd_ts)
								values('".$trans_id."','File','".$slno."','".$FileName."', '".$url."' , 'TempSave' ,'".$_SESSION['Pno'] ."'	, SYSDATE,  '".$_SESSION['Pno'] ."', SYSDATE)";
				$obj			=	new db_connect;
				
				$obj->db_insert($sql);
				$obj->free();	
				
				echo "The file has been uploaded successfully";				
		   }
		   else
		   {
				echo "There was an error uploading the file, please try again!";
		   }
	
	}
?>
  
