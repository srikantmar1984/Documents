<?php 
echo 'start';
// Database Setup
$HOST="172.27.128.148"; 
$PORT="1521"; // Default is 1521
$USER_NAME="ercindent";
$PASSWORD="ercindent";
$SERVICE_NAME="plmjd"; 

define("ORCL_HOST",$HOST);
define("ORCL_USER_NAME",$USER_NAME);
define("ORCL_PASSWORD",$PASSWORD);
define("ORCL_SERVICE_NAME",$SERVICE_NAME);

echo '2';
$sis = "(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=".ORCL_HOST.")(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=".ORCL_SERVICE_NAME.")))";
echo '3';
$conn=ocilogon('ercindent','ercindent',$sis) or die ("Problem while connecting to server...");

echo '5';//exit;

	//$conn=oci_connect('ercindent','ercindent','172.27.128.148');
	If (!$conn)
		echo 'Failed to connect to Oracle';
	else 
		echo 'Succesfully connected with Oracle DB :-)';
?>
