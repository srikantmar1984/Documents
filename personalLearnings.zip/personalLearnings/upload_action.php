<?php
	$ref='on';
	include("../db_classes/commanvar.php");
       include("../db_classes/class.db.php");
  	date_default_timezone_set("Asia/Calcutta");
	if(isset($_REQUEST['act']))
	{
		if($_REQUEST['act']=="Delete")
		{
				$sql="Delete FROM T_CSM_REG_DOC WHERE TRD_REG_NO='".$_REQUEST['trans_id']."' ";
				$obj=new db_connect;
				$obj->db_insert($sql);
				$obj->free();
		}
		else
		{
				$sql="SELECT TRD_REG_NO, TRD_FILE_NAME, TRD_FILE_PATH FROM T_CSM_REG_DOC WHERE TRD_CRT_BY='".$_SESSION['Pno']."' AND TRD_STATUS='TempSave' ";
				$obj=new db_connect;
				$obj->db_query($sql);
				$result=""; 
				while($row=$obj->db_fetch_array()) 
				{
			  		$result.='<div style="float:left"><a href="'.$row[2].'" style="color:black"><u>'.$row[1].'</u></a>&nbsp;<a id="DelFile" href="#"  attr="'.$row[0].'" style="color:red">X</a> &nbsp; </div>'; 
			  	}
				$obj->free();
				echo $result;
		}
	}
	else
	{

			$UploadDirectory	= '../uploads/scandocument/';
			$RandNumber   		= rand(0, 9999999999);
		
			$FileName			= strtolower($_FILES['mFile']['name']); //uploaded file name
			$ImageExt			= substr($FileName, strrpos($FileName, '.')); //file extension
			$FileType			= $_FILES['mFile']['type']; //file type
			$FileSize			= $_FILES['mFile']["size"]; //file size
			$RandNumber   		= rand(0, 9999999999); //Random number to make each filename unique.
			$uploaded_date		= date("Y-m-d H:i:s");
	
			$NewFileName = preg_replace(array('/\s/', '/\.[\.]+/', '/[^\w_\.\-]/'), array('_', '.', ''), strtolower('PQDoc'));
			$NewFileName = $NewFileName.'_'.$RandNumber.$ImageExt;
	

			if(move_uploaded_file($_FILES['mFile']["tmp_name"], $UploadDirectory . $NewFileName ))
		   	{
			   	$trans_id=date("ymdHi").$_SESSION['Pno'];
			
				$url='http://'.$_SERVER['SERVER_NAME'].'/tmlsafety/uploads/scandocument/'. $NewFileName;
				$sql="insert into T_CSM_REG_DOC(TRD_REG_NO, TRD_FILE_NAME, TRD_FILE_PATH, TRD_STATUS, TRD_CRT_BY, TRD_CRT_TS, TRD_UPD_BY, TRD_UPD_TS)
				values('".$trans_id."', '".$FileName."', '".$url."' , 'TempSave' ,'".$_SESSION['Pno'] ."'	, SYSDATE,  '".$_SESSION['Pno'] ."', SYSDATE)";
				$obj=new db_connect;
				$obj->db_insert($sql);
				$obj->free();
				
				//echo '<tr><td><a href="'.$url.'" target="_blank">'.$FileName.'</a></td><td><a id="btnDelFile" attr="'.$trans_id.'" href="#"><img src="images/delete.png"/></a></td></tr>';
				echo "The file has been uploaded successfully";
				
		   }
		   else
		   {
				echo "There was an error uploading the file, please try again!";
		   }
	
	}
  

?>