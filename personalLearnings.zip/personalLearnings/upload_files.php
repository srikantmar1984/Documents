<html>
<head>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script>
var $j = jQuery.noConflict();
$j(document).ready(function()
{
    $j('#FileUploader').on('submit', function(e)
    {
        e.preventDefault();
        $j('#uploadButton').attr('disabled', ''); // disable upload button
        //show uploading message
        $j("#output").html('<div style="padding:10px"><img src="images/spinner3.gif" alt="Please Wait"/> <span>Uploading...</span></div>');
        $j(this).ajaxSubmit({
        target: '#output',
        success:  afterSuccess //call function after success
        });
    });
});
 
function afterSuccess()
{
    $j('#FileUploader').resetForm();  // reset form
    $j('#uploadButton').removeAttr('disabled'); //enable submit button
}
</script>
</head>
<body>
<div id="theForm">
<div id="output"></div>
<form action="./uploader.php" id="FileUploader" enctype="multipart/form-data" method="post" >

  <div style="position:relative; float:right; margin-top:-15px; margin-right:-10px;"><a id="btnClose" href="#" ><img src="images/winclose.png" width="20" height="20" title="Close" /></a></div>
 <input type="hidden" name="hfTrans_id" id="hfTrans_id" value="<?php echo $_REQUEST['trans_id'] ?>" />
  <input type="hidden" name="hfid" id="hfid" value="<?php echo $_POST['id']; ?>" />
    <input type="text" name="mName" id="mName" value="<?php echo $_REQUEST['id']; ?>"  style="display:none" />
    <table width="100%">
    	<tr>
        	<td>File </td><td><input type="file" name="mFile" id="mFile" /></td>
        </tr>
       
    </table>
    
    
    <button type="submit" class="blue-button" id="uploadButton">Upload</button>
    <div class="spacer"></div>
</form>
</div>
</body>
</html>