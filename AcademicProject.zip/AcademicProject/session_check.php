<?php

if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION['userSessionInfo']['TUS_UID'])) {
    header("Location: index.php");
}
?>