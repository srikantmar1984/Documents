$(document).ready(function () {

    $(document).ajaxStart(function () {
        showProgress();
    });
    $(document).ajaxStop(function () {
        hideProgress();
    });
    $(document).ajaxError(function () {
        alert('Warring..... Error Occured !');
        hideProgress();
    });
    $(document).ajaxSuccess(function (event, request, settings) {
        if (request.responseText.indexOf("<b>Notice</b>:  Undefined index:") > 0)
        {
            alert('Warring...! Session Expired. Redirecting to Login Page.');
//                console.log(request.responseText);
//		window.location.href='../ercportal/index.php';			
//		event.abort();
            //if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) // enable to call only for chrome..
            //{
            //	event.abort();
            //}
        }
    });
    $(document).ajaxComplete(function () {
        hideProgress();
    });

    $('input[name="submit"]').click(function (e)
    {

        var $formId = $(this).parents('form');
        var formAction = $formId.attr('action');

        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

        $('.required', $formId).each(function () {
            var inputVal = $(this).val();
            var $parentTag = $(this).parent();
            if (inputVal == '')
            {
                //$parentTag.addClass('error');
                $(this).addClass('error');
            }
            else
            {
                //$parentTag.removeClass('error');
                $(this).removeClass('error');
            }

        });

        $('.numeric', $formId).each(function () {
            var inputVal = $(this).val();
            var numericReg = /^\d*[0-9](|.\d*[0-9]|,\d*[0-9])?$/;
            var $parentTag = $(this).parent();
            if (!numericReg.test(inputVal))
            {
                if (inputVal != '')
                    $(this).addClass('error');
                else
                    $(this).removeClass('error');
            }
            else
            {
                $(this).removeClass('error');
            }
        });

        $('.character', $formId).each(function () {
            var inputVal = $(this).val();
            var characterReg = /^\s*[a-zA-Z0-9,\s]+\s*$/;
            if (!characterReg.test(inputVal))
            {
                if (inputVal != '')
                    $(this).addClass('error');
            }
            else
            {
                $(this).removeClass('error');
            }
        });

        $('.limit-8').each(function () {
            var inputVal = $(this).val();
            var characterReg = /^([a-zA-Z0-9]{0,8})$/;
            if (!characterReg.test(inputVal)) {
                if (inputVal != '')
                    $(this).addClass('error');
            }
            else
            {
                $(this).removeClass('error');
            }
        });
        //01/31/2013
        $('.date').each(function () {
            var inputVal = $(this).val();
            var dateReg = /^[0,1]?\d{1}\/(([0-2]?\d{1})|([3][0,1]{1}))\/(([1]{1}[9]{1}[9]{1}\d{1})|([2-9]{1}\d{3}))$/;
            if (!dateReg.test(inputVal)) {
                if (inputVal != '')
                    $(this).addClass('error');
            }
            else
            {
                $(this).removeClass('error');
            }
        });

        $('.email').each(function () {
            var inputVal = $(this).val();
            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            if (!emailReg.test(inputVal)) {
                if (inputVal != '')
                    $(this).addClass('error');
            }
            else
            {
                $(this).removeClass('error');
            }
        });

        e.preventDefault();
    });

});

function setTextParam(txtData, intHeight)
{
    txtData.style.height = intHeight + "px";
}
function setTextHeight(txtData, intHeight)
{
    txtData.style.height = intHeight + "px";
}

function setTextWidth(txtData, intWidth)
{
    txtData.style.Width = intWidth + "px";
}


function OnlyNumeric(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if ((charCode >= 48 && charCode <= 57) || (charCode >= 37 && charCode <= 40) || charCode == 36 || charCode == 8) {
        return true;
    }
    else {
        return false;
    }
}

function OnlyNumericPaste() {

    // List of valid numbers

    var strDigits = "0123456789";

    // Get  the copied text

    var txtCopiedData = window.clipboardData.getData('Text');

    // Validate data for Numeric characters

    for (var intCtr = 0; intCtr < txtCopiedData.length; intCtr++)
    {
        if (strDigits.indexOf(txtCopiedData.substring(intCtr, intCtr + 1)) == -1)
        {
            alert("Caution...! Please enter/paste a valid number.");
            return false;
        }
    }


}

function validate()
{
    $('.required').each(function () {
        var inputVal = $(this).val();
        var $parentTag = $(this).parent();
        if (inputVal == '')
        {
            //$parentTag.addClass('error');
            $(this).addClass('error');
            alert('Please fill all * mark field or red border mark field');
            exit();
        }
        else
        {
            //$parentTag.removeClass('error');
            $(this).removeClass('error');
        }

    });
    $('.numeric').each(function () {
        var inputVal = $(this).val();
        var numericReg = /^\d*[0-9](|.\d*[0-9]|,\d*[0-9])?$/;
        var $parentTag = $(this).parent();
        if (!numericReg.test(inputVal))
        {
            if (inputVal != '')
            {
                $(this).addClass('error');
                alert('Please enter numeric value');
            }
            else
            {
                $(this).removeClass('error');
            }
            exit();
        }
        else
        {
            $(this).removeClass('error');
        }
    });

}
var spinnerVisible = false;
function showProgress() {
    if (!spinnerVisible) {
        $("div#spinner").fadeIn("fast");
        spinnerVisible = true;

    }
}
;
function hideProgress() {
    if (spinnerVisible) {
        var spinner = $("div#spinner");
        spinner.stop();
        spinner.fadeOut("fast");
        spinnerVisible = false;
    }
}
;
function myformatter(date)
{
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    var d = date.getDate();
    return (d < 10 ? ('0' + d) : d) + '-' + (m < 10 ? ('0' + m) : m) + '-' + y;
}
function ddMonyyyy(date)
{
    var monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"];
    var shortMonth = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var y = date.getFullYear();
    var m = date.getMonth();
    var d = date.getDate();

    return (d < 10 ? ('0' + d) : d) + '-' + shortMonth[m] + '-' + y;
}
function HideData(table)
{

    $("#" + table + " tr:last").remove();
    $('#' + table + ' tr').find('th:last, td:last').remove();

}
function highlightRow(table)
{
    $("#" + table + " tr:last").css({backgroundColor: "#F7F6F3", fontWeight: "bolder"});
}

function valid(f)
{
    !(/^[A-z&#209;&#241;0-9]&@-*$/i).test(f.value) ? f.value = f.value.replace(/[^A-z&#209;&#241;0-9&@-]/ig, '') : null;
}

$('input[class~="numeric"]').die('keydown').live('keydown', function (e) {
    // Allow: backspace, delete, tab, escape, enter and .
    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            // Allow: Ctrl+A
                    (e.keyCode == 65 && e.ctrlKey === true) ||
                    // Allow: home, end, left, right
                            (e.keyCode >= 35 && e.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
            }
            // Ensure that it is a number and stop the keypress
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                e.preventDefault();
            }
        });
$('input[class~="numeric"]').die('blur').live('blur', function (e) {
    if ($(this).val().trim() == "")
    {
        var attr = $(this).attr('data-def');

        // For some browsers, `attr` is undefined; for others,
        // `attr` is false.  Check for both.
        if (typeof attr !== typeof undefined && attr !== false) {
            $(this).val(attr);
        }
    }
});