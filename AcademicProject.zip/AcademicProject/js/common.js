/* 
 * @@@@@ Common Script file which can be access all pages in the project.
 * ##### Mainly global functions are declared here to reuse the code.
 */
function toggleExpand(objthis) {
    if ($(objthis).hasClass("toggleExpand")) {
        $(objthis).removeClass("toggleExpand");
        $(objthis).addClass("toggleCollapse");
        var src = $(objthis).find("img").attr("src");
        src = src.replace("collapse", "expand");
        $(objthis).find("img").attr("src", src);
        $('div[class~="filterrow"]').slideToggle("fast");
    } else {
        $(objthis).removeClass("toggleCollapse");
        $(objthis).addClass("toggleExpand");
        var src = $(objthis).find("img").attr("src");
        src = src.replace("expand", "collapse");
        $(objthis).find("img").attr("src", src);
        $('div[class~="filterrow"]').slideToggle("fast");
    }
}

function addmoreRow(thisTr, trClass) {
    var trCnt = parseInt($("#" + trClass).closest('tbody').children('tr').length) + 1;
    $(thisTr).closest('tr').find(".removeRr").show();
    var cloneTr = $("#" + trClass).clone();
    
//    console.log(cloneTr.find(".checkpdiInpt").attr('name'));
    var nameAtr = cloneTr.find(".checkpdiInpt").attr('name');
    var intPart = cloneTr.find('td:first-child').text().split('.')[0];
    if(nameAtr)
    cloneTr.find(".checkpdiInpt").attr('name',nameAtr+intPart+ trCnt);
    cloneTr.find('td:first-child').text(intPart + '.' + trCnt);
    $("#" + trClass).closest('tbody').append(cloneTr);
//    $("#" + trClass).closest('tbody').after(cloneTr);
}

function removeRow(thisTr, trClass) {
    var trCnt = $("#" + trClass).closest('tbody').children('tr').length;
    $("#" + trClass).closest('tbody').find('tr:last').remove();
    if (trCnt <= 2) {
        $(thisTr).closest('tr').find(".removeRr").hide();
    }
}

function uploadFile(thisVar, checkID) { 
    $("table tr").removeClass('uploadTrCrnt');
    $(thisVar).closest('tr').addClass('uploadTrCrnt');
    var chassisNo = $("#ddlChassis").val();
    $('#dd').dialog({
        title: 'Upload Image',
        width: 600,
        closed: false,
        cache: false,
        data: {chassisNo: chassisNo},
        href: wwwRoot + "process/upload_photo.php?checkID=" + checkID + "&chassisNo=" + chassisNo,
        modal: true
    });
}

$("#btnDeactFile").die('click').live('click', function () {
    $(this).closest('tr').remove();
});
/*
 * Common function for Numeric only
 */
function numericOnly(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}