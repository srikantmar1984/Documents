<script>
function tabGenerate() {
        //ajax call for PDI list
        var menuid = $("#urlMenuID").val();
        $.post(url, {action: "VHODETAILS", chassisNo: $("#ddlChassis").val(), menuid: menuid}, function () {
        }, 'JSON').done(function (data) {
//                    console.log(data);
            var resTable = '';
            $.each(data.CHECKDTLS, function (indexTab, tabDetails) {
                console.log(indexTab);
                var resTable = '<table style="background-color: #EFF3FB;">';
//                        resTable += "<thead><tr><th style='width:2%'>SL.NO.</th><th>Parameters</th><th>Checked on Vehicle</th><th>OK or NOT OK</th><th>Remarks</th></tr></thead>";
                var parntInc = 0;
                $.each(tabDetails, function (indexPrnt, parentDetails) {
                    if ($.type(parentDetails) == 'object') {
                        parntInc++;
                        var childInc = 0;
                        //Thead
                        if (parentDetails.TCH_INCRIMENTAL) {
                            resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='2'>" + parentDetails.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                            resTable += "<tbody><tr class='trid" + parentDetails.TCH_CHK_ID + "' id='addmoreTr" + parentDetails.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                            if (parentDetails.TCH_DATA_TYPE == 'file') {
                                resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + parentDetails.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                txtRemark = '';
                            } else {
                                        resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt vehicleParam" ></td>';
                                        txtRemark = '<textarea id="remarkBox_' + parentDetails.TCH_CHK_ID + '" maxlength="1900" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                            }
                            resTable += '<td>' + txtRemark + '</td>';
                            resTable += "</tr></tbody>";
                        } else {
                            resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                        }
                        //Tbody
                        $.each(parentDetails, function (index, childArr) {
                            childInc++;
                            if ($.type(childArr) == 'object') {
                                        txtRemark = '<textarea id="remarkBox_' + childArr.TCH_CHK_ID + '" maxlength="1900" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                resTable += "<tbody><tr id='trid" + childArr.TCH_CHK_ID + "' class='trid" + childArr.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";

                                if (childArr.TCH_DATA_TYPE == 'text') {
                                    resTable += '<td><input type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt" ></td>';
                                } else if (childArr.TCH_DATA_TYPE == 'radio') {
                                    $setValArr = childArr.TCH_VALUE_SET.split("##");
                                    resTable += '<td>';
                                    $setValArr.forEach(function ($value, $key) {
                                        $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                            resTable += '<label for="checkPDI' + ($key + 1) + childArr.TCH_CHK_ID + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + childArr.TCH_CHK_ID + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                    });
                                    resTable += '</td>';
                                } else if (childArr.TCH_DATA_TYPE == 'file') {
                                    resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + childArr.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                    txtRemark = '';
                                }
                                resTable += '<td>' + txtRemark + '</td>';
                                resTable += "</tr></tbody>";
                            }
                        })
                    }
                })
                resTable += "</table>";
//                        console.log(resTable);
                $('#tabMenuVHO').tabs('add', {
                    title: indexTab,
                    content: resTable,
                    closable: false
                });

            })

//            if (!$.isEmptyObject(data.FILLDATA)) {
//                $.each(data.FILLDATA, function (chkKey, chkVal) {
//                    $('input[type="text"][name="checkPDI_' + chkVal.TCD_CHK_ID + '"]').val(chkVal.TCD_VALUE);
//                    $('input[name="checkPDI_' + chkVal.TCD_CHK_ID + '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
//                    $("#remarkBox_" + chkVal.TCD_CHK_ID).val(chkVal.TCD_REMARKS);
//                })
//            }
            //if (typeof chkVal[0] != 'undefined') {
            if (!$.isEmptyObject(data.FILLDATA)) {
                        $.each(data.FILLDATA, function (chkKey, chkVal) {
                            if (typeof chkVal[0] != 'undefined') {
                                var checkIdCrnt = chkVal[0].TJD_CHK_ID;
                            if (chkVal.length > 1) {
                                for (i = 0; i < chkVal.length; i++) {
                                    i > 0 ? addmoreRow("#addmoreTr" + chkKey, "addmoreTr" + chkKey) : '';
                                }
                                for (i = 0; i < chkVal.length; i++) {
                                    var vehParms = chkVal[i].TJD_VEH_PARAM.split('###');
                                    console.log(vehParms);
                                    $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('.addMoreParam').val(vehParms[0]);
                                    $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('.vehicleParam').val(vehParms[1]);
                                    $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('input[checklist_id="' + chkKey + '"][value="' + chkVal[i].TJD_VALUE + '"]').prop('checked', true);
                                    $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find("#remarkBox_" + chkKey).val(chkVal[i].TJD_REMARKS);
                                }
                            } else {
                                if (chkVal[0].TJD_VEH_PARAM) {
                                    var vehParms = chkVal[0].TJD_VEH_PARAM.split('###');
                                    $(".trid" + chkKey).find('.addMoreParam').val(vehParms[0]);
                                    $(".trid" + chkKey).find('.vehicleParam').val(vehParms[1]);
                                }
                                $('input[name="checkPDI_' + chkKey + '"][value="' + chkVal[0].TJD_VALUE + '"]').prop('checked', true);
                                $("#remarkBox_" + chkKey).val(chkVal[0].TJD_REMARKS);
                            }
                            //Image file Loading
                            $.each(chkVal[0], function (keyFile, childFile) {
                                if ($.type(childFile) == 'object') {
                                    var imgTr = '<tr class="addMorePhotoTr" style="background-color:#FFFFFF"><td></td>';
                                    imgTr += '<td><img style="height:119Px;width:200Px;" src="' + wwwRoot + childFile.TFD_FILE_PATH + '"></td>';
                                    imgTr += '<td><input type="hidden" style="width:80%" value="' + childFile.TFD_FILE_TITLE + '" checklist_id="' + checkIdCrnt + '" class="photoName"><textarea maxlength="1900" rows="2" class="photoDesc" style="word-wrap: break-word;width:95%" placeholder="Photo Description">' + childFile.TFD_FILE_DESC + '</textarea></td>';
                                    imgTr += '<td colspan="2"><a href="javascript:void(0);" class="statusChange" id="btnDeactFile">Delete Image</a></td>';
                                    imgTr += '</tr>';
                                    $(".trid" + checkIdCrnt).after(imgTr);
                                }
                            })
                            }else{
                                $('input[type="text"][name="checkPDI_' + chkVal.TCD_CHK_ID + '"]').val(chkVal.TCD_VALUE);
                    $('input[name="checkPDI_' + chkVal.TCD_CHK_ID + '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
                    $("#remarkBox_" + chkVal.TCD_CHK_ID).val(chkVal.TCD_REMARKS);
                            }
                        })
                    }
            $("#tabMenuVHO").tabs('select', 0);
            $('#tabMenuVHO').find('input, textarea, button, select').attr('disabled', 'disabled');
        })
        $("#checklistFormBtn").show();
    }
</script>