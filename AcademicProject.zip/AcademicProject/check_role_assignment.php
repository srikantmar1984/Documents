<?php
		$ref='on';
 		include("db_classes/commanvar.php");
		include("db_classes/class.db.php");	
	 	date_default_timezone_set("Asia/Calcutta");
	
	

			//if ($_SESSION['Org'] == $_REQUEST['org'] && $_SESSION['Unit'] == $_REQUEST['vunit'] && $_SESSION['Locn'] == $_REQUEST['locn'])
           // {

 				$strSql = "SELECT ";
                $strSql .= "   NVL(MAX(t2.tra_acc_level) ,0) MaxAccessLevel ";
                $strSql .= " FROM ";
                $strSql .= "   t_sos_roles t1 ";
                $strSql .= " , t_sos_role_assign t2 ";
                $strSql .= " , t_sos_users_roles t3 ";
                $strSql .= " , t_sos_users_apps t4 ";
                $strSql .= " WHERE ";
                $strSql .= "   t1.tro_app_id = t4.tua_app_id ";
                $strSql .= " AND t1.tro_role_id = t2.tra_role_id ";
                $strSql .= " AND t1.tro_role_id = t3.tur_role_id ";
                $strSql .= " AND t4.tua_pno = t3.tur_pno ";
                $strSql .= " AND t1.tro_act_flg = 'Active' ";
                $strSql .= " AND t3.tur_act_flg = 'Active' ";
                $strSql .= " AND t4.tua_act_flg = 'Active' ";
                $strSql .= " AND t2.tra_scr_id = '" . $_REQUEST['screen_id'] . "' ";
                $strSql .= " AND t4.tua_pno = '" . $_SESSION['Pno'] . "' ";
                $strSql .= " AND t2.tra_org_id = '" . $_SESSION['Org'] . "' ";
                $strSql .= " AND t2.tra_unit_id = '" . $_SESSION['Unit'] . "' ";
                $strSql .= " AND t2.tra_locn_id = '" . $_SESSION['Locn'] . "' ";

           // }
           /* else
            {
				$strSql = "SELECT ";
                $strSql .= "   NVL(MAX(t2.tra_acc_level) ,0) MaxAccessLevel ";
                $strSql .= " FROM ";
                $strSql .= "   t_sos_roles t1 ";
                $strSql .= " , t_sos_role_assign_oth t2 ";
                $strSql .= " , t_sos_users_roles t3 ";
                $strSql .= " , t_sos_users_apps t4 ";
                $strSql .= " WHERE ";
                $strSql .= "   t1.tro_app_id = t4.tua_app_id ";
                $strSql .= " AND t1.tro_role_id = t2.tra_role_id ";
                $strSql .= " AND t1.tro_role_id = t3.tur_role_id ";
                $strSql .= " AND t4.tua_pno = t3.tur_pno ";
                $strSql .= " AND t1.tro_act_flg = 'Active' ";
                $strSql .= " AND t3.tur_act_flg = 'Active' ";
                $strSql .= " AND t4.tua_act_flg = 'Active' ";
                $strSql .= " AND t2.tra_scr_id = '" . $_REQUEST['screen_id']  . "' ";
                $strSql .= " AND t4.tua_pno = '" . $_SESSION['Pno'] . "' ";
                $strSql .= " AND t2.tra_org_id = '" . $_SESSION['Org'] . "' ";
                $strSql .= " AND t2.tra_unit_id = '" . $_SESSION['Unit'] . "' ";
                $strSql .= " AND t2.tra_locn_id = '" . $_SESSION['Locn'] . "' ";
                $strSql .= " AND t2.tra_oth_org_id = '" .$_REQUEST['org']. "' ";
                $strSql .= " AND t2.tra_oth_unit_id = '" .$_REQUEST['vunit']. "' ";
                $strSql .= " AND t2.tra_oth_locn_id = '" .$_REQUEST['locn']. "' ";

            }*/
				$obj=new db_connect;
				$obj->db_query($strSql);
				$intRetval = 0;
				while($row=$obj->db_fetch_array())
				{
					$intRetval =$row[0];
				
				}
				$obj->free();
				
				echo $intRetval;



?>