<?php //var_dump(class_exists("SOAPClient")); ?>
<?php


function doWebService()
{
       ########################################################################
       # Do some SOAP / Call a Web Service
       $client = new SoapClient("http://172.27.128.81/ercportal/usersdetail.asmx?WSDL");
       $strUser = $client->GetAllUser(array('Loc' => '1','TNo' => '91699'));

	    if (is_null($strUser->GetAllUserResult))
		{
		   echo "no result";
		}
		else
		{
			// var_dump($strUser->GetAllUserResult);
		  echo json_encode($strUser->GetAllUserResult);
		}
	   

}
function WebService_GetAllUsers()
{
       $client = new SoapClient("http://172.27.128.81/ercportal/usersdetail.asmx?WSDL");
       $strUser = $client->GetAllUsers(array('Locn' => $_REQUEST['Locn'],'Pno' => $_REQUEST['Pno'],'UserName' => $_REQUEST['UserName'],'Status' => $_REQUEST['Status'],'Dept' => $_REQUEST['Dept'],'Email' => $_REQUEST['Email'],'Desig' => $_REQUEST['Desig'],'domain' => $_REQUEST['domain'],'ExtNo' => $_REQUEST['ExtNo'],'Mobile' => $_REQUEST['Mobile'],'CreatedFrom' => $_REQUEST['CreatedFrom'],'CreatedTo' => $_REQUEST['CreatedTo'],'Org' => $_REQUEST['Org'],'Unit' => $_REQUEST['Unit'],'Role' => $_REQUEST['Role'],'App'=>$_REQUEST['App']));

	    if(is_null($strUser->GetAllUsersResult))
		{
		   echo "no result";
		}
		else
		{
		  echo json_encode($strUser->GetAllUsersResult);
		}
	   

}
if(isset($_REQUEST['getUser']) && $_REQUEST['getUser']=='All')
{
	WebService_GetAllUsers();
}
else
{
	doWebService();
}



?>