<?php

$ref = 'on';
include("db_classes/commanvar.php");
include("db_classes/class.db.php");

function checkLogin($userName = NULL, $passWord = NULL) {
    //LDAP CHECK
    $ldapRes = valideUserInLDAP($userName, $passWord);//print($ldapRes);
    $sql = "SELECT t1.*,t2.TED_NAME DEPTNAME,t3.TEP_NAME PLANTNAME FROM  T_VHS_USERS t1,
            T_VHS_DEPARTMENTS t2,
            T_ERC_PLANT t3 ";
    //DB Check
    if ($ldapRes) {
        $sql .= "where t1.TUS_PNO='" . $ldapRes['employeeid'] . "'";
    } else {
        $sql .= "where t1.TUS_PNO='" . $userName . "' AND t1.TUS_PASS='" . md5($passWord) . "' ";
    }
    $sql .= "AND t1.TUS_DEPT_ID = t2.TED_ID AND t1.tus_act_flg = 1 ";
    $sql .= "AND t1.TUS_PLNT = t3.TEP_ID AND t3.TEP_ACT_FLG = 1 ";

    $obj = new db_connect;
    $obj->db_query($sql);
    $record = $obj->db_fetch_assoc();
    $obj->db_query("SELECT t1.TRU_ROLE_ID,T2.TER_NAME FROM T_ERC_ROLE_USER t1,T_VHS_ROLES t2 WHERE T1.TRU_ACT_FLG = 1 AND T2.TER_ACT_FLG = 1 AND t1.TRU_USER_ID =" . $record[0]['TUS_UID'] . " AND T2.TER_ID =T1.TRU_ROLE_ID");
    while ($row = $obj->db_fetch_arrayAssoc()) {
        $record[0]['ROLES'][$row['TRU_ROLE_ID']] = $row['TER_NAME'];
    }
    $obj->free();
    return $record;
}

function valideUserInLDAP($user = NULL, $password = NULL) {
    $ldap_hostDomain = array("tmsndinf01.tmindia.tatamotors.com" => "@tmindia.tatamotors.com", "tmsndinf02.tmindia.tatamotors.com" => "@tmindia.tatamotors.com", "tmsndinf03.tmindia.tatamotors.com" => "@tmindia.tatamotors.com",  "PMPAD01.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com", "PMPAD02.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com", "PMPAD04.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com", "HNJAD01.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com", "ttpneinf02.ttglobal.tatatechnologies.com" => "@ttglobal.tatatechnologies.com", "ttpnerca01.ttglobal.tatatechnologies.com" => "@ttglobal.tatatechnologies.com");

//"PMPAD03.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
    $ldap_dns = array("@tmindia.tatamotors.com" => "DC=tmindia,DC=tatamotors,DC=com", "@ttglobal.tatatechnologies.com" => "DC=ttglobal,DC=tatatechnologies,DC=com", "@MYTTL.tatatechnologies.com" => "DC=MYTTL,DC=tatatechnologies,DC=com");

    $result = array();
    $attr = array("extensionattribute1", "samaccountname", "mail", "givenname", "sn", "physicaldeliveryofficename");
    foreach ($ldap_hostDomain as $key => $value) {
        $ldapConn = ldap_connect($key);
        if ($ldapConn) {
            //-----------Added to make PHP 5.3 compatible with ldap---------//
            ldap_set_option($ldapConn, LDAP_OPT_REFERRALS, 0);
            ldap_set_option($ldapConn, LDAP_OPT_PROTOCOL_VERSION, 3);
            //-------------------------------------------------------------//
            if ($bind = @ldap_bind($ldapConn, $user . $value, $password)) {
                $filter = "(name=" . $user . ")";
                $ldapResult = ldap_search($ldapConn, $ldap_dns[$value], $filter, $attr) or exit("Unable to search LDAP server");
                $entries = ldap_get_entries($ldapConn, $ldapResult) or exit("Unable to find entries LDAP server");
//                    print_r($entries);
                if ($entries['count']) {
                    $result = array(
                        "uname" => $entries[0]['givenname'][0] . ' ' . $entries[0]['sn'][0],
                        "employeeid" => $entries[0]['extensionattribute1'][0],
                        "samaccountname" => $entries[0]['samaccountname'][0],
                        "mail" => $entries[0]['mail'][0],
                        "givenname" => $entries[0]['givenname'][0],
                        "sn" => $entries[0]['sn'][0],
                        "location" => substr($entries[0]['physicaldeliveryofficename'][0], 4)
                    );
                }
                ldap_unbind($ldapConn);
                break;
            }
        } else {
            ldap_unbind($ldapConn);
        }
    }
    return $result;
}

if ($_POST['actType'] == "authenticate") {
    parse_str($_REQUEST['loginInfo'], $data);
    $res = checkLogin($data['username'], $data['password']);
    $returnResult = array();
    if (count($res)) {
        unset($res[0]['TUS_PASS']);
        $_SESSION['userSessionInfo'] = $res[0];
        echo '1';
    } else {
        echo '0';
    }
}
?>
