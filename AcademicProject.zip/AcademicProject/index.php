<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">  <!--disable compatible button-->
        <title>ERC Portal</title>
        <link rel="shortcut icon" href="images/erc_favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/common.css">
        <link rel="stylesheet" type="text/css" href="css/common.css">
        <link rel="stylesheet" type="text/css" href="css/Login/style.css" />
        <link rel="stylesheet" type="text/css" href="css/graphics/graphics.css">
        <link rel="stylesheet" type="text/css" href="css/icon.css">
        <script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
        <script type="text/javascript" src="js/graphics.js"></script>
        <script src="js/jquery.json-2.4.min.js"></script>
        <script src="js/validations.js"></script>
        <script  src="js/jquery-sortable.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('#btnSubmit').click(function () {

                    $.ajax({
                        type: "POST",
                        url: 'login_auth.php',
                        data: {loginInfo: $("#loginform").serialize(), actType: 'authenticate'},
                        success: function (data) {

                            var str = data.indexOf("Error");
                            if (str == '-1') {
                                if (data == '1') {
                                    window.location = 'home.php';
                                } else {
                                    alert('Invalid Credentials');
                                }
                            } else {
                                alert('Invalid Credentials');
                            }
                        }
                    });

                });

            });
        </script>

    </head>
    <body class="kks-layout">
        <div id="spinner">
            <span style="font-size:10px">Please Wait...</span>
        </div>
        <!--Header Start-->
        <?php include 'header.php'; ?>
        <!--Header End-->
        <!--main container-->
        <div data-options="region:'center',title:' '" id="content">
            <div style="padding:10%;">
                <section class="main">
                    <form id="loginform" class="form-2" method="post" action="">
                        <h1><span class="log-in">Log in</span></h1>
                        <p class="float">
                            <label for="login">Domain ID</label>
                            <input type="text"  name="username" placeholder="Domain ID">
                        </p>
                        <p class="float">
                            <label for="password">Password</label>
                            <input type="password" name="password" placeholder="Password" class="showpassword" >
                        </p>
                        <p class="clearfix"> 
                            <input id="btnSubmit" type="submit"  name="submit" value="Log in">
                        </p>
                    </form>
                </section>
            </div>       
        </div>
        <!--main container end-->
        <!--footer-->
        <?php include 'footer.php'; ?> 
        <!--footer end-->
    </body>
</html>