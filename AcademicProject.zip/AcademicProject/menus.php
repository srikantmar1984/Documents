<?php

$ref = 'on';
//	include("db_classes/commanvar.php");
include("db_classes/class.db.php");

if (!isset($_SESSION['userSessionInfo']['TUS_UID'])) {
    echo "<script>document.location.href='index.php'</script>";
}

function Accordion($userId, $plantId) {
    $sql = "SELECT 
                t1.tmt_name MenuName , t1.tmt_id MenuID , t1.tmt_slno 
           FROM 
                T_VHS_MENU_TABS t1 
              , ( 
                      ( 
                              SELECT DISTINCT 
                                        tmt_id 
                              FROM 
                                        T_VHS_MENU_TABS A1 
                                      , T_VHS_MENU_ACCESS A2 
                                      , t_erc_app_user A3 
                                      , t_erc_role_user A4 
                                      , T_VHS_APPLICATION A5 
                              WHERE 
                                        A1.tmt_id = A2.tma_menu_id 
                                      AND A2.tma_act_flg = 1 
                                      AND A1.tmt_application_id IS NOT NULL 
                                      AND A1.tmt_application_id = A3.tau_application_id 
                                      AND A3.TAU_ACT_FLG = 1
                                      AND A2.tma_role_id = A4.tru_role_id 
                                      AND A4.tru_act_flg = 1
                                      AND A3.tau_user_id = A4.tru_user_id 
                                      AND A4.tru_user_id = '$userId' 
                                      AND A2.tma_plant_id = '$plantId'
                                      AND A5.tea_id = A1.tmt_application_id 
                                      AND A5.tea_act_flg = 1
                      ) 
                      UNION 
                      ( 
                              SELECT DISTINCT 
                                        tmt_id 
                              FROM 
                                        T_VHS_MENU_TABS A1 
                                      , T_VHS_MENU_ACCESS A2 
                                      , t_erc_role_user A3 
                              WHERE 
                                        A1.tmt_id = A2.tma_menu_id 
                                      AND A2.tma_act_flg = 1 
                                      AND A1.tmt_application_id IS  NULL 
                                      AND A2.tma_role_id = A3.tru_role_id 
                                      AND A3.tru_act_flg = 1
                                      AND A3.tru_user_id = '$userId' 
                                      AND A2.tma_plant_id = '$plantId' 
                      ) 
                ) t2 
           WHERE 
                t1.tmt_id = t2.tmt_id 
               AND t1.tmt_parent_id IS NULL 
               AND t1.tmt_act_flg = 1
           ORDER BY 
                t1.tmt_slno ASC ";

    $obj = new db_connect;
    $obj->db_query($sql);

    $result = "<div class=\"kks-accordion\" data-options=\"border:false\">";
    while ($row = $obj->db_fetch_array()) {
        $result .= '<div class="t" title="' . $row[0] . '" style="padding:2px;" >';
        $result .= '<ul id="menuTree" class="kks-tree" data-options="animate:true,lines:true">';
        $result .= Menu($row[1], $userId, $plantId);
        $result .= '</ul>';
        $result .= "</div>";
    }
    $result .= "</div>";
    $obj->free();
    return $result;
}

function Menu($strMasterId, $userId, $plantId) {
    $sql = "SELECT 
                t1.tmt_name MenuName 
              , t1.tmt_id MenuID 
              , t1.TMT_PATH MenuPath 

              , t1.tmt_slno 
            FROM 
                T_VHS_MENU_TABS t1 
              , ( 
                      ( 
                              SELECT DISTINCT 
                                        tmt_id 
                              FROM                                                                  
                                      T_VHS_MENU_TABS A1 
                                      , T_VHS_MENU_ACCESS A2 
                                      , t_erc_app_user A3 
                                      , t_erc_role_user A4 
                                      , T_VHS_APPLICATION A5 
                              WHERE 
                                        A1.tmt_id = A2.tma_menu_id 
                                      AND A2.tma_act_flg = 1 
                                      AND A1.tmt_application_id IS NOT NULL 
                                      AND A1.tmt_application_id = A3.tau_application_id 
                                      AND A3.tau_act_flg = 1
                                      AND A2.tma_role_id = A4.tru_role_id 
                                      AND A4.tru_act_flg = 1
                                      AND A3.tau_user_id = A4.tru_user_id 
                                      AND A4.tru_user_id = '$userId' 
                                      AND A2.tma_plant_id = '$plantId' 
                                      AND A5.tea_id = A1.tmt_application_id 
                                      AND A5.tea_act_flg = 1
                      ) 
                      UNION 
                      ( 
                              SELECT DISTINCT 
                                        tmt_id 
                              FROM 
                                        T_VHS_MENU_TABS A1 
                                      , T_VHS_MENU_ACCESS A2 
                                      , t_erc_role_user A3 
                              WHERE 
                                        A1.tmt_id = A2.tma_menu_id 
                                      AND A2.tma_act_flg = 1
                                      AND A1.tmt_application_id IS  NULL 
                                      AND A2.tma_role_id = A3.tru_role_id 
                                      AND A3.tru_act_flg = 1
                                      AND A3.tru_user_id = '$userId' 
                                      AND A2.tma_plant_id = '$plantId'  
                      ) 
                ) t2 
            WHERE 
                t1.tmt_id = t2.tmt_id 
                AND t1.TMT_PARENT_ID = '" . $strMasterId . "'  
                AND t1.tmt_act_flg = 1
            ORDER BY 
                t1.tmt_slno ASC ";

    $obj = new db_connect;
    $obj->db_query($sql);
    $res = "";
    while ($row = $obj->db_fetch_array()) {
        $submenu = SubMenu($row[1], $userId, $plantId);
        if ($submenu == "<ul></ul>") {
            $res .= '<li><span><a id="lnkmenu" href="javascript:void(0)" attr="' . $row[2] . '" menuid="' . $row[1] . '" menuUrl="' . HOST_PATH . $row[2] . '" onclick=openUrl("' . HOST_PATH . $row[2] . '?menuid=' . $row[1] . '")>' . $row[0] . '</a></span>';
        } else {
            $res .= '<li state="closed"><span><a id="lnkmenu"  href="javascript:void(0)" attr="' . $row[2] . '">' . $row[0] . '</a></span>';
            $res .= $submenu;
        }
        $res .= '</li>';
    }
    $obj->free();
    return $res;
}

function SubMenu($strMasterId, $userId, $plantId) {

    $sql = "SELECT 
                   t1.tmt_name MenuName 
                 , t1.tmt_id MenuID 
                 , t1.TMT_PATH MenuPath 
                 , t1.tmt_slno 
             FROM 
                   T_VHS_MENU_TABS t1 
                 , ( 
                     ( 
                         SELECT DISTINCT 
                               tmt_id 
                         FROM 
                               T_VHS_MENU_TABS A1 
                             , T_VHS_MENU_ACCESS A2 
                             , t_erc_app_user A3 
                             , t_erc_role_user A4 
                             , T_VHS_APPLICATION A5 
                         WHERE 
                               A1.tmt_id = A2.tma_menu_id 
                             AND A2.tma_act_flg = 1
                             AND A1.tmt_application_id IS NOT NULL 
                             AND A1.tmt_application_id = A3.tau_application_id 
                             AND A3.tau_act_flg = 1
                             AND A2.tma_role_id = A4.tru_role_id 
                             AND A4.tru_act_flg = 1
                             AND A3.tau_user_id = A4.tru_user_id 
                             AND A4.tru_user_id = '$userId' 
                             AND A2.tma_plant_id = '$plantId' 
                             AND A5.tea_id = A1.tmt_application_id 
                            AND A5.tea_act_flg = 1
                     ) 
                     UNION 
                     ( 
                         SELECT DISTINCT 
                               tmt_id 
                         FROM 
                               T_VHS_MENU_TABS A1 
                             , T_VHS_MENU_ACCESS A2 
                             , t_erc_role_user A3 
                         WHERE 
                               A1.tmt_id = A2.tma_menu_id 
                             AND A2.tma_act_flg = 1
                             AND A1.tmt_application_id IS NULL 
                             AND A2.tma_role_id = A3.tru_role_id 
                             AND A3.tru_act_flg = 1
                             AND A3.tru_user_id = '$userId' 
                             AND A2.tma_plant_id = '$plantId'  
                     ) 
                   ) t2 
             WHERE 
                   t1.tmt_id = t2.tmt_id 
                 AND t1.TMT_PARENT_ID = '" . $strMasterId . "'  
                 AND t1.tmt_act_flg = 1
             ORDER BY 
                   t1.tmt_slno ASC ";
    $obj1 = new db_connect;
    $obj1->db_query($sql); //echo $sql;//exit;
    $res = '<ul>';
    while ($row1 = $obj1->db_fetch_array()) {
        $submenu = SubMenu($row1[1], $userId, $plantId);
        if ($submenu == "<ul></ul>") {
            $res .= '<li><span><a id="lnkmenu" href="javascript:void(0)" attr="' . $row1[2] . '" menuid="' . $row1[1] . '" menuUrl="' . HOST_PATH . $row1[2] . '" onclick=openUrl("' . HOST_PATH . $row1[2] . '?menuid=' . $row1[1] . '") >' . $row1[0] . '</a></span>';
        } else {
            $res .= '<li state="closed"><span><a id="lnkmenu"  href="javascript:void(0)" attr="' . $row1[2] . '">' . $row1[0] . '</a></span>';
            $res .= $submenu;
        }
        $res .= '</li>';
    }
    $res .= '</ul>';

    $obj1->free();
    return $res;
}

echo Accordion($_SESSION['userSessionInfo']['TUS_UID'], $_SESSION['userSessionInfo']['TUS_PLNT']);
echo '<script>$(".t:last").attr("selected","true");</script>';
?>