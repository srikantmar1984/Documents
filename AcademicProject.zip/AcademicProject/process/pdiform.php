<?php include("./process_common_class.php"); ?>
<style type="text/css">
    .onoffswitch {
        position: relative; width: 150px;
        -webkit-user-select:none; -moz-user-select:none; -ms-user-select: none;
    }
    .onoffswitch-checkbox {
        display: none;
    }
    .onoffswitch-label {
        display: block; overflow: hidden; cursor: pointer;
        border: 2px solid #999999; border-radius: 20px;
    }
    .onoffswitch-inner {
        display: block; width: 200%; margin-left: -100%;
        transition: margin 0.3s ease-in 0s;
    }
    .onoffswitch-inner:before, .onoffswitch-inner:after {
        display: block; float: left; width: 50%; height: 30px; padding: 0; line-height: 30px;
        font-size: 14px; color: white; font-family: Trebuchet, Arial, sans-serif; font-weight: bold;
        box-sizing: border-box;
    }
    .onoffswitch-inner:before {
        content: "NEW";
        padding-left: 10px;
        background-color: #34A7C1; color: #FFFFFF;
    }
    .onoffswitch-inner:after {
        content: "REJECTED";
        padding-right: 10px;
        background-color: #FF0054; color: #FFFFFF;
        text-align: right;
    }
    .onoffswitch-switch {
        display: block; width: 18px; margin: 6px;
        background: #FFFFFF;
        position: absolute; top: 0; bottom: 0;
        right: 100px;
        border: 2px solid #999999; border-radius: 20px;
        transition: all 0.3s ease-in 0s; 
    }
    .onoffswitch-checkbox:checked + .onoffswitch-label .onoffswitch-inner {
        margin-left: 0;
    }
    .onoffswitch-checkbox:checked + .onoffswitch-label .onoffswitch-switch {
        right: 18px; 
    }
</style>
<input type="hidden" id="hfPageTitle" value="PDI Form" screen_id="">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<div class="Grid" style="text-align: left;"><?php // print_r($_GET);     ?>
    <form name="iirreport" class="iirreport" id="logInc">
        <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td colspan="4">

                        <span>
                            <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                            <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select Chassis No--</option>
                                <?php
                                $chassisDtlArr = $process->chassisDetails();
                                foreach ($chassisDtlArr as $value) {
                                    echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>
                        <span>
                            <label id="lblPDI1" for="checkPDI1">
                                <input type="radio" value="NEW" class="chessisType" checked="checked" name="chessisType"/>
                                <b style="color:#5E9C00;">New</b>
                            </label>
                            <label id="lblPDI1" for="checkPDI1">
                                <input type="radio" value="REJECTED" class="chessisType" name="chessisType"/>
                                <b style="color:#ff0000;">Rejected</b>
                            </label>
                        </span>

                        <span style="display: none" id="pdiTypeSpan" >
                            <label for="ddlChassis" id="lblYes" ><b>Engineer Type:</b></label>
                            <?php
                            $elec = "";
                            $mech = "";
                            $disbl = "";

                            if (array_key_exists(8, $_SESSION['userSessionInfo']['ROLES'])) {
                                $mech = "selected='Selected'";
                                $elec = " ";
                                $disbl = 'disabled="disabled"';
                            } else if (array_key_exists(11, $_SESSION['userSessionInfo']['ROLES'])) {
                                $elec = "selected='Selected'";
                                $mech = " ";
                                $disbl = 'disabled="disabled"';
                            }
                            ?>
                            <select id="pdiEnggType" <?php echo $disbl; ?>>
                                <option value="">--Select--</option>
                                <option <?php echo $mech; ?> value="Mechanical">Mechanical Engineer</option>
                                <option <?php echo $elec; ?> value="Electrical">Electrical Engineer</option>
                            </select>
                        </span>
                    </td>
                </tr>
                <tr style="height:24px">
                    <td colspan="4">
                        <!--###########################################
                        ########## Chassis Details Start ##############
                        ###########################################-->
                        <?php include("ajax_chassis_details.php"); ?>
                        <!--###########################################
                        ########## Chassis Details END ################
                        ###########################################-->
                    </td>
                </tr>
            </tbody>
            <tr style="height:40px">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>PDI CHECKLIST FOR ERC PROTO VEHICLES</b>
                    </span>
                </td>
            </tr>
        </table>
        <div id="tabMenuVHO" class="kks-tabs" data-options="border:false" style=" width:auto;height:500px;overflow-y: auto;">
            <!--Tabs are added dynamically here-->
        </div>
        <table class="chassisDtlSpan" width="100%" cellpadding="0" cellspacing="0" style="display: none" >

            <tr style="height:40px">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>PROTO ASSEMBLY ENGINEER( PAE ) SELECTION</b>
                    </span>
                </td>
            </tr>
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td  colspan="2">
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="ddlPAEElect" id="lblModelNo" ><b>PAE Electrical:</b></label>
                            <select id="ddlPAEElect" name="ddlPAEElect" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select PAE Electrical--</option>
                                <?php
                                echo "<pre>";
                                print_r($_SESSION['userSessionInfo']);
                                $paeElect = $process->allPAEElectrical();
                                foreach ($paeElect as $value) {
                                    $select = '';
                                    if ($_SESSION['userSessionInfo']['TUS_UID'] == $value['USERID'])
                                        $select = 'selected="selected"';
                                    echo '<option value="' . $value['USERID'] . '"  ' . $select . '>' . $value['USERNAME'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="ddlPAEMech" id="lblModelNo" ><b>PAE Mechanical:</b></label>
                            <select id="ddlPAEMech" name="ddlPAEMech" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select PAE Mechanical--</option>
                                <?php
                                $paeMech = $process->allPAEMechanical();
                                foreach ($paeMech as $value) {
                                    $select = '';
                                    if ($_SESSION['userSessionInfo']['TUS_UID'] == $value['USERID'])
                                        $select = 'selected="selected"';
                                    echo '<option value="' . $value['USERID'] . '" >' . $value['USERNAME'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>

                    </td>
                    <td style="width: 20%">
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Comments:</b></label>
                        </span>
                    </td>
                    <td>
                        <span style="display: none" class="chassisDtlSpan" >
                            <textarea placeholder="Please Put Your Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="current_comment" rows="2" maxlength="1900"></textarea>
                        </span>


                    </td>
                </tr>

            </tbody>
        </table>

        <div id="checklistFormBtn" style="margin:10px;display: none">
            <a href="javascript:void(0);" class="kks-linkbutton l-btn,confirm" align="left" onclick="confirmClear();">
                <span style="text-align:left;" >Clear All</span>
            </a>
            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" onclick="savePdi('saveData');">
                <span  style="text-align:left;" >Save data</span>
            </a>
            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" id="linkSubmitPaps" onclick="savePdi('submitData');">
                <span  style="text-align:left;" >Submit</span>				 
            </a>
        </div>
    </form>
</div>
<script type="text/javascript">
    var url = wwwRoot + "process/pdiform_action.php";
    $(function () {
        $('.layout-button-left').trigger('click');
        $("#ddlChassis").change(function () {
            if ($(this).val()) {
                $("#pdiEnggType").trigger('change');
                $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan").show();

            } else {
                $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan,#bdyCheckList,#checklistFormBtn,#ajaxChassisInfoTbl").hide();
            }



        })
        $("#pdiEnggType").change(function () {
            var tabNos = $('.tabs >li').length;
            for (i = 0; i < tabNos; i++) {
                $("#tabMenuVHO").tabs('close', 0);
            }
            if ($(this).val()) {
                //ajax call for PDI list
                var menuid = $("#urlMenuID").val();
                $.post(url, {action: "pdiCheckList", chassisNo: $("#ddlChassis").val(), menuid: menuid}, function () {
                }, 'JSON').done(function (data) {
                    var resTable = '';
                    $.each(data.checkpointData, function (indexTab, tabDetails) {
                        var resTable = '<table style="background-color: #EFF3FB;">';
                        var parntInc = 0;
                        $.each(tabDetails, function (indexPrnt, parentDetails) {
                            if ($.type(parentDetails) == 'object') {
                                parntInc++;
                                var childInc = 0;
                                //Thead
                                if (parentDetails.TCH_INCRIMENTAL) {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='2'>" + parentDetails.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                                    resTable += "<tbody><tr class='trid" + parentDetails.TCH_CHK_ID + "' id='addmoreTr" + parentDetails.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                                    if (parentDetails.TCH_DATA_TYPE == 'file') {
                                        resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + parentDetails.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                        txtRemark = '';
                                    } else {
                                        resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                                        txtRemark = '<textarea maxlength="1900" id="remarkBox_' + parentDetails.TCH_CHK_ID + '" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                    }
                                    resTable += '<td>' + txtRemark + '</td>';
                                    resTable += "</tr></tbody>";
                                } else {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                                }
                                //Tbody
                                $.each(parentDetails, function (index, childArr) {
                                    childInc++;
                                    if ($.type(childArr) == 'object') {
                                        txtRemark = '<textarea maxlength="1900" rows="2" id="remarkBox_' + childArr.TCH_CHK_ID + '" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                        resTable += "<tbody><tr id='trid" + childArr.TCH_CHK_ID + "' class='trid" + childArr.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";

                                        if (childArr.TCH_DATA_TYPE == 'text') {
                                            resTable += '<td><input type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt" ></td>';
                                        } else if (childArr.TCH_DATA_TYPE == 'radio') {
                                            $setValArr = childArr.TCH_VALUE_SET.split("##");
                                            resTable += '<td>';
                                            $setValArr.forEach(function ($value, $key) {
                                                $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                                resTable += '<label for="checkPDI_' + ($key + 1) + childArr.TCH_CHK_ID + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI_' + ($key + 1) + childArr.TCH_CHK_ID + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                            });
                                            resTable += '</td>';
                                        } else if (childArr.TCH_DATA_TYPE == 'file') {
                                            resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + childArr.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                            txtRemark = '';
                                        } else if (childArr.TCH_DATA_TYPE == 'date') {
                                            resTable += '<td><input type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt datepicker" onkeypress="return false;" ></td>';
                                        }
                                        resTable += '<td>' + txtRemark + '</td>';
                                        resTable += "</tr></tbody>";
                                    }
                                })
                            }
                        })
                        resTable += "</table>";
                        $('#tabMenuVHO').tabs('add', {
                            title: indexTab,
                            content: resTable,
                            closable: false
                        });
                        $('.datepicker').datepick({showOnFocus: true, dateFormat: 'dd-M-yyyy'});
                    })

                    if (!$.isEmptyObject(data.checkpointValue)) {
                        $('#txtModelNo').val(data.checkpointValue[0].TLD_MODEL_NO);
                        $('#txtProtoType').val(data.checkpointValue[0].TLD_PROTO_TYPE);
                        $('#txtEngineNo').val(data.checkpointValue[0].TLD_ENGINE_NO);
                        $('#txtProjNo').val(data.checkpointValue[0].TLD_PROJECT_NAME);
                        $('#txtWBSNo').val(data.checkpointValue[0].TLD_WBS_NO);
                        $.each(data.checkpointValue, function (chkKey, chkVal) {
                            $('input[type="text"][name="checkPDI_' + chkVal.TCD_CHK_ID + '"]').val(chkVal.TCD_VALUE);
                            $('input[name="checkPDI_' + chkVal.TCD_CHK_ID + '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
                            $("#remarkBox_" + chkVal.TCD_CHK_ID).val(chkVal.TCD_REMARKS);
                        })
                        if (!$.isEmptyObject(data.LASTCOMMENT)) {
                            $("#current_comment").val(data.LASTCOMMENT.REMARK);
                            $("#pendUserName").html(data.LASTCOMMENT.PENDUSERNAME);
                        }

                    }
                    if (!$.isEmptyObject(data.AJAXCHASSISDTLS)) {
                        $("#ajaxChassisNo").html(data.AJAXCHASSISDTLS.CHASSSISNO);
                        $("#ajaxModelNo").html(data.AJAXCHASSISDTLS.TCD_MODEL);
                        $("#ajaxProtoType").html(data.AJAXCHASSISDTLS.TCD_PROTO_NO);
                        $("#ajaxWBSNo").html(data.AJAXCHASSISDTLS.TCD_WBS_LIST);
                        $("#ajaxProjCode").html(data.AJAXCHASSISDTLS.TCD_PROJ_CODE);
                        $("#ajaxVCNo").html(data.AJAXCHASSISDTLS.TCD_VC_NO);
                        $("#ajaxChassisInfoTbl").show();
                    }
                    $("#tabMenuVHO").tabs('select', 0);
                })
                $("#checklistFormBtn").show();
            } else {
                $("#tabMenuVHO").tabs('close', 0);
                $("#tabMenuVHO").tabs('close', 0);
                $("#tabMenuVHO").tabs('close', 0);
                $("#vhdFormBtn").hide();
            }
        })
        $(".chessisType").click(function () {
            $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan,#bdyCheckList,#checklistFormBtn").hide();
            $("#tabMenuVHO").tabs('close', 0);
            $("#tabMenuVHO").tabs('close', 0);
//            $("#vhdFormBtn").hide();
            //alert($(this).val());
            $.post(url, {action: "chassisDpdList", chassisType: $(this).val()}, function () {}, 'JSON')
                    .done(function (data) {
                        //console.log(data);
                        var dpdStr = '<option value="">--Select Chassis No--</option>';
                        $.each(data.allChessis, function (index, eachChassis) {
                            dpdStr += '<option value="' + eachChassis.CHASSSISNO + '">' + eachChassis.CHASSSISNO + '</option>';
                        })
                        $("#ddlChassis").html(dpdStr);
                    })
        })
    })

    function savePdi(type) {
        var totalField = $('.checkpdiInpt').length;
        var totalRadio = $(':radio[class="checkpdiInpt"]').length;
        var totalText = totalField - totalRadio;
        var totalRadioBlck = totalRadio / 3;
        var checkedRadio = $(':radio[class="checkpdiInpt"]:checked').length;
        if (type == "submitData") {
            if (!$("#ddlPAEElect").val()) {
                alert("Please Select PAE Electrical.");
                return false;
            }
            if (!$("#ddlPAEMech").val()) {
                alert("Please Select PAE Mechanical.");
                return false;
            }
            if (checkedRadio != totalRadioBlck) {
                alert("Please check all PDI checklist!");
                return false;
            }
        }
        var chassisNo = $('#ddlChassis').val();
        var enggType = $("#pdiEnggType").val();
        var checklistObj = [];
        $('.checkpdiInpt').each(function () {
            var remarks = $(this).closest('tr').find('.txtFieldTextBox').val();
            if ($(this).is(':checked')) {
                checklistObj.push({checkListId: $(this).attr('checklist_id'), val: $(this).val(), remarks: remarks});
            }
            if ($(this).is(':text') && $(this).val()) {
                checklistObj.push({checkListId: $(this).attr('checklist_id'), val: $(this).val(), remarks: remarks});
            }
        })
        if (!$.isEmptyObject(checklistObj)) {
            $.post(url,
                    {
                        type: type,
                        chassisNo: chassisNo,
                        checklistObj: checklistObj,
                        chassisType: $('input[name=chessisType]:checked').val(),
                        paeElect: $("#ddlPAEElect").val(),
                        paeMech: $("#ddlPAEMech").val(),
                        currComment: $("#current_comment").val(),
                        action: 'saveChkList'
                    }).done(function (data) {
                alert(data);
                openUrl(wwwRoot + "process/pdiform.php?menuid=14");
            })
        } else {
            alert("Please check atleast one PDI to complete save process!");
        }
    }
</script>