<?php include("./process_common_class.php"); ?>
<input type="hidden" id="hfPageTitle" value="Joint Inspection Form" screen_id="">
<input type="hidden" id="hfAccessLevel" value="">	
<div class="Grid" style="text-align: left;">
    <form name="iirreport" class="iirreport" id="logInc">
        <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td colspan="3">
                        <span>
                            <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                            <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select Chassis No--</option>
                                <?php
                                $chassisDtlArr = $process->chassisDetails();
                                foreach ($chassisDtlArr as $value) {
                                    echo '<option data-modelType="' . $value['MODEL_TYPE'] . '" value="' . $value['CHASSIS_NO'] . '" data-modelTypeNo="' . $value['MODEL_TYPE_NO'] . '" data-protoTypeNo="' . $value['PROTO_TYP_NO'] . '" data-enggNo="' . $value['ENG_NO'] . '" data-wbsNo="' . $value['WBS_NO'] . '" data-projectCode="' . $value['PROJECT_CODE'] . '">' . $value['CHASSIS_NO'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>
                        <span style="display: none" id="spnModelNo" >
                            <label for="ddlChassis" id="lblYes" ><b>Model No:</b></label>
                            <input id="txtModelNo" type="text" style="width:15%;background:  #E3E3E3" />
                        </span>
                        <span style="display: none" id="ercNoSpan" >
                            <label for="ddlChassis" id="lblYes" ><b>ERC No:</b></label>
                            <input id="txtModelNo" type="text" style="width:15%;background:  #E3E3E3" value="N/A" />                           
                        </span>
                    </td>
                </tr>
            </tbody>
            <tr style="height:40px">
                <td colspan="3" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>VEHICLE JOINT INSPECTION SIGN-OFF SHEET</b>
                    </span>
                </td>
            </tr>
        </table>
        <table id="bdyJIForm" style="display: none;background-color: #EFF3FB;">
            <?php // echo $process->pdiCheckList(); ?> 
        </table>
        <div id="jiEntryFormBtn" style="margin:10px;display: none">
            <a href="javascript:void(0);" class="kks-linkbutton l-btn,confirm" align="left" onclick="confirmClear();">
                <span style="text-align:left;" >Clear All</span>
            </a>	

            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" onclick="savePdi('saveData');">
                <span  style="text-align:left;" >Save data</span>
            </a>
            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" id="linkSubmitPaps" onclick="savePdi('submitData');">
                <span  style="text-align:left;" >Submit</span>				 
            </a>
        </div>

    </form>
</div>
<div id="dd"></div>
<script type="text/javascript">
    var url = wwwRoot + "process/jientry_action.php";
    $(function () {
        $('.layout-button-left').trigger('click');
        $("#ddlChassis").change(function () {

            if ($(this).val()) {
                //ajax call for ji list
                $.post(url, {action: "JIDETAILS", chassisNo: $(this).val()}, function () {
                }, 'JSON').done(function (data) {
                            var resTable = '';
                            var parntInc = 0;
                            $.each(data, function (indexPr, element) {
                                parntInc++;
                                var childInc = 0;

                                if (element.TCH_INCRIMENTAL) {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='2'>" + element.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr"+element.TCH_CHK_ID+"\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr"+element.TCH_CHK_ID+"\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                                    resTable += "<tbody><tr class='trid"+element.TCH_CHK_ID+"' id='addmoreTr"+element.TCH_CHK_ID+"'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + element.TCH_CHK_ID + '" checklist_id="' + element.TCH_CHK_ID + '"  id="checkPDI' + (indexPr + 1) + '" class="checkpdiInpt" ></td>';
                                    if(element.TCH_DATA_TYPE == 'file'){
                                        resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,'+element.TCH_CHK_ID+');" width="150Px"  value="Upload File"/></td>';
                                        txtRemark = '';
                                    }else{
                                        resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' + element.TCH_CHK_ID + '" checklist_id="' + element.TCH_CHK_ID + '"  id="checkPDI' + (indexPr + 1) + '" class="checkpdiInpt" ></td>';
                                        txtRemark = '<textarea maxlength="1900" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                    }
                                    resTable += '<td>'+txtRemark+'</td>';
                                    resTable += "</tr></tbody>";
                                } else {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + element.TCH_CHECK_POINT + "</th></tr></thead>";
                                }
                                $.each(element, function (index, childArr) {
                                    childInc++;
                                    if ($.type(childArr) == 'object') {
                                        txtRemark = '<textarea maxlength="1900" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                        resTable += "<tbody><tr id='trid"+childArr.TCH_CHK_ID+"' class='trid"+childArr.TCH_CHK_ID+"'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";

                                        if (childArr.TCH_DATA_TYPE == 'text') {
                                            resTable += '<td><input type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt" ></td>';
                                        } else if (childArr.TCH_DATA_TYPE == 'radio') {
                                            $setValArr = childArr.TCH_VALUE_SET.split("##");
                                            resTable += '<td>';
                                            $setValArr.forEach(function ($value, $key) {
                                                $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                                resTable += '<label for="checkPDI' + ($key + 1) + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                            });
                                            resTable += '</td>';
                                        } else if (childArr.TCH_DATA_TYPE == 'file') {
                                            resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,'+childArr.TCH_CHK_ID+');" width="150Px"  value="Upload File"/></td>';
                                            txtRemark = '';
                                        }
                                        resTable += '<td>'+txtRemark+'</td>';
                                        resTable += "</tr></tbody>";
                                    }

                                })
//                                }
                            })
                            $("#bdyJIForm").html(resTable).show();
                        })
                $("#pdiEnggType").trigger('change');
                $("#txtModelNo").val($('option:selected', $(this)).data('modeltypeno')).attr('readonly', true);
                $("#spnModelNo,#ercNoSpan,#jiEntryFormBtn").show();
            } else {
                $("#txtModelNo").val('').attr('readonly', true);
                $("#spnModelNo,#ercNoSpan,#jiEntryFormBtn").hide();
            }
        })

    })
</script>