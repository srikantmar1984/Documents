<?php include("./process_common_class.php"); ?>

<input type="hidden" id="hfPageTitle" value="Handover Doc">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<div class="Grid" style="text-align: left;"><?php //  echo "<pre>";print_r($_SESSION);    ?>
    <form name="iirreport" class="iirreport" id="logInc">
        <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td colspan="3">
                        <span>
                            <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                            <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select Chassis No--</option>
                                <?php
                                if (array_key_exists(6, $_SESSION['userSessionInfo']['ROLES'])) {
                                    $roleType = "design";
                                    $chassisDtlArr = $process->chassisPending();
                                } else {
                                    $roleType = "pae";
                                    $chassisDtlArr = $process->chassisPendingVHDPAE();
                                }
                                foreach ($chassisDtlArr as $value) {
                                    echo '<option data-pendstateid="' . $value['PENDSTATEID'] . '" data-statename="' . $value['STATENAME'] . '" value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>
                        <span style="display: none;margin-left: 20px;font-weight: bold;color:red" class="chassisDtlSpan" id="typeChassis" ></span>
                    </td>
                </tr>
            </tbody>
            <tr style="height:40px">
                <td colspan="3" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;border-right:0px">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>Proto Vehicle Hand over / Sign off Document</b>
                    </span>
                    <span class="chassisDtlSpan lblHeadLabel" style="text-decoration:underline;margin-right: 10px;display: none">
                        <?php if ($roleType == "design") { ?>
                            <a href="javascript:void(0);" onclick="viewVHDPae();"><b>Click to View VHD( PAE )</b></a>
                        <?php } ?>
                    </span>
                </td>                
            </tr>
            <tr style="height:24px">
                <td colspan="3">
                    <!--###########################################
                    ########## Chassis Details Start ##############
                    ###########################################-->
                    <?php include("ajax_chassis_details.php"); ?>
                    <!--###########################################
                    ########## Chassis Details END ################
                    ###########################################-->
                </td>
            </tr>
        </table>

        <div id="tabMenuVHO" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
            <!--Tabs are added dynamically here-->
        </div>
        <table class="chassisDtlSpan assignTable" width="100%" cellpadding="0" cellspacing="0" style="display: none" >

            <tr style="height:40px">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b class="assgn_commnt">Assign To</b>
                    </span>
                </td>
            </tr>
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td style="width: 20%" class="hideLastComent">
                        <span class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Last Comment By: </b><b style="color: #3637FE" id="pendUserName"></b></label>
                        </span>
                    </td>
                    <td class="hideLastComent">
                        <span class="chassisDtlSpan" >
                            <textarea placeholder="Last Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="last_comment" rows="2" maxlength="1900" disabled="disabled"></textarea>
                        </span>
                    </td>
                    <td style="width: 20%">
                        <span class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>If you have any commen? :</b></label>
                        </span>
                    </td>
                    <td>
                        <span class="chassisDtlSpan" >
                            <textarea placeholder="Please Put Your Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="current_comment" rows="2" maxlength="1900"></textarea>
                        </span>
                    </td>
                </tr>
                <tr style="height:24px" class="rejectCase">
                    <td  colspan="4">
                        <span style="display: none" class="chassisDtlSpan" >
                            <?php if ($roleType == "pae") { ?>
                                <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Design Engineer:</b></label>
                                <select id="ddlResponsibleEngg" name="ddlResponsibleEngg" style="width:15%;"  class="ddlFieldDropdown">
                                    <option value="">--Select Designer--</option>
                                    <?php
                                    $designEngg = $process->allDesignEngg();
                                    foreach ($designEngg as $value) {
                                        echo '<option value="' . $value['USERID'] . '" >' . $value['USERNAME'] . '</option>';
                                    }
                                    ?> 
                                </select>
                            <?php }  ?>
                        </span>


                    </td>

                </tr>
            </tbody>
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >

            </tbody>
        </table>
        <div id="vhdFormBtn" style="margin:10px;display: none">
            <a href="javascript:void(0);" class="kks-linkbutton l-btn,confirm" align="left" onclick="confirmClear();">
                <span style="text-align:left;" >Clear All</span>
            </a>	

            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" onclick="saveVhd('saveData');">
                <span  style="text-align:left;" >Save data</span>
            </a>
            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" id="linkSubmitPaps" onclick="saveVhd('submitData');">
                <span  style="text-align:left;" >Submit</span>				 
            </a>
        </div>

    </form>
</div>
<div id="divPopUpforUpload" style="text-align:left;position:absolute; top:30%; bottom:50%; left:30%; right:50%;display:none; z-index:2;">

</div>

<script type="text/javascript">
    var url = wwwRoot + "process/handover_doc_action.php";
    $(function () {
        $('.layout-button-left').trigger('click');
        $("#ddlChassis").change(function () {
            var tabNos = $('.tabs >li').length;
            for (i = 0; i < tabNos; i++) {
                $("#tabMenuVHO").tabs('close', 0);
            }
            if ($(this).val()) {
                $("#typeChassis").html("( " + $("#ddlChassis option:selected").data("statename") + " )");
                var pendingStateId = $("#ddlChassis option:selected").data("pendstateid");
                //ajax call for ji list
                var menuid = $("#urlMenuID").val();
                $.post(url, {action: "VHODETAILS", chassisNo: $(this).val(), menuid: menuid}, function () {
                }, 'JSON').done(function (data) {
                    var resTable = '';
                    $.each(data.CHECKDTLS, function (indexTab, tabDetails) {
                        var resTable = '<table style="background-color: #EFF3FB;">';
                        var parntInc = 0;
                        $.each(tabDetails, function (indexPrnt, parentDetails) {
                            if ($.type(parentDetails) == 'object') {
                                parntInc++;
                                var childInc = 0;
                                //Thead
                                if (parentDetails.TCH_INCRIMENTAL) {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='2'>" + parentDetails.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                                    resTable += "<tbody><tr class='trid" + parentDetails.TCH_CHK_ID + "' id='addmoreTr" + parentDetails.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkVHD_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkVHD' + (indexPrnt + 1) + '"class="checkVhdInpt" ></td>';
                                    if (parentDetails.TCH_DATA_TYPE == 'file') {
                                        resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + parentDetails.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                        txtRemark = '';
                                    } else {
                                        resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkVHD_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkVHD' + (indexPrnt + 1) + '" class="checkVhdInpt" ></td>';
                                        txtRemark = '<textarea maxlength="100" id="remarkBox_' + parentDetails.TCH_CHK_ID + '" rows="2" class="txtFieldTextBox jidevRemark"  style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                    }
                                    resTable += '<td>' + txtRemark + '</td>';
                                    resTable += "</tr></tbody>";
                                } else {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                                }
                                //Tbody
                                $.each(parentDetails, function (index, childArr) {
                                    childInc++;
                                    if ($.type(childArr) == 'object') {
                                        txtRemark = '<textarea maxlength="1900" rows="2" id="remarkBox_' + childArr.TCH_CHK_ID + '" class="txtFieldTextBox jidevRemark" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                        resTable += "<tbody><tr id='trid" + childArr.TCH_CHK_ID + "' class='trid" + childArr.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";

                                        if (childArr.TCH_DATA_TYPE == 'text' || childArr.TCH_DATA_TYPE == 'date') {
                                            resTable += '<td><input type="text" name="checkVHD_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkVHD' + (index + 1) + '" class="checkVhdInpt" ></td>';
                                        } else if (childArr.TCH_DATA_TYPE == 'radio') {
                                            $setValArr = childArr.TCH_VALUE_SET.split("##");
                                            resTable += '<td>';
                                            $setValArr.forEach(function ($value, $key) {
                                                $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                                resTable += '<label for="checkVHD' + ($key + 1) + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkVHD_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkVHD' + ($key + 1) + '"  value="' + $value + '" class="checkVhdInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                            });
                                            resTable += '</td>';
                                        } else if (childArr.TCH_DATA_TYPE == 'file') {
                                            resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + childArr.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                            txtRemark = '';
                                        }
                                        resTable += '<td>' + txtRemark + '</td>';
                                        resTable += "</tr></tbody>";
                                    }
                                })
                            }
                        })
                        resTable += "</table>";
                        $('#tabMenuVHO').tabs('add', {
                            title: indexTab,
                            content: resTable,
                            closable: false
                        });
                        if (!$.isEmptyObject(data.AJAXCHASSISDTLS)) {
                            $("#ajaxChassisNo").html(data.AJAXCHASSISDTLS.CHASSSISNO);
                            $("#ajaxModelNo").html(data.AJAXCHASSISDTLS.TCD_MODEL);
                            $("#ajaxProtoType").html(data.AJAXCHASSISDTLS.TCD_PROTO_NO);
                            $("#ajaxWBSNo").html(data.AJAXCHASSISDTLS.TCD_WBS_LIST);
                            $("#ajaxProjCode").html(data.AJAXCHASSISDTLS.TCD_PROJ_CODE);
                            $("#ajaxVCNo").html(data.AJAXCHASSISDTLS.TCD_VC_NO);
                            $("#ajaxChassisInfoTbl").show();
                        }
                    })
                    if (!$.isEmptyObject(data.FILLDATA)) {

                        $.each(data.FILLDATA, function (chkKey, chkVal) {
                            $('input[type="text"][name="checkVHD_' + chkVal.TCD_CHK_ID + '"]').val(chkVal.TCD_VALUE);
                            $('input[name="checkVHD_' + chkVal.TCD_CHK_ID + '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
                            $("#remarkBox_" + chkVal.TCD_CHK_ID).val(chkVal.TCD_REMARKS);
                        })
                    }
                    if (!$.isEmptyObject(data.LASTCOMMENT)) {
                        $("#last_comment").val(data.LASTCOMMENT.REMARK);
                        $("#pendUserName").html(data.LASTCOMMENT.PENDUSERNAME);
                    } else {
                        $(".hideLastComent").hide();
                        $("#current_comment").css('width', '50%');
                    }
                    $("#tabMenuVHO").tabs('select', 0);
                })
                $("#vhdFormBtn,.chassisDtlSpan").show();
                if (pendingStateId == 16 || pendingStateId == 17) {
                    $('.rejectCase').hide();
                    $('.assgn_commnt').html('Comment');
                }
            } else {
                $("#tabMenuVHO").tabs('close', 0);
                $("#tabMenuVHO").tabs('close', 0);
                $("#tabMenuVHO").tabs('close', 0);
                $("#vhdFormBtn,.chassisDtlSpan,#ajaxChassisInfoTbl").hide();
            }
        });
    });

    function saveVhd(type) {
        var menuid = $("#urlMenuID").val();
        var chassisNo = $('#ddlChassis').val();
        var responsilbeEngg = $("#ddlResponsibleEngg").val();
        var pendingStateId = $("#ddlChassis option:selected").data("pendstateid");
        if (type == 'submitData') {
            //validation will implement here
            if (!responsilbeEngg && $(".rejectCase").is(":visible") && menuid == 19) {
                $.messager.alert('Handover Doc Validation', '<b style="color:red">Please select designer!</b>', 'error');
                $("#ddlResponsibleEngg").focus();
                return false;
            }
        }
        var vhdValueObj = [];
        $('.checkVhdInpt').each(function () {
            var remarks = $(this).closest('tr').find('.txtFieldTextBox').val();
            if ($(this).is(':text') && $(this).val()) {
                vhdValueObj.push({checkListId: $(this).attr('checklist_id'), val: $(this).val(), remarks: remarks});
            }
        })
        $.post(url,
                {
                    type: type,
                    chassisNo: chassisNo,
                    vhdValueObj: vhdValueObj,
                    responsilbeEngg: responsilbeEngg,
                    pendingStateId: pendingStateId,
                    currComment: $("#current_comment").val(),
                    action: 'saveVhdValue'
                }).done(function (data) {
            $.messager.alert('Handover Doc', '<b style="color:green">' + data + '</b>', 'success');
            openUrl(wwwRoot + "process/handover_doc.php?menuid=" + menuid);
        })

    }

    function viewVHDPae() {
        $("#tabMenuVHO").tabs('close', 1);
        $("#tabMenuVHO").tabs('close', 1);
        $.post(wwwRoot + "process/ajax_viewpae_vhd.php", {action: "viewVHDPae", menuid: 19, chassisNo: $('#ddlChassis').val()}, function () {
        }, 'JSON').done(function (data) {
            $.each(data, function (index, childArr) {
                $('#tabMenuVHO').tabs('add', {
                    title: index,
                    content: childArr,
                    closable: true
                });
            })

        })
    }

    function confirmClear() {

        $('.checkVhdInpt').val('');
        $('#current_comment').val('');
        $('.jidevRemark').val('');
        $('#ddlResponsibleEngg').val('');
    }

</script>