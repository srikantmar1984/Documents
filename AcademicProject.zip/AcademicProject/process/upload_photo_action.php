<?php

include_once('./process_common_class.php');
$ref = 'on';
date_default_timezone_set("Asia/Calcutta");

if (isset($_REQUEST["act"])) {
    if ($_REQUEST["act"] == 'getUploadedPhotos') {
        echo getUploadedPhotos($_REQUEST['selectedYear'], $_REQUEST['selectedMonth']);
    }
    if ($_REQUEST["act"] == 'delFile') {

        echo deletePhoto(); //exit;
    }
} else {
    echo uploadPhoto("jiDocTemp");
}

function deletePhoto() {
    $updateSql = " UPDATE 
                    t_sos_rwd_photo_upload 
                SET tpu_upd_by = '" . $_SESSION['Pno'] . "',
                tpu_upd_ts = SYSDATE ";
    if ($_REQUEST["statusType"] == "Active") {
        $updateSql .= " , tpu_act_flg = 'InActive' ";
    } else {
        $updateSql .= " , tpu_act_flg = 'Active' ";
    }
    $updateSql .= "WHERE
                    tpu_org_id = '" . $_SESSION['Org'] . "'
                    AND tpu_unit_id = '" . $_SESSION['Unit'] . "'
                    AND tpu_locn_id = '" . $_SESSION['Locn'] . "' 
                    AND TRUNC(tpu_month) = '" . $_REQUEST["tpuMonth"] . "' 
                    AND tpu_seq_id = " . $_REQUEST["docId"];
    $obj = new db_connect;
    $obj->db_query($updateSql);
    $obj->free();
    return 'Success';
}

function getUploadedPhotos($year, $month) {
    $dateStrSrch = $month . '-' . $year;
    $strSql = "";
    $strSql .= "  SELECT 
                    REPLACE(REPLACE(tpu_file_path,'\\','/'),'~/','') IMAGEFILEPATH ,
                    tpu_file_path ACTIMAGEFILEPATH ,
                    tpu_seq_id IMAGEFILESEQID ,
                    tpu_file_name IMAGEFILENAME ,
                    tpu_file_desc IMAGEFILEDESC ,
                    tpu_month TPUMONTH ,
                    tpu_act_flg IMAGEFILESTATUS 
                FROM 
                    t_sos_rwd_photo_upload
                WHERE
                    tpu_org_id = '" . $_SESSION['Org'] . "' 
                    AND tpu_unit_id ='" . $_SESSION['Unit'] . "'
                    AND tpu_locn_id = '" . $_SESSION['Locn'] . "' 
                    AND TO_CHAR(tpu_month,'dd-Mon-yyyy') LIKE '%" . $dateStrSrch . "'"; //TRUNC(tpu_month) = '01-AUG-13' // AND TPU_ACT_FLG = 'Active'
    $obj = new db_connect();
    $obj->db_query($strSql);
    $result = "";
    while ($row = $obj->db_fetch_array()) {
        $filesz = round(filesize('../' . $row['ACTIMAGEFILEPATH']) / 1024);
        $result .= '<tr>';
        $result .= '<td width="15%">';
        $result .= '<img src=' . $row['IMAGEFILEPATH'] . ' style="height:119Px;width:200Px;"></img>';
        $result .= '</td>';
        $result .= '<td width="40%">';
        $result .= '<table style="border:none;">';
        $result .= '<tbody>';
        $result .= '<tr><td style="border:none;width:70%;">FileName</td><td style="font-weight:bold;border:none;">' . $row['IMAGEFILENAME'] . '</td></tr>';
        $result .= '<tr><td style="border:none;width:70%;">FileDescription</td><td style="font-weight:bold;border:none;">' . $row['IMAGEFILEDESC'] . '</td></tr>';
        if ($row['IMAGEFILESTATUS'] == "Active") {
            $linkStr = "Deactive Image";
            $color = "color:green";
        } else {
            $linkStr = "Active Image";
            $color = "color:red";
        }
        $result .= '<tr><td style="border:none;width:70%;">FileStatus</td><td style="font-weight:bold;border:none;' . $color . '">' . $row['IMAGEFILESTATUS'] . '</td></tr>';
        $result .= '<tr><td style="border:none;width:70%;">FileSize</td><td style="font-weight:bold;border:none;">' . $filesz . ' KB</td></tr>';
        $result .= '</tbody>';
        $result .= '</table>';
        $result .= '</td> ';

        $result .= '<td colspan="2"><a id="btnDeactFile" class="statusChange" href="javascript:void(0);" data-statusType=' . $row['IMAGEFILESTATUS'] . ' data-seqId=' . $row['IMAGEFILESEQID'] . ' data-tpuMonth=' . $row['TPUMONTH'] . '>' . $linkStr . '</a></td>';
        $result .= '</tr>';
    }
    $obj->free();
    return $result;
}

function uploadPhoto($destination) {
    $UploadDirectory = WEBROOT . $destination . '/';
    $RandNumber = rand(0, 9999999999);
    $FileName = strtolower($_FILES['mFile']['name']); //uploaded file name
    $ImageExt = substr($FileName, strrpos($FileName, '.')); //file extension
    $FileType = $_FILES['mFile']['type']; //file type
    $FileSize = $_FILES['mFile']["size"]; //file size
    $RandNumber = rand(0, 9999999999); //Random number to make each filename unique.
    $uploaded_date = date("Y-m-d H:i:s");
    $uploadFileTitle = $_REQUEST['uploadFileTitle']; //GIVES THE TITLE GIVEN BY USER
    $uploadFileCheckID = $_REQUEST['hidecheckID']; //GIVES THE TITLE GIVEN BY USER
    $uploadFileChassisNo = $_REQUEST['hidechassisNo']; //GIVES THE TITLE GIVEN BY USER
    $NewFileName = preg_replace(array('/\s/', '/\.[\.]+/', '/[^\w_\.\-]/'), array('_', '.', ''), strtolower('UPLOADEDFILE'));
    $NewFileName = $_SESSION['userSessionInfo']["TUS_PLNT"] . "_" . $uploadFileCheckID . '_' . $uploadFileChassisNo . '_' . $NewFileName . '_' . $RandNumber . $ImageExt;
    if (move_uploaded_file($_FILES['mFile']["tmp_name"], $UploadDirectory . $NewFileName)) {
        $result = '<tr style="background-color:#FFFFFF" class="addMorePhotoTr"><td></td>';
        $result .= '<td><img src=' . HOST_PATH . 'webroot/' . $destination . '/' . $NewFileName . ' style="height:119Px;width:200Px;"></img></td>';
        $result .= '<td><input type="hidden" class="photoName" checklist_id="128" value="' . $NewFileName . '" style="width:80%"><textarea placeholder="Photo Description" style="word-wrap: break-word;width:95%" class="photoDesc" rows="2" maxlength="1900">' . $uploadFileTitle . '</textarea></td>';
        $linkStr = "Delete Image";
        $color = "color:red";
        $result .= '<td colspan="2"><a id="btnDeactFile" class="statusChange" href="javascript:void(0);" data-statusType=' . $NewFileName . ' data-seqId=' . $NewFileName . ' data-tpuMonth=' . $NewFileName . '>' . $linkStr . '</a></td>';
        $result .= '</tr>';
    } else {
        echo "There was an error uploading the file, please try again!";
    }
    return $result;
}
?>