<?php include("./process_common_class.php"); ?>
<input type="hidden" id="hfPageTitle" value="Test Team Formation" screen_id="">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">

<div class="Grid" style="text-align: left;">

    <form id="teamForm"  enctype="multipart/form-data" action="process/team_formation_action.php?action=TEAMDATA" method="post" >
        <table width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tr style="height:24px">
                <td colspan="4">
                    <span>
                        <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                        <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                            <option value="">--Select Chassis No--</option>
                            <?php
                            $chassisDtlArr = $process->chassisPending2(7);
                            foreach ($chassisDtlArr as $value) {
                                echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                            }
                            ?> 
                        </select>
                    </span>
                </td>
            </tr>
            <tr style="height:40px">
                <td colspan="3" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>Test Team Formation</b>
                    </span>
                </td>
            </tr>
            <tbody style="background-color: #EFF3FB;display:none" class="chassisDtlSpan"  >
                <tr style="height: 35px;">
                    <td style="width:15%;"><strong>Select Team</strong>

                    </td>
                    <td style="width:75%">
                        <?php
                        echo $process->findteamNM();
                        ?>
                    </td>
                </tr>


            </tbody>
        </table>
        <!--================================================================================-->
        <!--====================== Team Details start =======================================-->
        <!--================================================================================-->
        <div id="divlist" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">

        </div>
        <!--<div id="divbutton" class="tranperent">
        <a id="btnCreate" href="javascript:void(0)" class="formteambtn" onclick="formteam()"  >Create</a>
        <input type="submit" class="formteambtn" onclick="formteam()"  value="Form"/>
        </div>-->

        <!--================================================================================-->
        <!--======================== Team Details End =======================================-->
        <!--================================================================================-->

        <div id="checklistFormBtn" style="display: none">
            <table width="100%" cellpadding="0" cellspacing="0"  >
                <tr>

                    <td width="25%"><b>Comment for Submission: </b></td>
                    <td width="50%">
                        <textarea placeholder="Please Put Your Comment" style="word-wrap: break-word;width: 50%" class="txtFieldTextBox" id="current_comment" rows="2" maxlength="1900"></textarea>
                    </td>
                    <td style="width:25%">
                        <a href="javascript:void(0);" class="kks-linkbutton l-btn confirm" iconCls="icon-approved" align="left" onclick="teamSubmit();">
                            <span style="text-align:left;" >Submit</span>
                        </a>
                    </td>
                </tr>
            </table>
        </div>

    </form>

    <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
        <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
            <tr style="height:40px;display: none" class="chassisDtlSpan">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>PDI CHECKLIST FOR ERC PROTO VEHICLES</b>
                    </span>
                </td>
            </tr>
            <tr style="height:24px">
                <td colspan="4">
                    <!--###########################################
                    ########## Chassis Details Start ##############
                    ###########################################-->
                    <?php include("ajax_chassis_details.php"); ?>
                    <!--###########################################
                    ########## Chassis Details END ################
                    ###########################################-->
                </td>
            </tr>
        </tbody>

    </table>
    <div id="tabMenuVHO" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto" >
        <!--Tabs are added dynamically here-->
    </div>

</div>

<div id="dd"></div>
<style>
    .round2corners {
        box-shadow: 0 15px 20px rgba(0, 0, 0, 0.3);
        background: #FFFFE6;/*  #3c8dbc; #39cccc;*/
        margin:1%;
        width:300Px;
        height: 120px;
        float: left;
        display: block;
        border:4;
    }
    .tranperent {
        background: #FFFFFF;
        margin:1%;
        width:300Px;
        display: block;
    }
    .round1corners{
        margin:1%;
        width:270Px;
        display: block;
        overflow:auto;
        height: 70Px;
    } 
    .formteambtn{
        border-radius: 15px 15px;
        background: #3c8dbc;
        margin:1%;
        width:80Px;
        overflow:auto;
        color: white;
        position:relative;
        top:50%; 
        height: 40Px;
    } 

    h3{
        margin:1%;
        background: rgba(79, 124, 192, 0.92);
        color: white;

    }
</style>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript">
    var url = wwwRoot + "process/team_formation_action.php";
    $(function () {
        $("#tabMenuVHO :input").attr("disabled", true);
        $('.layout-button-left').trigger('click');
        $("#ddlChassis").change(function () {
            $("#tabMenuVHO").tabs('close', 0);
            $("#tabMenuVHO").tabs('close', 0);
            if ($(this).val()) {
                $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan,#divlist").show();
                tabGenerate();
            } else {

                $("#vhdFormBtn").hide();
                $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan,#bdyCheckList,#checklistFormBtn,#divlist,#ajaxChassisInfoTbl").hide();
            }
        })
        $("#uploadReq").click(function () {
            if ($(this).is(":checked")) {
                $("#teamUploadDco,#uploadButtonVLO").hide();
            } else {
                $("#teamUploadDco,#uploadButtonVLO").show();
            }
        });



        $("input[type='checkbox'][name='teams']").click(function () {

            var chk = $(this).val();
            var chkprop = $(this).prop('checked');
            var grptype = $(this).attr('grptype');
            var chkNM = $(this).attr('grpNM');
            if (chkprop) {

                $.post(url,
                        {
                            chk: chk,
                            grptype: grptype,
                            chkNM: chkNM,
                            action: "fillmember"
                        },
                        function (data) {
                            // console.log(data);//return false;
                            var teamlist = "<div id=" + chk + " class='round2corners'><h3>" + chkNM + "</h3><div class='round1corners'>" + data + "</div></div>";
                            $("#divlist").append(teamlist);
                        });
            } else {

                $("#" + chk).remove();

            }

        });

        function tabGenerate() {
            //ajax call for PDI list
            var menuid = $("#urlMenuID").val();
            $.post(url, {action: "pdiCheckList", chassisNo: $("#ddlChassis").val(), menuid: menuid}, function () {
            }, 'JSON').done(function (data) { //console.log(data);return false;
                console.log(data);
                var resTable = '';
                $.each(data.checkpointData, function (indexTab, tabDetails) {
                    var resTable = '<table style="background-color: #EFF3FB;">';
                    var parntInc = 0;
                    $.each(tabDetails, function (indexPrnt, parentDetails) {
                        if ($.type(parentDetails) == 'object') {
                            parntInc++;
                            var childInc = 0;
                            //Thead
                            if (parentDetails.TCH_INCRIMENTAL) {
                                resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='2'>" + parentDetails.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                                resTable += "<tbody><tr class='trid" + parentDetails.TCH_CHK_ID + "' id='addmoreTr" + parentDetails.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                                if (parentDetails.TCH_DATA_TYPE == 'file') {
                                    resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + parentDetails.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                    txtRemark = '';
                                } else {
                                    resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                                    txtRemark = '<textarea maxlength="1900" id="remarkBox_' + parentDetails.TCH_CHK_ID + '" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                }
                                resTable += '<td>' + txtRemark + '</td>';
                                resTable += "</tr></tbody>";
                            } else {
                                resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                            }
                            //Tbody
                            $.each(parentDetails, function (index, childArr) {
                                childInc++;
                                if ($.type(childArr) == 'object') {
                                    txtRemark = '<textarea maxlength="1900" rows="2" id="remarkBox_' + childArr.TCH_CHK_ID + '" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                    resTable += "<tbody><tr id='trid" + childArr.TCH_CHK_ID + "' class='trid" + childArr.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";

                                    if (childArr.TCH_DATA_TYPE == 'text' || childArr.TCH_DATA_TYPE == 'date') {
                                        resTable += '<td><input type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt" ></td>';
                                    } else if (childArr.TCH_DATA_TYPE == 'radio') {
                                        $setValArr = childArr.TCH_VALUE_SET.split("##");
                                        resTable += '<td>';
                                        $setValArr.forEach(function ($value, $key) {
                                            $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                            resTable += '<label for="checkPDI' + ($key + 1) + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                        });
                                        resTable += '</td>';
                                    } else if (childArr.TCH_DATA_TYPE == 'file') {
                                        resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + childArr.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                        txtRemark = '';
                                    }
                                    resTable += '<td>' + txtRemark + '</td>';
                                    resTable += "</tr></tbody>";
                                }
                            })
                        }
                    })
                    resTable += "</table>";
//                        console.log(resTable);
                    $('#tabMenuVHO').tabs('add', {
                        title: indexTab,
                        content: resTable,
                        closable: false
                    });
                    if (!$.isEmptyObject(data.AJAXCHASSISDTLS)) {
                        $("#ajaxChassisNo").html(data.AJAXCHASSISDTLS.CHASSSISNO);
                        $("#ajaxModelNo").html(data.AJAXCHASSISDTLS.TCD_MODEL);
                        $("#ajaxProtoType").html(data.AJAXCHASSISDTLS.TCD_PROTO_NO);
                        $("#ajaxWBSNo").html(data.AJAXCHASSISDTLS.TCD_WBS_LIST);
                        $("#ajaxProjCode").html(data.AJAXCHASSISDTLS.TCD_PROJ_CODE);
                        $("#ajaxVCNo").html(data.AJAXCHASSISDTLS.TCD_VC_NO);
                        $("#ajaxChassisInfoTbl").show();
                    }
                    if (!$.isEmptyObject(data.AJAXFIRDTLS)) {
                        $("#ajaxSLNo").html(1);
                        $("#ajaxFileName").html(data.AJAXFIRDTLS.TEU_FILE_NAME);
                        $("#ajaxType").html(data.AJAXFIRDTLS.TEU_ULD_TYPE);
                        var actStr = '<div class="ajax-file-upload-red" onclick="deleteFir(' + '\'' + data.AJAXFIRDTLS.TEU_CHASSIS_NO + '\'' + ',' + '\'' + data.AJAXFIRDTLS.TEU_FILE_NAME + '\'' + ',' + '\'' + data.AJAXFIRDTLS.TEU_SL_NO + '\'' + ')">Delete</div>';
                        actStr += '<div class="ajax-file-upload-green"><a href="' + data.AJAXFIRDTLS.TEU_FILE_PATH + '" style="color:#fff;text-decoration: none;" target="_blank">View</a></div>';
                        $("#ajaxAct").html(actStr);
                        $("#ajaxFirInfoTbl").show();
                    }
                    if ($.isEmptyObject(data.AJAXFIRDTLS)) {
                        $("#ajaxFirInfoTbl").hide();
                    }
                })

                if (!$.isEmptyObject(data.checkpointValue)) {
                    $('#txtModelNo').val(data.checkpointValue[0].TLD_MODEL_NO).attr('disabled', 'disabled');
                    $('#txtProtoType').val(data.checkpointValue[0].TLD_PROTO_TYPE).attr('disabled', 'disabled');
                    $('#txtEngineNo').val(data.checkpointValue[0].TLD_ENGINE_NO).attr('disabled', 'disabled');
                    $('#txtProjNo').val(data.checkpointValue[0].TLD_PROJECT_NAME).attr('disabled', 'disabled');
                    $('#txtWBSNo').val(data.checkpointValue[0].TLD_WBS_NO).attr('disabled', 'disabled');
                    $.each(data.checkpointValue, function (chkKey, chkVal) {
                        $('input[type="text"][name="checkPDI_' + chkVal.TCD_CHK_ID + '"]').val(chkVal.TCD_VALUE);
                        $('input[name="checkPDI_' + chkVal.TCD_CHK_ID + '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
                        $("#remarkBox_" + chkVal.TCD_CHK_ID).val(chkVal.TCD_REMARKS);
                    })
                }
                if (!$.isEmptyObject(data.LASTCOMMENT)) {
                    $("#last_comment").val(data.LASTCOMMENT.REMARK);
                    $("#pendUserName").html(data.LASTCOMMENT.PENDUSERNAME);
                } else {
                    $(".hideLastComent").hide();
                    $("#current_comment").css('width', '50%');
                }
                $("#tabMenuVHO").tabs('select', 0);
                $('#tabMenuVHO').find('input, textarea, button, select').attr('disabled', 'disabled');

            })
            $("#checklistFormBtn").show();
        }

    });




    function teamSubmit() {

        event.preventDefault();
        var cnt = 0;
        var memIDs = [];
        var searchIDs = $("input[type='checkbox'][name='teams']:checked").map(function () {
            return this.value;
        }).toArray();
        //console.log(searchIDs);
        if (searchIDs.length == 0) {
            alert('Please select Team!');
            return false;
        } else
        {

            $.each(searchIDs, function (index, item) {
                cnt = 0;
                // console.log(this);


                $("input[type='checkbox'][name='" + this + "']:checked").each(function ()
                {
                    cnt++;
                    memIDs.push(item + "_" + $(this).val());
                });
                if (cnt == 0)
                {
                    alert('You have missed selection from team,please select Team member from all group!');
                    return false;
                }

            });



        }
        if (cnt == 0)
        {

            return false;
        }
        //console.log(memIDs);
        if (memIDs.length == 0) {
            alert('Please select Team members!');
            return false;
        }

        if (!$("#ddlChassis").val()) {
            alert('Please select Chassis No!');
            $("#ddlChassis").focus();
            return false;
        }

        var confrm = confirm("Are you sure to proceed with this team members?");
        if (confrm) {
            $("#teamForm").ajaxSubmit({
                data: {
                    chassisNo: $("#ddlChassis").val(),
                    currComment: $("#current_comment").val(),
                    pendingUser: memIDs

                },
                success: function (response, status, xh) {
                    //console.log(response);return false;
                    $.messager.alert('Information...!', '<b style="color:green">' + response + '</b>', 'info');
                    //$('#teamForm')[0].reset();
                    openUrl(wwwRoot + "process/team_formation.php?menuid=29");
                }
            });
        }
    }
</script>
<style>
    .ajax-file-upload-green {
        background-color: #77b55a;
        border-radius: 4px;
        color: #fff;
        cursor: pointer;
        display: inline-block;
        font-family: arial;
        font-size: 13px;
        font-weight: normal;
        margin: 5px 10px 5px 0;
        padding: 4px 15px;
        text-decoration: none;
        text-shadow: 0 1px 0 #5b8a3c;
        vertical-align: top;
    }
    .ajax-file-upload-red {
        background-color: #e4685d;
        border-radius: 4px;
        box-shadow: 0 39px 0 -24px #e67a73 inset;
        color: #fff;
        cursor: pointer;
        display: inline-block;
        font-family: arial;
        font-size: 13px;
        font-weight: normal;
        margin: 5px 10px 5px 0;
        padding: 4px 15px;
        text-decoration: none;
        text-shadow: 0 1px 0 #b23e35;
        vertical-align: top;
    }
</style>