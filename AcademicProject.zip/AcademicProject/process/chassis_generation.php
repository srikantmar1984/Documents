<input type="hidden" id="hfPageTitle" value="Chassis Details" screen_id="">
<input type="hidden" id="hfAccessLevel" value="0">									
<?php include("./process_common_class.php"); ?>
<div id="mainContent" style="text-align:left">
    <div  class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
        <!--###############################CHASSIS SEARCH TAB START##################################################-->
        <div title="Search" data-options="iconCls:'icon-search'" style="padding:10px"> 		
            <input type="hidden" id="hfPlantId" value="<?php echo $_SESSION['userSessionInfo']["TUS_PLNT"]; ?>" >	
            <form id="frmChassis" name="frmChassis" method="post">
                <table width="100%">
                    <tr>
                        <td>
                            <span class="lblFieldLabel"><strong>Business Unit</strong> </span></td><td width="2%">&nbsp;
                        </td>
                        <td width="25%">
                            <select id="chcSrchBU" name="chcSrchBU" style="width:99%;"  class="ddlFieldDropdown"> 
                                <option value="">All</option>
                                <option value="CC">Commercial Vehicle Prototype</option>
                                <option value="PC">Passenger Vehicle Prototype</option>
                            </select>
                        </td>
                        <td align="right">
                            <span class="lblFieldLabel"><strong>GVW</strong> </span></td><td width="2%">&nbsp;
                        </td>
                        <td width="25%">
                            <input type="text" id="chcSrchGVW" name="chcSrchGVW" class="txtFieldTextBox" style="width:98%;" onkeypress="return numericOnly(event)" /> 
                        </td>
                        <td align="right">
                            <span class="lblFieldLabel"><strong>Wheel Base</strong> </span></td><td width="2%">&nbsp;
                        </td>
                        <td width="20%">
                            <input type="text" id="chcSrchWB" name="chcSrchWB" class="txtFieldTextBox" style="width:98%;" onkeypress="return numericOnly(event)" /> 
                        </td>
                    </tr>
                    <tr>
                        <td><span class="lblFieldLabel"><strong>Year </strong> </span></td><td width="2%">&nbsp;</td>
                        <td width="25%">
                            <select id="chcSrchYear" name="chcSrchYear" style="width:99%;"  class="ddlFieldDropdown">
                                <option value="">All</option>
                                <?php
                                for ($intYear = (date("Y") - 1); $intYear <= (date("Y")); $intYear++) {
                                    echo '<option value="' . substr($intYear, -2) . '" ' . ($intYear == date("Y") ? 'selected="selected"' : '') . '>' . $intYear . '</option>';
                                }
                                ?>
                            </select> 
                        </td>
                        <td align="right"><span class="lblFieldLabel"><strong>Month </strong> </span></td><td width="2%">&nbsp;</td>
                        <td width="20%">
                            <select id="chcSrchMonth" name="chcSrchMonth" style="width:99%;"  class="ddlFieldDropdown">
                                <option value="">All</option>
                                <?php
                                $month = 1; // current month
//                                        $month = date('n'); // current month
                                for ($x = 0; $x < 12; $x++) {
                                    ?>
                                    <option value="<?php echo date('m', mktime(0, 0, 0, $month + $x, 1)); ?>" 
                                            <?php echo date('m', mktime(0, 0, 0, $month + $x, 1)) == date('m') ? "selected='selected'" : ""; ?> >
                                                <?php echo date('F', mktime(0, 0, 0, $month + $x, 1)); ?>
                                            <?php } ?>
                            </select> 
                        </td>

                        <td align="right"><span class="lblFieldLabel"><strong>LH-RH </strong> </span></td><td width="2%">&nbsp;</td>
                        <td>
                            <select id="chcSrchLR" name="chcSrchLR" style="width:99%;"  class="ddlFieldDropdown"> 
                                <option value="">All</option>
                                <option value="L">L</option>
                                <option value="R">R</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><span class="lblFieldLabel"><strong>Created On </strong></span></td><td width="2%">&nbsp;</td>
                        <td> <input id="txtSrchFrom" name="txtSrchFrom"  class="kks-datebox" data-options="formatter:myformatter"  /> To <input id="txtSrchTo" name="txtSrchTo"  class="kks-datebox" data-options="formatter:myformatter"  /></td>
                        <td align="right"><span class="lblFieldLabel"><strong>Chassis No</strong>  </span></td><td width="2%">&nbsp;</td>
                        <td>
                            <input type="text" id="chcSrchChsNo" name="chcSrchChsNo" class="txtFieldTextBox" style="width:98%;" /> 
                        </td>
                        <td align="right">
                            <span class="lblFieldLabel"><strong>Project Code </strong></span></td><td width="2%">&nbsp;
                        </td>
                        <td width="20%">
                            <input type="text" id="chcSrchProjCode" name="chcSrchProjCode" class="txtFieldTextBox" style="width:98%;" /> 
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <span class="lblFieldLabel"><strong>Engine No </strong></span>
                        </td><td width="2%">&nbsp;</td>
                        <td> 
                            <input id="txtSrchEngine" name="txtSrchEngine"  class="txtFieldTextBox"   /> 
                        </td>
                        <td align="right"><span class="lblFieldLabel"><strong>WBS List</strong>  </span></td><td width="2%">&nbsp;</td>
                        <td>
                            <select id="chcSrchWBSList" name="chcSrchWBSList" style="width:99%;"  class="ddlFieldDropdown">
                                <option value="">All</option>
                                <?php
//                                                                var_dump($webApi->bcDetails());
                                $wbsList = $process->wbsList();
                                foreach ($wbsList as $key => $wbsEach) {
                                    echo '<option value="' . $wbsEach['WBSLIST'] . '" >' . $wbsEach['WBSLIST'] . '</option>';
                                }
                                ?>
                            </select>
                        </td>
                        <td align="right">
                            <span class="lblFieldLabel"><strong>VC No </strong></span></td><td width="2%">&nbsp;
                        </td>
                        <td width="20%">
                            <input type="text" id="chcSrchVC" name="chcSrchVC" class="txtFieldTextBox" style="width:98%;" /> 
                        </td>
                    </tr>
                    <tr height="15">

                    </tr>
                    <tr>
                        <td colspan="8"> &nbsp; <a href="javascript:void(0)" class="kks-linkbutton" onclick="searchData()">Search</a>  &nbsp; <a href="javascript:void(0)" class="kks-linkbutton" onclick="clearChassisData()">Clear All</a></td>
                    </tr>
                </table>
                <div class="Grid" id="listChassisDtls">
                    <table cellpadding="0" cellspacing="0"  id="grduser" style="padding-right:8px;">
                        <thead>
                            <tr>
                                <th width="3%">SL. NO.</th>
                                <th >Chassis No</th>
                                <th>Business Unit</th>
                                <th>GVW</th>
                                <th>Wheel Base</th>
                                <th>Year</th>
                                <th>Month</th>
                                <th>LH-RH</th>
                                <th>Location</th>

                                <th >Engine No</th>
                                <th>Invoice No</th>
                                <th style="width:100Px">Invoice Date</th>
                                <th style="width:150Px">WBS</th>
                                <th style="width:80Px">Tyre Size</th>
                                <th>Model</th>
                                <th>Project Code</th>
                                <th style="width:100Px">Release</th>
                                <th style="width:100Px">VC</th>
                                <th>Old Chassis</th>
                                <th>Proto TYpe No</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="res">

                        </tbody>
                        <tbody id="tr_clone_sub" style="display:none"></tbody>
                    </table>
                </div>           
            </form>


        </div>
        <!--###############################CHASSIS SEARCH TAB END##################################################-->

        <!--###############################CREATE CHASSIS TAB START##################################################-->
        <div title="Create Chassis No" data-options="iconCls:'icon-add'" style="padding:10px;">
            <div id="divChassisAdd" class="Grid" >
                <form id="crtChassisFrm" method="post">
                    <table border="0" cellpadding="0" cellspacing="0" style="width: 100%; vertical-align:top">
                        <tbody>
                            <tr style="height: 22Px;">
                                <td colspan="6" style=" padding-left: 5px;">
                                    <b><u>Create Chassis No</u></b>
                                </td>
                            </tr>
                            <tr>
                                <td width="11%">
                                    <span  class="lblFieldLabel">Business Unit</span>
                                </td>
                                <td width="33%">
                                    <select id="chcAddBU" name="chcAddBU" style="width:99%;"  class="ddlFieldDropdown kks-validatebox" required="true"> 
                                        <option value="">--Select--</option>
                                        <option value="PC">Commercial Vehicle Prototype</option>
                                        <option value="CC">Passenger Vehicle Prototype</option>
                                    </select>
                                </td>
                                <td width="7%">
                                    <span  class="lblFieldLabel">GVW</span>
                                </td>
                                <td width="25%" >
                                    <input type="text" id="chcAddGVW" name="chcAddGVW" class="txtFieldTextBox kks-validatebox" required="true" style="width:98%;" onkeypress="return numericOnly(event)" /> 
                                </td>
                                <td width="9%">
                                    <span  class="lblFieldLabel">Wheel Base</span>
                                </td>
                                <td width="15%" >
                                    <input type="text" id="chcAddWB" name="chcAddWB" class="txtFieldTextBox kks-validatebox" required="true" style="width:98%;" onkeypress="return numericOnly(event)" /> 
                                </td>
                            </tr>
                            <tr>
                                <td width="11%">
                                    <span  class="lblFieldLabel">Year</span>
                                </td>
                                <td width="33%">
                                    <select id="chcAddYear" name="chcAddYear" style="width:99%;"  class="ddlFieldDropdown kks-validatebox" required="true">
                                        <option value="">--Select--</option>
                                        <?php
                                        for ($intYear = (date("Y") - 1); $intYear <= (date("Y")); $intYear++) {
                                            echo '<option value="' . substr($intYear, -2) . '" ' . ($intYear == date("Y") ? 'selected="selected"' : '') . '>' . $intYear . '</option>';
                                        }
                                        ?>
                                    </select> 
                                </td>
                                <td width="7%">
                                    <span class="lblFieldLabel">Month</span>
                                </td>
                                <td colspan="1" >
                                    <select id="chcAddMonth" name="chcAddMonth" style="width:99%;"  class="ddlFieldDropdown kks-validatebox" required="true">
                                        <option value="">--Select--</option>
                                        <?php
                                        $month = 1; // current month
//                                        $month = date('n'); // current month
                                        for ($x = 0; $x < 12; $x++) {
                                            ?>
                                            <option value="<?php echo date('m', mktime(0, 0, 0, $month + $x, 1)); ?>" 
                                                    <?php echo date('m', mktime(0, 0, 0, $month + $x, 1)) == date('m') ? "selected='selected'" : ""; ?> >
                                                        <?php echo date('F', mktime(0, 0, 0, $month + $x, 1)); ?>
                                                    <?php } ?>
                                    </select> 
                                </td>
                                    <!--<input type="text" id="txtCrtEmail" name="txtCrtEmail" class="txtFieldTextBox kks-validatebox" required="true" validType="email" style="width:98%;" />--> 
                                <td width="11%"><span class="lblFieldLabel">LH-RH</span></td>
                                <td width="33%" >
                                    <select id="chcAddLR" name="chcAddLR" style="width:99%;"  class="ddlFieldDropdown"> 
                                        <option value="L">L</option>
                                        <option value="R">R</option>
                                    </select> 
                                </td>
                            </tr>
                            <tr>

                                <td width="7%">
                                    <span class="lblFieldLabel">Location</span>
                                </td>
                                <td width="25%" >
                                    <select id="chcAddPlant" name="chcAddPlant" style="width:99%;"  class="ddlFieldDropdown">
                                        <option value="J">JSR</option>
                                        <option value="P">PUN</option>
                                        <option value="L">LKO</option>

                                    </select>
                                </td>
                            </tr>


                        </tbody>
                    </table>

                    <br>
                    <a id="btnCreate" href="javascript:void(0)" class="kks-linkbutton" onclick="$('#crtChassisFrm').submit()"  >Create</a>
                </form>
            </div>
        </div> 
        <!--###############################CREATE CHASSIS TAB END##################################################-->


    </div>
</div>
<div id="error"></div>


<script type="text/javascript" src="js/jquery.kksui.min.js"></script>
<script type="text/javascript" >
var url = wwwRoot + "process/chassis_generation_action.php";

$(document).ready(function () {
    $('.layout-button-left').trigger('click');
    /*
     * Submit Create Chassis No Form
     * @@@This is called while user is newly added
     */
    $('#crtChassisFrm').form({
        url: url + "?action=createChassis",
        onSubmit: function () {
            var wbNo = $("#chcAddWB").val();
            error = 1;
            if (wbNo && (wbNo < 32 || wbNo > 99)) {
                $.messager.alert('Error...!', '<b style="color:red">Please enter wheel base number in between 32 to 99!</b>', 'error');
                error = 0;
            }
            if (error && $(this).form('validate')) {
                return true;
            } else {
                return false;
            }
        },
        success: function (data) {
            $.messager.alert('Information...!', '<b style="color:green">' + data + '</b>', 'info');
            $('#crtChassisFrm')[0].reset();
        }
    });



});
/*
 * Search Users according to the searching criteria search
 */
function searchData() {
    $.post(url,
            {
                searchBU: $("#chcSrchBU").val().trim(),
                searchGVW: $("#chcSrchGVW").val().trim(),
                searchWB: $("#chcSrchWB").val().trim(),
                searchYR: $("#chcSrchYear").val().trim(),
                searchMON: $("#chcSrchMonth").val().trim(),
                searchLR: $("#chcSrchLR").val().trim(),
                searchCHSNO: $("#chcSrchChsNo").val().trim(),
                CreatedFrom: $('input[name=txtSrchFrom]').val().trim(),
                CreatedTo: $('input[name=txtSrchTo]').val().trim(),
                searchEngineNo: $("#txtSrchEngine").val().trim(),
                searchWBSList: $("#chcSrchWBSList").val().trim(),
                searchVCNo: $("#chcSrchVC").val().trim(),
                action: "AllChassisList"
            },
            function (data) {
                data = jQuery.parseJSON(data);
//            console.log(data);//return false;
                $('#res').empty();
                if (data.ChassisDtls != undefined) {
                    if (data.ChassisDtls.length > 0) {
                        var tblStr = '';
                        $.each(data['ChassisDtls'], function (i, eachChassis) {
                            //tblStr +='<tr id="' + eachChassis['TCD_CHASSIS_NO'] + '">';
                            tblStr += '<tr>';
                            tblStr += '<td>' + eachChassis['TCD_SLNO'] + '</td>';
                            tblStr += '<td>' + eachChassis['TCD_CHASSIS_NO'] + '</td>';
                            tblStr += '<td>' + eachChassis['TCD_BU'] + '</td>';
                            tblStr += '<td>' + eachChassis['TCD_GVW'] + '</td>';
                            tblStr += '<td>' + eachChassis['TCD_WB'] + '</td>';
                            tblStr += '<td>' + eachChassis['TCD_YR'] + '</td>';
                            tblStr += '<td>' + eachChassis['TCD_MONTH'] + '</td>';
                            tblStr += '<td>' + eachChassis['TCD_LH_RH'] + '</td>';
                            tblStr += '<td>' + eachChassis['TCD_LOCN'] + '</td>';

                            tblStr += '<td id="EDTENGINE">' + eachChassis['TCD_ENGINE'] + '</td>';
                            tblStr += '<td id="EDTINVNO">' + eachChassis['TCD_INVOICE'] + '</td>';
                            tblStr += '<td id="EDTINVDATE">' + eachChassis['TCD_INV_DATE'] + '</td>';
                            tblStr += '<td id="EDTWBSLIST">' + eachChassis['TCD_WBS_LIST'] + '</td>';
                            tblStr += '<td id="EDTTYRE">' + eachChassis['TCD_TYRE'] + '</td>';
                            tblStr += '<td id="EDTMODEL">' + eachChassis['TCD_MODEL'] + '</td>';
                            tblStr += '<td id="EDTPROJCODE">' + eachChassis['TCD_PROJ_CODE'] + '</td>';
                            tblStr += '<td id="EDTREL">' + eachChassis['TCD_VC_REL'] + '</td>';
                            tblStr += '<td id="EDTVC">' + eachChassis['TCD_VC_NO'] + '</td>';
                            tblStr += '<td id="EDTOLDCHS">' + eachChassis['TCD_OLD_CHASSIS'] + '</td>';
                            tblStr += '<td id="EDTPROTO">' + eachChassis['TCD_PROTO_NO'] + '</td>';
                            tblStr += '<td id="action"><a id="btnEditCHS" chsno="' + eachChassis['TCD_CHASSIS_NO'] + '"  href="javascript:void(0)"><img src="images/edit.png"  title="Edit"/></a></td>';
                            tblStr += '</tr>';
                        });
                        $('#res').append(tblStr);
                    }
                } else {
                    alert('No Data Found');

                }
            });
}

function clearChassisData() {
    $('#frmChassis')[0].reset();
    $('#res').html('');
}

//========================================== Edit Chassis Details =============================================================
//===========================================================================================================================
function filloption(strItem, $id, $selId = NULL, ext = NULL){
    if (strItem == "VC") {
        if (ext.trim().length == 0) {
            alert('Project Code mandatory for VC');
            return false;

        }
        $.post(url,
                {
                    projCode: ext,
                    action: "vcListReturn"
                },
                function (data) {
                    data = jQuery.parseJSON(data);
                    var vcOpt = '<option value="">--Select--</option>';
                    $.each(data['ALLVCLIST'], function (i, eachVC) {

                        vcOpt += "<option value='" + eachVC.PARTNUMBER + "'>" + eachVC.PARTNUMBER + "</option>";
                    })
                    $("#" + $id).html(vcOpt);
                    if ($selId.length > 0)
                    {
                        $('#' + $id).val($selId);
                    }
                    $("#imgEditWait").fadeOut();
                });

    } else {
        $.post(wwwRoot + "process/chassis_generation_action.php",
                {
                    itm: strItem,
                    ext: ext,
                    action: "fillOptions"
                },
                function (data) {

                    $('#' + $id).html(data);
                    if ($selId.length > 0)
                    {
                        $('#' + $id).val($selId);
                    }
                });
}

//return strOptions;
}

$('#btnEditCHS').die('click').live('click', function () {
    if ($("#tr_clone_sub").html() != '') {
        alert("Please complete your previous action!");
    } else {
        var parent = $(this).parent().parent();

        //Clone the selected Row
        var clone = parent.clone();
        $("#tr_clone_sub").html(clone);
        var chsNO = $(this).attr('chsno');

        var ch = parent.find("#EDTWBSLIST");
        var WBSId = ch.html();
        ch.html('<select id="edtWBSLISTVal" name="edtWBSLISTVal" style="width:99%" class="ddlFieldDropdown"></select>');
        $('#chcSrchWBSList option').clone().appendTo('#edtWBSLISTVal');
        $("#edtWBSLISTVal").val(WBSId);


        var chTYRE = parent.find("#EDTTYRE");
        var TYREId = chTYRE.html();
        chTYRE.html('<select id="edtTYREVal" name="edtTYREVal" style="width:99%" class="ddlFieldDropdown"></select>');
        var optionlist = filloption("TYRE", "edtTYREVal", TYREId, '');


        var projCode = "";

        var chENGINE = parent.find("#EDTENGINE");
        chENGINE.html('<input id="subENGINEVal" type="text" value="' + chENGINE.text() + '" style="width:99%"  class="txtFieldTextBox"  />');
        var chSubINVNO = parent.find("#EDTINVNO");
        chSubINVNO.html('<input id="subINVNOVal" type="text" value="' + chSubINVNO.text() + '" style="width:99%"  class="txtFieldTextBox"  />');
        var chSubPROJCODE = parent.find("#EDTPROJCODE");
        projCode = chSubPROJCODE.text();
        chSubPROJCODE.html('<input id="subPROJCODEVal" type="text" value="' + chSubPROJCODE.text() + '" style="width:99%"  class="txtFieldTextBox"  />');
        var chSubOLDCHS = parent.find("#EDTOLDCHS");
        chSubOLDCHS.html('<input id="subOLDCHSVal" type="text" value="' + chSubOLDCHS.text() + '" style="width:99%"  class="txtFieldTextBox"  />');

        var chSubProto = parent.find("#EDTPROTO");
        chSubProto.html('<input id="subProtoVal" type="text" value="' + chSubProto.text() + '" style="width:99%"  class="txtFieldTextBox"  />');

        var chSubMODEL = parent.find("#EDTMODEL");
        chSubMODEL.html('<input id="subMODELVal" type="text" value="' + chSubMODEL.text() + '" style="width:99%"  class="txtFieldTextBox"  />');

        var chSubINVDATE = parent.find("#EDTINVDATE");
        chSubINVDATE.html(' <input id="subINVDATEVal" name="subINVDATEVal"  class="datepicker"  value="' + chSubINVDATE.text() + '"   />');
        $('.datepicker').datepick({showOnFocus: true, dateFormat: 'dd-M-yyyy'});


        var chSubRel = parent.find("#EDTREL");
        var chSubVC = parent.find("#EDTVC");
        var VCId = chSubVC.html();
        var RelId = chSubRel.html();

        var imgloadurl = "images/small-spinner.gif";
        if (RelId == "Yes") {
            chSubRel.html(' <input type="radio" id="subRelYes" name="edtRel" value="1" onclick="rdbchange()" Checked />Yes <input type="radio" id="subRelNo" onclick="rdbchange()" name="edtRel" value="0" />No');
            chSubVC.html('<select id="edtVCVal" name="edtVCVal" style="width:99%" class="ddlFieldDropdown"></select><img id="imgEditWait" src="images/small-spinner.gif"  alt="Wait">');

            var optionlist = filloption("VC", "edtVCVal", VCId, projCode);

        } else
        {
            chSubRel.html(' <input type="radio" id="subRelYes" name="edtRel" onclick="rdbchange()" value="1" />Yes <input type="radio" id="subRelNo" name="edtRel" onclick="rdbchange()"  value="0" Checked />No');
            chSubVC.html('<input id="txtVCVal" type="text" value="' + chSubVC.text() + '" style="width:99%"  class="txtFieldTextBox"  />');
        }


        var ch6 = parent.find("#action");
        ch6.html('<a id="btnUpdateSubCat" chsno="' + chsNO + '"  href="javascript:void(0)"><img src="images/accept.png" title="Update"  /></a> &nbsp; <a id="btnCancelSubCat" href="javascript:void(0)"><img src="images/cancel.png" title="Cancel"  /></a>');

    }

});


$('#btnUpdateSubCat').die('click').live('click', function () {
    var chsno = $(this).attr('chsno');
    var parent = $(this).parent().parent();
    var subMODELVal = parent.find("#subMODELVal").val().trim();
    var subENGINEVal = parent.find("#subENGINEVal").val().trim();
    var subINVNOVal = parent.find("#subINVNOVal").val().trim();
    var subINVDATEVal = parent.find("#subINVDATEVal").val().trim();
    var subPROJCODEVal = parent.find("#subPROJCODEVal").val().trim();
    var subOLDCHSVal = parent.find("#subOLDCHSVal").val().trim();
    var subProtoVal = parent.find("#subProtoVal").val().trim();
    var edtTYREVal = parent.find("#edtTYREVal").val().trim();
    var edtWBSLISTVal = parent.find("#edtWBSLISTVal").val().trim();
    var rdbval = parent.find("input[type='radio'][name='edtRel']:checked").val();
    var rdbVC = "";
    if (rdbval == "1") {
        rdbVC = parent.find("#edtVCVal option:selected").text().trim();
    } else
    {
        rdbVC = parent.find("#txtVCVal").val().trim();
    }
    //console.log(chsno +":"+subENGINEVal +":"+subMODELVal +":"+subINVNOVal  +":"+subINVDATEVal  +":"+subPROJCODEVal  +":"+subOLDCHSVal  +":"+edtTYREVal  +":"+edtWBSLISTVal +":"+rdbval +":"+rdbVC);

    $.ajax({
        type: 'POST',
        url: wwwRoot + "process/chassis_generation_action.php",
        data: {
            action: 'updateChassis',
            chsno: chsno,
            subENGINEVal: subENGINEVal,
            subMODELVal: subMODELVal,
            subINVNOVal: subINVNOVal,
            subINVDATEVal: subINVDATEVal,
            subPROJCODEVal: subPROJCODEVal,
            subOLDCHSVal: subOLDCHSVal,
            subProtoVal: subProtoVal,
            edtTYREVal: edtTYREVal,
            edtWBSLISTVal: edtWBSLISTVal,
            rdbval: rdbval,
            rdbVC: rdbVC

        },
        success: function (data) {
            if (data == '0') {
                alert('Updated sucessfully');
                parent.find("#EDTENGINE").html(subENGINEVal);
                parent.find("#EDTMODEL").html(subMODELVal);
                parent.find("#EDTINVNO").html(subINVNOVal);
                parent.find("#EDTINVDATE").html(subINVDATEVal);
                parent.find("#EDTPROJCODE").html(subPROJCODEVal);
                parent.find("#EDTOLDCHS").html(subOLDCHSVal);
                parent.find("#EDTPROTO").html(subProtoVal);
                parent.find("#EDTTYRE").html(edtTYREVal);
                parent.find("#EDTWBSLIST").html(edtWBSLISTVal);
                if (rdbval == "1") {
                    parent.find("#EDTREL").html("Yes");
                } else {
                    parent.find("#EDTREL").html("No");
                }

                parent.find("#EDTVC").html(rdbVC);

                parent.find("#action").html('<a  id="btnEditCHS" chsno="' + chsno + '"   href="javascript:void(0)"><img src="images/edit.png" title="Edit"  /></a>');
                $("#tr_clone_sub").html('');
            } else {
                alert('Error During Submit !');
            }

        }
    });
});

$('#btnCancelSubCat').die('click').live('click', function () {

    var parent = $(this).parent().parent();
    var clone = $("#tr_clone_sub").html();

    clone = clone.replace('<tr>', '');
    clone = clone.replace('</tr>', '');

    parent.html(clone.replace('<tr>', ''));
    $("#tr_clone_sub").html('');

});


function rdbchange() {
    var projCode = $("#subPROJCODEVal").val().trim();
    if (projCode) {
        var confMsg = 'Project Code should correct for VC.  Are you sure your Project code is correct?';
        if (confirm(confMsg))
        {
            var rdbval = $("input[type='radio'][name='edtRel']:checked").val();
            var parent = $("input[type='radio'][name='edtRel']:checked").parent().parent();
            var chSubVC = parent.find("#EDTVC");



            if (rdbval == "1") {
                var VCId = $("#txtVCVal").val();
                chSubVC.html('<select id="edtVCVal" name="edtVCVal" style="width:99%" class="ddlFieldDropdown"></select><img id="imgEditWait" src="images/small-spinner.gif"  alt="Wait">');

                var optionlist = filloption("VC", "edtVCVal", VCId, projCode);

            } else
            {
                var VCId = $("#edtVCVal").val();
                chSubVC.html('<input id="txtVCVal" type="text" value="' + VCId + '" style="width:99%"  class="txtFieldTextBox"  />');
            }
        } else {
            $("input[name=edtRel][value=0]").prop('checked', true);
        }
    } else {
        $("input[name=edtRel][value=0]").prop('checked', true);
        alert("Project Code mandatory for VC");
    }


}
//=============================================================================================================================


</script>
<?php // echo "<script> hideDetail();  </script>"  ?>
<?php // echo "<script> findAccessLevel(); hideDetail();  </script>"   ?>
