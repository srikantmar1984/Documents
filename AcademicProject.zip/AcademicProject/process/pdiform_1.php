<?php include("./process_common_class.php"); ?>
<input type="hidden" id="hfPageTitle" value="PDI Form" screen_id="">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<div class="Grid" style="text-align: left;">
    <form name="iirreport" class="iirreport" id="logInc">
        <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td colspan="4">
                        <span>
                            <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                            <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select Chassis No--</option>
                                <?php
                                $chassisDtlArr = $process->chassisDetails();
//                                print_r($chassisDtlArr);
                                foreach ($chassisDtlArr as $value) {
                                    echo '<option value="' . $value['TCD_CHASSIS_NO'] . '" >' . $value['TCD_CHASSIS_NO'] . '</option>';
//                                    echo '<option data-modelType="' . $value['MODEL_TYPE'] . '" value="' . $value['CHASSIS_NO'] . '" data-modelTypeNo="' . $value['MODEL_TYPE_NO'] . '" data-protoTypeNo="' . $value['PROTO_TYP_NO'] . '" data-enggNo="' . $value['ENG_NO'] . '" data-wbsNo="' . $value['WBS_NO'] . '" data-projectCode="' . $value['PROJECT_CODE'] . '">' . $value['CHASSIS_NO'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>
                        
                        <span style="display: none" id="pdiTypeSpan" >
                            <label for="ddlChassis" id="lblYes" ><b>Engineer Type:</b></label>
                            <?php
                            $elec = "";
                            $mech = "";
                            $disbl = "";
                            
                            if (array_key_exists(8, $_SESSION['userSessionInfo']['ROLES'])) {
                                $mech = "selected='Selected'";
                                $elec = " ";
                                $disbl = 'disabled="disabled"';
                            } else if (array_key_exists(11, $_SESSION['userSessionInfo']['ROLES'])) {
                                $elec = "selected='Selected'";
                                $mech = " ";
                                $disbl = 'disabled="disabled"';
                            }
                            ?>
                            <select id="pdiEnggType" <?php echo $disbl; ?>>
                                <option value="">--Select--</option>
                                <option <?php echo $mech; ?> value="Mechanical">Mechanical Engineer</option>
                                <option <?php echo $elec; ?> value="Electrical">Electrical Engineer</option>
<!--                                <option <?php // echo $mech; ?> value="Mechanical">Mechanical Engineer</option>
                                <option <?php // echo $elec; ?> value="Electrical">Electrical Engineer</option>-->
                            </select>
                        </span>
                    </td>
                </tr>
                <tr style="height:24px">
                    <td colspan="4">
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="txtModelNo" id="lblModelNo" ><b>Model No:</b></label>
                            <input id="txtModelNo" type="text" style="width:11%;" /><!--<input id="txtModelNo" type="text" style="width:15%;background:  #E3E3E3" />-->
                        </span>
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="txtProtoType" id="lblProtoType" ><b>Proto Type:</b></label>
                            <input id="txtProtoType" type="text" style="width:11%;" />
                        </span>
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="txtEngineNo" id="lblEngineNo" ><b>Engine No:</b></label>
                            <input id="txtEngineNo" type="text" style="width:11%;" />
                        </span>
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="txtWBSNo" id="lblWBSNo" ><b>WBS No:</b></label>
                            <input id="txtWBSNo" type="text" style="width:11%;" />
                        </span>
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="txtProjNo" id="lblProjNo" ><b>Project Code:</b></label>
                            <input id="txtProjNo" type="text" style="width:11%;" />
                        </span>
                    </td>
                </tr>
            </tbody>
            <tr style="height:40px">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <!--<b>Check List</b>-->
                        <b>PDI CHECKLIST FOR ERC PROTO VEHICLES</b>
                    </span>
                </td>
            </tr>
<!--            <tbody id="bdyCheckList" style="display: none;background-color: #EFF3FB;">
                
            </tbody>-->
        </table>
         <div id="tabMenuVHO" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
            <!--Tabs are added dynamically here-->
        </div>
        <div id="checklistFormBtn" style="margin:10px;display: none">
            <a href="javascript:void(0);" class="kks-linkbutton l-btn,confirm" align="left" onclick="confirmClear();">
                <span style="text-align:left;" >Clear All</span>
            </a>	

            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" onclick="savePdi('saveData');">
                <span  style="text-align:left;" >Save data</span>
            </a>
            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" id="linkSubmitPaps" onclick="savePdi('submitData');">
                <span  style="text-align:left;" >Submit</span>				 
            </a>
        </div>

    </form>
</div>
<script type="text/javascript">
        var url = wwwRoot + "process/pdiform_action.php";
    $(function () {
        $('.layout-button-left').trigger('click');
        $("#ddlChassis").change(function () {

            if ($(this).val()) {
                $("#pdiEnggType").trigger('change');
//                $("#txtModelNo").val($('option:selected', $(this)).data('modeltypeno')).attr('readonly', true);
                $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan").show();
            } else {
//                $("#txtModelNo").val('').attr('readonly', true);
                $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan,#bdyCheckList,#checklistFormBtn").hide();
            }
        })
        $("#pdiEnggType").change(function () {
             var tabNos = $('.tabs >li').length;
            for (i = 0; i < tabNos; i++) {
                $("#tabMenuVHO").tabs('close', 0);
            }
            if ($(this).val()) {
                //ajax call for ji list
                var menuid = $("#urlMenuID").val();
                $.post(url, {action: "pdiCheckList", chassisNo: $("#ddlChassis").val(),menuid:menuid}, function () {
                }, 'JSON').done(function (data) {
                    console.log(data);return false;
                    var resTable = '';
                    $.each(data.checkpointData, function (indexTab, tabDetails) {
                        var resTable = '<table style="background-color: #EFF3FB;">';
                        var parntInc = 0;
                        $.each(tabDetails, function (indexPrnt, parentDetails) {
                            if ($.type(parentDetails) == 'object') {
                            parntInc++;
                                var childInc = 0;
                                //Thead
                                if (parentDetails.TCH_INCRIMENTAL) {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='2'>" + parentDetails.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr"+parentDetails.TCH_CHK_ID+"\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr"+parentDetails.TCH_CHK_ID+"\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                                    resTable += "<tbody><tr class='trid"+parentDetails.TCH_CHK_ID+"' id='addmoreTr"+parentDetails.TCH_CHK_ID+"'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                                    if(parentDetails.TCH_DATA_TYPE == 'file'){
                                        resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,'+parentDetails.TCH_CHK_ID+');" width="150Px"  value="Upload File"/></td>';
                                        txtRemark = '';
                                    }else{
                                        resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                                        txtRemark = '<textarea maxlength="1900" id="remarkBox_'+parentDetails.TCH_CHK_ID+'" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                    }
                                    resTable += '<td>'+txtRemark+'</td>';
                                    resTable += "</tr></tbody>";
                                } else {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                                }
                                //Tbody
                                $.each(parentDetails, function (index, childArr) {
                                    childInc++;
                                    if ($.type(childArr) == 'object') {
                                        txtRemark = '<textarea maxlength="1900" rows="2" id="remarkBox_'+childArr.TCH_CHK_ID+'" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                        resTable += "<tbody><tr id='trid"+childArr.TCH_CHK_ID+"' class='trid"+childArr.TCH_CHK_ID+"'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";

                                        if (childArr.TCH_DATA_TYPE == 'text') {
                                            resTable += '<td><input type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt" ></td>';
                                        } else if (childArr.TCH_DATA_TYPE == 'radio') {
//                                            resTable += '<td><input type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt" ></td>';
                                            $setValArr = childArr.TCH_VALUE_SET.split("##");
                                            resTable += '<td>';
                                            $setValArr.forEach(function ($value, $key) {
                                                $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                                resTable += '<label for="checkPDI' + ($key + 1) + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                            });
                                            resTable += '</td>';
                                        } else if (childArr.TCH_DATA_TYPE == 'file') {
                                            resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,'+childArr.TCH_CHK_ID+');" width="150Px"  value="Upload File"/></td>';
                                            txtRemark = '';
                                        }
                                        resTable += '<td>'+txtRemark+'</td>';
                                        resTable += "</tr></tbody>";
                                    }
                                })
                            }
                        })
//                        console.log(indexPr);
//                        console.log(element);
                        resTable += "</table>";
                                $('#tabMenuVHO').tabs('add',{
                                    title:indexTab,
                                    content:resTable,
                                    closable:false
                                });
                       
                    })
                    
                    if(!$.isEmptyObject(data.checkpointValue)){
//                        alert(data.checkpointValue[0].TCD_CHK_ID);
//                        $('#ddlChassis').val();
                        $('#txtModelNo').val(data.checkpointValue[0].TLD_MODEL_NO);
                        $('#txtProtoType').val(data.checkpointValue[0].TLD_PROTO_TYPE);
                        $('#txtEngineNo').val(data.checkpointValue[0].TLD_ENGINE_NO);
                        $('#txtProjNo').val(data.checkpointValue[0].TLD_PROJECT_NAME);
                        $('#txtWBSNo').val(data.checkpointValue[0].TLD_WBS_NO);
                        $.each(data.checkpointValue, function (chkKey, chkVal) {
                            $('input[type="text"][name="checkPDI_' + chkVal.TCD_CHK_ID+ '"]').val(chkVal.TCD_VALUE);
//                            $('input[name="checkPDI_' + chkVal.TCD_CHK_ID+ '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
                            $('input[name="checkPDI_' + chkVal.TCD_CHK_ID+ '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
                            $("#remarkBox_"+chkVal.TCD_CHK_ID).val(chkVal.TCD_REMARKS);
                        })
                    }
                    
//                    $("#tabMenuVHO").html(resHtmlStr).show();
                
                $("#tabMenuVHO").tabs('select', 0);
                })
//                $("#pdiEnggType").trigger('change');
//                $("#txtModelNo").val($('option:selected', $(this)).data('modeltypeno')).attr('readonly', true);
                $("#checklistFormBtn").show();
            } else {
                $("#tabMenuVHO").tabs('close', 0);
                $("#tabMenuVHO").tabs('close', 0);
                $("#tabMenuVHO").tabs('close', 0);
                $("#vhdFormBtn").hide();
            }
            /*if ($(this).val()) {
                $.post(url, {enggType: $(this).val(), action: "pdiCheckList"},function(){},"JSON")
                        .done(function (data) {
                            var $resTable = '';
                            $.each(data, function (index, element) {
                                if (element.TCH_PARENT_ID) {
                                    $resTable += "<tr><td>" + element.TCH_CHECK_POINT + "</td></tr>";
                                } else {
                                    $resTable += "<tr><td width='3%'>" + (index+1) + "</td>";
                                    $resTable += "<td width='35%'><span class='checkHead'>" + element.TCH_CHECK_POINT + "</span></td>";
                                    $resTable += '<td width="30%">';
                                    if (element.TCH_DATA_TYPE == 'radio') {
//                                        $setValArr = explode('##', $row['TCH_VALUE_SET']);
                                        $setValArr = element.TCH_VALUE_SET.split("##");
                                        $setValArr.forEach(function ($value, $key) {
                                            $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                            $resTable += '<label for="checkPDI' + ($key + 1) + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + element.TCH_CHK_ID + '" checklist_id="' + element.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                        });
                                    } else if (element.TCH_DATA_TYPE == 'text') {
                                        $resTable += '<input type="text" name="checkPDI_' + element.TCH_CHK_ID + '" checklist_id="' + element.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt" >';
                                    }
                                    $resTable += '</td>';
                                    $resTable += '<td width="30%" ><textarea maxlength="1900" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                    $resTable += "</td></tr>";
                                }
                            })
//                            console.log(data);                    
                            $("#bdyCheckList").html($resTable);
                            $('#checklistFormBtn').show();
                        })

            } else {
                $("#bdyCheckList").html('');
                $("#bdyCheckList,#checklistFormBtn").hide();
            }*/
        })
    })

    function savePdi(type) {
//        alert($('.checkpdiInpt').length);
//        alert($(':radio[class="checkpdiInpt"]').length/3);
//        alert($(':radio[class="checkpdiInpt"]:checked').length);
        
        var totalField = $('.checkpdiInpt').length;
        var totalRadio = $(':radio[class="checkpdiInpt"]').length;
        var totalText = totalField - totalRadio;
        var totalRadioBlck = totalRadio/3;
        var checkedRadio = $(':radio[class="checkpdiInpt"]:checked').length;
//        alert(totalField+"$$$$"+totalRadio+"$$$$"+totalText+"$$$$"+totalRadioBlck+"$$$$"+checkedRadio);
        if(type == "submitData"){
            if(checkedRadio !=totalRadioBlck){
                alert("Please check all PDI checklist!");
                return false;
            }
            var cntTxt = 0;
            $(':text[class="checkpdiInpt"]').each(function(){
                if(!$(this).val()){
                    cntTxt = 1;          
                }
            })
            if(cntTxt){
                alert("Please check all PDI checklist!");
                return false;
            }
        }
//        var protoTypeNo = $('#ddlChassis option:selected').data('prototypeno');
        var chassisNo = $('#ddlChassis').val();
        var modelNo = $('#txtModelNo').val().trim();
        var protoTypeNo = $('#txtProtoType').val().trim();
        var enggNo = $('#txtEngineNo').val().trim();
        var projectName = $('#txtProjNo').val().trim();
        var wbsNo = $('#txtWBSNo').val().trim();
//        var enggNo = $('#ddlChassis option:selected').data('enggno');
//        var projectName = $('#ddlChassis option:selected').data('projectcode');
//        var wbsNo = $('#ddlChassis option:selected').data('wbsno');
//        var modelNo = $('#txtModelNo').val();
        var enggType = $("#pdiEnggType").val();
//        alert(enggType);
        var checklistObj = [];
        $('.checkpdiInpt').each(function(){
            var remarks = $(this).closest('tr').find('.txtFieldTextBox').val();
            if($(this).is(':checked')){
                checklistObj.push({checkListId:$(this).attr('checklist_id'),val:$(this).val(),remarks:remarks});               
            }
            if($(this).is(':text') && $(this).val()){
                checklistObj.push({checkListId:$(this).attr('checklist_id'),val:$(this).val(),remarks:remarks});               
            }
        })
        $.post(url,
                {
                    type:type,
                    chassisNo:chassisNo,
                    protoTypeNo:protoTypeNo,
                    enggNo:enggNo,
                    modelNo:modelNo,
                    enggType:enggType,
                    projectName:projectName,
                    wbsNo:wbsNo,
                    checklistObj:checklistObj,
                    action:'saveChkList'
                }).done(function(data){
                    alert(data);
                })
        
    }
</script>