<?php
include_once('./process_common_class.php');
date_default_timezone_set("Asia/Calcutta");
$process = new Process();
if (isset($_REQUEST['action'])) {
    if (($_REQUEST['action'] == 'VHODETAILS')) {
//        print_r($_REQUEST);exit;
        echo json_encode($process->checkListWithTab());
    }
}

?>