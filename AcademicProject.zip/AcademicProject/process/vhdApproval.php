<?php include("./process_common_class.php"); ?>
<style>
    .btn-group, .btn-group-vertical {
        display: inline-block;
        position: relative;
        vertical-align: middle;
    }
    .btn-group > .btn:first-child:not(:last-child):not(.dropdown-toggle) {
        border-bottom-right-radius: 0;
        border-top-right-radius: 0;
    }
    .btn-group > .btn:first-child {
        margin-left: 0;
    }
    .btn-group-vertical > .btn.active, .btn-group-vertical > .btn:active, .btn-group-vertical > .btn:focus, .btn-group-vertical > .btn:hover, .btn-group > .btn.active, .btn-group > .btn:active, .btn-group > .btn:focus, .btn-group > .btn:hover {
        z-index: 2;
    }
    .btn-group-vertical > .btn.active, .btn-group-vertical > .btn:active, .btn-group-vertical > .btn:focus, .btn-group-vertical > .btn:hover, .btn-group > .btn.active, .btn-group > .btn:active, .btn-group > .btn:focus, .btn-group > .btn:hover {
        z-index: 2;
    }
    .btn-group-vertical > .btn.active, .btn-group-vertical > .btn:active, .btn-group-vertical > .btn:focus, .btn-group-vertical > .btn:hover, .btn-group > .btn.active, .btn-group > .btn:active, .btn-group > .btn:focus, .btn-group > .btn:hover {
        z-index: 2;
    }
    .btn-danger.active.focus, .btn-danger.active:focus, .btn-danger.active:hover, .btn-danger.focus:active, .btn-danger:active:focus, .btn-danger:active:hover, .open > .dropdown-toggle.btn-danger.focus, .open > .dropdown-toggle.btn-danger:focus, .open > .dropdown-toggle.btn-danger:hover {
        background-color: #ac2925;
        border-color: #761c19;
        color: #fff;
    }
    .btn-danger.active.focus, .btn-danger.active:focus, .btn-danger.active:hover, .btn-danger.focus:active, .btn-danger:active:focus, .btn-danger:active:hover, .open > .dropdown-toggle.btn-danger.focus, .open > .dropdown-toggle.btn-danger:focus, .open > .dropdown-toggle.btn-danger:hover {
        background-color: #ac2925;
        border-color: #761c19;
        color: #fff;
    }
    .btn.active.focus, .btn.active:focus, .btn.focus, .btn.focus:active, .btn:active:focus, .btn:focus {
        outline: thin dotted;
        outline-offset: -2px;
    }
    .btn:focus {
        outline: medium none;
    }
    .btn:active {
        box-shadow: 0 3px 5px rgba(0, 0, 0, 0.125) inset;
    }
    .btn-group-vertical > .btn, .btn-group > .btn {
        float: left;
        position: relative;
    }
    .btn-danger.active, .btn-danger:active, .open > .dropdown-toggle.btn-danger {
        background-image: none;
    }
    .btn-danger.active, .btn-danger:active, .open > .dropdown-toggle.btn-danger {
        background-color: #c9302c;
        border-color: #ac2925;
        color: #fff;
    }

    .btn-danger.focus, .btn-danger:focus {
        background-color: #c9302c;
        border-color: #761c19;
        color: #fff;
    }
    .btn.active, .btn:active {
        background-image: none;
        box-shadow: 0 3px 5px rgba(0, 0, 0, 0.125) inset;
        outline: 0 none;
    }
    .btn.focus, .btn:focus, .btn:hover {
        color: #333;
        text-decoration: none;
    }
    .btn.focus, .btn:focus, .btn:hover {
        color: #333;
        text-decoration: none;
    }
    .btn.active.focus, .btn.active:focus, .btn.focus, .btn.focus:active, .btn:active:focus, .btn:focus {
        outline: thin dotted;
        outline-offset: -2px;
    }
    .btn-danger {
        background-color: #dd4b39;
        border-color: #d73925;
    }
    .btn {
        border: 1px solid transparent;
        border-radius: 3px;
        box-shadow: none;
    }
    .btn-danger {
        background-color: #d9534f;
        border-color: #d43f3a;
        color: #fff;
    }
    .btn {
        -moz-user-select: none;
        background-image: none;
        border: 1px solid transparent;
        border-radius: 4px;
        cursor: pointer;
        display: inline-block;
        font-size: 14px;
        font-weight: 400;
        line-height: 1.42857;
        margin-bottom: 0;
        padding: 6px 12px;
        text-align: center;
        vertical-align: middle;
        white-space: nowrap;
    }
    button, input, select, textarea {
        font-family: inherit;
        font-size: inherit;
        line-height: inherit;
    }
    button, html input[type="button"], input[type="reset"], input[type="submit"] {
        cursor: pointer;
    }
    button, select {
        text-transform: none;
    }
    button {
        overflow: visible;
    }
    button, input, optgroup, select, textarea {
        color: inherit;
        font: inherit;
        margin: 0;
    }
    .btn-danger.active.focus, .btn-danger.active:focus, .btn-danger.active:hover, .btn-danger.focus:active, .btn-danger:active:focus, .btn-danger:active:hover, .open > .dropdown-toggle.btn-danger.focus, .open > .dropdown-toggle.btn-danger:focus, .open > .dropdown-toggle.btn-danger:hover {
        background-color: #ac2925;
        border-color: #761c19;
        color: #fff;
    }
    .btn-danger.active.focus, .btn-danger.active:focus, .btn-danger.active:hover, .btn-danger.focus:active, .btn-danger:active:focus, .btn-danger:active:hover, .open > .dropdown-toggle.btn-danger.focus, .open > .dropdown-toggle.btn-danger:focus, .open > .dropdown-toggle.btn-danger:hover {
        background-color: #ac2925;
        border-color: #761c19;
        color: #fff;
    }
    .btn-group.open .dropdown-toggle {
        box-shadow: 0 3px 5px rgba(0, 0, 0, 0.125) inset;
    }
    .btn-group > .btn + .dropdown-toggle {
        padding-left: 8px;
        padding-right: 8px;
    }
    .btn-group .dropdown-toggle:active, .btn-group.open .dropdown-toggle {
        outline: 0 none;
    }
    .btn-group .dropdown-toggle:active, .btn-group.open .dropdown-toggle {
        outline: 0 none;
    }
    .btn-group > .btn:last-child:not(:first-child), .btn-group > .dropdown-toggle:not(:first-child) {
        border-bottom-left-radius: 0;
        border-top-left-radius: 0;
    }
    .btn-group .btn + .btn, .btn-group .btn + .btn-group, .btn-group .btn-group + .btn, .btn-group .btn-group + .btn-group {
        margin-left: -1px;
    }
    .btn-group-vertical > .btn.active, .btn-group-vertical > .btn:active, .btn-group-vertical > .btn:focus, .btn-group-vertical > .btn:hover, .btn-group > .btn.active, .btn-group > .btn:active, .btn-group > .btn:focus, .btn-group > .btn:hover {
        z-index: 2;
    }
    .btn-group-vertical > .btn.active, .btn-group-vertical > .btn:active, .btn-group-vertical > .btn:focus, .btn-group-vertical > .btn:hover, .btn-group > .btn.active, .btn-group > .btn:active, .btn-group > .btn:focus, .btn-group > .btn:hover {
        z-index: 2;
    }
    .btn-group-vertical > .btn.active, .btn-group-vertical > .btn:active, .btn-group-vertical > .btn:focus, .btn-group-vertical > .btn:hover, .btn-group > .btn.active, .btn-group > .btn:active, .btn-group > .btn:focus, .btn-group > .btn:hover {
        z-index: 2;
    }
    .btn-danger.active, .btn-danger:active, .open > .dropdown-toggle.btn-danger {
        background-image: none;
    }
    .btn-danger.active.focus, .btn-danger.active:focus, .btn-danger.active:hover, .btn-danger.focus:active, .btn-danger:active:focus, .btn-danger:active:hover, .open > .dropdown-toggle.btn-danger.focus, .open > .dropdown-toggle.btn-danger:focus, .open > .dropdown-toggle.btn-danger:hover {
        background-color: #ac2925;
        border-color: #761c19;
        color: #fff;
    }
    .btn-danger.active.focus, .btn-danger.active:focus, .btn-danger.active:hover, .btn-danger.focus:active, .btn-danger:active:focus, .btn-danger:active:hover, .open > .dropdown-toggle.btn-danger.focus, .open > .dropdown-toggle.btn-danger:focus, .open > .dropdown-toggle.btn-danger:hover {
        background-color: #ac2925;
        border-color: #761c19;
        color: #fff;
    }
    .btn-danger.active, .btn-danger:active, .open > .dropdown-toggle.btn-danger {
        background-color: #c9302c;
        border-color: #ac2925;
        color: #fff;
    }
    .btn.active.focus, .btn.active:focus, .btn.focus, .btn.focus:active, .btn:active:focus, .btn:focus {
        outline: thin dotted;
        outline-offset: -2px;
    }


    .btn:focus {
        outline: medium none;
    }
    .btn:active {
        box-shadow: 0 3px 5px rgba(0, 0, 0, 0.125) inset;
    }
    .btn-group-vertical > .btn, .btn-group > .btn {
        float: left;
        position: relative;
    }
    .dropdown-toggle:focus {
        outline: 0 none;
    }
    .btn-danger.active, .btn-danger:active, .open > .dropdown-toggle.btn-danger {
        background-image: none;
    }
    .btn-danger.active, .btn-danger:active, .open > .dropdown-toggle.btn-danger {
        background-color: #c9302c;
        border-color: #ac2925;
        color: #fff;
    }

    .btn-danger.focus, .btn-danger:focus {
        background-color: #c9302c;
        border-color: #761c19;
        color: #fff;
    }
    .btn.active, .btn:active {
        background-image: none;
        box-shadow: 0 3px 5px rgba(0, 0, 0, 0.125) inset;
        outline: 0 none;
    }
    .btn.focus, .btn:focus, .btn:hover {
        color: #333;
        text-decoration: none;
    }
    .btn.focus, .btn:focus, .btn:hover {
        color: #333;
        text-decoration: none;
    }
    .btn.active.focus, .btn.active:focus, .btn.focus, .btn.focus:active, .btn:active:focus, .btn:focus {
        outline: thin dotted;
        outline-offset: -2px;
    }
    .btn-danger {
        background-color: #dd4b39;
        border-color: #d73925;
    }
    .btn {
        border: 1px solid transparent;
        border-radius: 3px;
        box-shadow: none;
    }
    .btn-danger {
        background-color: #d9534f;
        border-color: #d43f3a;
        color: #fff;
    }
    .btn {
        -moz-user-select: none;
        background-image: none;
        border: 1px solid transparent;
        border-radius: 4px;
        cursor: pointer;
        display: inline-block;
        font-size: 14px;
        font-weight: 400;
        line-height: 1.42857;
        margin-bottom: 0;
        padding: 6px 12px;
        text-align: center;
        vertical-align: middle;
        white-space: nowrap;
    }
    button, input, select, textarea {
        font-family: inherit;
        font-size: inherit;
        line-height: inherit;
    }
    button, html input[type="button"], input[type="reset"], input[type="submit"] {
        cursor: pointer;
    }
    button, select {
        text-transform: none;
    }
    button {
        overflow: visible;
    }
    button, input, optgroup, select, textarea {
        color: inherit;
        font: inherit;
        margin: 0;
    }
    .btn .caret {
        margin-left: 0;
    }
    .caret {
        border-left: 4px solid transparent;
        border-right: 4px solid transparent;
        border-top: 4px dashed;
        display: inline-block;
        height: 0;
        margin-left: 2px;
        vertical-align: middle;
        width: 0;
    }
    .btn-danger.active.focus, .btn-danger.active:focus, .btn-danger.active:hover, .btn-danger.focus:active, .btn-danger:active:focus, .btn-danger:active:hover, .open > .dropdown-toggle.btn-danger.focus, .open > .dropdown-toggle.btn-danger:focus, .open > .dropdown-toggle.btn-danger:hover {
        color: #fff;
    }
    .btn-danger.active, .btn-danger:active, .open > .dropdown-toggle.btn-danger {
        color: #fff;
    }
    .btn-danger:hover {
        background-color: #c9302c;
        border-color: #ac2925;
        color: #fff;
    }
    .btn-danger:hover, .btn-danger:active, .btn-danger.hover {
        background-color: #d73925;
    }
    .btn-danger:hover {
        color: #fff;
    }
    .btn-danger.focus, .btn-danger:focus {
        color: #fff;
    }
    .btn.focus, .btn:focus, .btn:hover {
        color: #333;
    }
    .btn-danger {
        color: #fff;
        border-color: #ac2925;
    }
    .btn {
        cursor: pointer;
        font-size: 14px;
        font-weight: 400;
        line-height: 1.42857;
        text-align: center;
        white-space: nowrap;
    }
    button, input, select, textarea {
        font-family: inherit;
        font-size: inherit;
        line-height: inherit;
    }
    button, html input[type="button"], input[type="reset"], input[type="submit"] {
        cursor: pointer;
    }
    button, select {
        text-transform: none;
    }
    button, input, optgroup, select, textarea {
        color: inherit;
        font: inherit;
    }
    sr-only {
        border: 0 none;
        clip: rect(0px, 0px, 0px, 0px);
        height: 1px;
        margin: -1px;
        overflow: hidden;
        padding: 0;
        position: absolute;
        width: 1px;
    }
    .open > .dropdown-menu {
        display: block;
    }
    .dropdown-menu {
        background-clip: padding-box;
        background-color: #fff;
        border: 1px solid rgba(0, 0, 0, 0.15);
        border-radius: 4px;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.176);
        display: none;
        float: left;
        font-size: 14px;
        left: 0;
        list-style: outside none none;
        margin: 2px 0 0;
        min-width: 160px;
        padding: 5px 0;
        position: absolute;
        text-align: left;
        top: 100%;
        z-index: 1000;
    }
    ol, ul {
        margin-bottom: 10px;
        margin-top: 0;
    }
    .dropdown-menu > li > a {
        clear: both;
        color: #333;
        display: block;
        font-weight: 400;
        line-height: 1.42857;
        padding: 3px 20px;
        white-space: nowrap;

        color: #337ab7;
        text-decoration: none;
        background-color: transparent;
    }
    .dropdown-menu > li > a:hover {
        background-color: #e1e3e9;
        color: #333;
    }
    .dropdown-menu > li > a:focus, .dropdown-menu > li > a:hover {
        background-color: #f5f5f5;
        color: #262626;
        text-decoration: none;
    }
    .dropdown-menu > .divider {
        background-color: #eee;
    }
    .dropdown-menu .divider {
        background-color: #e5e5e5;
        height: 1px;
        margin: 9px 0;
        overflow: hidden;
    }
</style>
<input type="hidden" id="hfPageTitle" value="Vehical Handover Document Approval" screen_id="">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<div class="Grid" style="text-align: left;">
    <form name="iirreport" class="iirreport" id="logInc">
        <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td colspan="4">

                        <span>
                            <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                            <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select Chassis No--</option>
                                <?php
                                if (array_key_exists(12, $_SESSION['userSessionInfo']['ROLES']))
                                    $chassisDtlArr = $process->chassisPending2(18);
                                else
                                    $chassisDtlArr = $process->chassisPending();

                                echo "<pre>";
                                //print_r($chassisDtlArr);
                                foreach ($chassisDtlArr as $value) {
                                    if ($value['PENDSTATEID'] == 15)
                                        echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                                    else if (@$_REQUEST ['menuid'] == 27 && $value['PENDSTATEID'] == 18)
                                        echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                                    else
                                        echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>
                    </td>
                </tr>
            </tbody>
            <tr style="height:24px">
                <td colspan="3">
                    <!--###########################################
                    ########## Chassis Details Start ##############
                    ###########################################-->
                    <?php include("ajax_chassis_details.php"); ?>
                    <!--###########################################
                    ########## Chassis Details END ################
                    ###########################################-->
                </td>
            </tr>
            <tr style="height:40px">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>VHD Data</b>
                    </span>
                </td>
            </tr>
        </table>
        <div id="tabMenuVHO" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
            <!--Tabs are added dynamically here-->
        </div>
        <table class="chassisDtlSpan" width="100%" cellpadding="0" cellspacing="0" style="display: none" >
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td style="width: 20%" class="hideLastComent">
                        <span class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Last Comment By: </b><b style="color: #3637FE" id="pendUserName"></b></label>
                        </span>
                    </td>
                    <td class="hideLastComent">
                        <span class="chassisDtlSpan" >
                            <textarea placeholder="Last Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="last_comment" rows="2" maxlength="1900" disabled="disabled"></textarea>
                        </span>
                    </td>
                    <td style="width: 20%">
                        <span class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Comment for Approve/Reject:</b></label>
                        </span>
                    </td>
                    <td>
                        <span class="chassisDtlSpan" >
                            <textarea placeholder="Please Put Your Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="current_comment" rows="2" maxlength="1900"></textarea>
                        </span>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php if (array_key_exists(9, $_SESSION['userSessionInfo']['ROLES']) || array_key_exists(12, $_SESSION['userSessionInfo']['ROLES'])) { ?>
            <table class="chassisDtlSpan" width="100%" cellpadding="0" cellspacing="0" style="display: none" >

                <tr style="height:40px">
                    <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                        <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                            <b>Closure Process</b>
                        </span>
                    </td>
                </tr>
                <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                    <tr style="height:24px">
                        <td  colspan="4">
                            <span style="display: none" class="chassisDtlSpan" >
                                <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Vehicle Acceptance Date:</b></label>
                                <input id="acceptDate" name="txtFrom"  class="datepicker" data-options="formatter:myformatter" value="<?php echo date('d-M-Y'); ?>" onkeypress="return false;" />
                            </span>

                        </td>

                    </tr>
                </tbody>
            </table>
            <div id="checklistFormBtn" style="margin:10px;display: none">
                <a href="javascript:void(0);" class="kks-linkbutton l-btn confirm" iconCls="icon-approved" align="left" onclick="vhdClosure('approved');">
                    <span style="text-align:left;" >Approved</span>
                </a>
                <a href="javascript:void(0);" class="kks-linkbutton l-btn" iconCls="icon-rejected" align="left" onclick="vhdClosure('rejected');">
                    <span  style="text-align:left;" >Reject</span>
                </a>
            </div>
        <?php } else { ?>
            <div id="checklistFormBtn" class="btn-group" style="margin: 20px 0 135px 20px;display: none">
                <button class="btn btn-danger btn-flat" type="button">Action</button>
                <button data-toggle="dropdown" class="btn btn-danger btn-flat dropdown-toggle" type="button" aria-expanded="false">
                    <span class="caret"></span>
                    <span class="sr-only"></span>
                </button>
                <ul role="menu" class="dropdown-menu">
                    <li><a href="javascript:void(0);" style="color: green;font-weight: bold" onclick="vhdApproved('approved', 'approved');">Approved</a></li>
                    <li class="divider"></li>
                    <!--<li><a href="javascript:void(0);" style="color: red;font-weight: bold" onclick="vhdApproved('rejected','rejectAll');">Reject All</a></li>-->
                    <li><a href="javascript:void(0);" style="color: red;font-weight: bold" onclick="vhdApproved('rejected', 'rejecteddesign');">Reject Design</a></li>
                    <li><a href="javascript:void(0);" style="color: red;font-weight: bold" onclick="vhdApproved('rejected', 'rejectedpae');">Reject PAE</a></li>
                </ul>
            </div>
        <?php } ?>
    </form>
</div>

<script type="text/javascript">

    var url = wwwRoot + "process/handover_doc_action.php";
    $(function () {
        $('.datepicker').datepick({showOnFocus: true, dateFormat: 'dd-M-yyyy', maxDate: 0});
        $(".dropdown-toggle,.dropdown-menu").click(function () {
            $(".btn-group").toggleClass('open');
        })
        $("#tabMenuVHO :input").attr("disabled", true);
        $('.layout-button-left').trigger('click');
        $("#ddlChassis").change(function () {
            if ($(this).val()) {
                $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan").show();
                tabGenerate();
            } else {
                var tabNos = $('.tabs >li').length;
                for (i = 0; i < tabNos; i++) {
                    $("#tabMenuVHO").tabs('close', 0);
                }
                $("#vhdFormBtn").hide();
                $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan,#bdyCheckList,#checklistFormBtn,#ajaxChassisInfoTbl").hide();
            }
        })
    })

    function tabGenerate() {
        //ajax call for PDI list
        var menuid = $("#urlMenuID").val();
        $.post(url, {action: "VHODETAILS", chassisNo: $("#ddlChassis").val(), menuid: menuid}, function () {
        }, 'JSON').done(function (data) {

            var resTable = '';
            $.each(data.CHECKDTLS, function (indexTab, tabDetails) {
//                console.log(indexTab);
                var incHeadColSpan = 2;
                var headColSpan = 3;
                if (indexTab == "Joint Inspection") {
                    incHeadColSpan = 3;
                    headColSpan = 4;
                }
                var resTable = '<table style="background-color: #EFF3FB;">';
                var parntInc = 0;
                $.each(tabDetails, function (indexPrnt, parentDetails) {
                    if ($.type(parentDetails) == 'object') {
                        parntInc++;
                        var childInc = 0;
                        //Thead
                        if (parentDetails.TCH_INCRIMENTAL) {
                            resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='" + incHeadColSpan + "'>" + parentDetails.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
//                            resTable += "<tbody><tr class='trid" + parentDetails.TCH_CHK_ID + "' id='addmoreTr" + parentDetails.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                            resTable += "<tbody><tr class='trid" + parentDetails.TCH_CHK_ID + "' id='addmoreTr" + parentDetails.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt addMoreParam" ></td>';

                            if (parentDetails.TCH_DATA_TYPE == 'file') {
                                resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + parentDetails.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                txtRemark = '';
                            } else {
                                resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt vehicleParam" ></td>';
                                txtRemark = '<textarea maxlength="1900" id="remarkBox_' + parentDetails.TCH_CHK_ID + '" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                            }
                            if (indexTab == "Joint Inspection") {
                                $setValArr = ["OK", "NOT OK"];
                                resTable += '<td>';
                                $setValArr.forEach(function ($value, $key) {
                                    $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                    resTable += '<label for="checkPDI' + ($key + 1) + parentDetails.TCH_CHK_ID + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + parentDetails.TCH_CHK_ID + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                });
                                resTable += '</td>';
                            }
                            resTable += '<td>' + txtRemark + '</td>';
                            resTable += "</tr></tbody>";
                        } else {
                            resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='" + headColSpan + "'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                        }
                        //Tbody
                        $.each(parentDetails, function (index, childArr) {
                            childInc++;
                            if ($.type(childArr) == 'object') {
                                txtRemark = '<textarea maxlength="1900" rows="2" id="remarkBox_' + childArr.TCH_CHK_ID + '" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                resTable += "<tbody><tr id='trid" + childArr.TCH_CHK_ID + "' class='trid" + childArr.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";

                                if (childArr.TCH_DATA_TYPE == 'text') {
//                                    resTable += '<td><input type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt" ></td>';
                                    resTable += '<td><input style="width:80%" type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt vehicleParam" ></td>';
                                } else if (childArr.TCH_DATA_TYPE == 'radio' && indexTab != "Joint Inspection") {
                                    $setValArr = childArr.TCH_VALUE_SET.split("##");
                                    resTable += '<td>';
                                    $setValArr.forEach(function ($value, $key) {
                                        $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                        resTable += '<label for="checkPDI' + ($key + 1) + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                    });
                                    resTable += '</td>';
                                } else if (childArr.TCH_DATA_TYPE == 'file') {
                                    resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + childArr.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                    txtRemark = '';
                                } else if (indexTab == "Joint Inspection") {
                                    resTable += '<td></td>';
                                }
                                if (indexTab == "Joint Inspection") {
                                    $setValArr = ["OK", "NOT OK"];
                                    resTable += '<td>';
                                    $setValArr.forEach(function ($value, $key) {
                                        $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                        resTable += '<label for="checkPDI' + ($key + 1) + childArr.TCH_CHK_ID + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + childArr.TCH_CHK_ID + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                    });
                                    resTable += '</td>';
                                }
                                resTable += '<td>' + txtRemark + '</td>';
                                resTable += "</tr></tbody>";
                            }
                        })
                    }
                })
                resTable += "</table>";
//                        console.log(resTable);
                $('#tabMenuVHO').tabs('add', {
                    title: indexTab,
                    content: resTable,
                    closable: false
                });
                if (!$.isEmptyObject(data.AJAXCHASSISDTLS)) {
                    $("#ajaxChassisNo").html(data.AJAXCHASSISDTLS.CHASSSISNO);
                    $("#ajaxModelNo").html(data.AJAXCHASSISDTLS.TCD_MODEL);
                    $("#ajaxProtoType").html(data.AJAXCHASSISDTLS.TCD_PROTO_NO);
                    $("#ajaxWBSNo").html(data.AJAXCHASSISDTLS.TCD_WBS_LIST);
                    $("#ajaxProjCode").html(data.AJAXCHASSISDTLS.TCD_PROJ_CODE);
                    $("#ajaxVCNo").html(data.AJAXCHASSISDTLS.TCD_VC_NO);
                    $("#ajaxChassisInfoTbl").show();
                }
            })
            if (!$.isEmptyObject(data.FILLDATA)) {
                $.each(data.FILLDATA, function (chkKey, chkVal) {
                    if (typeof chkVal[0] != 'undefined') {
                        var checkIdCrnt = chkVal[0].TJD_CHK_ID;
                        if (chkVal.length > 1) {
                            for (i = 0; i < chkVal.length; i++) {
                                i > 0 ? addmoreRow("#addmoreTr" + chkKey, "addmoreTr" + chkKey) : '';
                            }
                            for (i = 0; i < chkVal.length; i++) {
                                var vehParms = chkVal[i].TJD_VEH_PARAM.split('###');
//                                console.log(vehParms);
                                $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('.addMoreParam').val(vehParms[0]);
                                $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('.vehicleParam').val(vehParms[1]);
                                $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('input[checklist_id="' + chkKey + '"][value="' + chkVal[i].TJD_VALUE + '"]').prop('checked', true);
                                $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find("#remarkBox_" + chkKey).val(chkVal[i].TJD_REMARKS);
                            }
                        } else {
                            if (chkVal[0].TJD_VEH_PARAM) {
                                var vehParms = chkVal[0].TJD_VEH_PARAM.split('###');
                                $(".trid" + chkKey).find('.addMoreParam').val(vehParms[0]);
                                $(".trid" + chkKey).find('.vehicleParam').val(vehParms[1]);
                            }
                            $('input[name="checkPDI_' + chkKey + '"][value="' + chkVal[0].TJD_VALUE + '"]').prop('checked', true);
                            $("#remarkBox_" + chkKey).val(chkVal[0].TJD_REMARKS);
                        }
                        //Image file Loading
                        $.each(chkVal[0], function (keyFile, childFile) {
                            if ($.type(childFile) == 'object') {
                                var imgTr = '<tr class="addMorePhotoTr" style="background-color:#FFFFFF"><td></td>';
                                imgTr += '<td><img style="height:119Px;width:200Px;" src="' + wwwRoot + childFile.TFD_FILE_PATH + '"></td>';
                                imgTr += '<td><input type="hidden" style="width:80%" value="' + childFile.TFD_FILE_TITLE + '" checklist_id="' + checkIdCrnt + '" class="photoName"><textarea maxlength="1900" rows="2" class="photoDesc" style="word-wrap: break-word;width:95%" placeholder="Photo Description">' + childFile.TFD_FILE_DESC + '</textarea></td>';
                                imgTr += '<td colspan="2"><a href="javascript:void(0);" class="statusChange" id="btnDeactFile">Delete Image</a></td>';
                                imgTr += '</tr>';
                                $(".trid" + checkIdCrnt).after(imgTr);
                            }
                        })
                    } else {
                        $('input[type="text"][name="checkPDI_' + chkVal.TCD_CHK_ID + '"]').val(chkVal.TCD_VALUE);
                        $('input[name="checkPDI_' + chkVal.TCD_CHK_ID + '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
                        $("#remarkBox_" + chkVal.TCD_CHK_ID).val(chkVal.TCD_REMARKS);
                    }
                })
            }
            $("#tabMenuVHO").tabs('select', 0);
            $('#tabMenuVHO').find('input, textarea, button, select').attr('disabled', 'disabled');
            if (!$.isEmptyObject(data.LASTCOMMENT)) {
                $("#last_comment").val(data.LASTCOMMENT.REMARK);
                $("#pendUserName").html(data.LASTCOMMENT.PENDUSERNAME);
            } else {
                $(".hideLastComent").hide();
                $("#current_comment").css('width', '50%');
            }
        })
        $("#checklistFormBtn").show();
    }

    function vhdApproved(ptype, subProcType) {
        $.post(url, {action: "vhdApproval", processType: ptype, subProcessType: subProcType, currComment: $("#current_comment").val(), chassisNo: $("#ddlChassis").val()}, function () {
        }).done(function (data) {
            alert(data);
            openUrl(wwwRoot + "process/vhdApproval.php?menuid=23");
        })
    }

    function vhdClosure(type) {
        if (type) {
            if (!$("#acceptDate").val() && type == 'approved') {
                $.messager.alert('Validation Error', '<b style="color:red">Please Enter Vehicle Acceptance Date!</b>', 'error');
                return false;
            }
            var confMsg = confirm('Are you sure want to ' + type + ' the process?');
            if (confMsg) {
                $.post(url, {action: "vhdClosed", chassisNo: $("#ddlChassis").val(), acceptDate: $("#acceptDate").val(), submitType: type, currComment: $("#current_comment").val()}, function () {
                }).done(function (data) {
                    alert(data);
                    openUrl(wwwRoot + "process/vhdApproval.php?menuid=23");
                })
            }
        }
    }
</script>