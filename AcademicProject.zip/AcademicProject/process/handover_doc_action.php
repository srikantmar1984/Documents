<?php

include_once('./process_common_class.php');
include_once('../email/email_template_class.php');
date_default_timezone_set("Asia/Calcutta");
$process = new Process();
if (isset($_REQUEST['action'])) {
    if (($_REQUEST['action'] == 'VHODETAILS')) {
        $retrunRes['CHECKDTLS'] = $process->checkListWithTab();
        if (array_key_exists(6, $_SESSION['userSessionInfo']['ROLES'])) {
            $procesType = 'VHD-Design';
        } else {
            $procesType = 'VHD';
        }
        $retrunRes['FILLDATA'] = fillDataVHD($procesType);
        $retrunRes['LASTCOMMENT'] = $process->findLastComment($_REQUEST["chassisNo"]);
        $retrunRes['AJAXCHASSISDTLS'] = $process->findChassisInfo($_REQUEST["chassisNo"]);
        $retrunRes['LASTCOMMENT'] = $process->findLastComment($_REQUEST["chassisNo"]);
        echo json_encode($retrunRes);
    } else if ($_REQUEST['action'] == 'saveVhdValue') {
        echo saveVHDDoc();
    } else if ($_REQUEST['action'] == 'viewVHDPae') {
        print_r($_REQUEST);
        exit;
//        echo saveVHDDoc();
    } else if ($_REQUEST['action'] == 'vhdApproval') {
        echo vhdAproveProcess();
    } else if ($_REQUEST['action'] == 'vhdAccepted') {
        echo vhdAccepted();
    } else if ($_REQUEST['action'] == 'vhdClosed') {
        echo vhdClosed();
    }
}

function saveVHDDoc() {
    $process = new Process();
    $emailTemplate = new emailTemplate();
    if ($_REQUEST['type'] == "saveData") {
        if (array_key_exists(6, $_SESSION['userSessionInfo']['ROLES'])) {
            //Designer
            $stateID = 13;
            $deleteStateId = 13;
            $procesType = 'VHD-Design';
        } else {
            //PAE
            $stateID = 11;
            $deleteStateId = 11;
            $procesType = 'VHD';
        }
        $pendOpt = "";

        $msg = "VHD saved for the Chassis Number: " . $_REQUEST["chassisNo"];
    } else if ($_REQUEST['type'] == "submitData") {
        $pendingUserID = @$_REQUEST["responsilbeEngg"];
        $pendOpt = "UPDATE";
        if (array_key_exists(6, $_SESSION['userSessionInfo']['ROLES'])) {
            //Designer
            $pendingUserID = "( SELECT T_VHS_USERS.TUS_UID FROM T_VHS_USERS,T_ERC_ROLE_USER WHERE T_VHS_USERS.TUS_UID = T_ERC_ROLE_USER.TRU_USER_ID AND T_ERC_ROLE_USER.TRU_ROLE_ID = 7 )";
            if (@$_REQUEST["pendingStateId"] == 15) {
                $stateID = 15;
                $process->histryInsert('VHD', 12);
            } else {
                $stateID = 17;
            }

            $deleteStateId = 11;
            $procesType = 'VHD-Design';
            $pendStateID = 15;
            $emailTempContNotfy = $emailTemplate->vhdPAEDoneNotifyToPlangEngg();
        } else {
            //PAE
            if (@$_REQUEST["pendingStateId"] == 16) {
                $stateID = 16;
                $pendStateID = 15;
                $pendingUserID = " (SELECT TPD_UPD_BY from T_VHS_PENDING_DTLS WHERE TPD_CHASSIS_NO = '" . $_REQUEST["chassisNo"] . "') ";
                $emailTempContNotfy = $emailTemplate->vhdPAEDoneNotifyToPlangEngg();
                //Insert to history table
                $process->histryInsert('VHD', 11);
            } else {
                $stateID = 12;
                $pendStateID = 13;
                $emailTempContNotfy = $emailTemplate->vhdPAEDoneNotifyToDesigner();
            }
            $procesType = 'VHD';
            $deleteStateId = 11;
        }
        $msg = "VHD updated for the Chassis Number: " . $_REQUEST["chassisNo"];
//        $pendStateID $pendingUserID
    }
    $obj = new db_connect;
    $deletStatDtlSql = "DELETE FROM T_VHS_STATE_DTLS WHERE TSD_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' AND TSD_STATE_ID=$deleteStateId";
    $obj->db_query($deletStatDtlSql);
    checkDtlsOperation($procesType);
    $process->logDtlsStatusChange($stateID);
    $process->stateDtlsOperation($stateID);


    if ($pendOpt) {

        $process->pendingDtlsOperation($pendStateID, $pendingUserID, $stateID);


        $emailTempContUsrConf = $emailTemplate->vhdPAEDoneUserConfirmation();
        sendMailNotification($_SESSION['userSessionInfo']["TUS_EMAIL_ID"], $emailTempContUsrConf['subject'], $emailTempContUsrConf['body'], $emailTempContUsrConf['headers']);

        $sqlPendTo = "SELECT TUS_EMAIL_ID AS EMAIL FROM T_VHS_USERS WHERE TUS_UID = $pendingUserID";
        $resPendTo = $obj->db_fetch_assoc($obj->db_query($sqlPendTo));
        sendMailNotification($resPendTo[0]['EMAIL'], $emailTempContNotfy['subject'], $emailTempContNotfy['body'], $emailTempContNotfy['headers']);
    }
    return $msg;
}

function checkDtlsOperation($procesType = 'VHD') {
    $obj = new db_connect;
    //Delete record from  T_VHS_CHECK_DTLS
    $deletChkSql = "DELETE FROM T_VHS_CHECK_DTLS WHERE TCD_LOG_NO='" . $_REQUEST["chassisNo"] . "' AND TCD_PROCESS_TYPE='$procesType'";
    $obj->db_query($deletChkSql);
    //INSERT record to  T_VHS_CHECK_DTLS
    if (isset($_REQUEST["vhdValueObj"])) {
        foreach ($_REQUEST["vhdValueObj"] as $value) {
            $sqlChekDtls = "INSERT INTO T_VHS_CHECK_DTLS";
            $sqlChekDtls .= " ( ";
            $sqlChekDtls .= "    TCD_LOG_NO ";
            $sqlChekDtls .= "  , TCD_CHK_ID ";
            $sqlChekDtls .= "  , TCD_CHASSIS_NO ";
            $sqlChekDtls .= "  , TCD_VALUE ";
            $sqlChekDtls .= "  , TCD_REMARKS ";
            $sqlChekDtls .= "  , TCD_CRT_BY ";
            $sqlChekDtls .= "  , TCD_CRT_TS ";
            $sqlChekDtls .= "  , TCD_UPD_BY ";
            $sqlChekDtls .= "  , TCD_UPD_TS ";
            $sqlChekDtls .= "  , TCD_PROCESS_TYPE ";
            $sqlChekDtls .= " ) ";
            $sqlChekDtls .= " VALUES ";
            $sqlChekDtls .= " ( ";
            $sqlChekDtls .= " '" . $_REQUEST["chassisNo"] . "' ";
            $sqlChekDtls .= "  , " . $value['checkListId'];
            $sqlChekDtls .= "  , '" . $_REQUEST["chassisNo"] . "' ";
            $sqlChekDtls .= "  , '" . $value['val'] . "' ";
            $sqlChekDtls .= "  , '" . $value['remarks'] . "' ";
            $sqlChekDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
            $sqlChekDtls .= "  , SYSDATE ";
            $sqlChekDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
            $sqlChekDtls .= "  , SYSDATE ";
            $sqlChekDtls .= "  , '{$procesType}' ";
            $sqlChekDtls .= " ) ";
            $obj = new db_connect;
            $obj->db_insert($sqlChekDtls);
        }
    }
    $obj->free();
}

function sendMailNotification($to, $subjecy, $body, $header) {
    $sent = @mail($to, $subjecy, $body, $header);
    return $sent;
}

function fillDataVHD($procesType = 'VHD') {
    $returnArr = array();
    $sql = "SELECT TCD_LOG_NO,
            TCD_CHK_ID,
            TCD_VALUE,
            TCD_REMARKS
          FROM T_VHS_CHECK_DTLS
          WHERE TCD_LOG_NO = '{$_REQUEST["chassisNo"]}'";
    if (array_key_exists(7, $_SESSION['userSessionInfo']['ROLES'])) {
        $sql .= " AND ( TCD_PROCESS_TYPE = 'VHD' OR TCD_PROCESS_TYPE = 'VHD-Design' )";
    } else if (array_key_exists(3, $_SESSION['userSessionInfo']['ROLES']) || array_key_exists(9, $_SESSION['userSessionInfo']['ROLES']) || array_key_exists(12, $_SESSION['userSessionInfo']['ROLES'])) {
        $sql .= " ";
        $process = new Process();
        $returnArr = $process->fillDataJI();
    } else {
        $sql .= " AND TCD_PROCESS_TYPE = '$procesType'";
    }
    $obj = new db_connect;
    $obj->db_query($sql);
    $resTable = '';

    while ($row = $obj->db_fetch_arrayAssoc()) {
        $returnArr[] = $row;
    }
    $obj->free();
    return $returnArr;
}

function vhdAproveProcess() {
    $process = new Process();
    $process->logDtlsModify("TLD_TEST_PM", "(SELECT TSD_CRT_BY FROM T_VHS_STATE_DTLS WHERE TSD_STATE_ID = 7 AND TSD_CHASSIS_NO ='{$_REQUEST["chassisNo"]}')");

    $emailTemplate = new emailTemplate();
    /*
     * @@@ Either the process Approved or Rejected
     * @@@@ If Approved then the next process goes to Testing Head
     * @@@@ If Rejected -- Rejected will be 3 type. @@1) RejectAll.. 2) RejectPAE.. 3) RejectDesign
     */
    $stateID = 15;
    if ($_REQUEST['processType'] == 'approved') {
        $pendStateID = 18;
        $pendingUserID = "( SELECT tld_test_pm FROM t_vhs_log_dtls WHERE tld_log_no = '{$_REQUEST["chassisNo"]}')";
        //VHD Approved acknokledge to Planning Head
        $emailTempContNotfyProcess = $emailTemplate->vhdApprovalDoneNotifyToPlanningHead();
    } elseif ($_REQUEST['processType'] == 'rejected') {
        if ($_REQUEST['subProcessType'] == 'rejecteddesign') {
            $pendStateID = 17;
//            $pendingUserID = "(SELECT TPD_UPD_BY FROM T_VHS_PENDING_DTLS WHERE TPD_CHASSIS_NO ='{$_REQUEST["chassisNo"]}')";
            $pendingUserID = "(SELECT TSD_CRT_BY FROM T_VHS_STATE_DTLS WHERE TSD_STATE_ID = 17 AND TSD_CHASSIS_NO ='{$_REQUEST["chassisNo"]}')";
            ///VHD Rejected acknokledge to Design Engg
            $emailTempContNotfyProcess = $emailTemplate->vhdRejectedNotifyToDesigner();
        } else if ($_REQUEST['subProcessType'] == 'rejectedpae') {
            $pendStateID = 16;
            $pendingUserID = "(SELECT TLD_PAE_ELECT FROM T_VHS_LOG_DTLS WHERE TLD_LOG_NO ='{$_REQUEST["chassisNo"]}')";
            ///VHD Rejected acknokledge to PAE Engg
            $emailTempContNotfyProcess = $emailTemplate->vhdRejectedNotifyToPAE();
        }
    }
    /*
     * STEP-1: UPDATE LOG DTLS
     * STEP-2: UPDATE STATE DTLS
     * STEP-3: UPDATE PENDIGN DTLS
     * STEP-4: EMAIL NOTIFICATION
     */

    $process->logDtlsStatusChange($stateID);
    $process->stateDtlsOperation($stateID);
    $process->pendingDtlsOperation($pendStateID, $pendingUserID, $stateID);


    //User Notification about success approval process(Planning Engg)
    $emailTempContNotfyPlangUser = $emailTemplate->vhdApprovalDoneUserConfirmation();
    sendMailNotification($_SESSION['userSessionInfo']["TUS_EMAIL_ID"], $emailTempContNotfyPlangUser['subject'], $emailTempContNotfyPlangUser['body'], $emailTempContNotfyPlangUser['headers']);

    $obj = new db_connect;
    $sqlPendTo = "SELECT TUS_EMAIL_ID AS EMAIL FROM T_VHS_USERS WHERE TUS_UID = $pendingUserID";
    $resPendTo = $obj->db_fetch_assoc($obj->db_query($sqlPendTo));
    sendMailNotification($resPendTo[0]['EMAIL'], $emailTempContNotfyProcess['subject'], $emailTempContNotfyProcess['body'], $emailTempContNotfyProcess['headers']);
    return "Process completed successfully!";
}

function vhdClosed() {
    /*
     * STEP-1: UPDATE LOG DTLS
     * STEP-2: UPDATE STATE DTLS
     * STEP-3: UPDATE PENDIGN DTLS
     * STEP-4: EMAIL NOTIFICATION
     * @@@@@@@@ if rejected then send a mail to PAI and to the user itself(Test PM)
     * @@@@@@@@ if approved then send a mail to user itself(Test PM) and to PAI.........
     */
    $stateID = 18;
    $process = new Process();
    $emailTemplate = new emailTemplate();
    $process->logDtlsStatusChange($stateID, $_REQUEST["acceptDate"]);
    $process->stateDtlsOperation($stateID);
    $obj = new db_connect;
    $paiEmailSql = "SELECT T_VHS_USERS.TUS_EMAIL_ID EMAILID
                ,T_VHS_USERS.TUS_NAME USERNAME
                FROM T_VHS_USERS,
                  T_ERC_ROLE_USER
                WHERE T_VHS_USERS.TUS_UID       = T_ERC_ROLE_USER.TRU_USER_ID
                AND T_ERC_ROLE_USER.TRU_ROLE_ID = 7";
    $emailPAI = $obj->db_fetch_assoc($obj->db_query($paiEmailSql));
    $obj->free();
    $paiEmail = $emailPAI[0]['EMAILID'];
    $paiUserName = $emailPAI[0]['USERNAME'];
    if ($_REQUEST["submitType"] == 'rejected') {
        $pendStateID = 15;
        $pendingUserID = "( SELECT T_VHS_USERS.TUS_UID FROM T_VHS_USERS,T_ERC_ROLE_USER WHERE T_VHS_USERS.TUS_UID = T_ERC_ROLE_USER.TRU_USER_ID AND T_ERC_ROLE_USER.TRU_ROLE_ID = 7 )";
        $process->pendingDtlsOperation($pendStateID, $pendingUserID, $stateID);

        // Update Chassis Details
        $obj = new db_connect;
        $updtLogSql = " UPDATE
                        T_VHS_LOG_DTLS
                    SET
                        TLD_STATUS=$pendStateID
                    WHERE
                        TLD_LOG_NO='" . $_REQUEST["chassisNo"] . "' ";
        $obj->db_query($updtLogSql);
        //SEND MAIL to PAI and to the user itself(Test PM) 
        $emailTempVhdRejectUserConfirmation = $emailTemplate->vhdRejectUserConfirmation($_SESSION['userSessionInfo']['TUS_NAME']);
        sendMailNotification($_SESSION['userSessionInfo']["TUS_EMAIL_ID"], $emailTempVhdRejectUserConfirmation['subject'], $emailTempVhdRejectUserConfirmation['body'], $emailTempVhdRejectUserConfirmation['headers']);


        $emailTempVhdRejectNotifyPAI = $emailTemplate->vhdRejectNotifyPAI($paiUserName);
        sendMailNotification($paiEmail, $emailTempVhdRejectNotifyPAI['subject'], $emailTempVhdRejectNotifyPAI['body'], $emailTempVhdRejectNotifyPAI['headers']);
        return "Chassis reverted successfully!";
    } else if ($_REQUEST["submitType"] == 'approved') {
        $obj = new db_connect;
        $deletPendDtlsSql = "DELETE FROM T_VHS_PENDING_DTLS WHERE TPD_CHASSIS_NO = '" . $_REQUEST["chassisNo"] . "'";
        $obj->db_query($deletPendDtlsSql);

        //Send Mail to user itself(Test PM) and PAI.........vhdAcceptUserConfirmation
        $emailTempVhdAcceptUserConfirmation = $emailTemplate->vhdAcceptUserConfirmation($_SESSION['userSessionInfo']['TUS_NAME']);
        sendMailNotification($_SESSION['userSessionInfo']["TUS_EMAIL_ID"], $emailTempVhdAcceptUserConfirmation['subject'], $emailTempVhdAcceptUserConfirmation['body'], $emailTempVhdAcceptUserConfirmation['headers']);
        $emailTempVhdAcceptNotifyPAI = $emailTemplate->vhdAcceptedNotifyToPAI($paiUserName);
        sendMailNotification($paiEmail, $emailTempVhdAcceptNotifyPAI['subject'], $emailTempVhdAcceptNotifyPAI['body'], $emailTempVhdAcceptNotifyPAI['headers']);
        return "Process completed successfully!";
    } else {
        return "Something wrong happends to the system. Please contact VHS Team!";
    }
}

?>