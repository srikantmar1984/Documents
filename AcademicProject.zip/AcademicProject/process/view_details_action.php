<?php

include_once('./process_common_class.php');
date_default_timezone_set("Asia/Calcutta");
$process = new Process();
if (isset($_REQUEST['action'])) {
    if (($_REQUEST['action'] == 'searchViewDetail')) {
        echo json_encode($process->searchViewDetail());
    } else if ($_REQUEST['action'] == 'satusDetail') {
        $_REQUEST['menuid'] = 26;
        include("staus_detail.php");
    }
}
?>