<?php

include_once('./process_common_class.php');
include_once('../email/email_template_class.php');
date_default_timezone_set("Asia/Calcutta");
$process = new Process();
$emailTemplate = new emailTemplate();


if (isset($_REQUEST['action'])) {
    if ($_REQUEST['action'] == "fillmember") {
        echo $process->findteamlist($_REQUEST['chk'], $_SESSION['userSessionInfo']['TUS_PNO'], $_REQUEST['grptype'], $_REQUEST['chkNM']);
        exit;
    } else if (($_REQUEST['action'] == 'pdiCheckList')) {
        $finalArr['checkpointData'] = $process->checkListWithTab();
        $finalArr['checkpointValue'] = findPDISavedData();
        $finalArr['LASTCOMMENT'] = $process->findLastComment($_REQUEST["chassisNo"]);
        $finalArr['AJAXCHASSISDTLS'] = $process->findChassisInfo($_REQUEST["chassisNo"]);
        $finalArr['AJAXFIRDTLS'] = $process->findFirInfo($_REQUEST["chassisNo"]);
        echo json_encode($finalArr);
        exit;
    } else if (($_REQUEST['action'] == 'TEAMDATA')) {
        $penduser = "";
        $arr = explode(',', $_REQUEST["pendingUser"]);
        $sqlTeamInsert = "INSERT ALL";
        foreach ($arr as $item) {
            $grpId = explode('_', $item);
            $sqlTeamInsert .= " INTO t_VHS_TEAM (	TTM_CHASSIS_NO	, TTM_GROUP_ID	, TTM_MEMBER	, TTM_ACT_FLG	, TTM_CRT_BY	, TTM_CRT_TS	, TTM_UPD_BY	, TTM_UPD_TS )
            VALUES ('{$_REQUEST["chassisNo"]}','" . $grpId[0] . "','" . $grpId[1] . "',1,{$_SESSION['userSessionInfo']["TUS_UID"]},sysdate,{$_SESSION['userSessionInfo']["TUS_UID"]},sysdate) ";
            $penduser = $grpId[1];
        }
        $sqlTeamInsert .= "SELECT * FROM DUAL";
        $obj = new db_connect();
        $obj->db_insert($sqlTeamInsert);
        $obj->free();
        $process->logDtlsStatusChange(7);
        $process->stateDtlsOperation(7);
        $process->pendingDtlsOperation(8, $penduser, 7);
        $process->logDtlsModify("TLD_TEST_PM", "(SELECT TSD_CRT_BY FROM T_VHS_STATE_DTLS WHERE TSD_STATE_ID = 7 AND TSD_CHASSIS_NO ='{$_REQUEST["chassisNo"]}')");

        $emailTempContTEAM = $emailTemplate->teamDoneConfirmation($_SESSION['userSessionInfo']['TUS_NAME']);
        $sent = @mail($_SESSION['userSessionInfo']["TUS_EMAIL_ID"], $emailTempContTEAM['subject'], $emailTempContTEAM['body'], $emailTempContTEAM['headers']);

        $obj = new db_connect();
        $membersEmailSql = "SELECT TUS_NAME USERNAME, TUS_EMAIL_ID EMAILID FROM T_VHS_USERS WHERE TUS_UID IN (SELECT TTM_MEMBER FROM t_VHS_TEAM WHERE TTM_CHASSIS_NO ='{$_REQUEST["chassisNo"]}' )";

        $obj->db_query($membersEmailSql);
        while ($emailmembers = $obj->db_fetch_arrayAssoc()) {

            $sendUserName = $emailmembers['USERNAME'];
            $emailTemplateForJI = $emailTemplate->teamDoneIntimationForJI($sendUserName);
            $sent = @mail($emailmembers['EMAILID'], $emailTemplateForJI['subject'], $emailTemplateForJI['body'], $emailTemplateForJI['headers']);
        }
        $obj->free();



        echo "Test Team has been formed successfully!";
        exit;
    }
}

function findPDISavedData() {
    $sql = "SELECT TCD_LOG_NO,
            TCD_CHK_ID,
            TCD_VALUE,
            TCD_REMARKS
           
            FROM T_VHS_CHECK_DTLS 
            WHERE TCD_LOG_NO = '{$_REQUEST["chassisNo"]}'";
    $obj = new db_connect;
    $obj->db_query($sql);
    $resTable = '';
    $returnArr = array();
    while ($row = $obj->db_fetch_arrayAssoc()) {
        $returnArr[] = $row;
    }
    $obj->free();
    return $returnArr;
}
