<?php include("./process_common_class.php"); ?>
<input type="hidden" id="hfPageTitle" value="VLO Upload" screen_id="">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<div class="Grid" style="text-align: left;">
    <form id="valoForm"  enctype="multipart/form-data" action="process/valocheck_action.php?action=VLODATA" method="post" >
        <table width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tr style="height:24px">
                <td colspan="4">
                    <span>
                        <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                        <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                            <option value="">--Select Chassis No--</option>
                            <?php
                            $chassisDtlArr = $process->chassisPending();
                            foreach ($chassisDtlArr as $value) {
                                echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                            }
                            ?> 
                        </select>
                    </span>
                </td>
            </tr>
            <tr style="height:24px">
                <td colspan="4">
                    <!--###########################################
                    ########## Chassis Details Start ##############
                    ###########################################-->
                    <?php include("ajax_chassis_details.php"); ?>
                    <!--###########################################
                    ############## Chassis Details End ############
                    ###########################################-->
                </td>
            </tr>
            <tr style="height:40px">
                <td colspan="3" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>VLO UPLOAD FOR ERC PROTO VEHICLES</b>
                    </span>
                </td>
            </tr>
            <tbody style="background-color: #EFF3FB;display: none" class="chassisDtlSpan"  >
                <tr style="height: 35px;">
                    <td style="width:2%">1</td>
                    <td style="width:44%;">Upload VLO
                        <span>
                            <label id="lblPDI1" for="checkPDI1">
                                <input type="checkbox" value="1" id="uploadReq" name="uploadReq"/>
                                <b style="color:#ff0000;">Not Required</b>
                            </label>
                        </span>
                    </td>
                    <td style="width:44%">
                        <input type="file" name="valoUploadDco" id="valoUploadDco" />
                        <button type="button" class="blue-button" id="uploadButtonVLO" onclick="uploadVloFile();">Upload</button>
                    </td>
                </tr>
                <tr>
                    <td style="width:2%">2</td>
                    <td>DMU Score</td>
                    <td>
                        <input type="text" name="valoDMUScore" id="valoDMUScore" onkeypress="return numericOnly(event)" maxlength="3" />
                    </td>
                </tr>
                <tr>
                    <td style="width:2%">3</td>
                    <td>ACTUAL Score</td>
                    <td>
                        <input type="text" name="valoACTScore" id="valoACTScore" onkeypress="return numericOnly(event)" maxlength="3" />
                    </td>
                </tr>

                <tr>
                    <td style="width:2%">5</td>
                    <td><b>Comments: </b></td>
                    <td>
                        <textarea placeholder="Please Put Your Comment" style="word-wrap: break-word;width: 50%" class="txtFieldTextBox" id="current_comment" rows="2" maxlength="1900"></textarea>
                    </td>
                </tr>
                <tr>
                    <td style="width:2%">6</td>
                    <td><b>Last Comment By: </b><b style="color: #3637FE" id="pendUserName"></b></td>
                    <td>
                        <textarea placeholder="Last Comment" style="word-wrap: break-word;width: 50%" class="txtFieldTextBox" id="last_comment" rows="2" maxlength="1900" disabled="disabled"></textarea>
                    </td>
                </tr>
                <tr>
                    <td style="width:2%">3</td>
                    <td>Assigned To Planner</td>
                    <td>
                        <select id="ddlPendingUser" name="ddlPendingUser" style="width:25%;"  class="ddlFieldDropdown">
                            <option value="">--Select Planner--</option>
                            <?php
                            $users = $process->assignedUserByRole(4);
                            foreach ($users as $value) {
                                echo '<option value="' . $value['USERID'] . '" data-email="' . $value['EMAIL'] . '" >' . $value['USERNAME'] . '</option>';
                            }
                            ?> 
                        </select>
                    </td>
                </tr>
            </tbody>
        </table>
        <!--================================================================================-->
        <!--====================== VLO Details start =======================================-->
        <!--================================================================================-->
        <table id="ajaxVLOInfoTbl" cellpadding="0" cellspacing="0" style="display: none">
            <thead>
                <tr style="height:40px">
                    <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                        <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                            <b>VLO Details</b>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th width="5%">Sr.No</th>
                    <th width="15%">File Name</th>
                    <th width="15%">Type</th>
                    <th width="15%">Action</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        <!--================================================================================-->
        <!--======================== VLO Details End =======================================-->
        <!--================================================================================-->
        <div id="checklistFormBtn" style="margin:10px;display: none">
            <a href="javascript:void(0);" class="kks-linkbutton l-btn confirm" iconCls="icon-approved" align="left" onclick="vloSubmit('approved');">
                <span style="text-align:left;" >Approve</span>
            </a>
            <a href="javascript:void(0);" class="kks-linkbutton l-btn" iconCls="icon-rejected" align="left" onclick="vloSubmit('rejected');">
                <span  style="text-align:left;" >Reject</span>
            </a>
            <!--<button type="submit" class="kks-linkbutton l-btn">Upload</button>-->
        </div>

    </form>
    <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
        <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
            <tr style="height:40px;display: none" class="chassisDtlSpan">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>PDI CHECKLIST FOR ERC PROTO VEHICLES</b>
                    </span>
                </td>
            </tr>
            <!--
                        <tr style="height:24px;display: none" class="chassisDtlSpan">
                            <td colspan="4">
                                <span style="display: none" class="chassisDtlSpan" >
                                    <label for="txtModelNo" id="lblModelNo" ><b>Model No:</b></label>
                                    <input id="txtModelNo" type="text" style="width:11%;" />
                                </span>
                                <span style="display: none" class="chassisDtlSpan" >
                                    <label for="txtProtoType" id="lblProtoType" ><b>Proto Type:</b></label>
                                    <input id="txtProtoType" type="text" style="width:11%;" />
                                </span>
                                <span style="display: none" class="chassisDtlSpan" >
                                    <label for="txtEngineNo" id="lblEngineNo" ><b>Engine No:</b></label>
                                    <input id="txtEngineNo" type="text" style="width:11%;" />
                                </span>
                                <span style="display: none" class="chassisDtlSpan" >
                                    <label for="txtWBSNo" id="lblWBSNo" ><b>WBS No:</b></label>
                                    <input id="txtWBSNo" type="text" style="width:11%;" />
                                </span>
                                <span style="display: none" class="chassisDtlSpan" >
                                    <label for="txtProjNo" id="lblProjNo" ><b>Project Code:</b></label>
                                    <input id="txtProjNo" type="text" style="width:11%;" />
                                </span>
                            </td>
                        </tr>-->
        </tbody>

    </table>
    <div id="tabMenuVHO" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto" >
        <!--Tabs are added dynamically here-->
    </div>

</div>
<div id="dd"></div>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript">
    var url = wwwRoot + "process/valocheck_action.php";
    $(function () {
        $("#tabMenuVHO :input").attr("disabled", true);
        $('.layout-button-left').trigger('click');
        $("#ddlChassis").change(function () {
            if ($(this).val()) {
                $(".chassisDtlSpan,.chassisDtlSpantd,#bdyCheckList,#pdiTypeSpan").show();
                tabGenerate();
            } else {
                $("#tabMenuVHO").tabs('close', 0);
                $("#tabMenuVHO").tabs('close', 0);
                $("#vhdFormBtn").hide();
                $(".chassisDtlSpan,.chassisDtlSpantd,#bdyCheckList,#pdiTypeSpan,#bdyCheckList,#checklistFormBtn,#ajaxVLOInfoTbl").hide();
            }
        })
        $("#uploadReq").click(function () {
            if ($(this).is(":checked")) {
                $("#valoUploadDco,#uploadButtonVLO").hide();
            } else {
                $("#valoUploadDco,#uploadButtonVLO").show();
            }
        })
    })

    function tabGenerate() {
        //ajax call for PDI list
        var menuid = $("#urlMenuID").val();
        $.post(url, {action: "pdiCheckList", chassisNo: $("#ddlChassis").val(), menuid: menuid}, function () {
        }, 'JSON').done(function (data) {
            var resTable = '';
            $.each(data.checkpointData, function (indexTab, tabDetails) {
                var resTable = '<table style="background-color: #EFF3FB;">';
                var parntInc = 0;
                $.each(tabDetails, function (indexPrnt, parentDetails) {
                    if ($.type(parentDetails) == 'object') {
                        parntInc++;
                        var childInc = 0;
                        //Thead
                        if (parentDetails.TCH_INCRIMENTAL) {
                            resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='2'>" + parentDetails.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                            resTable += "<tbody><tr class='trid" + parentDetails.TCH_CHK_ID + "' id='addmoreTr" + parentDetails.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                            if (parentDetails.TCH_DATA_TYPE == 'file') {
                                resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + parentDetails.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                txtRemark = '';
                            } else {
                                resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                                txtRemark = '<textarea maxlength="1900" id="remarkBox_' + parentDetails.TCH_CHK_ID + '" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                            }
                            resTable += '<td>' + txtRemark + '</td>';
                            resTable += "</tr></tbody>";
                        } else {
                            resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                        }
                        //Tbody
                        $.each(parentDetails, function (index, childArr) {
                            childInc++;
                            if ($.type(childArr) == 'object') {
                                txtRemark = '<textarea maxlength="1900" rows="2" id="remarkBox_' + childArr.TCH_CHK_ID + '" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                resTable += "<tbody><tr id='trid" + childArr.TCH_CHK_ID + "' class='trid" + childArr.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";

                                if (childArr.TCH_DATA_TYPE == 'text' || childArr.TCH_DATA_TYPE == 'date') {
                                    resTable += '<td><input type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt" ></td>';
                                } else if (childArr.TCH_DATA_TYPE == 'radio') {
                                    $setValArr = childArr.TCH_VALUE_SET.split("##");
                                    resTable += '<td>';
                                    $setValArr.forEach(function ($value, $key) {
                                        $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                        resTable += '<label for="checkPDI' + ($key + 1) + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                    });
                                    resTable += '</td>';
                                } else if (childArr.TCH_DATA_TYPE == 'file') {
                                    resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + childArr.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                    txtRemark = '';
                                }
                                resTable += '<td>' + txtRemark + '</td>';
                                resTable += "</tr></tbody>";
                            }
                        })
                    }
                })
                resTable += "</table>";
                $('#tabMenuVHO').tabs('add', {
                    title: indexTab,
                    content: resTable,
                    closable: false
                });
                if (!$.isEmptyObject(data.AJAXCHASSISDTLS)) {
                    $("#ajaxChassisNo").html(data.AJAXCHASSISDTLS.CHASSSISNO);
                    $("#ajaxModelNo").html(data.AJAXCHASSISDTLS.TCD_MODEL);
                    $("#ajaxProtoType").html(data.AJAXCHASSISDTLS.TCD_PROTO_NO);
                    $("#ajaxWBSNo").html(data.AJAXCHASSISDTLS.TCD_WBS_LIST);
                    $("#ajaxProjCode").html(data.AJAXCHASSISDTLS.TCD_PROJ_CODE);
                    $("#ajaxVCNo").html(data.AJAXCHASSISDTLS.TCD_VC_NO);
                    $("#ajaxChassisInfoTbl").show();
                }

            })

            console.log(data);
            if (!$.isEmptyObject(data.checkpointValue)) {

                //alert(data.AJAXCHASSISDTLS[0].TLD_MODEL_NO);
                $('#txtModelNo').val(data.checkpointValue[0].TLD_MODEL_NO).attr('disabled', 'disabled');
                $('#txtProtoType').val(data.checkpointValue[0].TLD_PROTO_TYPE).attr('disabled', 'disabled');
                $('#txtEngineNo').val(data.checkpointValue[0].TLD_ENGINE_NO).attr('disabled', 'disabled');
                $('#txtProjNo').val(data.checkpointValue[0].TLD_PROJECT_NAME).attr('disabled', 'disabled');
                $('#txtWBSNo').val(data.checkpointValue[0].TLD_WBS_NO).attr('disabled', 'disabled');
                $.each(data.checkpointValue, function (chkKey, chkVal) {
                    $('input[type="text"][name="checkPDI_' + chkVal.TCD_CHK_ID + '"]').val(chkVal.TCD_VALUE);
                    $('input[name="checkPDI_' + chkVal.TCD_CHK_ID + '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
                    $("#remarkBox_" + chkVal.TCD_CHK_ID).val(chkVal.TCD_REMARKS);
                })
            }

            if (!$.isEmptyObject(data.LASTCOMMENT)) {
                $("#last_comment").val(data.LASTCOMMENT.REMARK);
                $("#pendUserName").html(data.LASTCOMMENT.PENDUSERNAME);
            } else {
                $(".hideLastComent").hide();
                $("#current_comment").css('width', '50%');
            }

            if (!$.isEmptyObject(data.AJAXVLODTLS)) {
                $("#ajaxVLOInfoTbl tbody").append(vloTrGenerate(data.AJAXVLODTLS));
                $("#ajaxVLOInfoTbl").show();
            } else {
                $("#ajaxVLOInfoTbl").hide();
            }

            $("#tabMenuVHO").tabs('select', 0);
            $('#tabMenuVHO').find('input, textarea, button, select').attr('disabled', 'disabled');
        })
        $("#checklistFormBtn").show();
    }

    function vloSubmit() {
        if (!$("#ddlPendingUser").val()) {
            alert('Please select planner!');
            $("#ddlPendingUser").focus();
            return false;
        }

        var confrm = confirm("Are you sure to proceed with this VLO upload?");
        if (confrm) {
            $("#valoForm").ajaxSubmit({
                data: {
                    chassisNo: $("#ddlChassis").val(),
                    currComment: $("#current_comment").val(),
                    pendingUser: $("#ddlPendingUser").val(),
                    emailId: $("#ddlPendingUser option:selected").data('email')
                },
                success: function (response, status, xh) {
                    alert(response);
                    openUrl(wwwRoot + "process/valocheck.php?menuid=21");
                }})
        }
        ;

    }

    function uploadVloFile() {
        if (!$("#uploadReq").is(":checked") && !$("#valoUploadDco").val()) {
            alert('Please upload VLO file!');
            return false;
        }
        $("#valoForm").ajaxSubmit({
            dataType: 'json',
            data: {
                action: 'UPLOADVLOFILE',
                chassisNo: $("#ddlChassis").val(),
                currComment: $("#current_comment").val(),
                emailId: $("#ddlPendingUser option:selected").data('email')
            },
            success: function (response, status, xh) {
                if (response.status) {
                    $("#ajaxVLOInfoTbl tbody").html(vloTrGenerate(response.VLODTLS));
                } else {
                    alert(response.msg);
                }
                $("#ajaxVLOInfoTbl").show();
            }
        });
    }
    function deleteVLO(chassisNo, fileName, slNo) {
        var confBox = confirm('Are you sure want to delete the VLO file?');
        if (confBox) {
            $.post(url, {action: "DELETEVLO", chassisNo: chassisNo, fileName: fileName, slNo: slNo}, function () {
            }, 'JSON').done(function (data) {
                if (data) {
                    var TrVlo = vloTrGenerate(data);
                    if (TrVlo)
                        $("#ajaxVLOInfoTbl tbody").html(TrVlo);
                    else
                        $("#ajaxVLOInfoTbl").hide();
                    alert('VLO file deleted successfully.');
                }
            })
        }
    }
    function vloTrGenerate(response) {
        var trVlo = '';
        $.each(response, function (indexNo, vloDtls) {
            trVlo += '<tr class="trAdd editTblTR" style="background-color: rgb(247, 246, 243); font-weight: bolder;">';
            trVlo += '<td id="ajaxSLNo">' + (++indexNo) + '</td>';
            trVlo += '<td id="ajaxFileName">' + vloDtls.NAME + '</td>';
            trVlo += '<td id="ajaxType">' + vloDtls.TYPE + '</td>';
            trVlo += '<td id="ajaxAct"><div class="ajax-file-upload-red" onclick="deleteVLO(' + '\'' + vloDtls.CHASSISNO + '\'' + ',' + '\'' + vloDtls.NAME + '\'' + ',' + '\'' + vloDtls.SLNO + '\'' + ')">Delete</div>';
            trVlo += '<div class="ajax-file-upload-green"><a href="' + vloDtls.PATH + '" style="color:#fff;text-decoration: none;" target="_blank">View</a></div></td>';
            trVlo += '</tr>';
        })
        return trVlo;
    }
</script>