<?php

include_once('./process_common_class.php');
include_once('../email/email_template_class.php');
date_default_timezone_set("Asia/Calcutta");
$process = new Process();
$emailTemplate = new emailTemplate();

if (isset($_REQUEST['action'])) {
    if (($_REQUEST['action'] == 'JIDETAILS')) {
        $retrunRes['CHECKDTLS'] = $process->checkListWithTab();
        $retrunRes['FILLDATA'] = fillDataJI();
        $retrunRes['LASTCOMMENT'] = $process->findLastComment($_REQUEST["chassisNo"]);
        echo json_encode($retrunRes);
    }
    if (($_REQUEST['action'] == 'saveJIChkList')) {
        echo saveJICheckList();
    }
}

function fillDataJI() {
    $sql = "SELECT TJD_ID,
                TJD_LOG_NO,
                TJD_CHK_ID,
                TJD_SLNO,
                TJD_VALUE,
                TJD_VEH_PARAM,
                TJD_DOC_ID,
                TJD_REMARKS
            FROM T_VHS_JI_DTLS
            WHERE TJD_LOG_NO = '{$_REQUEST["chassisNo"]}'";
    $obj = new db_connect;
    $obj->db_query($sql);
    $resTable = '';
    $returnArr = array();
    while ($row = $obj->db_fetch_arrayAssoc()) {
        if (@$row['TJD_DOC_ID']) {
            $objNew = new db_connect;
            $imageSql = "SELECT TFD_FILE_TITLE,TFD_FILE_PATH,TFD_FILE_DESC FROM T_VHS_FILE_DTLS WHERE TFD_DOC_ID ={$row['TJD_DOC_ID']}";
            $objNew->db_query($imageSql);
            while ($rowFile = $objNew->db_fetch_arrayAssoc()) {
                $row[] = $rowFile;
            }
        }
        $returnArr[$row['TJD_CHK_ID']][] = $row;
    }
    $obj->free();
    return $returnArr;
}

function saveJICheckList() {
    $process = new Process();
    $emailTemplate = new emailTemplate();

    $obj = new db_connect;

    /*
     * Delete Images from the folder
     * Delete files from the T_VHS_FILE_DTLS table
     * Delete doc from T_VHS_DOC_DTLS table
     * Delete record from  T_VHS_JI_DTLS
     */
    $imageSql = "SELECT TFD_FILE_TITLE,TFD_FILE_PATH FROM T_VHS_FILE_DTLS WHERE TFD_DOC_ID IN (SELECT TJD_DOC_ID FROM T_VHS_JI_DTLS WHERE TJD_LOG_NO = '{$_REQUEST["chassisNo"]}' AND TJD_DOC_ID is not null)";
    $resFileDetails = $obj->db_fetch_assoc($obj->db_query($imageSql));
    foreach ($resFileDetails as $keyFile => $valueFile) {
        if (file_exists('.' . $valueFile['TFD_FILE_PATH'])) {
            $newPath = WEBROOT . 'jiDocTemp/' . $valueFile['TFD_FILE_TITLE'];
            $oldPath = WEBROOT . 'jiDoc/' . $valueFile['TFD_FILE_TITLE'];
            rename($oldPath, $newPath);
        }
    }
    $deletFileSql = "DELETE FROM T_VHS_FILE_DTLS WHERE TFD_DOC_ID IN (SELECT TJD_DOC_ID FROM T_VHS_JI_DTLS WHERE TJD_LOG_NO = '" . $_REQUEST["chassisNo"] . "' AND TJD_DOC_ID is not null)";
    $obj->db_query($deletFileSql);
    $deletDocSql = "DELETE FROM T_VHS_DOC_DTLS WHERE TDD_DOC_ID IN (SELECT TJD_DOC_ID FROM T_VHS_JI_DTLS WHERE TJD_LOG_NO = '" . $_REQUEST["chassisNo"] . "' AND TJD_DOC_ID is not null)";
    $obj->db_query($deletDocSql);
    //history table will call here
    $deletJIChkSql = "DELETE FROM T_VHS_JI_DTLS WHERE TJD_LOG_NO='" . $_REQUEST["chassisNo"] . "'";
    $obj->db_query($deletJIChkSql);

    /*
     * update Logdetail -- status change
     * insert state 
     * update pending with
     * insert into ji details
     * doc details and file details
     */


    if ($_REQUEST['type'] == "saveData") {
        //Delelte state details where chassisno and stateid=6
        $deletStatDtlSql = "DELETE FROM T_VHS_STATE_DTLS WHERE TSD_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' AND TSD_STATE_ID=6";
        $obj->db_query($deletStatDtlSql);
        $stateID = 6;
        $msg = "Joint Inspection Form saved successfully! ";
    } else if ($_REQUEST['type'] == "submitData") {
        if (array_key_exists(8, $_SESSION['userSessionInfo']['ROLES']) || array_key_exists(11, $_SESSION['userSessionInfo']['ROLES'])) {
            $stateID = 8;
            $pendStateID = 7;
            $pendingUserID = " (SELECT TPD_UPD_BY from T_VHS_PENDING_DTLS WHERE TPD_CHASSIS_NO = '" . $_REQUEST["chassisNo"] . "') ";
            $emailTempJIApprProcs = $emailTemplate->JIUpdateByPAE($process->finduserNM($pendingUserID));
        } else {
            $stateID = 7;
            if (@$_REQUEST["jiStatus"] == 1) {
                $pendStateID = 9; // JI approved and go for VHD
                $pendingUserID = "(SELECT TLD_PAE_ELECT FROM T_VHS_LOG_DTLS WHERE TLD_LOG_NO ='{$_REQUEST["chassisNo"]}' )";
                $emailTempJIApprProcs = $emailTemplate->JIDoneSuccess($process->finduserNM($pendingUserID));
                $toApprProcs = '';
            } else {
                $pendStateID = 8; // JI rejected and go for modification in JI by PAE
                $pendingUserID = "(SELECT TLD_PAE_ELECT FROM T_VHS_LOG_DTLS WHERE TLD_LOG_NO ='{$_REQUEST["chassisNo"]}' )";
                $emailTempJIApprProcs = $emailTemplate->JIDoneReject($process->finduserNM($pendingUserID));
                $process->histryInsert('JIHISTORY', 12, fillDataJI());
            }
        }

        $process->pendingDtlsOperation($pendStateID, $pendingUserID, $stateID);
        $msg = "Joint Inspection Form submited successfully! ";
    }

    $process->logDtlsStatusChange($stateID);
    $process->stateDtlsOperation($stateID);

    //insert into ji details
    foreach ($_REQUEST["checklistObj"] as $value) {
        $docId = '';
        //insert doc to the doc and file tables
        if (@$value['photolistObj']) {
            //insert into doc details
            $obj = new db_connect;
            $docDetls = $obj->db_reader(" (Select nvl(max(to_number(TDD_DOC_ID)),0)+1 DOCID  from T_VHS_DOC_DTLS ) ");
            $docId = $docDetls['DOCID'][0];
            $sqlDocDtls = "INSERT INTO T_VHS_DOC_DTLS";
            $sqlDocDtls .= " ( ";
            $sqlDocDtls .= " TDD_DOC_ID ";
            $sqlDocDtls .= ", TDD_LOG_NO ";
            $sqlDocDtls .= ", TDD_TITLE ";
            $sqlDocDtls .= ", TDD_DESC ";
            $sqlDocDtls .= ", TDD_ACT_FLG ";
            $sqlDocDtls .= ", TDD_CRT_BY ";
            $sqlDocDtls .= ", TDD_CRT_TS ";
            $sqlDocDtls .= ", TDD_UPD_BY ";
            $sqlDocDtls .= ", TDD_UPD_TS ";
            $sqlDocDtls .= " ) ";
            $sqlDocDtls .= " VALUES ";
            $sqlDocDtls .= " ( ";
            $sqlDocDtls .= " $docId ";
            $sqlDocDtls .= " ,'" . $_REQUEST["chassisNo"] . "' ";
            $sqlDocDtls .= " ,'' ";
            $sqlDocDtls .= " ,'' ";
            $sqlDocDtls .= " ,1";
            $sqlDocDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
            $sqlDocDtls .= " ,SYSDATE";
            $sqlDocDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
            $sqlDocDtls .= " ,SYSDATE";
            $sqlDocDtls .= " ) ";
            $obj = new db_connect;
            $obj->db_insert($sqlDocDtls);
            foreach ($value['photolistObj'] as $filesKey => $filesVal) {
                //move file to the JIDOC folder
                $oldPath = WEBROOT . 'jiDocTemp/' . $filesVal['photoName'];
                $newPath = WEBROOT . 'jiDoc/' . $filesVal['photoName'];
                rename($oldPath, $newPath);
                //insert to file details table
                $sqlFileDtls = "INSERT INTO T_VHS_FILE_DTLS";
                $sqlFileDtls .= " ( ";
                $sqlFileDtls .= " TFD_ID ";
                $sqlFileDtls .= ", TFD_DOC_ID ";
                $sqlFileDtls .= ", TFD_FILE_TITLE ";
                $sqlFileDtls .= ", TFD_FILE_DESC ";
                $sqlFileDtls .= ", TFD_CRT_BY ";
                $sqlFileDtls .= ", TFD_CRT_TS ";
                $sqlFileDtls .= ", TFD_FILE_PATH ";
                $sqlFileDtls .= ", TFD_SLNO ";
                $sqlFileDtls .= ", TFD_ACT_FLG ";
                $sqlFileDtls .= " ) ";
                $sqlFileDtls .= " VALUES ";
                $sqlFileDtls .= " ( ";
                $sqlFileDtls .= " (Select nvl(max(to_number(TFD_ID)),0)+1 from T_VHS_FILE_DTLS ) ";
                $sqlFileDtls .= " , $docId ";
                $sqlFileDtls .= " ,'" . $filesVal['photoName'] . "' ";
                $sqlFileDtls .= " ,'" . $filesVal['photoDesc'] . "' ";
                $sqlFileDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
                $sqlFileDtls .= " ,SYSDATE";
                $sqlFileDtls .= "  , '" . './webroot/jiDoc/' . $filesVal['photoName'] . "'";
                $sqlFileDtls .= "  , " . ($filesKey + 1);
                $sqlFileDtls .= " ,1";
                $sqlFileDtls .= " ) ";
                $obj = new db_connect;
                $obj->db_insert($sqlFileDtls);
            }
        }
        $value['vehicleParam'] = @$value['addMoreParam'] . "###" . @$value['vehicleParam'];

        $sqlChekDtls = "INSERT INTO T_VHS_JI_DTLS";
        $sqlChekDtls .= " ( ";
        $sqlChekDtls .= "    TJD_ID ";
        $sqlChekDtls .= "  , TJD_LOG_NO ";
        $sqlChekDtls .= "  , TJD_CHK_ID ";
        $sqlChekDtls .= "  , TJD_SLNO ";
        $sqlChekDtls .= "  , TJD_VALUE ";
        $sqlChekDtls .= "  , TJD_REMARKS ";
        $sqlChekDtls .= "  , TJD_VEH_PARAM ";
        $sqlChekDtls .= "  , TJD_CRT_BY ";
        $sqlChekDtls .= "  , TJD_CRT_TS ";
        $sqlChekDtls .= "  , TJD_UPD_BY ";
        $sqlChekDtls .= "  , TJD_UPD_TS ";
        $sqlChekDtls .= "  , TJD_DOC_ID ";
        $sqlChekDtls .= " ) ";
        $sqlChekDtls .= " VALUES ";
        $sqlChekDtls .= " ( ";
        $sqlChekDtls .= " (Select nvl(max(to_number(TJD_ID)),0)+1  from T_VHS_JI_DTLS ) ";
        $sqlChekDtls .= " ,'" . $_REQUEST["chassisNo"] . "' ";
        $sqlChekDtls .= "  , " . $value['checkListId'];
        $sqlChekDtls .= " ,(Select nvl(max(to_number(TJD_SLNO)),0)+1  from T_VHS_JI_DTLS WHERE TJD_LOG_NO ='{$_REQUEST["chassisNo"]}' AND TJD_CHK_ID='{$value['checkListId']}') "; //###################################
        $sqlChekDtls .= "  , '" . $value['val'] . "' ";
        $sqlChekDtls .= "  , '" . @$value['remarks'] . "' ";
        $sqlChekDtls .= "  , '" . @$value['vehicleParam'] . "' ";
        $sqlChekDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlChekDtls .= "  , SYSDATE ";
        $sqlChekDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlChekDtls .= "  , SYSDATE ";
        $sqlChekDtls .= "  , '" . $docId . "'";
        $sqlChekDtls .= " ) ";
        $obj = new db_connect;
        $obj->db_insert($sqlChekDtls);
    }

    //email send
    if ($_REQUEST['type'] == "submitData") {
        //ji success mail to the user who submited 
        $emailTempJIConfirm = $emailTemplate->JIDoneUserConfirmation();
        $sent = @mail($_SESSION['userSessionInfo']["TUS_EMAIL_ID"], $emailTempJIConfirm['subject'], $emailTempJIConfirm['body'], $emailTempJIConfirm['headers']);

        //JI REJECT/SUCCESS
        if (array_key_exists(8, $_SESSION['userSessionInfo']['ROLES']) || array_key_exists(11, $_SESSION['userSessionInfo']['ROLES'])) {
            $sqlPendTo = "SELECT TUS_EMAIL_ID AS EMAIL FROM T_VHS_USERS WHERE TUS_UID = $pendingUserID";
            $resPendTo = $obj->db_fetch_assoc($obj->db_query($sqlPendTo));
            $sent = @mail($resPendTo[0]['EMAIL'], $emailTempJIApprProcs['subject'], $emailTempJIApprProcs['body'], $emailTempJIApprProcs['headers']);
        } else {
            $sqlApprProcs = "SELECT t1.TLD_PAE_ELECT paeelect,t1.TLD_PAE_MECH paemech,t2.TUS_EMAIL_ID emailelect,t3.TUS_EMAIL_ID emailmech FROM T_VHS_LOG_DTLS t1,"
                    . "T_VHS_USERS t2,T_VHS_USERS t3 WHERE t1.TLD_LOG_NO='{$_REQUEST["chassisNo"]}' AND t1.TLD_PAE_ELECT = t2.TUS_UID AND t1.TLD_PAE_MECH = t3.TUS_UID";
            $resApprProcs = $obj->db_fetch_assoc($obj->db_query($sqlApprProcs));
            $toApprProcsElect = $resApprProcs[0]['EMAILELECT'];
            $toApprProcsMech = $resApprProcs[0]['EMAILMECH'];
            $sent = @mail($toApprProcsElect, $emailTempJIApprProcs['subject'], $emailTempJIApprProcs['body'], $emailTempJIApprProcs['headers']);
            $sent = @mail($toApprProcsMech, $emailTempJIApprProcs['subject'], $emailTempJIApprProcs['body'], $emailTempJIApprProcs['headers']);
        }
    }
    $obj->free();
    return $msg;
}

?>