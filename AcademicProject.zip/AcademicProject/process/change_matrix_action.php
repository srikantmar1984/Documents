<?php

include_once('./process_common_class.php');
include_once('../email/email_template_class.php');
date_default_timezone_set("Asia/Calcutta");
$process = new Process();
$emailTemplate = new emailTemplate();

if (isset($_REQUEST['action'])) {
    if (($_REQUEST['action'] == 'JIDETAILS')) {
        $retrunRes['CHECKDTLS'] = $process->checkListWithTab();
        $retrunRes['FILLDATA'] = fillDataDaviation();
        $retrunRes['LASTCOMMENT'] = $process->findLastComment($_REQUEST["chassisNo"]);
        $retrunRes['AJAXMATRIXDTLS'] = $process->findMatrixInfo($_REQUEST["chassisNo"]);
        $retrunRes['AJAXCHASSISDTLS'] = $process->findChassisInfo($_REQUEST["chassisNo"]);
        echo json_encode($retrunRes);
    } else if (($_REQUEST['action'] == 'UPLOADMATRIXFILE')) {
        echo json_encode(uploadMatrix());
    } else if ($_REQUEST['action'] == "DELETEMATRIX") {
        deleteMATRIX();
        echo json_encode(matrixList());
        exit;
    } else if ($_REQUEST['action'] == "SAVEDAVIATION") {
        $retrunRes['msg'] = saveDeviation();
        echo json_encode($retrunRes);
        exit;
    }
}

function fillDataDaviation() {
    $sql = "SELECT TVD_CHASSIS_NO,TVD_CHK_ID,TVD_REMARKS FROM T_VHS_DEVIATION
            WHERE TVD_CHASSIS_NO = '{$_REQUEST["chassisNo"]}' AND TVD_ACT_FLG = 1";
    $obj = new db_connect;
    $obj->db_query($sql);
    $returnArr = $obj->db_fetch_assoc($obj->db_query($sql));
    $obj->free();
    return $returnArr;
}

function uploadMatrix() {
    $returnArr = array();
    ##################################################
    $NewFileName = '';
    $destination = '';
    if (@$_FILES) {
        if ($_FILES['matrixUpload']['error']) {
            $returnArr['status'] = false;
            $returnArr['msg'] = "There was an error while uploading change matrix, please try again!";
        } else {
            $UploadDirectory = WEBROOT . 'changeMatrixDoc/';
            $fileExt = substr(strtolower($_FILES['matrixUpload']['name']), strrpos(strtolower($_FILES['matrixUpload']['name']), '.')); //file extension
            $NewFileName = $_SESSION['userSessionInfo']["TUS_PLNT"] . '_' . $_REQUEST['chassisNo'] . '_' . rand(100, 999) . '_' . "MATRIX" . $fileExt;
            $source = $_FILES['matrixUpload']["tmp_name"];
            $destination = $UploadDirectory . $NewFileName;
            if (move_uploaded_file($source, $destination)) {
                $obj = new db_connect();
                $sqlSlno = "Select nvl(max(to_number(TEU_SL_NO)),0)+1 SLNO from T_VHS_EXT_UPLOAD Where TEU_CHASSIS_NO = '{$_REQUEST["chassisNo"]}' AND TEU_ULD_TYPE ='MATRIX'";
                $slno = $obj->db_fetch_assoc($obj->db_query($sqlSlno));
                $obj->free();
                $sqlFIRInsert = "INSERT INTO 
                                    T_VHS_EXT_UPLOAD (
                                                    TEU_CHASSIS_NO,
                                                    TEU_ULD_TYPE,
                                                    TEU_SL_NO,
                                                    TEU_FILE_NAME,
                                                    TEU_FILE_PATH,
                                                    TEU_ACT_FLG,
                                                    TEU_CRT_BY,
                                                    TEU_CRT_TS,
                                                    TEU_UPD_BY,
                                                    TEU_UPD_TS
                                                    )
                                    VALUES (

                                            '{$_REQUEST["chassisNo"]}',
                                            'MATRIX',
                                            {$slno[0]['SLNO']},
                                            '$NewFileName',
                                            './webroot/changeMatrixDoc/" . $NewFileName . "' ,
                                            1,
                                            {$_SESSION['userSessionInfo']["TUS_UID"]},
                                            sysdate,
                                            {$_SESSION['userSessionInfo']["TUS_UID"]},
                                            sysdate
                                        )";
                $obj = new db_connect();
                $obj->db_insert($sqlFIRInsert);
                $obj->free();
                $returnArr['status'] = true;
                $returnArr['MATRIXDTLS'] = matrixList();
                $returnArr['slno'] = $slno[0]['SLNO'];
            }
        }
    }

    return $returnArr;
    ##################################################
}

function matrixList() {
    $obj = new db_connect();
    $sqlMatrixList = " SELECT TEU_CHASSIS_NO CHASSISNO,
                        TEU_ULD_TYPE TYPE,
                        TEU_SL_NO SLNO,
                        TEU_FILE_NAME NAME,
                        TEU_FILE_PATH PATH
                  FROM T_VHS_EXT_UPLOAD
                  WHERE TEU_CHASSIS_NO = '{$_REQUEST["chassisNo"]}'
                  AND TEU_ULD_TYPE     = 'MATRIX' AND TEU_ACT_FLG=1";
    $matrixDtls = $obj->db_fetch_assoc($obj->db_query($sqlMatrixList));
    $obj->free();
    return $matrixDtls;
}

function deleteMATRIX() {
    $obj = new db_connect;
    $sqlDelete = "UPDATE T_VHS_EXT_UPLOAD SET TEU_ACT_FLG=3 WHERE TEU_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' AND TEU_ULD_TYPE='MATRIX' AND TEU_FILE_NAME='" . $_REQUEST["fileName"] . "' AND TEU_SL_NO='" . $_REQUEST["slNo"] . "'";
    $obj->db_query($sqlDelete);
    $obj->free();
    return TRUE;
}

function saveDeviation() {
    $process = new Process();
    $emailTemplate = new emailTemplate();
    $msgReturn = "Due to some internal problem your data couldn't save. Please try after sometime or contact support team.";
    $deleteFlg = deleteDeviations($_REQUEST["chassisNo"]); //delete all record from t_vhs_deviation where chessisNo = this
    if ($deleteFlg) {
        insertDeviations();
        if ($_REQUEST['type'] == "saveData") {
            //show alert message with save flag
            $msgReturn = "Deviations are saved successfully!";
        } else if ($_REQUEST['type'] == "submitData") {
            /*
             * update Logdetail -- status change
             * insert state 
             * update pending with
             * Email sent
             */
            $process->logDtlsStatusChange(6);
            $process->stateDtlsOperation(6);
            $process->pendingDtlsOperation(7, $_REQUEST['pendingUser'], 6);

            $emailTempDeviationConfm = $emailTemplate->deviationDoneConfirmation($_SESSION['userSessionInfo']['TUS_NAME']);
            $sent = @mail($_SESSION['userSessionInfo']["TUS_EMAIL_ID"], $emailTempDeviationConfm['subject'], $emailTempDeviationConfm['body'], $emailTempDeviationConfm['headers']);

            $emailTempDeviationIntm = $emailTemplate->deviationDoneIntimation($_REQUEST['pendingUserName']);
            $sent = @mail($_REQUEST["pendingUserEmail"], $emailTempDeviationIntm['subject'], $emailTempDeviationIntm['body'], $emailTempDeviationIntm['headers']);
            $msgReturn = "Deviations are submitted successfully!";
        }
    }
    return $msgReturn;
    //delete all record from t_vhs_deviation where chessisNo = this
    //insert all daviations and remarks
}

function deleteDeviations($chassisNo) {
    $obj = new db_connect;
    $sqlToDel = "DELETE FROM T_VHS_DEVIATION WHERE TVD_CHASSIS_NO = '" . $chassisNo . "'";
    $obj->db_query($sqlToDel);
    $obj->free();
    return TRUE;
}

function insertDeviations() {
    $strSql = "INSERT ALL";
    foreach ($_REQUEST['checklistObj'] as $key => $value) {
        $strSql .= " into T_VHS_DEVIATION(TVD_CHASSIS_NO,TVD_CHK_ID,TVD_ACT_FLG,TVD_REMARKS,TVD_CRT_BY,TVD_CRT_TS,TVD_UPD_BY,TVD_UPD_TS)
                    values('" . $_REQUEST["chassisNo"] . "'," . $value['checkListId'] . ",1,'" . $value['remarks'] . "'," . $_SESSION['userSessionInfo']["TUS_UID"] . ",SYSDATE," . $_SESSION['userSessionInfo']["TUS_UID"] . ",SYSDATE)";
    }
    $strSql .= "  SELECT * FROM dual ";
    $obj = new db_connect;
    $obj->db_query($strSql);
    $obj->free();
    return TRUE;
}

?>