<?php

class WebApi {

    var $sid, $connection;
    var $query;
    var $host;
    var $total_record, $rec_position;
    var $total_fields, $field_name;

    function bcDetails($projCode = NULL) {
        $HOST = "172.22.97.4";
        $PORT = "1521";
        $USER_NAME = "SUPPROD";
        $PASSWORD = "pcolour";
        $SID = "plmps";
        $this->db_connect($HOST, $SID, $USER_NAME, $PASSWORD);
        $this->db_query("select partnumber, ownername from assembly where ProjectName='$projCode' and PartType='V' and Superseded='-' AND ownername= 'Release Vault'");
//        $this->db_query("select partnumber, ownername from assembly where ProjectName='2067' and PartType='V' and Superseded='-' AND ownername= 'Release Vault'");
        $tyreSizeListArr = $this->db_fetch_assoc();
        return $tyreSizeListArr;
    }

    function db_connect($HOST, $SID, $USER_NAME, $PASSWORD) {
        $this->host = "" . $HOST . "";
        $this->sid = "(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=" . $HOST . ")(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=" . $SID . ")))";
        $this->connection = ocilogon($USER_NAME, $PASSWORD, $this->sid) or die($this->get_error_msg($this->connection, "Problem while connecting to " . $this->sid . " server...")); //username,password,sid
    }

    function db_query($query_str = "") {
        $this->sql = $query_str;
        $this->rec_position = 0;
        $this->query = @ociparse($this->connection, $query_str);
        ociexecute($this->query)or die($this->get_error_msg($this->query, "Query Error : " . $query_str));
    }

    function db_fetch_assoc() {
        $rows = array();
        while ($result = @oci_fetch_assoc($this->query)) {
            $rows[] = $result;
        }
        return $rows;
    }

    function get_error_msg($error_no, $msg = "") {
        $log_msg = NULL;
        $error_msg = "<b>Custom Error :</b> <pre><font color=red>\n\t" . ereg_replace(",", ",\n\t", $msg) . "</font></pre>";
        $error_msg .= "<b><i>System generated Error :</i></b>";
        $error_msg .= "<font color=red><pre>";
        foreach (ocierror($error_no) as $key => $val) {
            $log_msg .= "$key :  " . $val . "\n";
            $error_msg .= "$key : $val \n";
        }

        $error_msg .= "</pre></font>";
        return $error_msg;
    }

}

$webApi = new WebApi();
?>