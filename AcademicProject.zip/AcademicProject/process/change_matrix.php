<?php include("./process_common_class.php"); ?>
<input type="hidden" id="hfPageTitle" value="Change Matrix and Deviation" screen_id="">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<div class="Grid" style="text-align: left;">
    <!--<form name="formDaviation" class="formDaviation" id="logInc">-->
    <form id="formDaviation"  enctype="multipart/form-data" action="process/change_matrix_action.php" method="post" >
        <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td colspan="4">
                        <span>
                            <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                            <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select Chassis No--</option>
                                <?php
                                $chassisDtlArr = $process->chassisPending();
                                foreach ($chassisDtlArr as $value) {
                                    echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>
                    </td>
                </tr>
                <tr style="height:24px">
                    <td colspan="4">
                        <!--###########################################
                        ########## Chassis Details Start ##############
                        ###########################################-->
                        <?php include("ajax_chassis_details.php"); ?>
                        <!--###########################################
                        ############## Chassis Details End ############
                        ###########################################-->
                    </td>
                </tr>
            </tbody>
            <tbody id="tbodyChngMatrix" style="background-color: #EFF3FB;display: none" >
                <tr style="height:40px">
                    <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                        <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                            <b>CHANGE MATRIX UPLOAD</b>
                        </span>
                    </td>
                </tr>
                <tr style="height: 35px;">
                    <!--<td style="width:2%">1</td>-->
                    <td  style="width:10%;">
                        <span>
                            <label id="lblPDI1" for="checkPDI1">
                                <!--<input type="checkbox" value="1" id="uploadReq" name="uploadReq"/>-->
                                <b>Upload Matrix </b>
                            </label>
                        </span>
                    </td>
                    <td colspan="3" style="width:44%">
                        <input type="file" name="matrixUpload" id="matrixUpload" />
                        <button type="button" class="blue-button" id="uploadButtonMATRIX" onclick="uploadMatrixFile();">Upload</button>
                    </td>
                </tr>
            </tbody>
        </table>
        <!--================================================================================-->
        <!--====================== Change Matrix start =======================================-->
        <!--================================================================================-->
        <table id="ajaxMATRIXInfoTbl" cellpadding="0" cellspacing="0" style="display: none">
            <thead>
                <tr style="height:40px">
                    <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                        <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                            <b>Change Matrix Details</b>
                        </span>
                    </td>
                </tr>
                <tr>
                    <th width="5%">Sr.No</th>
                    <th width="15%">File Name</th>
                    <th width="15%">Type</th>
                    <th width="15%">Action</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        <!--================================================================================-->
        <!--======================== Change Matrix End =======================================-->
        <!--================================================================================-->
        <table class="" width="100%" cellpadding="0" cellspacing="0" id="test" >
            <tr style="height:40px;display: none" class="hideNoChassis">
                <td colspan="3" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>SET DEVIATIONS FOR VEHICLE JOINT INSPECTION</b>
                    </span>
                </td>
            </tr>
        </table>
        <div id="tabMenuVHO" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
            <!--Tabs are added dynamically here-->
        </div>
        <table class="assignTable" width="100%" cellpadding="0" cellspacing="0" style="display: none" >

            <tr style="height:40px">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>Comment</b>
                    </span>
                </td>
            </tr>
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td style="width: 20%" class="hideLastComent">
                        <span class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Last Comment By: </b><b style="color: #3637FE" id="pendUserName"></b></label>
                        </span>
                    </td>
                    <td class="hideLastComent">
                        <span class="chassisDtlSpan" >
                            <textarea placeholder="Last Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="last_comment" rows="2" maxlength="1900" disabled="disabled"></textarea>
                        </span>
                    </td>
                    <td style="width: 20%">
                        <span class="chassisDtlSpan" >
                            <label><b>If have any comment? :</b></label>
                        </span>
                    </td>
                    <td>
                        <span class="chassisDtlSpan" >
                            <textarea placeholder="Please Put Your Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="current_comment" rows="2" maxlength="1900"></textarea>
                        </span>


                    </td>


                </tr>
                <tr>
                    <td>
                        <span>
                            <label><b>Assigned To Test Project Manager</b></label>
                        </span>
                    </td>
                    <td>
                        <select id="ddlPendingUser" name="ddlPendingUser" style="width:95%;"  class="ddlFieldDropdown">
                            <option value="">--Select Project Manager--</option>
                            <?php
                            $users = $process->assignedUserByRole(9);
                            foreach ($users as $value) {
                                echo '<option value="' . $value['USERID'] . '" data-email="' . $value['EMAIL'] . '" data-onlyusername="' . $value['ONLYUSERNAME'] . '" >' . $value['USERNAME'] . '</option>';
                            }
                            ?> 
                        </select>
                    </td>
                    <td></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
        <div id="jiEntryFormBtn" style="margin:10px;display: none">
            <a href="javascript:void(0);" class="kks-linkbutton l-btn,confirm" align="left" onclick="confirmClear();">
                <span style="text-align:left;" >Clear All</span>
            </a>	

            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" onclick="saveDeviation('saveData');">
                <span  style="text-align:left;" >Save data</span>
            </a>
            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" id="linkSubmitPaps" onclick="saveDeviation('submitData');">
                <span  style="text-align:left;" >Submit</span>				 
            </a>
        </div>

    </form>
</div>
<div id="dd"></div>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript">
var url = wwwRoot + "process/change_matrix_action.php";
$(function () {
    $('.layout-button-left').trigger('click');
    $("#ddlChassis").change(function () {
        var tabNos = $('.tabs >li').length;
        for (i = 0; i < tabNos; i++) {
            $("#tabMenuVHO").tabs('close', 0);
        }
        if ($(this).val()) {
            //ajax call for ji list
            var menuid = $("#urlMenuID").val();
            $.post(url, {action: "JIDETAILS", chassisNo: $(this).val(), menuid: menuid}, function () {
            }, 'JSON').done(function (data) {
                var resTable = '';
                $.each(data.CHECKDTLS, function (indexTab, tabDetails) {
                    var resTable = '<table style="background-color: #EFF3FB;">';
                    resTable += "<thead><tr><th style='width:2%'>SL.NO.</th><th>Parameters</th><th style='width:2%'>Deviation</th><th>Remarks</th></tr></thead>";
                    var parntInc = 0;
                    $.each(tabDetails, function (indexPrnt, parentDetails) {
                        if ($.type(parentDetails) == 'object') {
                            parntInc++;
                            var childInc = 0;
                            //Thead
                            if (parentDetails.TCH_INCRIMENTAL) {
                                resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                                resTable += "<tbody><tr id='trid" + parentDetails.TCH_CHK_ID + "' class='trid" + parentDetails.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + ".1</td><td>" + parentDetails.TCH_CHECK_POINT + "</td>";
                                resTable += '<td style="text-align: center;">';
                                resTable += '<input type="checkbox" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + parentDetails.TCH_CHK_ID + '"  value="1" class="checkJiDev">';
                                resTable += '</td>';
                                txtRemark = '<textarea id="remarkBox_' + parentDetails.TCH_CHK_ID + '" maxlength="1900" rows="2" class="txtFieldTextBox jidevRemark" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                resTable += '<td>' + txtRemark + '</td>';
                                resTable += "</tr></tbody>";
                            } else {
                                resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                            }
                            //Tbody
                            $.each(parentDetails, function (index, childArr) {
                                childInc++;
                                if ($.type(childArr) == 'object') {
                                    txtRemark = '<textarea id="remarkBox_' + childArr.TCH_CHK_ID + '" maxlength="1900" rows="2" class="txtFieldTextBox jidevRemark" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                    resTable += "<tbody><tr id='trid" + childArr.TCH_CHK_ID + "' class='trid" + childArr.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";
                                    resTable += '<td style="text-align: center;">';
                                    resTable += '<input type="checkbox" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + childArr.TCH_CHK_ID + '"  value="1" class="checkJiDev">';
                                    resTable += '</td>';
                                    resTable += '<td>' + txtRemark + '</td>';
                                    resTable += "</tr></tbody>";
                                }
                            })
                        }
                    })
                    resTable += "</table>";
                    $('#tabMenuVHO').tabs('add', {
                        title: indexTab,
                        content: resTable,
                        closable: false
                    });
                    if (!$.isEmptyObject(data.AJAXCHASSISDTLS)) {
                        $("#ajaxChassisNo").html(data.AJAXCHASSISDTLS.CHASSSISNO);
                        $("#ajaxModelNo").html(data.AJAXCHASSISDTLS.TCD_MODEL);
                        $("#ajaxProtoType").html(data.AJAXCHASSISDTLS.TCD_PROTO_NO);
                        $("#ajaxWBSNo").html(data.AJAXCHASSISDTLS.TCD_WBS_LIST);
                        $("#ajaxProjCode").html(data.AJAXCHASSISDTLS.TCD_PROJ_CODE);
                        $("#ajaxVCNo").html(data.AJAXCHASSISDTLS.TCD_VC_NO);
                        $("#ajaxChassisInfoTbl").show();
                    }

                })


                if (!$.isEmptyObject(data.FILLDATA)) {
                    $.each(data.FILLDATA, function (chkKey, chkVal) {
                        $("#checkPDI" + chkVal.TVD_CHK_ID).prop('checked', true);
                        $("#remarkBox_" + chkVal.TVD_CHK_ID).val(chkVal.TVD_REMARKS);
                    })
                }

                if (!$.isEmptyObject(data.LASTCOMMENT)) {
                    $("#last_comment").val(data.LASTCOMMENT.REMARK);
                    $("#pendUserName").html(data.LASTCOMMENT.PENDUSERNAME);
                } else {
                    $(".hideLastComent").hide();
                    $("#current_comment").css('width', '50%');
                }
                if (!$.isEmptyObject(data.AJAXMATRIXDTLS)) {
                    $("#ajaxMATRIXInfoTbl tbody").append(matrixTrGenerate(data.AJAXMATRIXDTLS));
                    $("#ajaxMATRIXInfoTbl").show();
                } else {
                    $("#ajaxMATRIXInfoTbl tbody").html('');
                    $("#ajaxMATRIXInfoTbl").hide();
                }
                $("#tabMenuVHO").tabs('select', 0);
            })
            $("#pdiEnggType").trigger('change');
            $("#txtModelNo").val($('option:selected', $(this)).data('modeltypeno')).attr('readonly', true);
            $("#jiEntryFormBtn,.assignTable,#tbodyChngMatrix,#ajaxMATRIXInfoTbl,.hideNoChassis").show();
        } else {
            $("#txtModelNo").val('').attr('readonly', true);
            $("#ajaxMATRIXInfoTbl tbody").html('');
            $("#jiEntryFormBtn,.assignTable,#tbodyChngMatrix,#ajaxMATRIXInfoTbl,.hideNoChassis").hide();
        }
    })
})

function saveDeviation(type) {

//        #################################################################################################
    var deviationFlg = 0;
    var chassisNo = $('#ddlChassis').val();
    var checklistObj = [];
    $('.checkJiDev').each(function () {
        var remarks = $(this).closest('tr').find('.jidevRemark').val();
        if ($(this).is(':checked')) {
            checklistObj.push({checkListId: $(this).attr('checklist_id'), remarks: remarks});
        }
    })
    if ($.isEmptyObject(checklistObj)) {
        deviationFlg = 1;
        alert("You haven't set any deviations. Please set deviation before save!");
        return false;
    }
//        alert($("#ajaxMATRIXInfoTbl tbody tr").length);
    var confmMsgStr = "Are you sure want to save change matrix?";
    if (type == "submitData") {
        if (!$("#ddlPendingUser").val()) {
            alert('Please select Test Project Manager!');
            $("#ddlPendingUser").focus();
            return false;
        }
        confmMsgStr = "Are you sure want to submit change matrix?";
        if (!$("#ajaxMATRIXInfoTbl tbody tr").length) {
            confmMsgStr = "Matrix file is not uploaded. Are you sure want to submit without uploading change matrix?";
        }
    }

//        console.log(checklistObj);return false;
    var confMsg = confirm(confmMsgStr);
    if (confMsg) {
        $.post(url,
                {
                    type: type,
                    chassisNo: chassisNo,
                    checklistObj: checklistObj,
                    currComment: $("#current_comment").val(),
                    pendingUser: $("#ddlPendingUser").val(),
                    pendingUserEmail: $("#ddlPendingUser option:selected").data('email'),
                    pendingUserName: $("#ddlPendingUser option:selected").data('onlyusername'),
                    action: 'SAVEDAVIATION'
                }, function () {
        }, 'JSON').done(function (data) {
            alert(data.msg);
            if (type == "submitData") {
                openUrl(wwwRoot + "process/change_matrix.php?menuid=28");
            }
        })
    }
    return false;
//        #################################################################################################
}

function uploadMatrixFile() {
    if (!$("#uploadReq").is(":checked") && !$("#matrixUpload").val()) {
        alert('Please upload change matrix file!');
        return false;
    }
    $("#formDaviation").ajaxSubmit({
        dataType: 'json',
        data: {
            action: 'UPLOADMATRIXFILE',
            chassisNo: $("#ddlChassis").val()
        },
        success: function (response, status, xh) {
            if (response.status) {
//                console.log(response);return false;
                $("#ajaxMATRIXInfoTbl tbody").html(matrixTrGenerate(response.MATRIXDTLS));
            } else {
                alert(response.msg);
            }
            $("#ajaxMATRIXInfoTbl").show();
        }
    });
}

function matrixTrGenerate(response) {
    var trMATRIX = '';
    $.each(response, function (indexNo, matrixDtls) {
        trMATRIX += '<tr class="trAdd editTblTR" style="background-color: rgb(247, 246, 243); font-weight: bolder;">';
        trMATRIX += '<td id="ajaxSLNo">' + (++indexNo) + '</td>';
        trMATRIX += '<td id="ajaxFileName">' + matrixDtls.NAME + '</td>';
        trMATRIX += '<td id="ajaxType">' + matrixDtls.TYPE + '</td>';
        trMATRIX += '<td id="ajaxAct"><div class="ajax-file-upload-red" onclick="deleteMATRIX(' + '\'' + matrixDtls.CHASSISNO + '\'' + ',' + '\'' + matrixDtls.NAME + '\'' + ',' + '\'' + matrixDtls.SLNO + '\'' + ')">Delete</div>';
        trMATRIX += '<div class="ajax-file-upload-green"><a href="' + matrixDtls.PATH + '" style="color:#fff;text-decoration: none;" target="_blank">View</a></div></td>';
        trMATRIX += '</tr>';
    })
    return trMATRIX;
}

function deleteMATRIX(chassisNo, fileName, slNo) {
    var confBox = confirm('Are you sure want to delete the change matrix file?');
    if (confBox) {
        $.post(url, {action: "DELETEMATRIX", chassisNo: chassisNo, fileName: fileName, slNo: slNo}, function () {
        }, 'JSON').done(function (data) {
            if (data) {
                var trMATRIX = matrixTrGenerate(data);
                if (trMATRIX) {
                    $("#ajaxMATRIXInfoTbl tbody").html(trMATRIX);
                } else {
                    $("#ajaxMATRIXInfoTbl").hide();
                    $("#ajaxMATRIXInfoTbl tbody").html('');
                }
                alert('Change matrix file deleted successfully.');
            }
        })
    }
}

function confirmClear()
{
    $('input[type="Checkbox"][value="1"]').prop('checked', false);
    $('#current_comment').val('');
    $('#ddlPendingUser').val('');
    $('.jidevRemark').val('');
}

</script>