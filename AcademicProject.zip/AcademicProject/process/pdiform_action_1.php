<?php

include_once('./process_common_class.php');
include_once('../email/email_template_class.php');
$ref = 'on';
date_default_timezone_set("Asia/Calcutta");
$process = new Process();
if (isset($_REQUEST['action'])) {

    if (($_REQUEST['action'] == 'pdiCheckList')) {
        
        $finalArr['checkpointData'] = $process->checkListWithTab();
        $finalArr['checkpointValue'] = findPDISavedData();
        echo json_encode($finalArr);exit;
//        echo json_encode($process->checkListWithTab());exit;
//        if ($_REQUEST['enggType'] == "Electrical") {
////            $form_type = 'PDI_DOC_MECH';
//            $tabID = 426;
//        } else if ($_REQUEST['enggType'] == "Mechanical") {
////            $form_type = 'PDI_DOC_MECH';
//            $tabID = 425;
//        }
//        echo json_encode(pdiCheckList($tabID));
        echo json_encode(pdiSavedData());exit;
    } else if ($_REQUEST['action'] == 'saveChkList') {
//        print_r($_REQUEST);EXIT;
//        if ($_REQUEST['enggType'] == "Electrical") {
             if ($_REQUEST['type'] == "saveData") {
                $stateID = 2;
            }else if ($_REQUEST['type'] == "submitData") {
                $stateID = 3;
            }
//        }
//        else if ($_REQUEST['enggType'] == "Mechanical") {
//            if ($_REQUEST['type'] == "saveData") {
//                $stateID = 1;
//            }else if ($_REQUEST['type'] == "submitData") {
//                $stateID = 2;
//            }
//        }
        savePdiCheckList($stateID);
    }
}

function findPDISavedData() {
    $sql = "SELECT TCD_LOG_NO,
  TCD_CHK_ID,
  TCD_VALUE,
  TCD_REMARKS,
  TLD_MODEL_NO,
  TLD_PROTO_TYPE,
  TLD_ENGINE_NO,
  TLD_WBS_NO,
  TLD_PROJECT_NAME,
  TLD_BUGET_CODE
FROM T_VHS_CHECK_DTLS,
  T_VHS_LOG_DTLS
WHERE TCD_LOG_NO = '{$_REQUEST["chassisNo"]}'
AND TLD_LOG_NO   = TCD_LOG_NO";
//    $sql = "Select 
//                *
//            FROM 
//                T_VHS_LOG_DTLS
//            WHERE
//                TLD_LOG_NO = '{$_REQUEST["chassisNo"]}'
//                ORDER BY TCH_CHK_ID ASC ";
//return $sql;
    $obj = new db_connect;
    $obj->db_query($sql);
    $resTable = '';
    $returnArr = array();
    while ($row = $obj->db_fetch_arrayAssoc()) {
        $returnArr[] = $row;
    }
    $obj->free();
    return $returnArr;
}
//function pdiCheckList($tabID) {
//    $sql = "Select 
//                TCH_CHK_ID,
//                TCH_CHECK_POINT,
//                TCH_ACT_FLG,
//                TCH_DATA_TYPE,
//                TCH_PARENT_ID,
//                TCH_VALUE_SET
//            FROM 
//                T_VHS_CHECK_HEAD
//            WHERE
//                TCH_TAB_ID = $tabID
//                AND TCH_ACT_FLG = 1
//                ORDER BY TCH_CHK_ID ASC ";
//    $obj = new db_connect;
//    $obj->db_query($sql);
//    $resTable = '';
//    $returnArr = array();
//    while ($row = $obj->db_fetch_arrayAssoc()) {
//        $returnArr[] = $row;
//    }
//    $obj->free();
//    return $returnArr;
//}

function savePdiCheckList($stateID = NULL) {
    /*
     * STEP-1: First delete all corrensponding table records with the basis of current chassis number
     * STEP-2: Save data to the 'T_VHS_LOG_DTLS' table.
     * STEP-3: Save data to the 'T_VHS_STATE_DTLS' table.
     * STEP-4: Save data to the 'T_VHS_CHECK_DTLS' table.
     * STEP-5: Save data to the 'T_VHS_PENDING_DTLS' table.
     */
    //STEP-1: A) Delete record from  T_VHS_LOG_DTLS
    $deletLogSql = "DELETE FROM T_VHS_LOG_DTLS WHERE TLD_LOG_NO='".$_REQUEST["chassisNo"]."'";
    $deletStateSql = "DELETE FROM T_VHS_STATE_DTLS WHERE TSD_CHASSIS_NO='".$_REQUEST["chassisNo"]."'";
    $deletChkSql = "DELETE FROM T_VHS_CHECK_DTLS WHERE TCD_LOG_NO='".$_REQUEST["chassisNo"]."'";
//    $deletPendSql = "DELETE FROM T_VHS_PENDING_DTLS WHERE TPD_CHASSIS_NO='".$_REQUEST["chassisNo"]."'";
    $obj=new db_connect;
    $obj->db_query($deletLogSql);
    $obj->db_query($deletStateSql);
    $obj->db_query($deletChkSql);
//    $obj->db_query($deletPendSql);
    $obj->free();
    //STEP:1
    $sqlLogDtls = "INSERT INTO T_VHS_LOG_DTLS( 
                        TLD_LOG_NO, 
                        TLD_SLNO,
                        TLD_MODEL_NO,
                        TLD_PROTO_TYPE,
                        TLD_CHASSIS_NO,
                        TLD_ENGINE_NO,
                        TLD_WBS_NO,
                        TLD_PROJECT_NAME,
                        TLD_BUGET_CODE,
                        TLD_STATUS,
                        TLD_PLANT_ID,
                        TLD_CRT_BY,
                        TLD_CRT_TS,
                        TLD_UPD_BY,
                        TLD_UPD_TS 
                        ) ";
    $sqlLogDtls .= " VALUES ( ";
    $sqlLogDtls .= "'".$_REQUEST["chassisNo"]."'";
    $sqlLogDtls .= "  ,  (Select nvl(max(to_number(TLD_SLNO)),0)+1  from T_VHS_LOG_DTLS ) ";
    $sqlLogDtls .= "  , '" . $_REQUEST["modelNo"] . "' ";
    $sqlLogDtls .= "  , '" . $_REQUEST["protoTypeNo"] . "' ";
    $sqlLogDtls .= "  , '" . $_REQUEST["chassisNo"] . "' ";
    $sqlLogDtls .= "  , '" . $_REQUEST["enggNo"] . "' ";
    $sqlLogDtls .= "  , '" . $_REQUEST["wbsNo"] . "' ";
    $sqlLogDtls .= "  , '" . $_REQUEST["projectName"] . "' ";
    $sqlLogDtls .= "  , '" . $_REQUEST["enggNo"] . "' ";
    $sqlLogDtls .= "  , 1";#status will update
    $sqlLogDtls .= "  ," . $_SESSION['userSessionInfo']["TUS_PLNT"];
    $sqlLogDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
    $sqlLogDtls .= "  , SYSDATE ";
    $sqlLogDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
    $sqlLogDtls .= "  , SYSDATE ";
    $sqlLogDtls .= " ) ";
    $obj = new db_connect;
    $obj->db_insert($sqlLogDtls);
    $obj->free();
//    print_r($_REQUEST);exit;
    
    //STEP:2
    $sqlStatDtls = "INSERT INTO T_VHS_STATE_DTLS";
    $sqlStatDtls .= " ( ";
    $sqlStatDtls .= "    TSD_STATE_ID ";
    $sqlStatDtls .= "  , TSD_TRANS_ID ";//Primary key of that table.
    $sqlStatDtls .= "  , TSD_CHASSIS_NO ";
    $sqlStatDtls .= "  , TSD_CRT_BY ";
    $sqlStatDtls .= "  , TSD_CRT_TS ";
    $sqlStatDtls .= "  , TSD_UPD_BY ";
    $sqlStatDtls .= "  , TSD_UPD_TS ";
    $sqlStatDtls .= " ) ";
    $sqlStatDtls .= " VALUES ";
    $sqlStatDtls .= " ( ";

    $sqlStatDtls .= $stateID;
    $sqlStatDtls .= "  ,  (Select nvl(max(to_number(TSD_TRANS_ID)),0)+1  from T_VHS_STATE_DTLS ) ";
    $sqlStatDtls .= "  , '" . $_REQUEST["chassisNo"] . "' ";
    $sqlStatDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
    $sqlStatDtls .= "  , SYSDATE ";
    $sqlStatDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
    $sqlStatDtls .= "  , SYSDATE ";
    $sqlStatDtls .= " ) ";
    $obj = new db_connect;
    $obj->db_insert($sqlStatDtls);
    $obj->free();
//    $sqlStatDtls = "INSERT INTO T_VHS_STATE_DTLS";
//    $sqlStatDtls .= " ( ";
//    $sqlStatDtls .= "    TSD_STATE_HEAD_ID ";
//    $sqlStatDtls .= "  , TSD_LOG_NO ";
//    $sqlStatDtls .= "  , TSD_CHASSIS_NO ";
//    $sqlStatDtls .= "  , TSD_CRT_BY ";
//    $sqlStatDtls .= "  , TSD_CRT_TS ";
//    $sqlStatDtls .= "  , TSD_UPD_BY ";
//    $sqlStatDtls .= "  , TSD_UPD_TS ";
//    $sqlStatDtls .= " ) ";
//    $sqlStatDtls .= " VALUES ";
//    $sqlStatDtls .= " ( ";
//
//    $sqlStatDtls .= $stateID;
//    $sqlStatDtls .= "  , '" . $_REQUEST["chassisNo"] . "' ";
//    $sqlStatDtls .= "  , '" . $_REQUEST["chassisNo"] . "' ";
//    $sqlStatDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
//    $sqlStatDtls .= "  , SYSDATE ";
//    $sqlStatDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
//    $sqlStatDtls .= "  , SYSDATE ";
//    $sqlStatDtls .= " ) ";
//    $obj = new db_connect;
//    $obj->db_insert($sqlStatDtls);
//    $obj->free();
    
    //STEP:3
    foreach ($_REQUEST["checklistObj"] as $value) {
        $sqlChekDtls = "INSERT INTO T_VHS_CHECK_DTLS";
        $sqlChekDtls .= " ( ";
//    $sqlChekDtls .= "    TCD_ID ";
        $sqlChekDtls .= "    TCD_LOG_NO ";
        $sqlChekDtls .= "  , TCD_CHK_ID ";
        $sqlChekDtls .= "  , TCD_CHASSIS_NO ";
        $sqlChekDtls .= "  , TCD_VALUE ";
        $sqlChekDtls .= "  , TCD_REMARKS ";
        $sqlChekDtls .= "  , TCD_CRT_BY ";
        $sqlChekDtls .= "  , TCD_CRT_TS ";
        $sqlChekDtls .= "  , TCD_UPD_BY ";
        $sqlChekDtls .= "  , TCD_UPD_TS ";
        $sqlChekDtls .= " ) ";
        $sqlChekDtls .= " VALUES ";
        $sqlChekDtls .= " ( ";        
        $sqlChekDtls .= " '" . $_REQUEST["chassisNo"] . "' ";
        $sqlChekDtls .= "  , ". $value['checkListId'];
        $sqlChekDtls .= "  , '". $_REQUEST["chassisNo"] . "' ";
        $sqlChekDtls .= "  , '" . $value['val'] . "' ";
        $sqlChekDtls .= "  , '" . $value['remarks'] . "' ";
        $sqlChekDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlChekDtls .= "  , SYSDATE ";
        $sqlChekDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlChekDtls .= "  , SYSDATE ";
        $sqlChekDtls .= " ) ";
        $obj = new db_connect;
        $obj->db_insert($sqlChekDtls);
    }
    
    if($_REQUEST['type'] == "submitData"){
        
    //STEP:4
    
        $sqlPendDtls = "INSERT INTO T_VHS_PENDING_DTLS";
        $sqlPendDtls .= " ( ";
        $sqlPendDtls .= "    TPD_CHASSIS_NO ";
        $sqlPendDtls .= "  , TPD_STATE_ID ";
        $sqlPendDtls .= "  , TPD_PEND_WITH ";
        $sqlPendDtls .= "  , TPD_UPD_BY ";
        $sqlPendDtls .= "  , TPD_UPD_TS ";
        $sqlPendDtls .= " ) ";
        $sqlPendDtls .= " VALUES ";
        $sqlPendDtls .= " ( ";
        $sqlPendDtls .= "'" . $_REQUEST["chassisNo"] . "' ";
        $sqlPendDtls .= " , " . $stateID;
        $sqlPendDtls .= "  ,  ( SELECT T_VHS_USERS.TUS_UID FROM T_VHS_USERS,T_ERC_ROLE_USER WHERE T_VHS_USERS.TUS_UID = T_ERC_ROLE_USER.TRU_USER_ID AND T_ERC_ROLE_USER.TRU_ROLE_ID = 7 ) ";
        $sqlPendDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlPendDtls .= "  , SYSDATE ";
        $sqlPendDtls .= " ) ";
        $obj = new db_connect;
        $obj->db_insert($sqlPendDtls);
    //Update Chassis flag(TCD_IS_PDI_DONE) in table T_VHS_CHASSIS_DTLS
        $updateChasisFlag = "UPDATE T_VHS_CHASSIS_DTLS SET TCD_IS_PDI_DONE=1 WHERE TCD_CHASSIS_NO='". $_REQUEST["chassisNo"] . "' ";
        $obj->db_query($updateChasisFlag);       
        $obj->free();
        
        /*
         * Email Notifications
         * @@@ First mail sent to the PAI to acknowledge the PDI completion
         * @@@ Second mail sent to the PAE to confirm the PDI completion
         */
        //Send mail to the PAI.
        $obj = new db_connect;
        $paiEmailSql = "SELECT T_VHS_USERS.TUS_EMAIL_ID FROM T_VHS_USERS,T_ERC_ROLE_USER WHERE T_VHS_USERS.TUS_UID = T_ERC_ROLE_USER.TRU_USER_ID AND T_ERC_ROLE_USER.TRU_ROLE_ID = 7 ";
        $emailPAI = $obj->db_fetch_assoc($obj->db_query($paiEmailSql));       
        $obj->free();
        $emailTempCont = $emailTemplate->pdiDoneNotifyToPAI();
        $to = $emailPAI[0];
        $sent = @mail($to, $emailTempCont['subject'], $emailTempCont['body'], $emailTempCont['headers']);
        
        //Send mail to the PAE.
        $emailTempCont = $emailTemplate->pdiDoneConfirmToPAE();
        $to = $_SESSION['userSessionInfo']["TUS_EMAIL_ID"];
        $sent = @mail($to, $emailTempCont['subject'], $emailTempCont['body'], $emailTempCont['headers']);
        
    }
    
//        $obj->free();
//        print_r($_REQUEST);exit;
}

?>