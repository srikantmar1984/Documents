<table id="ajaxFirInfoTbl" cellpadding="0" cellspacing="0" style="display: none">
    <thead>
        <tr style="height:40px">
            <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                    <b>FIR Details</b>
                </span>
            </td>
        </tr>
        <tr>
            <th width="5%">Sr.No</th>
            <th width="15%">File Name</th>
            <th width="15%">Type</th>
            <th width="15%">Action</th>
        </tr>
    </thead>
    <tbody>
        <tr class="trAdd editTblTR" style="background-color: rgb(247, 246, 243); font-weight: bolder;">
            <td id="ajaxSLNo"></td>
            <td id="ajaxFileName"></td>
            <td id="ajaxType"></td>
            <td id="ajaxAct"></td>
        </tr>
    </tbody>
</table>
<style>
    .ajax-file-upload-green {
        background-color: #77b55a;
        border-radius: 4px;
        color: #fff;
        cursor: pointer;
        display: inline-block;
        font-family: arial;
        font-size: 13px;
        font-weight: normal;
        margin: 5px 10px 5px 0;
        padding: 4px 15px;
        text-decoration: none;
        text-shadow: 0 1px 0 #5b8a3c;
        vertical-align: top;
    }
    .ajax-file-upload-red {
        background-color: #e4685d;
        border-radius: 4px;
        box-shadow: 0 39px 0 -24px #e67a73 inset;
        color: #fff;
        cursor: pointer;
        display: inline-block;
        font-family: arial;
        font-size: 13px;
        font-weight: normal;
        margin: 5px 10px 5px 0;
        padding: 4px 15px;
        text-decoration: none;
        text-shadow: 0 1px 0 #b23e35;
        vertical-align: top;
    }
</style>