<?php

include_once('./process_common_class.php');
include_once('../email/email_template_class.php');
date_default_timezone_set("Asia/Calcutta");
$process = new Process();
$emailTemplate = new emailTemplate();
if (isset($_REQUEST['action'])) {
    if (($_REQUEST['action'] == 'pdiCheckList')) {
        $finalArr['checkpointData'] = $process->checkListWithTab();
        $finalArr['checkpointValue'] = $process->findPDISavedData();
        $finalArr['LASTCOMMENT'] = $process->findLastComment($_REQUEST["chassisNo"]);
        $finalArr['AJAXCHASSISDTLS'] = $process->findChassisInfo($_REQUEST["chassisNo"]);
        $finalArr['AJAXVLODTLS'] = $process->findVLOInfo($_REQUEST["chassisNo"]);
        echo json_encode($finalArr);
        exit;
    } else if (($_REQUEST['action'] == 'VLODATA')) {
        $sqlValoInsert = "INSERT 
            INTO 
                T_VHS_VALO_DTLS 
                VALUES (
                    '{$_REQUEST["chassisNo"]}',
                    '{$_REQUEST["valoDMUScore"]}',
                    '{$_REQUEST["valoACTScore"]}',
                    1,
                    sysdate,
                    {$_SESSION['userSessionInfo']["TUS_UID"]},
                    sysdate,
                    {$_SESSION['userSessionInfo']["TUS_UID"]}
                )";
        $obj = new db_connect();
        $obj->db_insert($sqlValoInsert);
        $obj->free();
        /*
         * @@@ Log details status change
         * State details insert
         * pending details update
         * email notification: 1)confirmation 2) Invite to JI
         */
        $process->logDtlsStatusChange(5);
        $process->stateDtlsOperation(5);
        $process->pendingDtlsOperation(6, $_REQUEST["pendingUser"], 5);

        $emailTempContVALO = $emailTemplate->valoDoneConfirmation($_SESSION['userSessionInfo']['TUS_NAME']);
        $sent = @mail($_SESSION['userSessionInfo']["TUS_EMAIL_ID"], $emailTempContVALO['subject'], $emailTempContVALO['body'], $emailTempContVALO['headers']);

        ######
        $obj = new db_connect();
        $paiEmailSql = "SELECT TUS_NAME USERNAME FROM T_VHS_USERS WHERE TUS_UID = {$_REQUEST["pendingUser"]}";
        $emailPAI = $obj->db_fetch_assoc($obj->db_query($paiEmailSql));
        $obj->free();
        $sendUserName = $emailPAI[0]['USERNAME'];
        ######
        $emailTemplateForJI = $emailTemplate->valoDoneIntimationForJI($sendUserName);
        $sent = @mail($_REQUEST["emailId"], $emailTemplateForJI['subject'], $emailTemplateForJI['body'], $emailTemplateForJI['headers']);
        echo "The VALO file has been uploaded successfully!";
        exit;
    } else if ($_REQUEST['action'] == 'UPLOADVLOFILE') {
        $returnArr = array();
        ##################################################
        $NewFileName = '';
        $destination = '';
        if (@$_FILES) {
            if ($_FILES['valoUploadDco']['error']) {
                $returnArr['status'] = false;
                $returnArr['msg'] = "There was an error while uploading VLO, please try again!";
            } else {
                $UploadDirectory = WEBROOT . 'valoDoc/';
                $fileExt = substr(strtolower($_FILES['valoUploadDco']['name']), strrpos(strtolower($_FILES['valoUploadDco']['name']), '.')); //file extension
                $NewFileName = $_SESSION['userSessionInfo']["TUS_PLNT"] . '_' . $_REQUEST['chassisNo'] . '_' . rand(100, 999) . '_' . "VLO" . $fileExt;
                $source = $_FILES['valoUploadDco']["tmp_name"];
                $destination = $UploadDirectory . $NewFileName;
                if (move_uploaded_file($source, $destination)) {
                    $obj = new db_connect();
                    $sqlSlno = "Select nvl(max(to_number(TEU_SL_NO)),0)+1 SLNO from T_VHS_EXT_UPLOAD Where TEU_CHASSIS_NO = '{$_REQUEST["chassisNo"]}' AND TEU_ULD_TYPE ='VLO'";
                    $slno = $obj->db_fetch_assoc($obj->db_query($sqlSlno));
                    $obj->free();
                    $sqlFIRInsert = "INSERT INTO 
                                    T_VHS_EXT_UPLOAD (
                                                    TEU_CHASSIS_NO,
                                                    TEU_ULD_TYPE,
                                                    TEU_SL_NO,
                                                    TEU_FILE_NAME,
                                                    TEU_FILE_PATH,
                                                    TEU_ACT_FLG,
                                                    TEU_CRT_BY,
                                                    TEU_CRT_TS,
                                                    TEU_UPD_BY,
                                                    TEU_UPD_TS
                                                    )
                                    VALUES (

                                            '{$_REQUEST["chassisNo"]}',
                                            'VLO',
                                            {$slno[0]['SLNO']},
                                            '$NewFileName',
                                            './webroot/valoDoc/" . $NewFileName . "' ,
                                            1,
                                            {$_SESSION['userSessionInfo']["TUS_UID"]},
                                            sysdate,
                                            {$_SESSION['userSessionInfo']["TUS_UID"]},
                                            sysdate
                                        )";
                    $obj = new db_connect();
                    $obj->db_insert($sqlFIRInsert);
                    $obj->free();
                    $returnArr['status'] = true;
                    $returnArr['VLODTLS'] = vloList();
                    $returnArr['slno'] = $slno[0]['SLNO'];
                }
            }
        }

        echo json_encode($returnArr);
        ##################################################
    } else if ($_REQUEST['action'] == "DELETEVLO") {
        deleteVLO();
        echo json_encode(vloList());
        exit;
    }
}

function vloList() {
    $obj = new db_connect();
    $sqlVloList = " SELECT TEU_CHASSIS_NO CHASSISNO,
                        TEU_ULD_TYPE TYPE,
                        TEU_SL_NO SLNO,
                        TEU_FILE_NAME NAME,
                        TEU_FILE_PATH PATH
                  FROM T_VHS_EXT_UPLOAD
                  WHERE TEU_CHASSIS_NO = '{$_REQUEST["chassisNo"]}'
                  AND TEU_ULD_TYPE     = 'VLO' AND TEU_ACT_FLG=1";
    $vloDtls = $obj->db_fetch_assoc($obj->db_query($sqlVloList));
    $obj->free();
    return $vloDtls;
}

function deleteVLO() {
    $obj = new db_connect;
    $sqlDelete = "UPDATE T_VHS_EXT_UPLOAD SET TEU_ACT_FLG=3 WHERE TEU_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' AND TEU_ULD_TYPE='VLO' AND TEU_FILE_NAME='" . $_REQUEST["fileName"] . "' AND TEU_SL_NO='" . $_REQUEST["slNo"] . "'";
    $obj->db_query($sqlDelete);
    $obj->free();
    return TRUE;
}
