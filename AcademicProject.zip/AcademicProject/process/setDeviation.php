<?php include("./process_common_class.php"); ?>
<input type="hidden" id="hfPageTitle" value="Set Deviation Form" screen_id="">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<div class="Grid" style="text-align: left;">
    <form name="iirreport" class="iirreport" id="logInc">
        <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td colspan="3">
                        <span>
                            <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                            <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select Chassis No--</option>
                                <?php
                                print_r($_SESSION);
                                if (array_key_exists(8, $_SESSION['userSessionInfo']['ROLES']) || array_key_exists(11, $_SESSION['userSessionInfo']['ROLES'])) {
                                    $chassisDtlArr = $process->chassisPendingJIPAE();
                                } else {
                                    $chassisDtlArr = $process->chassisPending();
                                }

                                foreach ($chassisDtlArr as $value) {

                                    echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>
                    </td>
                </tr>
            </tbody>
            <tr style="height:40px">
                <td colspan="3" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>VEHICLE JOINT INSPECTION SIGN-OFF SHEET</b>
                    </span>
                </td>
            </tr>
        </table>
        <div id="tabMenuVHO" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
            <!--Tabs are added dynamically here-->
        </div>
        <table class="assignTable" width="100%" cellpadding="0" cellspacing="0" style="display: none" >

            <tr style="height:40px">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>Comment</b>
                    </span>
                </td>
            </tr>
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td style="width: 20%" class="hideLastComent">
                        <span class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Last Comment By: </b><b style="color: #3637FE" id="pendUserName"></b></label>
                        </span>
                    </td>
                    <td class="hideLastComent">
                        <span class="chassisDtlSpan" >
                            <textarea placeholder="Last Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="last_comment" rows="2" maxlength="1900" disabled="disabled"></textarea>
                        </span>
                    </td>
                    <td style="width: 20%">
                        <span class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Comment for Approve/Reject:</b></label>
                        </span>
                    </td>
                    <td>
                        <span class="chassisDtlSpan" >
                            <textarea placeholder="Please Put Your Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="current_comment" rows="2" maxlength="1900"></textarea>
                        </span>


                    </td>


                </tr>
                <tr>

                    <td>Assigned To Test Engineer</td>
                    <td>
                        <select id="ddlPendingUser" name="ddlPendingUser" style="width:15%;"  class="ddlFieldDropdown">
                            <option value="">--Select Test Engineer--</option>
                            <?php
                            $users = $process->assignedUserByRole(10);
                            foreach ($users as $value) {
                                echo '<option value="' . $value['USERID'] . '" data-email="' . $value['EMAIL'] . '" >' . $value['USERNAME'] . '</option>';
                            }
                            ?> 
                        </select>
                    </td>
                    <td ></td>
                    <td ></td>
                </tr>
            </tbody>
        </table>
        <div id="jiEntryFormBtn" style="margin:10px;display: none">
            <a href="javascript:void(0);" class="kks-linkbutton l-btn,confirm" align="left" onclick="confirmClear();">
                <span style="text-align:left;" >Clear All</span>
            </a>	

            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" onclick="saveJi('saveData');">
                <span  style="text-align:left;" >Save data</span>
            </a>
            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" id="linkSubmitPaps" onclick="saveJi('submitData');">
                <span  style="text-align:left;" >Submit</span>				 
            </a>
        </div>

    </form>
</div>
<div id="dd"></div>
<script type="text/javascript">
    var url = wwwRoot + "process/setDeviation_action.php";
    $(function () {
        $('.layout-button-left').trigger('click');
        $("#ddlChassis").change(function () {
            var tabNos = $('.tabs >li').length;
            for (i = 0; i < tabNos; i++) {
                $("#tabMenuVHO").tabs('close', 0);
            }
            if ($(this).val()) {
                //ajax call for ji list
                var menuid = $("#urlMenuID").val();
                $.post(url, {action: "JIDETAILS", chassisNo: $(this).val(), menuid: menuid}, function () {
                }, 'JSON').done(function (data) {
                    var resTable = '';
                    $.each(data.CHECKDTLS, function (indexTab, tabDetails) {
                        var resTable = '<table style="background-color: #EFF3FB;">';
                        resTable += "<thead><tr><th style='width:2%'>SL.NO.</th><th>Parameters</th><th>Checked on Vehicle</th><th>OK or NOT OK</th><th>Remarks</th></tr></thead>";
                        var parntInc = 0;
                        $.each(tabDetails, function (indexPrnt, parentDetails) {
                            if ($.type(parentDetails) == 'object') {
                                parntInc++;
                                var childInc = 0;
                                //Thead
                                if (parentDetails.TCH_INCRIMENTAL) {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                                    resTable += "<tbody><tr class='trid" + parentDetails.TCH_CHK_ID + "' id='addmoreTr" + parentDetails.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt addMoreParam" ></td>';
                                    if (parentDetails.TCH_DATA_TYPE == 'file') {
                                        resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + parentDetails.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                        txtRemark = '';
                                    } else {
                                        resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt vehicleParam" ></td>';
                                        txtRemark = '<textarea id="remarkBox_' + parentDetails.TCH_CHK_ID + '" maxlength="1900" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                    }
                                    //#################################################################################################                         
                                    $setValArr = ["OK", "NOT OK"];
                                    resTable += '<td>';
                                    $setValArr.forEach(function ($value, $key) {
                                        $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                        resTable += '<label for="checkPDI' + ($key + 1) + parentDetails.TCH_CHK_ID + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + parentDetails.TCH_CHK_ID + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                    });
                                    resTable += '</td>';
                                    //################################################################################################      

                                    resTable += '<td>' + txtRemark + '</td>';
                                    resTable += "</tr></tbody>";
                                } else {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='4'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                                }
                                //Tbody
                                $.each(parentDetails, function (index, childArr) {
                                    childInc++;
                                    if ($.type(childArr) == 'object') {
                                        txtRemark = '<textarea id="remarkBox_' + childArr.TCH_CHK_ID + '" maxlength="1900" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                        resTable += "<tbody><tr id='trid" + childArr.TCH_CHK_ID + "' class='trid" + childArr.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";

                                        if (childArr.TCH_DATA_TYPE == 'text') {
                                            resTable += '<td><input style="width:80%" type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt vehicleParam" ></td>';
                                        } else if (childArr.TCH_DATA_TYPE == 'file') {
                                            resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + childArr.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                            txtRemark = '';
                                        } else {
                                            resTable += '<td></td>';
                                        }
                                        $setValArr = ["OK", "NOT OK"];
                                        resTable += '<td>';
                                        $setValArr.forEach(function ($value, $key) {
                                            $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                            resTable += '<label for="checkPDI' + ($key + 1) + childArr.TCH_CHK_ID + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + childArr.TCH_CHK_ID + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                        });
                                        resTable += '</td>';
                                        resTable += '<td>' + txtRemark + '</td>';
                                        resTable += "</tr></tbody>";
                                    }
                                })
                            }
                        })
                        resTable += "</table>";
                        $('#tabMenuVHO').tabs('add', {
                            title: indexTab,
                            content: resTable,
                            closable: false
                        });

                    })

                    if (!$.isEmptyObject(data.FILLDATA)) {
                        $.each(data.FILLDATA, function (chkKey, chkVal) {
                            var checkIdCrnt = chkVal[0].TJD_CHK_ID;
                            if (chkVal.length > 1) {
                                for (i = 0; i < chkVal.length; i++) {
                                    i > 0 ? addmoreRow("#addmoreTr" + chkKey, "addmoreTr" + chkKey) : '';
                                }
                                for (i = 0; i < chkVal.length; i++) {
                                    var vehParms = chkVal[i].TJD_VEH_PARAM.split('###');
                                    $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('.addMoreParam').val(vehParms[0]);
                                    $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('.vehicleParam').val(vehParms[1]);
                                    $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('input[checklist_id="' + chkKey + '"][value="' + chkVal[i].TJD_VALUE + '"]').prop('checked', true);
                                    $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find("#remarkBox_" + chkKey).val(chkVal[i].TJD_REMARKS);
                                }
                            } else {
                                if (chkVal[0].TJD_VEH_PARAM) {
                                    var vehParms = chkVal[0].TJD_VEH_PARAM.split('###');
                                    $(".trid" + chkKey).find('.addMoreParam').val(vehParms[0]);
                                    $(".trid" + chkKey).find('.vehicleParam').val(vehParms[1]);
                                }
                                $('input[name="checkPDI_' + chkKey + '"][value="' + chkVal[0].TJD_VALUE + '"]').prop('checked', true);
                                $("#remarkBox_" + chkKey).val(chkVal[0].TJD_REMARKS);
                            }
                            //Image file Loading
                            $.each(chkVal[0], function (keyFile, childFile) {
                                if ($.type(childFile) == 'object') {
                                    var imgTr = '<tr class="addMorePhotoTr" style="background-color:#FFFFFF"><td></td>';
                                    imgTr += '<td><img style="height:119Px;width:200Px;" src="' + wwwRoot + childFile.TFD_FILE_PATH + '"></td>';
                                    imgTr += '<td><input type="hidden" style="width:80%" value="' + childFile.TFD_FILE_TITLE + '" checklist_id="' + checkIdCrnt + '" class="photoName"><textarea maxlength="1900" rows="2" class="photoDesc" style="word-wrap: break-word;width:95%" placeholder="Photo Description">' + childFile.TFD_FILE_DESC + '</textarea></td>';
                                    imgTr += '<td colspan="2"><a href="javascript:void(0);" class="statusChange" id="btnDeactFile">Delete Image</a></td>';
                                    imgTr += '</tr>';
                                    $(".trid" + checkIdCrnt).after(imgTr);
                                }
                            })
                        })
                    }

                    if (!$.isEmptyObject(data.LASTCOMMENT)) {
                        $("#last_comment").val(data.LASTCOMMENT.REMARK);
                        $("#pendUserName").html(data.LASTCOMMENT.PENDUSERNAME);
                    } else {
                        $(".hideLastComent").hide();
                        $("#current_comment").css('width', '50%');
                    }

                    $("#tabMenuVHO").tabs('select', 0);
                })
                $("#pdiEnggType").trigger('change');
                $("#txtModelNo").val($('option:selected', $(this)).data('modeltypeno')).attr('readonly', true);
                $("#jiEntryFormBtn,.assignTable").show();
            } else {
                $("#txtModelNo").val('').attr('readonly', true);
                $("#jiEntryFormBtn,.assignTable").hide();
            }
        })
    })

    function saveJi(type) {
        var totalField = $('.checkpdiInpt').length;
        var totalRadio = $(':radio[class="checkpdiInpt"]').length;
        var totalText = totalField - totalRadio;
        var totalRadioBlck = totalRadio / 2;
        var checkedRadio = $(':radio[class="checkpdiInpt"]:checked').length;
        if (type == "submitData") {
            if (checkedRadio != totalRadioBlck) {
                alert("Please check all PDI checklist!");
                return false;
            }
        }
        var chassisNo = $('#ddlChassis').val();
        var checklistObj = [];
        var jiStatus = 1;
        var confMsg = confirm('All JI are Okay. This process will consider as JI completion. Are you sure want proceed?');
        $('.checkpdiInpt').each(function () {
            var remarks = $(this).closest('tr').find('.txtFieldTextBox').val();
            var vehicleParam = $(this).closest('tr').find('.vehicleParam').val();
            var addMoreParam = $(this).closest('tr').find('.addMoreParam').val();
            if ($(this).is(':checked')) {
                var photolistObj = [];
                $(this).closest('tbody').find('.addMorePhotoTr').each(function () {
                    var photoName = $(this).find(".photoName").val();
                    photolistObj.push({photoName: $(this).find(".photoName").val(), photoDesc: $(this).find(".photoDesc").val()});
                })

                if ($(this).val() == "NOT OK") {
                    jiStatus = 2;
                    var confMsg = confirm('All JI are not Okay. This process will Revert the JI modification to PAE. Are you sure want to Revert the JI to PAE?');
                }
                checklistObj.push({checkListId: $(this).attr('checklist_id'), val: $(this).val(), remarks: remarks, vehicleParam: vehicleParam, addMoreParam: addMoreParam, photolistObj: photolistObj});
            }
        })


        if (confMsg) {
            if (!$("#ddlPendingUser").val()) {
                alert('Please Select Test Engineer!');
                $("#ddlPendingUser").focus();
                return false;
            }

            $.post(url,
                    {
                        type: type,
                        chassisNo: chassisNo,
                        checklistObj: checklistObj,
                        chassisType: $('input[name=chessisType]:checked').val(),
                        jiStatus: jiStatus,
                        currComment: $("#current_comment").val(),
                        pendingUser: $("#ddlPendingUser").val(),
                        action: 'saveJIChkList'
                    }).done(function (data) {
                openUrl(wwwRoot + "process/jientry.php?menuid=18");
            })
        }


    }
</script>