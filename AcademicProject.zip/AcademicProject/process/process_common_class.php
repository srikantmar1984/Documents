<?php

include("../db_classes/commanvar.php");
include("../db_classes/class.db.php");

class Process {

    function chassisDetails() {
//        $sql = "SELECT MODEL_TYPE,MODEL_TYPE_NO,PROTO_TYP_NO,CHASSIS_NO,ENG_NO,WBS_NO,PROJECT_CODE FROM M_VTS_CHASSIS_ENG";//Previouly pull the record from existing table
        $sql = "SELECT";
        $sql .= "   TCD_CHASSIS_NO as CHASSSISNO ";
        $sql .= " , TCD_BU ";
        $sql .= " , TCD_GVW ";
        $sql .= " , TCD_WB ";
        $sql .= " , TO_CHAR(TO_DATE(TCD_MONTH, 'MM'), 'Month') AS TCD_MONTH ";
        $sql .= " , TO_CHAR(TO_DATE(TCD_YR, 'YY'), 'YYYY') AS TCD_YR ";
        $sql .= " , TCD_LH_RH ";
        $sql .= ", CASE
                    WHEN TCD_LOCN = 'J'
                       THEN 'JSR'
                    WHEN TCD_LOCN = 'P'
                       THEN 'PUN'
                    WHEN TCD_LOCN = 'L'
                       THEN 'LKO'
                 END AS TCD_LOCN ";
        $sql .= " , TCD_SLNO ";
        $sql .= " , TCD_ACT_FLG ";
        $sql .= " , TCD_CRT_BY ";
        $sql .= " , TCD_CRT_TS ";
        $sql .= " , TCD_UPD_BY ";
        $sql .= " , TCD_UPD_TS ";
        $sql .= " FROM T_VHS_CHASSIS_DTLS WHERE TCD_IS_PDI_DONE=0";
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisDtlArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $chassisDtlArr[] = $row;
        }
        $obj->free();
        return $chassisDtlArr;
    }

    function chassisPending() {
        $sql = "SELECT 
                t1.TPD_CHASSIS_NO as CHASSSISNO, 
                t3.TSH_STATE_NAME STATENAME,
                t1.TPD_STATE_ID PENDSTATEID
            from 
                T_VHS_PENDING_DTLS t1,
                T_ERC_STATE_HEAD t3 
            WHERE 
                t1.TPD_STATE_ID  = t3.TSH_ID
                AND TPD_PEND_WITH =" . $_SESSION['userSessionInfo']['TUS_UID'];
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisDtlArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $chassisDtlArr[] = $row;
        }
        $obj->free();
        return $chassisDtlArr;
    }

    function chassisPendTestEng() {
        $sql = "SELECT
                    ttm_chassis_no as CHASSSISNO
                FROM
                    t_vhs_team t1,
                    t_vhs_pending_dtls t2
                WHERE
                    t1.ttm_member = " . $_SESSION['userSessionInfo']['TUS_UID'] . "
                AND
                    t1.ttm_act_flg = 1
                AND
                    t2.tpd_state_id IN (8,9)
                AND
                    t1.ttm_chassis_no = t2.tpd_chassis_no";
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisDtlArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $chassisDtlArr[] = $row;
        }
        $obj->free();
        return $chassisDtlArr;
    }

    function chassisPendingVHDPAE() {
        $sql = "SELECT 
                t1.TPD_CHASSIS_NO AS CHASSSISNO,
                t3.TSH_STATE_NAME STATENAME,
                t1.TPD_STATE_ID PENDSTATEID
            FROM 
                T_VHS_PENDING_DTLS t1, 
                T_VHS_LOG_DTLS t2, 
                T_ERC_STATE_HEAD t3 
            WHERE 
                t1.TPD_STATE_ID IN(11,16) 
                AND t1.TPD_CHASSIS_NO = t2.TLD_LOG_NO 
                AND t1.TPD_STATE_ID  = t3.TSH_ID
                AND (T2.TLD_PAE_ELECT = " . $_SESSION['userSessionInfo']['TUS_UID'] . " OR T2.TLD_PAE_MECH = " . $_SESSION['userSessionInfo']['TUS_UID'] . ")";
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisDtlArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $chassisDtlArr[] = $row;
        }
        $obj->free();
        return $chassisDtlArr;
    }

    function chassisPendingJIPAE() {
        $sql = "SELECT 
                t1.TPD_CHASSIS_NO AS CHASSSISNO,
                t3.TSH_STATE_NAME STATENAME,
                t1.TPD_STATE_ID PENDSTATEID
            FROM 
                T_VHS_PENDING_DTLS t1, 
                T_VHS_LOG_DTLS t2, 
                T_ERC_STATE_HEAD t3 
            WHERE 
                t1.TPD_STATE_ID =10
                AND t1.TPD_CHASSIS_NO = t2.TLD_LOG_NO 
                AND t1.TPD_STATE_ID  = t3.TSH_ID
                AND (T2.TLD_PAE_ELECT = " . $_SESSION['userSessionInfo']['TUS_UID'] . " OR T2.TLD_PAE_MECH = " . $_SESSION['userSessionInfo']['TUS_UID'] . ")";
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisDtlArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $chassisDtlArr[] = $row;
        }
        $obj->free();
        return $chassisDtlArr;
    }

    function checkListWithTab() {
        $sql = " SELECT T1.TCH_CHK_ID,
                    T1.TCH_CHECK_POINT,
                    T1.TCH_PARENT_ID,
                    T1.TCH_DATA_TYPE,
                    T1.TCH_VALUE_SET,
                    T1.TCH_INCRIMENTAL,
                    T1.TCH_TAB_ID,
                    T1.TCH_SLNO,
                    T2.TTS_ACCESS_LEVEL,
                    T3.TMT_NAME,
                    T4.TCD_VALUE
                FROM T_VHS_CHECK_HEAD t1,
                    T_VHS_TAB_MENU t2,
                    T_VHS_MENU_TABS t3,
                    T_VHS_CODES t4
                WHERE T3.TMT_ID    ={$_REQUEST['menuid']}
                    AND T1.TCH_ACT_FLG = 1
                    AND T2.TTS_MENU_ID = T3.TMT_ID
                    AND T2.TTS_TAB_ID  = T1.TCH_TAB_ID(+)
                    AND T2.TTS_TAB_ID  = T4.TCD_ID
                ORDER BY  T4.TCD_SLNO ASC, T1.TCH_TAB_ID ASC,
                    T1.TCH_PARENT_ID DESC,
                    T1.TCH_SLNO ASC";
        $obj = new db_connect;
        $obj->db_query($sql);
        $returnArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            if (!$row['TCH_PARENT_ID']) {
                $returnArr[$row['TCD_VALUE']][$row['TCH_CHK_ID']] = $row;
            } else {
                $returnArr[$row['TCD_VALUE']][$row['TCH_PARENT_ID']][] = $row;
            }
        }
        $obj->free();
        return $returnArr;
    }

    function GenDropDown($sql = "", $selVal = "") {
        $obj = new db_connect;
        $obj->db_query($sql);
        $Cols = '';
        while ($row = $obj->db_fetch_array()) {
            $Cols .= '<option value="' . $row[0] . '" ';
            if ($row[0] == $selVal) {
                $Cols .= ' selected';
            }
            $Cols .= ' >' . $row[1] . '</option>';
        }
        $obj->free();
        return $Cols;
    }

    function logDtlsStatusChange($stateID = 1, $closureDate = NULL) {
        $obj = new db_connect;
        $sqlLogDtlsUpd = "UPDATE
                T_VHS_LOG_DTLS
            SET                
                TLD_STATUS = $stateID,
                TLD_UPD_BY = {$_SESSION['userSessionInfo']['TUS_UID']},";
        if ($closureDate) {
            $sqlLogDtlsUpd .= "  TLD_CLOSURE_TS =  to_date('" . $closureDate . "','dd-MM-yyyy'),";
        }
        $sqlLogDtlsUpd .= "  TLD_UPD_TS = SYSDATE
            WHERE TLD_LOG_NO='" . $_REQUEST["chassisNo"] . "' ";
        $obj->db_query($sqlLogDtlsUpd);
        $obj->free();
    }

    function stateDtlsOperation($stateID = 1) {
        $obj = new db_connect;
        $sqlStatDtls = "INSERT INTO T_VHS_STATE_DTLS";
        $sqlStatDtls .= " ( ";
        $sqlStatDtls .= "    TSD_STATE_ID ";
        $sqlStatDtls .= "  , TSD_TRANS_ID "; //Primary key of that table.
        $sqlStatDtls .= "  , TSD_CHASSIS_NO ";
        $sqlStatDtls .= "  , TSD_CRT_BY ";
        $sqlStatDtls .= "  , TSD_CRT_TS ";
        $sqlStatDtls .= "  , TSD_UPD_BY ";
        $sqlStatDtls .= "  , TSD_UPD_TS ";
        $sqlStatDtls .= "  , TSD_REMARKS ";
        $sqlStatDtls .= " ) ";
        $sqlStatDtls .= " VALUES ";
        $sqlStatDtls .= " ( ";

        $sqlStatDtls .= $stateID;
        $sqlStatDtls .= "  ,  (Select nvl(max(to_number(TSD_TRANS_ID)),0)+1  from T_VHS_STATE_DTLS ) ";
        $sqlStatDtls .= "  , '" . $_REQUEST["chassisNo"] . "' ";
        $sqlStatDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlStatDtls .= "  , SYSDATE ";
        $sqlStatDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlStatDtls .= "  , SYSDATE ";
        $sqlStatDtls .= "  , '" . @$_REQUEST["currComment"] . "' ";
        $sqlStatDtls .= " ) ";
        $obj->db_insert($sqlStatDtls);
        $obj->free();
    }

    function pendingDtlsOperation($stateID = 1, $pendingID = NULL, $compStdID = 99999) {
        $obj = new db_connect;
        $updtPendSql = " UPDATE
                        T_VHS_PENDING_DTLS
                    SET
                        TPD_STATE_ID=$stateID,
                        TPD_COMPLETED_STATE_ID = {$compStdID},
                        TPD_PEND_WITH = $pendingID,
                        TPD_UPD_BY = {$_SESSION['userSessionInfo']['TUS_UID']},
                        TPD_UPD_TS = SYSDATE
                    WHERE
                        TPD_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' ";
        $obj->db_query($updtPendSql);
        $obj->free();
    }

    function assignedUserByRole($roleID = NULL) {
        $sql = "SELECT T_VHS_USERS.TUS_UID USERID,T_VHS_USERS.TUS_NAME || '(' || T_VHS_USERS.TUS_PNO || ')' USERNAME,T_VHS_USERS.TUS_EMAIL_ID EMAIL,T_VHS_USERS.TUS_NAME ONLYUSERNAME FROM T_VHS_USERS,T_ERC_ROLE_USER WHERE T_VHS_USERS.TUS_UID = T_ERC_ROLE_USER.TRU_USER_ID AND T_ERC_ROLE_USER.TRU_ROLE_ID = $roleID";
        $obj = new db_connect;
        $obj->db_query($sql);
        $users = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $users[] = $row;
        }
        $obj->free();
        return $users;
    }

    function allPAEElectrical() {
        $sql = "SELECT T_VHS_USERS.TUS_UID USERID,
                T_VHS_USERS.TUS_NAME || '(' || T_VHS_USERS.TUS_PNO || ')' USERNAME
                FROM T_VHS_USERS,
                  T_ERC_ROLE_USER
                WHERE T_VHS_USERS.TUS_UID       = T_ERC_ROLE_USER.TRU_USER_ID
                AND T_ERC_ROLE_USER.TRU_ROLE_ID = 11";
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisDtlArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $chassisDtlArr[] = $row;
        }
        $obj->free();
        return $chassisDtlArr;
    }

    function allPAEMechanical() {
        $sql = "SELECT T_VHS_USERS.TUS_UID USERID,
                T_VHS_USERS.TUS_NAME || '(' || T_VHS_USERS.TUS_PNO || ')' USERNAME
                FROM T_VHS_USERS,
                  T_ERC_ROLE_USER
                WHERE T_VHS_USERS.TUS_UID       = T_ERC_ROLE_USER.TRU_USER_ID
                AND T_ERC_ROLE_USER.TRU_ROLE_ID = 8";
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisDtlArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $chassisDtlArr[] = $row;
        }
        $obj->free();
        return $chassisDtlArr;
    }

    function allDesignEngg() {
        $sql = "SELECT T_VHS_USERS.TUS_UID USERID,
                T_VHS_USERS.TUS_NAME || '(' || T_VHS_USERS.TUS_PNO || ')' USERNAME
                FROM T_VHS_USERS,
                  T_ERC_ROLE_USER
                WHERE T_VHS_USERS.TUS_UID       = T_ERC_ROLE_USER.TRU_USER_ID
                AND T_ERC_ROLE_USER.TRU_ROLE_ID = 6";
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisDtlArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $chassisDtlArr[] = $row;
        }
        $obj->free();
        return $chassisDtlArr;
    }

    function allPlanningEngg() {
        $sql = "SELECT T_VHS_USERS.TUS_UID USERID,
                T_VHS_USERS.TUS_NAME || '(' || T_VHS_USERS.TUS_PNO || ')' USERNAME
                FROM T_VHS_USERS,
                  T_ERC_ROLE_USER
                WHERE T_VHS_USERS.TUS_UID       = T_ERC_ROLE_USER.TRU_USER_ID
                AND T_ERC_ROLE_USER.TRU_ROLE_ID = 4";
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisDtlArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $chassisDtlArr[] = $row;
        }
        $obj->free();
        return $chassisDtlArr;
    }

    function fillDataJI() {
        $sql = "SELECT TJD_ID,
                    TJD_LOG_NO,
                    TJD_CHK_ID,
                    TJD_SLNO,
                    TJD_VALUE,
                    TJD_VEH_PARAM,
                    TJD_DOC_ID,
                    TJD_REMARKS
                FROM T_VHS_JI_DTLS
                WHERE TJD_LOG_NO = '{$_REQUEST["chassisNo"]}'";
        $obj = new db_connect;
        $obj->db_query($sql);
        $resTable = '';
        $returnArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            if (@$row['TJD_DOC_ID']) {
                $objNew = new db_connect;
                $imageSql = "SELECT TFD_FILE_TITLE,TFD_FILE_PATH,TFD_FILE_DESC FROM T_VHS_FILE_DTLS WHERE TFD_DOC_ID ={$row['TJD_DOC_ID']}";
                $objNew->db_query($imageSql);
                while ($rowFile = $objNew->db_fetch_arrayAssoc()) {
                    $row[] = $rowFile;
                }
            }
            $returnArr[$row['TJD_CHK_ID']][] = $row;
        }
        $obj->free();
        return $returnArr;
    }

    function histryInsert($processType = NULL, $stateID = NULL, $jiData = NULL) {
        if ($processType == "JIHISTORY") {
//            $sql = "SELECT * FROM T_VHS_CHECK_DTLS WHERE TCD_LOG_NO = '" . $_REQUEST["chassisNo"] . "' AND TCD_PROCESS_TYPE = '$processType'";
            $returnArr = $jiData;
        } else {
            $sql = "SELECT * FROM T_VHS_CHECK_DTLS WHERE TCD_LOG_NO = '" . $_REQUEST["chassisNo"] . "' AND TCD_PROCESS_TYPE = '$processType'";
            $obj = new db_connect;
            $obj->db_query($sql);

            while ($row = $obj->db_fetch_arrayAssoc()) {
                $returnArr[] = $row;
            }
        }
        $result = serialize($returnArr);

        $obj = new db_connect;
        $sql = "BEGIN PROC_VHS_SLV_HISTORYSAVE('" . trim($_REQUEST["chassisNo"]) . "','" . $stateID . "','" . $_SESSION['userSessionInfo']['TUS_UID'] . "','" . $_SESSION['userSessionInfo']['TUS_UID'] . "','" . $result . "'); END;";
        $obj->db_query($sql);
        $obj->free();
    }

    function searchViewDetail() {
        $sql = "SELECT t1.*,
            t2.TSH_STATE_NAME,
            T4.TUS_NAME
            || '('
            || T4.TUS_PNO
            || ')' AS PENDUSER,
            NVL(t5.TCD_MODEL,' ') MODEL , NVL(t5.TCD_PROTO_NO,' ') PROTO_NO ,NVL(t5.TCD_WBS_LIST,' ') WBS_LIST  , NVL(t6.TEW_PROJ,' ') PROJ
          FROM T_VHS_LOG_DTLS t1,
            T_ERC_STATE_HEAD t2,
            T_VHS_PENDING_DTLS t3,
            T_VHS_USERS t4,
            T_VHS_CHASSIS_DTLS t5,
            T_ERC_WBS t6
          WHERE t1.TLD_STATUS  = t2.TSH_ID
          AND t1.TLD_LOG_NO = t5.TCD_CHASSIS_NO
          AND t1.TLD_LOG_NO    = T3.TPD_CHASSIS_NO(+)
          AND T3.TPD_PEND_WITH = T4.TUS_UID (+)
          AND t5.TCD_WBS_LIST = t6.TEW_ID(+)";
        if (@$_REQUEST['chassisNo']) {
            $sql .= "  AND t1.TLD_LOG_NO = '{$_REQUEST['chassisNo']}' ";
        }
        if (@$_REQUEST['stateId']) {
            $sql .= "  AND t1.TLD_STATUS = {$_REQUEST['stateId']} ";
        }
        if (@$_REQUEST['fromDate']) {
            $sql .= " AND TRUNC(t1.TLD_CRT_TS) >= '" . $_REQUEST['fromDate'] . "' ";
        }
        if (@$_REQUEST['toDate']) {
            $sql .= " AND TRUNC(t1.TLD_CRT_TS) <= '" . $_REQUEST['toDate'] . "' ";
        }
//        if (@$_REQUEST['stateId']) {
//            $sql .= " AND t2.TSH_ID = {$_REQUEST['stateId']} ";
//        }
        $sql .= "  ORDER BY T1.TLD_SLNO ";
        $obj = new db_connect;
        $obj->db_query($sql);
        $logDetails = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $logDetails[] = $row;
        }
        $obj->free();
        return $logDetails;
    }

    function fillAllChassis() {
        $sql = "SELECT TLD_LOG_NO CHASSSISNO FROM T_VHS_LOG_DTLS ORDER BY TLD_SLNO";
        $obj = new db_connect;
        $obj->db_query($sql);
        $allChassis = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $allChassis[] = $row;
        }
        $obj->free();
        return $allChassis;
    }

    function fillAllStatus() {
        $sql = "SELECT TSH_ID STATEID,TSH_STATE_NAME STATENAME FROM T_ERC_STATE_HEAD WHERE TSH_ACT_FLG = 1 AND TSH_ID NOT IN(1,2,6,9,11) ORDER BY TSH_ID";
        $obj = new db_connect;
        $obj->db_query($sql);
        $allState = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $allState[] = $row;
        }
        $obj->free();
        return $allState;
    }

    function findLastComment($chassisNo = NULL) {
        $sql = "SELECT * FROM(SELECT t1.TSD_REMARKS REMARK,
                t2.TUS_NAME || '(' || t2.TUS_PNO || ')' PENDUSERNAME
                FROM T_VHS_STATE_DTLS t1,
                T_VHS_USERS t2
                WHERE TSD_CHASSIS_NO = '$chassisNo'
                AND t1.TSD_UPD_BY = t2.TUS_UID
                ORDER BY TSD_UPD_TS DESC) WHERE 
                rownum           = 1";

        $obj = new db_connect;
        $lastComent = $obj->db_fetch_assoc($obj->db_query($sql));
        $obj->free();
        $res[] = array();
        if (isset($lastComent[0])) {
            $res['REMARK'] = $lastComent[0]['REMARK'];
            $res['PENDUSERNAME'] = $lastComent[0]['PENDUSERNAME'];
        }
        return $res;
    }

    function finduserNM($uid) {
        $sql = "SELECT TUS_NAME FROM T_VHS_USERS WHERE TUS_ACT_FLG = 1 AND TUS_UID = " . $uid;
        $obj = new db_connect;
        $obj->db_query($sql);
        $userName = $obj->db_fetch_assoc($obj->db_query($sql));
        $obj->free();
        return $userName[0]['TUS_NAME'];
    }

    function wbsList() {
        $sql = "SELECT NVL(TIW_WBS_NO,'No WBS for'||TWK_WORK_ORDER) WBSList
                FROM t_ind_wbs , t_ind_workorders
                WHERE TWK_WORK_ORDER = TIW_WO_NO
                AND TIW_ACT_FLG = 'Active'
                AND TWK_ACT_FLG = 'Active'
                AND UPPER(TWK_STATUS) = 'OPEN'
                AND TWK_CUTOFF_TS > SYSDATE";
        $obj = new db_connect;
        $obj->db_query($sql);
        $wbsListArr = $obj->db_fetch_assoc();
        return $wbsListArr;
    }

    function tyreSizeList() {
        $sql = "SELECT TCD_VALUE TYRESIZE
                FROM T_VHS_CODES
                WHERE TCD_PARENT_ID=(SELECT TCD_ID FROM T_VHS_CODES WHERE TCD_VALUE ='Tyre Size' AND TCD_PLANT_ID={$_SESSION['userSessionInfo']["TUS_PLNT"]})
                AND TCD_ACT_FLG = 1";
        $obj = new db_connect;
        $obj->db_query($sql);
        $tyreSizeListArr = $obj->db_fetch_assoc();
        return $tyreSizeListArr;
    }

    function findChassisInfo($chassisNo = NULL) {
        $sql = "SELECT";
        $sql .= "   TCD_CHASSIS_NO as CHASSSISNO ";
        $sql .= " , TCD_MODEL ";
        $sql .= " , TCD_PROTO_NO ";
        $sql .= " , TCD_WBS_LIST ";
        $sql .= " , TCD_PROJ_CODE ";
        $sql .= " , TCD_VC_NO ";
        $sql .= " FROM T_VHS_CHASSIS_DTLS WHERE TCD_CHASSIS_NO='$chassisNo'";
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisInfoArr = $obj->db_fetch_assoc($obj->db_query($sql));
        return $chassisInfoArr[0];
    }

    function findFirInfo($chassisNo = NULL) {
        $sql = "SELECT * FROM t_vhs_ext_upload where teu_chassis_no= '$chassisNo' AND teu_uld_type='FIR' AND TEU_ACT_FLG=1";
        $obj = new db_connect;
        $obj->db_query($sql);
        $firInfoArr = $obj->db_fetch_assoc($obj->db_query($sql));
        if ($firInfoArr)
            return $firInfoArr[0];
        else
            return array();
    }

    function findVLOInfo($chassisNo = NULL) {
        $sqlVloList = " SELECT TEU_CHASSIS_NO CHASSISNO,
                        TEU_ULD_TYPE TYPE,
                        TEU_SL_NO SLNO,
                        TEU_FILE_NAME NAME,
                        TEU_FILE_PATH PATH
                  FROM T_VHS_EXT_UPLOAD
                  WHERE TEU_CHASSIS_NO = '{$_REQUEST["chassisNo"]}'
                  AND TEU_ULD_TYPE     = 'VLO' AND TEU_ACT_FLG=1";
        $obj = new db_connect;
        $vloInfoArr = $obj->db_fetch_assoc($obj->db_query($sqlVloList));
        if ($vloInfoArr)
            return $vloInfoArr;
        else
            return array();
    }

    function findMatrixInfo($chassisNo = NULL) {
        $sqlVloList = " SELECT TEU_CHASSIS_NO CHASSISNO,
                        TEU_ULD_TYPE TYPE,
                        TEU_SL_NO SLNO,
                        TEU_FILE_NAME NAME,
                        TEU_FILE_PATH PATH
                  FROM T_VHS_EXT_UPLOAD
                  WHERE TEU_CHASSIS_NO = '{$_REQUEST["chassisNo"]}'
                  AND TEU_ULD_TYPE     = 'MATRIX' AND TEU_ACT_FLG=1";
        $obj = new db_connect;
        $vloInfoArr = $obj->db_fetch_assoc($obj->db_query($sqlVloList));
        if ($vloInfoArr)
            return $vloInfoArr;
        else
            return array();
    }

    function findPDISavedData() {
        $sql = "SELECT TCD_LOG_NO,
            TCD_CHK_ID,
            TCD_VALUE,
            TCD_REMARKS           
            FROM T_VHS_CHECK_DTLS 
            WHERE TCD_LOG_NO = '{$_REQUEST["chassisNo"]}'";
        $obj = new db_connect;
        $obj->db_query($sql);
        $resTable = '';
        $returnArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $returnArr[] = $row;
        }
        $obj->free();
        return $returnArr;
    }

    function findteamNM() {
        $teamDtls = "";
        $obj = new db_connect();
        $sqlteamList = " SELECT DISTINCT TCD_VALUE,TCD_ID ,TGM_GROUP_TYPE FROM t_erc_group_map, T_VHS_CODES  WHERE TGM_GROUP_CAT = TCD_ID AND TGM_APP_ID = '1' ";
        $obj->db_query($sqlteamList);
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $teamDtls .= '<input type="checkbox" name="teams" grpNM =' . $row["TCD_VALUE"] . '  grptype= ' . $row["TGM_GROUP_TYPE"] . ' value=' . $row["TCD_ID"] . '><strong>' . $row["TCD_VALUE"] . '</strong>';
        }
        $obj->free();

        return $teamDtls;
    }

    function chassisPending2($stsID) {
        $sql = "SELECT 
                t1.TPD_CHASSIS_NO as CHASSSISNO, 
                t3.TSH_STATE_NAME STATENAME,
                t1.TPD_STATE_ID PENDSTATEID
            from 
                T_VHS_PENDING_DTLS t1,
                T_ERC_STATE_HEAD t3 
            WHERE 
                t1.TPD_STATE_ID ='{$stsID}' AND t1.TPD_STATE_ID  = t3.TSH_ID ";
        if (!in_array("ODT Head", $_SESSION['userSessionInfo']['ROLES'])) {
            $sql .= "AND TPD_PEND_WITH =" . $_SESSION['userSessionInfo']['TUS_UID'];
        }
        $obj = new db_connect;
        $obj->db_query($sql);
        $chassisDtlArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $chassisDtlArr[] = $row;
        }
        $obj->free();
        return $chassisDtlArr;
    }

    function findteamlist($grpID, $headId, $teamgrp, $chkNM) {
        $teamlist = "";

        $obj = new db_connect();
        $sqlteamList = " SELECT TUS_NAME||'('||TUS_PNO||')' MEMBNM,TUS_UID TGM_MEMBER,TGM_GROUP_CAT FROM t_erc_group_map , T_VHS_USERS 
                            WHERE TGM_ACT_FLG = 1 AND TRIM(TGM_MEMBER) = TRIM(TUS_PNO)
                            AND TGM_GROUP_CAT = '" . $grpID . "'
                            AND TGM_USER_TYPE !=  'Head'
                            AND  TGM_GROUP_ID IN (
                            SELECT DISTINCT TGM_GROUP_ID 
                            FROM t_erc_group_map 
                            WHERE TGM_GROUP_TYPE= '" . $teamgrp . "'
                            AND TGM_USER_TYPE=  'Head'";
        if (!in_array("ODT Head", $_SESSION['userSessionInfo']['ROLES'])) {
            $sqlteamList .= "   AND TGM_MEMBER IN ('" . $headId . "') ";
        }
        $sqlteamList .= "   AND TGM_APP_ID = '1'
                            UNION
                            SELECT DISTINCT  TGM_GROUP_ID 
                            FROM t_erc_group_map 
                            WHERE TGM_GROUP_TYPE= '2'
                            AND TGM_APP_ID = '1'
                        ) ";
        $obj->db_query($sqlteamList);
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $teamlist .= '<input type="checkbox" name=' . $grpID . ' value=' . $row["TGM_MEMBER"] . '><strong>' . $row["MEMBNM"] . '</strong><br/>';
        }


        return $teamlist;
    }

    function findDeviationInfo($chassisNo = NULL) {
        $sql = "SELECT TVD_CHASSIS_NO,TVD_CHK_ID,TVD_REMARKS FROM T_VHS_DEVIATION WHERE TVD_CHASSIS_NO = '$chassisNo' AND TVD_ACT_FLG = 1"; //CC76399061RJ00019
        $obj = new db_connect;
        $obj->db_query($sql);
        $returnArr = array();
        while ($row = $obj->db_fetch_arrayAssoc()) {
            $returnArr[] = $row["TVD_CHK_ID"];
        }
        $obj->free();
        $result['count'] = count($returnArr);
        $result['devIds'] = implode(',', $returnArr);
        return $result;
    }

    function logDtlsModify($tblcolumn, $val) {
        $obj = new db_connect;
        $sqlLogDtlsUpd = "UPDATE
                T_VHS_LOG_DTLS
            SET                
                $tblcolumn = $val, TLD_UPD_BY = {$_SESSION['userSessionInfo']['TUS_UID']}, TLD_UPD_TS = SYSDATE WHERE TLD_LOG_NO='" . $_REQUEST["chassisNo"] . "' ";
        $obj->db_query($sqlLogDtlsUpd);
        $obj->free();
    }

}

$process = new Process();
?>