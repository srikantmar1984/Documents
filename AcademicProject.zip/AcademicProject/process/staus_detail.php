<?php

###########################################################################################
###################### HTML Table for Process Status Start ################################
###########################################################################################   


$sql = "SELECT T1.TSD_CHASSIS_NO CHASSISNO,
            TO_CHAR(T1.TSD_CRT_TS, 'DD-MON-YYYY HH24:MI:SS A.M.') CREATED,
           T2.TSH_STATE_NAME STATUS,
           T2.TSH_LC_TYPE LCSTATUS,
           UPPER(T3.TUS_NAME) || '(' || T3.TUS_PNO || ')' AS USERNAME,
           t1.TSD_REMARKS REM
         FROM T_VHS_STATE_DTLS t1,
           T_ERC_STATE_HEAD t2,
           T_VHS_USERS t3
         WHERE TSD_CHASSIS_NO = '{$_REQUEST['chassisNo']}'
         AND T1.TSD_STATE_ID  = T2.TSH_ID
         AND T2.TSH_LC_TYPE   = 'Submit'
         AND T1.TSD_UPD_BY = T3.TUS_UID
         ORDER BY T1.TSD_CRT_TS";
$obj = new db_connect;
$obj->db_query($sql);
$statusDetails = array();
while ($row = $obj->db_fetch_arrayAssoc()) {
    $statusDetails[] = $row;
}
$sqlPendTo = "SELECT UPPER(T2.TUS_NAME) || ' (' || T2.TUS_PNO || ')' AS PENDUSERNAME FROM T_VHS_PENDING_DTLS t1,T_VHS_USERS t2 WHERE t1.TPD_CHASSIS_NO = '{$_REQUEST['chassisNo']}' AND T1.TPD_PEND_WITH = T2.TUS_UID";
$resPendTo = $obj->db_fetch_assoc($obj->db_query($sqlPendTo));
$processStatusHtml = '<div class="kks-panel" title="Process Status" data-options="collapsible:true"> 
    <div class="Grid">
        <table cellpadding="0" cellspacing="0" id="tblMOCStatus">
            <thead>
                <tr>
                    <!--<th width="100px">User Role</th>-->
                    <th width="100px">Status</th>
                    <th width="100px">User Name</th>
                    <th width="100px">Action Date</th>
                    <th width="100px">Comments</th>
                </tr>
            </thead>
            <tbody>';
?>
<?php

foreach ($statusDetails as $key => $value) {
    $processStatusHtml .= "<tr>
                            <td>{$value['STATUS']} </td>
                            <td>{$value['USERNAME']}</td>
                            <td>{$value['CREATED']} </td> 
                            <td>{$value['REM']} </td>                                    
                        </tr>";
}
$processStatusHtml .= '</tbody></table>';
if ($resPendTo) {
    $processStatusHtml .= '<table>
                <table>
                    <tbody>
                        <tr>
                            <td style="padding-left: 5px; text-align: left; background-color: rgb(255, 255, 230);" colspan="4">
                                <span style="color: rgb(102, 51, 0); text-decoration: none;" class="lblFieldLabel">
                                    <b>Pending With : <br>  <span style="margin-left:20px;">' . $resPendTo[0]['PENDUSERNAME'] . ' <br></span></b>
                                </span>
                            </td>
                        </tr>      
                    </tbody>
                </table>';
}
$processStatusHtml .= ' </div></div>';


###########################################################################################
###################### HTML Table for Process Status End ##################################
########################################################################################### 
###########################################################################################
################# HTML form of  All CheckList with TAB START ##############################
###########################################################################################   
$sql = " SELECT 
T1.TCH_CHK_ID,
	T1.TCH_CHECK_POINT,
	T1.TCH_PARENT_ID,
	T1.TCH_DATA_TYPE,
         T1.TCH_VALUE_SET,
	NVL(T5.TCD_VALUE, 0) CHECKVALUE,
	--T5.TCD_REMARKS,
	NVL(T5.TCD_REMARKS, 0) REMARKSVALUE,
	T1.TCH_INCRIMENTAL,
	T1.TCH_TAB_ID,
	T1.TCH_SLNO,
	T2.TTS_ACCESS_LEVEL,
	T3.TMT_NAME,
	T4.TCD_VALUE
FROM T_VHS_CHECK_HEAD t1,
	T_VHS_TAB_MENU t2,
	T_VHS_MENU_TABS t3,
	T_VHS_CODES t4,
  (SELECT TCD_CHK_ID,TCD_VALUE,TCD_REMARKS FROM T_VHS_CHECK_DTLS WHERE  TCD_PROCESS_TYPE = 'VHD' AND TCD_CHASSIS_NO = '{$_REQUEST['chassisNo']}') t5
WHERE T3.TMT_ID    ={$_REQUEST['menuid']}
	AND T1.TCH_ACT_FLG = 1
	AND T2.TTS_MENU_ID = T3.TMT_ID
	AND T2.TTS_TAB_ID  = T1.TCH_TAB_ID(+)
	AND T2.TTS_TAB_ID  = T4.TCD_ID
	AND t1.TCH_CHK_ID = T5.TCD_CHK_ID(+)
ORDER BY  T4.TCD_SLNO ASC, T1.TCH_TAB_ID ASC,
	T1.TCH_PARENT_ID DESC,
	T1.TCH_SLNO ASC";
$obj = new db_connect;
$obj->db_query($sql);
$returnArr = array();
while ($row = $obj->db_fetch_arrayAssoc()) {
    if (!$row['TCH_PARENT_ID']) {
        $retrunRes[$row['TCD_VALUE']][$row['TCH_CHK_ID']] = $row;
    } else {
        $retrunRes[$row['TCD_VALUE']][$row['TCH_PARENT_ID']][] = $row;
    }
}
$resultTable = '';
foreach ($retrunRes as $indexTab => $tabDetails) {
    $resultTable .= '<div class="kks-panel" title="' . $indexTab . '" data-options="collapsible:true,collapsed:true"><div class="Grid">';
    $resultTable .= '<table style="background-color: #EFF3FB;">';
    $parntInc = 0;
    $incHeadColSpan = 2;
    $headColSpan = 3;
    if ($indexTab == "Joint Inspection") {
        $incHeadColSpan = 3;
        $headColSpan = 4;
    }
    $parntInc = 0;

    foreach ($tabDetails as $indexPrnt => $parentDetails) {
        if (is_array($parentDetails)) {
            $parntInc++;
            $childInc = 0;
            if ($parentDetails['TCH_INCRIMENTAL']) {
                $resultTable .= "<thead><tr><th style='width:2%'>" . $parntInc . "</th><th colspan='" . $incHeadColSpan . "'>" . $parentDetails['TCH_CHECK_POINT'] . "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr" . $parentDetails['TCH_CHK_ID'] . "\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr" . $parentDetails['TCH_CHK_ID'] . "\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                $resultTable .= "<tbody><tr class='trid" . $parentDetails['TCH_CHK_ID'] . "' id='addmoreTr" . $parentDetails['TCH_CHK_ID'] . "'><td style='width:2%'>" . $parntInc . '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' . $parentDetails['TCH_CHK_ID'] . '" checklist_id="' . $parentDetails['TCH_CHK_ID'] . '"  id="checkPDI' . ($indexPrnt + 1) . '" class="checkpdiInpt addMoreParam" ></td>';
                if ($parentDetails['TCH_DATA_TYPE'] == 'file') {
                    $resultTable .= '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' . $parentDetails['TCH_CHK_ID'] . ');" width="150Px"  value="Upload File"/></td>';
                    $txtRemark = '';
                } else {
                    $resultTable .= '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' . $parentDetails['TCH_CHK_ID'] . '" checklist_id="' . $parentDetails['TCH_CHK_ID'] . '"  id="checkPDI' . ($indexPrnt + 1) . '" class="checkpdiInpt vehicleParam" ></td>';
                    $txtRemark = '<textarea maxlength="1900" id="remarkBox_' . $parentDetails['TCH_CHK_ID'] . '" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                }
                if ($indexTab == "Joint Inspection") {
                    $setValArr = array("OK", "NOT OK");
                    $resultTable .= '<td>';
                    foreach ($setValArr as $key => $value) {
                        $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                        $resultTable .= '<label for="checkPDI' . ($key + 1) . $parentDetails['TCH_CHK_ID'] . '" id="lblPDI' . ($key + 1) . '" ><input type="radio" name="checkPDI_' . $parentDetails['TCH_CHK_ID'] . '" checklist_id="' . $parentDetails['TCH_CHK_ID'] . '"  id="checkPDI' . ($key + 1) . $parentDetails['TCH_CHK_ID'] . '"  value="' . $value . '" class="checkpdiInpt"><b style="color:' . $colr . ';">' . $value . '<b></label>';
                    };
                    $resultTable .= '</td>';
                }
                $resultTable .= '<td>' . $txtRemark . '</td>';
                $resultTable .= "</tr></tbody>";
            } else {
                $resultTable .= "<thead><tr><th style='width:2%'>" . $parntInc . "</th><th colspan='" . $headColSpan . "'>" . $parentDetails['TCH_CHECK_POINT'] . "</th></tr></thead>";
            }
            foreach ($parentDetails as $index => $childArr) {
                $childInc++;
                if (is_array($childArr)) {
                    $txtRemark = '<textarea maxlength="1900" rows="2" id="remarkBox_' . $childArr['TCH_CHK_ID'] . '" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                    $resultTable .= "<tbody><tr id='trid" . $childArr['TCH_CHK_ID'] . "' class='trid" . $childArr['TCH_CHK_ID'] . "'><td style='width:2%'>" . $parntInc . "." . $childInc . "</td><td>" . $childArr['TCH_CHECK_POINT'] . "</td>";

                    if ($childArr['TCH_DATA_TYPE'] == 'text') {
                        $resultTable .= '<td><input style="width:80%" type="text" name="checkPDI_' . $childArr['TCH_CHK_ID'] . '" checklist_id="' . $childArr['TCH_CHK_ID'] . '"  id="checkPDI' . ($index + 1) . '" class="checkpdiInpt vehicleParam" ></td>';
                    } else if ($childArr['TCH_DATA_TYPE'] == 'radio' && $indexTab != "Joint Inspection") {
                        $setValArr = explode('##', $childArr['TCH_VALUE_SET']);
                        $resultTable .= '<td>';
                        foreach ($setValArr as $key => $value) {
                            $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                            $resultTable .= '<label for="checkPDI' . ($key + 1) . '" id="lblPDI' . ($key + 1) . '" ><input type="radio" name="checkPDI_' . $childArr['TCH_CHK_ID'] . '" checklist_id="' . $childArr['TCH_CHK_ID'] . '"  id="checkPDI' . ($key + 1) . '"  value="' . $value . '" class="checkpdiInpt"><b style="color:' . $colr . ';">' . $value . '<b></label>';
                        };
                        $resultTable .= '</td>';
                    } else if ($childArr['TCH_DATA_TYPE'] == 'file') {
                        $resultTable .= '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' . $childArr['TCH_CHK_ID'] . ');" width="150Px"  value="Upload File"/></td>';
                        $txtRemark = '';
                    } else if ($indexTab == "Joint Inspection") {
                        $resultTable .= '<td></td>';
                    }
                    if ($indexTab == "Joint Inspection") {
                        $setValArr = array("OK", "NOT OK");
                        $resultTable .= '<td>';
                        foreach ($setValArr as $key => $value) {
                            $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                            $resultTable .= '<label for="checkPDI' . ($key + 1) . $childArr['TCH_CHK_ID'] . '" id="lblPDI' . ($key + 1) . '" ><input type="radio" name="checkPDI_' . $childArr['TCH_CHK_ID'] . '" checklist_id="' . $childArr['TCH_CHK_ID'] . '"  id="checkPDI' . ($key + 1) . $childArr['TCH_CHK_ID'] . '"  value="' . $value . '" class="checkpdiInpt"><b style="color:' . $colr . ';">' . $value . '<b></label>';
                        }
                        $resultTable .= '</td>';
                    }
                    $resultTable .= '<td>' . $txtRemark . '</td>';
                    $resultTable .= "</tr></tbody>";
                }
            }
        }
    }

    $resultTable .= "</table></div></div>";
}
include ('team_detail.php');
$resultTable .= $teamstatusHtml;
###########################################################################################  
################## HTML form of  All CheckList with TAB END ###############################    
########################################################################################### 
##########################################################################################
#################### Filled Data for All CheckLists START ################################
##########################################################################################
$checkValArr = $process->fillDataJI();
$sql = "SELECT TCD_LOG_NO,
  TCD_CHK_ID,
  TCD_VALUE,
  TCD_REMARKS
FROM T_VHS_CHECK_DTLS
WHERE TCD_LOG_NO = '{$_REQUEST["chassisNo"]}'";
$obj = new db_connect;
$obj->db_query($sql);
while ($row = $obj->db_fetch_arrayAssoc()) {
    $checkValArr[] = $row;
}
$obj->free();

$resultArr['HTMLCONT'] = '<div id="details_div">' . $processStatusHtml . $resultTable . '</div>';
$resultArr['FILLDATA'] = $checkValArr;

//$resultArr['TEAMCONT'] = $teamstatusHtml;
echo json_encode($resultArr);
##########################################################################################
###################### Filled Data for All CheckLists END ################################
##########################################################################################
?>