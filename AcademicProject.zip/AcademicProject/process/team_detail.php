<?php

###########################################################################################
###################### HTML Table for Team Status Start ################################
###########################################################################################   


$sql = "SELECT  
            TUS_NAME||'-'|| TUS_PNO TEAMMEM,TUS_UID, TUS_EMAIL_ID EMAIL, TCD_VALUE GRPNM
        FROM T_VHS_TEAM , T_VHS_USERS , T_VHS_CODES
        WHERE TTM_CHASSIS_NO = '{$_REQUEST['chassisNo']}'
        AND TTM_MEMBER = TUS_UID
        AND TTM_ACT_FLG = '1'
        AND TCD_ID = TTM_GROUP_ID
        AND TCD_ACT_FLG = '1'";


$obj = new db_connect;
$obj->db_query($sql);
$statusDetails = array();
while ($row = $obj->db_fetch_arrayAssoc()) {
    $statusDetails[] = $row;
}
$teamstatusHtml = '<div class="kks-panel" title="Team Details" data-options="collapsible:true,collapsed:true"> 
    <div class="Grid">
        <table cellpadding="0" cellspacing="0" id="tblTEAMStatus">
            <thead>
                <tr>
                    <th>Test Group</th>
                    <th>Member Name</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>';
?>
<?php

foreach ($statusDetails as $key => $value) {
    $teamstatusHtml .= "<tr>
                            <td>{$value['GRPNM']} </td>
                            <td>{$value['TEAMMEM']}</td>
                            <td>{$value['EMAIL']} </td>                                    
                        </tr>";
}
$teamstatusHtml .= '</tbody></table>';
$teamstatusHtml .= ' </div></div>';

###########################################################################################
###################### HTML Table for Team  Status End ##################################
########################################################################################### 
?>