<?php

include_once('./process_common_class.php');
include_once('../email/email_template_class.php');

date_default_timezone_set("Asia/Calcutta");
$process = new Process();
if (isset($_REQUEST['action'])) {
    if (($_REQUEST['action'] == 'pdiCheckList')) {
        $finalArr['checkpointData'] = $process->checkListWithTab();
        $finalArr['checkpointValue'] = findPDISavedData();
        $finalArr['LASTCOMMENT'] = $process->findLastComment($_REQUEST["chassisNo"]);
        $finalArr['AJAXCHASSISDTLS'] = $process->findChassisInfo($_REQUEST["chassisNo"]);
        $finalArr['AJAXFIRDTLS'] = $process->findFirInfo($_REQUEST["chassisNo"]);
        echo json_encode($finalArr);
        exit;
    } else if ($_REQUEST['action'] == 'saveChkList') {
        if ($_REQUEST['type'] == "saveData") {
            $stateID = 2;
        } else if ($_REQUEST['type'] == "submitData") {
            $stateID = 3;
        }
        echo savePdiCheckList($stateID);
    } else if ($_REQUEST['action'] == 'pdiapproval') {
        echo pdiAproveProcess();
    } else if ($_REQUEST['action'] == 'chassisDpdList') {
        if ($_REQUEST['chassisType'] == "REJECTED") {
            $finalArr['allChessis'] = chassisRejectPDI();
        } else {
            $finalArr['allChessis'] = $process->chassisDetails();
        }
        echo json_encode($finalArr);
    } else if ($_REQUEST['action'] == "deleteFir") {
        echo deleteFir();
    }
}

function findPDISavedData() {
    $sql = "SELECT TCD_LOG_NO,
            TCD_CHK_ID,
            TCD_VALUE,
            TCD_REMARKS
           
            FROM T_VHS_CHECK_DTLS 
            WHERE TCD_LOG_NO = '{$_REQUEST["chassisNo"]}'";
    $obj = new db_connect;
    $obj->db_query($sql);
    $resTable = '';
    $returnArr = array();
    while ($row = $obj->db_fetch_arrayAssoc()) {
        $returnArr[] = $row;
    }
    $obj->free();
    return $returnArr;
}

/*
 * @@@ Save PDI checklist when submited/saved
 * @@@ RETURN the display message only !!
 * STEP-1: First delete all corrensponding table records with the basis of current chassis number
 * STEP-2: Save data to the 'T_VHS_LOG_DTLS' table.
 * STEP-3: Save data to the 'T_VHS_STATE_DTLS' table.
 * STEP-4: Save data to the 'T_VHS_CHECK_DTLS' table.
 * STEP-5: Save data to the 'T_VHS_PENDING_DTLS' table.
 */

function savePdiCheckList($stateID = NULL) {
    checkDtlsOperation();
    if ($_REQUEST["chassisType"] == 'NEW') {
        if ($_REQUEST['type'] == "saveData") {
            logDtlsOperation("INSERT", $stateID);
            stateDtlsOperation("INSERT", $stateID);
            return "PDI save for the Chassis Number: " . $_REQUEST["chassisNo"];
        } else if ($_REQUEST['type'] == "submitData") {
            logDtlsOperation("INSERT", $stateID);
            stateDtlsOperation("INSERT", $stateID);
            chasssisDtlOperation(1);
            pendingDtlsOperation("INSERT");
            sendMailNotification();
            return "PDI Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        }
    } else if ($_REQUEST["chassisType"] == 'REJECTED') {
        logDtlsOperation("UPDATE", $stateID);
        if ($_REQUEST['type'] == "saveData") {
            stateDtlsOperation("INSERT", $stateID);
            return "PDI save for the Chassis Number: " . $_REQUEST["chassisNo"];
        } else if ($_REQUEST['type'] == "submitData") {
            stateDtlsOperation("UPDATE", $stateID);
            pendingDtlsOperation("UPDATE");
            sendMailNotification();
            return "PDI Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        }
    }
}

function checkDtlsOperation() {
    $obj = new db_connect;
    //Delete record from  T_VHS_CHECK_DTLS
    $deletChkSql = "DELETE FROM T_VHS_CHECK_DTLS WHERE TCD_LOG_NO='" . $_REQUEST["chassisNo"] . "' AND TCD_PROCESS_TYPE='PDI'";
    $obj->db_query($deletChkSql);

    //INSERT record to  T_VHS_CHECK_DTLS
    foreach ($_REQUEST["checklistObj"] as $value) {
        $sqlChekDtls = "INSERT INTO T_VHS_CHECK_DTLS";
        $sqlChekDtls .= " ( ";
        $sqlChekDtls .= "    TCD_LOG_NO ";
        $sqlChekDtls .= "  , TCD_CHK_ID ";
        $sqlChekDtls .= "  , TCD_CHASSIS_NO ";
        $sqlChekDtls .= "  , TCD_VALUE ";
        $sqlChekDtls .= "  , TCD_REMARKS ";
        $sqlChekDtls .= "  , TCD_CRT_BY ";
        $sqlChekDtls .= "  , TCD_CRT_TS ";
        $sqlChekDtls .= "  , TCD_UPD_BY ";
        $sqlChekDtls .= "  , TCD_UPD_TS ";
        $sqlChekDtls .= "  , TCD_PROCESS_TYPE ";
        $sqlChekDtls .= " ) ";
        $sqlChekDtls .= " VALUES ";
        $sqlChekDtls .= " ( ";
        $sqlChekDtls .= " '" . $_REQUEST["chassisNo"] . "' ";
        $sqlChekDtls .= "  , " . $value['checkListId'];
        $sqlChekDtls .= "  , '" . $_REQUEST["chassisNo"] . "' ";
        $sqlChekDtls .= "  , '" . $value['val'] . "' ";
        $sqlChekDtls .= "  , '" . $value['remarks'] . "' ";
        $sqlChekDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlChekDtls .= "  , SYSDATE ";
        $sqlChekDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlChekDtls .= "  , SYSDATE ";
        $sqlChekDtls .= "  , 'PDI' ";
        $sqlChekDtls .= " ) ";
        $obj = new db_connect;
        $obj->db_insert($sqlChekDtls);
    }
    $obj->free();
}

function logDtlsOperation($opType = NULL, $stateID = NULL) {
    $obj = new db_connect;
    if ($opType == 'INSERT') {
        //Delete record from  T_VHS_LOG_DTLS
        $deletLogSql = "DELETE FROM T_VHS_LOG_DTLS WHERE TLD_LOG_NO='" . $_REQUEST["chassisNo"] . "'";
        $obj->db_query($deletLogSql);
        $sqlLogDtls = "INSERT INTO T_VHS_LOG_DTLS( 
                            TLD_LOG_NO, 
                            TLD_SLNO,
                            TLD_ENGINE_NO,
                            TLD_BUGET_CODE,
                            TLD_STATUS,
                            TLD_PLANT_ID,
                            TLD_CRT_BY,
                            TLD_CRT_TS,
                            TLD_UPD_BY,
                            TLD_UPD_TS, 
                            TLD_PAE_ELECT, 
                            TLD_PAE_MECH 
                            ) ";
        $sqlLogDtls .= " VALUES ( ";
        $sqlLogDtls .= "'" . $_REQUEST["chassisNo"] . "'";
        $sqlLogDtls .= "  ,  (Select nvl(max(to_number(TLD_SLNO)),0)+1  from T_VHS_LOG_DTLS ) ";
        $sqlLogDtls .= "  , ' ' ";
        $sqlLogDtls .= "  , ' ' ";
        $sqlLogDtls .= "  , " . $stateID;
        $sqlLogDtls .= "  ," . $_SESSION['userSessionInfo']["TUS_PLNT"];
        $sqlLogDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlLogDtls .= "  , SYSDATE ";
        $sqlLogDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlLogDtls .= "  , SYSDATE ";
        $sqlLogDtls .= "  , '{$_REQUEST["paeMech"]}' ";
        $sqlLogDtls .= "  , '{$_REQUEST["paeElect"]}' ";
        $sqlLogDtls .= " ) ";
        $obj->db_insert($sqlLogDtls);
    } else if ($opType == 'UPDATE') {
        $sqlLogDtlsUpd = "UPDATE
                T_VHS_LOG_DTLS
            SET
                TLD_MODEL_NO = '{$_REQUEST["modelNo"]}',
                TLD_PROTO_TYPE = '{$_REQUEST["protoTypeNo"]}',
                TLD_ENGINE_NO = '{$_REQUEST["enggNo"]}',
                TLD_WBS_NO = '{$_REQUEST["wbsNo"]}',
                TLD_PROJECT_NAME = '{$_REQUEST["projectName"]}',
                TLD_BUGET_CODE = '{$_REQUEST["enggNo"]}',
                TLD_STATUS = $stateID,
                TLD_UPD_BY = {$_SESSION['userSessionInfo']['TUS_UID']},
                TLD_UPD_TS = SYSDATE,
                TLD_PAE_ELECT = {$_REQUEST["paeElect"]},
                TLD_PAE_MECH = {$_REQUEST["paeMech"]}
            WHERE TLD_LOG_NO='" . $_REQUEST["chassisNo"] . "' ";
        $obj->db_query($sqlLogDtlsUpd);
    }
    $obj->free();
}

function stateDtlsOperation($opType = NULL, $stateID = NULL) {
    $obj = new db_connect;
    if ($opType == 'INSERT') {
        //DELETE
        $deletStateSql = "DELETE FROM T_VHS_STATE_DTLS WHERE TSD_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' AND TSD_STATE_ID=2";
        $obj->db_query($deletStateSql);
        //INSER
        $sqlStatDtls = "INSERT INTO T_VHS_STATE_DTLS";
        $sqlStatDtls .= " ( ";
        $sqlStatDtls .= "    TSD_STATE_ID ";
        $sqlStatDtls .= "  , TSD_TRANS_ID "; //Primary key of that table.
        $sqlStatDtls .= "  , TSD_CHASSIS_NO ";
        $sqlStatDtls .= "  , TSD_CRT_BY ";
        $sqlStatDtls .= "  , TSD_CRT_TS ";
        $sqlStatDtls .= "  , TSD_UPD_BY ";
        $sqlStatDtls .= "  , TSD_UPD_TS ";
        $sqlStatDtls .= "  , TSD_REMARKS ";
        $sqlStatDtls .= " ) ";
        $sqlStatDtls .= " VALUES ";
        $sqlStatDtls .= " ( ";

        $sqlStatDtls .= $stateID;
        $sqlStatDtls .= "  ,  (Select nvl(max(to_number(TSD_TRANS_ID)),0)+1  from T_VHS_STATE_DTLS ) ";
        $sqlStatDtls .= "  , '" . $_REQUEST["chassisNo"] . "' ";
        $sqlStatDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlStatDtls .= "  , SYSDATE ";
        $sqlStatDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlStatDtls .= "  , SYSDATE ";
        $sqlStatDtls .= "  , '" . @$_REQUEST["currComment"] . "' ";
        $sqlStatDtls .= " ) ";
        $obj->db_insert($sqlStatDtls);
    } else if ($opType == 'UPDATE') {
        $sqlStatDtlsUpd = "UPDATE
                T_VHS_STATE_DTLS
            SET
                TSD_STATE_ID = $stateID,
                TSD_UPD_BY = {$_SESSION['userSessionInfo']['TUS_UID']},
                TSD_UPD_TS = SYSDATE,
                TSD_REMARKS = '" . @$_REQUEST["currComment"] . "'
            WHERE TSD_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' AND TSD_STATE_ID=2 ";
        $obj->db_query($sqlStatDtlsUpd);
    }
    $obj->free();
}

function pendingDtlsOperation($opType = NULL) {
    $obj = new db_connect;
    if ($opType == 'INSERT') {
        $sqlPendDtls = "INSERT INTO T_VHS_PENDING_DTLS";
        $sqlPendDtls .= " ( ";
        $sqlPendDtls .= "    TPD_CHASSIS_NO ";
        $sqlPendDtls .= "  , TPD_STATE_ID ";
        $sqlPendDtls .= "  , TPD_COMPLETED_STATE_ID ";
        $sqlPendDtls .= "  , TPD_PEND_WITH ";
        $sqlPendDtls .= "  , TPD_UPD_BY ";
        $sqlPendDtls .= "  , TPD_UPD_TS ";
        $sqlPendDtls .= " ) ";
        $sqlPendDtls .= " VALUES ";
        $sqlPendDtls .= " ( ";
        $sqlPendDtls .= "'" . $_REQUEST["chassisNo"] . "' ";
        $sqlPendDtls .= " , 4";
        $sqlPendDtls .= " , 3";
        $sqlPendDtls .= "  ,  ( SELECT T_VHS_USERS.TUS_UID FROM T_VHS_USERS,T_ERC_ROLE_USER WHERE T_VHS_USERS.TUS_UID = T_ERC_ROLE_USER.TRU_USER_ID AND T_ERC_ROLE_USER.TRU_ROLE_ID = 7 ) ";
        $sqlPendDtls .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
        $sqlPendDtls .= "  , SYSDATE ";
        $sqlPendDtls .= " ) ";
        $obj->db_insert($sqlPendDtls);
    } else if ($opType == 'UPDATE') {
        $updtPendSql = " UPDATE
                        T_VHS_PENDING_DTLS
                    SET
                        TPD_STATE_ID=4,
                        TPD_COMPLETED_STATE_ID=3,
                        TPD_PEND_WITH = ( SELECT T_VHS_USERS.TUS_UID FROM T_VHS_USERS,T_ERC_ROLE_USER WHERE T_VHS_USERS.TUS_UID = T_ERC_ROLE_USER.TRU_USER_ID AND T_ERC_ROLE_USER.TRU_ROLE_ID = 7 ),
                        TPD_UPD_BY = {$_SESSION['userSessionInfo']['TUS_UID']},
                        TPD_UPD_TS = SYSDATE
                    WHERE
                        TPD_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' ";
        $obj->db_query($updtPendSql);
    }
    $obj->free();
}

function chasssisDtlOperation($pdiDoneVal = 1) {
    $obj = new db_connect;
    //Update Chassis flag(TCD_IS_PDI_DONE) in table T_VHS_CHASSIS_DTLS
    $updateChasisFlag = "UPDATE T_VHS_CHASSIS_DTLS SET TCD_IS_PDI_DONE=$pdiDoneVal WHERE TCD_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' ";
    $obj->db_query($updateChasisFlag);
    $obj->free();
}

function sendMailNotification() {
    //Send mail to the PAI.
    $obj = new db_connect;
    $paiEmailSql = "SELECT T_VHS_USERS.TUS_EMAIL_ID EMAILID
                    ,T_VHS_USERS.TUS_NAME USERNAME
                    FROM T_VHS_USERS,
                      T_ERC_ROLE_USER
                    WHERE T_VHS_USERS.TUS_UID       = T_ERC_ROLE_USER.TRU_USER_ID
                    AND T_ERC_ROLE_USER.TRU_ROLE_ID = 7";
    $emailPAI = $obj->db_fetch_assoc($obj->db_query($paiEmailSql));
    $obj->free();
    $to = $emailPAI[0]['EMAILID'];
    $sendUserName = $emailPAI[0]['USERNAME'];
    $emailTemplate = new emailTemplate();
    $emailTempCont = $emailTemplate->pdiDoneNotifyToPAI($sendUserName);

    $sent = @mail($to, $emailTempCont['subject'], $emailTempCont['body'], $emailTempCont['headers']);

    //Send mail to the PAE.
    $emailTempCont = $emailTemplate->pdiDoneConfirmToPAE($_SESSION['userSessionInfo']['TUS_NAME']);
    $to = $_SESSION['userSessionInfo']["TUS_EMAIL_ID"];
    $sent = @mail($to, $emailTempCont['subject'], $emailTempCont['body'], $emailTempCont['headers']);
}

function pdiAproveProcess() {
    $obj = new db_connect;
    $msg = '';
    $emailTemplate = new emailTemplate();
    /*
      ###############################################################################################################
      ############################################ FIR UPLOAD START #################################################
      ###############################################################################################################
     */
    if (@$_FILES) {
        if ($_FILES['firUploadDco']['error']) {
            return "There was an error while uploading VALO, please try again!";
        }
        $UploadDirectory = WEBROOT . 'firDoc/';
        $fileExt = substr(strtolower($_FILES['firUploadDco']['name']), strrpos(strtolower($_FILES['firUploadDco']['name']), '.')); //file extension
        $NewFileName = $_SESSION['userSessionInfo']["TUS_PLNT"] . '_' . $_REQUEST['chassisNo'] . '_' . rand(100, 999) . '_' . "FIR" . $fileExt;
        $source = $_FILES['firUploadDco']["tmp_name"];
        $destination = $UploadDirectory . $NewFileName;
        if (move_uploaded_file($source, $destination)) {
            inactiveFir();
            $sqlFIRInsert = "INSERT INTO 
                                    T_VHS_EXT_UPLOAD (
                                                    TEU_CHASSIS_NO,
                                                    TEU_ULD_TYPE,
                                                    TEU_SL_NO,
                                                    TEU_FILE_NAME,
                                                    TEU_FILE_PATH,
                                                    TEU_ACT_FLG,
                                                    TEU_CRT_BY,
                                                    TEU_CRT_TS,
                                                    TEU_UPD_BY,
                                                    TEU_UPD_TS
                                                    )
                                    VALUES (

                                            '{$_REQUEST["chassisNo"]}',
                                            'FIR',
                                            (Select nvl(max(to_number(TEU_SL_NO)),0)+1  from T_VHS_EXT_UPLOAD Where TEU_CHASSIS_NO = '{$_REQUEST["chassisNo"]}' AND TEU_ULD_TYPE ='FIR'),
                                            '$NewFileName',
                                            './webroot/firDoc/" . $NewFileName . "' ,
                                            1,
                                            {$_SESSION['userSessionInfo']["TUS_UID"]},
                                            sysdate,
                                            {$_SESSION['userSessionInfo']["TUS_UID"]},
                                            sysdate
                                        )";
            $obj = new db_connect();
            $obj->db_insert($sqlFIRInsert);
            $obj->free();
        }
    }
    /*
      ###############################################################################################################
      ############################################## FIR UPLOAD END #################################################
      ###############################################################################################################
     */
    if ($_REQUEST['processType'] == "approved") {
        $stateId = 4;
        $nxtStateID = 18;
        $pendingWith = "(SELECT T_VHS_USERS.TUS_UID FROM T_VHS_USERS,T_ERC_ROLE_USER WHERE T_VHS_USERS.TUS_UID = T_ERC_ROLE_USER.TRU_USER_ID AND T_ERC_ROLE_USER.TRU_ROLE_ID = 5)";
        $msg = "Chassis No: {$_REQUEST["chassisNo"]} Approved Successfully! ";
    } else if ($_REQUEST['processType'] == "rejected") {
        $stateId = $nxtStateID = 2;
        $pendingWith = "(SELECT TPD_UPD_BY FROM T_VHS_PENDING_DTLS WHERE TPD_CHASSIS_NO ='{$_REQUEST["chassisNo"]}')";
        $msg = "Chassis No: {$_REQUEST["chassisNo"]} Rejected Successfully! ";
        // STEP-4:
        $updtChassDtlSql = "UPDATE T_VHS_CHASSIS_DTLS SET TCD_IS_PDI_DONE=2 WHERE TCD_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' ";
        $obj->db_query($updtChassDtlSql);
    }
    $sqlUserName = "SELECT TUS_NAME USERNAME FROM T_VHS_USERS WHERE TUS_UID=$pendingWith";
    $obj = new db_connect;
    $pendUserName = $obj->db_fetch_assoc($obj->db_query($sqlUserName));
    /*
     * STEP-1: Update status in 'T_VHS_LOG_DTLS' table.
     * STEP-2: Insert into 'T_VHS_STATE_DTLS' table.
     * STEP-3: Update in 'T_VHS_PENDING_DTLS' table.
     * STEP-4: If rejected Update TCD_IS_PDI_DONE in 'T_VHS_CHASSIS_DTLS' table.
     * STEP-5: Send mail to ..............@@@@#####$$$$
     */

    //STEP-1:

    $updtLogSql = " UPDATE
                        T_VHS_LOG_DTLS
                    SET
                        TLD_STATUS=$stateId
                    WHERE
                        TLD_LOG_NO='" . $_REQUEST["chassisNo"] . "' ";
    $obj->db_query($updtLogSql);

//    STEP-2:
    stateDtlsOperation("INSERT", $stateId);

//    STEP-3:
//    pendingDtlsOperation("UPDATE");
    $updtPendSql = " UPDATE
                        T_VHS_PENDING_DTLS
                    SET
                        TPD_STATE_ID=$nxtStateID,
                        TPD_COMPLETED_STATE_ID=$stateId,
                        TPD_PEND_WITH = $pendingWith,
                        TPD_UPD_BY = {$_SESSION['userSessionInfo']['TUS_UID']},
                        TPD_UPD_TS = SYSDATE
                    WHERE
                        TPD_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' ";
    $obj->db_query($updtPendSql);
    $obj->free();
    if ($_REQUEST['processType'] == "approved") {
        //set to and name of touser

        $emailTempCont = $emailTemplate->pdiDoneApprovedByPAI($_SESSION['userSessionInfo']['TUS_NAME']);
    } else if ($_REQUEST['processType'] == "rejected") {
        //set to
        $emailTempCont = $emailTemplate->pdiDoneRejectedByPAI($_SESSION['userSessionInfo']['TUS_NAME']);
    }
    $emailTempContConfrm = $emailTemplate->pdiApproveConfrmation($_SESSION['userSessionInfo']['TUS_NAME']);
    $sent = @mail($_SESSION['userSessionInfo']["TUS_EMAIL_ID"], $emailTempContConfrm['subject'], $emailTempContConfrm['body'], $emailTempContConfrm['headers']);
    $sent = @mail($pendUserName[0]['USERNAME'], $emailTempCont['subject'], $emailTempCont['body'], $emailTempCont['headers']);
    return $msg;
}

function deleteFir() {
    $obj = new db_connect;
    $sqlDelete = "UPDATE T_VHS_EXT_UPLOAD SET TEU_ACT_FLG=3 WHERE TEU_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' AND TEU_ULD_TYPE='FIR' AND TEU_FILE_NAME='" . $_REQUEST["fileName"] . "' AND TEU_SL_NO='" . $_REQUEST["slNo"] . "'";
    $obj->db_query($sqlDelete);
    $obj->free();
    return TRUE;
}

function inactiveFir() {
    $obj = new db_connect;
    $sql = "UPDATE T_VHS_EXT_UPLOAD SET TEU_ACT_FLG=2 WHERE TEU_CHASSIS_NO='" . $_REQUEST["chassisNo"] . "' AND TEU_ULD_TYPE='FIR'";
    $obj->db_query($sql);
    $obj->free();
    return TRUE;
}

function chassisRejectPDI() {
    $sql = "SELECT 
                t1.TPD_CHASSIS_NO AS CHASSSISNO,
                t3.TSH_STATE_NAME STATENAME,
                t1.TPD_STATE_ID PENDSTATEID
            FROM 
                T_VHS_PENDING_DTLS t1, 
                T_VHS_LOG_DTLS t2, 
                T_ERC_STATE_HEAD t3, 
                T_VHS_STATE_DTLS t4 
            WHERE 
                t1.TPD_STATE_ID IN(2,3) 
                AND t1.TPD_CHASSIS_NO = t2.TLD_LOG_NO 
                AND t1.TPD_STATE_ID  = t3.TSH_ID
                AND t1.TPD_CHASSIS_NO  = t4.TSD_CHASSIS_NO
                AND t4.TSD_STATE_ID IN(2)
                AND (T2.TLD_PAE_ELECT = " . $_SESSION['userSessionInfo']['TUS_UID'] . " OR T2.TLD_PAE_MECH = " . $_SESSION['userSessionInfo']['TUS_UID'] . ")";
    //return $sql;
    $obj = new db_connect;
    $obj->db_query($sql);
    $chassisDtlArr = array();
    while ($row = $obj->db_fetch_arrayAssoc()) {
        $chassisDtlArr[] = $row;
    }
    $obj->free();
    return $chassisDtlArr;
}

?>