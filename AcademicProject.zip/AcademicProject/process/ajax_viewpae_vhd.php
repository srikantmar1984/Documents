<?php

include_once('./process_common_class.php');
$sql = " SELECT 
T1.TCH_CHK_ID,
	T1.TCH_CHECK_POINT,
	T1.TCH_PARENT_ID,
	T1.TCH_DATA_TYPE,
	NVL(T5.TCD_VALUE, 0) CHECKVALUE,
	--T5.TCD_REMARKS,
	NVL(T5.TCD_REMARKS, 0) REMARKSVALUE,
	T1.TCH_INCRIMENTAL,
	T1.TCH_TAB_ID,
	T1.TCH_SLNO,
	T2.TTS_ACCESS_LEVEL,
	T3.TMT_NAME,
	T4.TCD_VALUE
FROM T_VHS_CHECK_HEAD t1,
	T_VHS_TAB_MENU t2,
	T_VHS_MENU_TABS t3,
	T_VHS_CODES t4,
  (SELECT TCD_CHK_ID,TCD_VALUE,TCD_REMARKS FROM T_VHS_CHECK_DTLS WHERE  TCD_PROCESS_TYPE = 'VHD' AND TCD_CHASSIS_NO = '{$_REQUEST['chassisNo']}') t5
WHERE T3.TMT_ID    ={$_REQUEST['menuid']}
	AND T1.TCH_ACT_FLG = 1
	AND T2.TTS_MENU_ID = T3.TMT_ID
	AND T2.TTS_TAB_ID  = T1.TCH_TAB_ID(+)
	AND T2.TTS_TAB_ID  = T4.TCD_ID
	AND t1.TCH_CHK_ID = T5.TCD_CHK_ID(+)
ORDER BY  T4.TCD_SLNO ASC, T1.TCH_TAB_ID ASC,
	T1.TCH_PARENT_ID DESC,
	T1.TCH_SLNO ASC";
$obj = new db_connect;
$obj->db_query($sql);
$returnArr = array();
while ($row = $obj->db_fetch_arrayAssoc()) {
    if (!$row['TCH_PARENT_ID']) {
        $retrunRes[$row['TCD_VALUE']][$row['TCH_CHK_ID']] = $row;
    } else {
        $retrunRes[$row['TCD_VALUE']][$row['TCH_PARENT_ID']][] = $row;
    }
}
$output = array();
foreach ($retrunRes as $key => $value) {
    $resTable = '<table style="background-color: #EFF3FB;">';
    $parntInc = 0;
    foreach ($value as $indexPrnt => $parentDetails) {
        if (is_array($parentDetails)) {
            $parntInc++;
            $childInc = 0;
            $resTable .= "<thead><tr><th style='width:2%'>" . $parntInc . "</th><th colspan='3'>" . $parentDetails['TCH_CHECK_POINT'] . "</th></tr></thead>";
            foreach ($parentDetails as $index => $childArr) {
                $childInc++;
                if (is_array($childArr)) {
                    $txtRemark = '<textarea disabled="disabled" maxlength="1900" rows="2" style="word-wrap: break-word;width:95%" placeholder="Remarks">' . $childArr['REMARKSVALUE'] . '</textarea>';
                    $resTable .= "<tbody><tr id='trid" . $childArr['TCH_CHK_ID'] . "' class='trid" . $childArr['TCH_CHK_ID'] . "'><td style='width:2%'>" . $parntInc . "." . $childInc . "</td><td>" . $childArr['TCH_CHECK_POINT'] . "</td>";
                    if ($childArr['TCH_DATA_TYPE'] == 'text') {
                        $resTable .= '<td><input disabled="disabled" type="text" name="ShowcheckVHD_' . $childArr['TCH_CHK_ID'] . '" value="' . $childArr['CHECKVALUE'] . '" class="showcheckVhdInpt" ></td>';
                    }
                    $resTable .= '<td>' . $txtRemark . '</td>';
                    $resTable .= "</tr></tbody>";
                }
            }
        }
    }
    $output[$key] = $resTable;
}
echo json_encode($output);
