<?php

include_once('./process_common_class.php');
include_once('../email/email_template_class.php');
include("./web_api_class.php");
$ref = 'on';
date_default_timezone_set("Asia/Calcutta");
$process = new Process();

if (isset($_REQUEST['action'])) {

    if (($_REQUEST['action'] == 'createChassis')) {
        echo chassisGen();
        exit;
    } else if (($_REQUEST['action'] == 'AllChassisList')) {
        echo json_encode(chassisDetailsList());
        exit;
    } else if ($_REQUEST['action'] == "vcListReturn") {
        set_time_limit(0);
        $vcList['ALLVCLIST'] = $webApi->bcDetails($_REQUEST['projCode']);
        echo json_encode($vcList);
        exit;
    } else if ($_REQUEST['action'] == "updateChassis") {
        echo updateChassis();
        exit;
    } else {
        $strOptions = "<option value=''>--Select--</option>";
        if ($_REQUEST['itm'] == "TYRE") {
            $process = new Process();
            $tyreSizeList = $process->tyreSizeList();
            foreach ($tyreSizeList as $key => $tyreEach) {
                $strOptions .= '<option value="' . $tyreEach['TYRESIZE'] . '" >' . $tyreEach['TYRESIZE'] . '</option>';
            }
        }
        echo $strOptions;
        exit();
    }
}

function chassisGen() {
    $newChassisDtls = array();
    $obj = new db_connect;
    $row = $obj->db_reader("Select nvl(max(to_number(TCD_SLNO)),0)+1 SLNO from t_vhs_chassis_dtls");
    $newSlNo = str_pad($row["SLNO"][0], 5, 0, STR_PAD_LEFT);
    $newChassisNo = $_REQUEST['chcAddBU'] . strrev($_REQUEST['chcAddGVW']) . $_REQUEST['chcAddWB'] . strrev($_REQUEST['chcAddMonth']) . strrev($_REQUEST['chcAddYear']) . $_REQUEST['chcAddLR'] . $_REQUEST['chcAddPlant'] . $newSlNo;
    $newChassisDtls['TCD_SLNO'] = $row["SLNO"][0];
    $newChassisDtls['TCD_CHASSIS_NO'] = $newChassisNo;
/*
    $obj = new db_connect;
  
  $row = $obj->db_reader("Select count(TCD_CHASSIS_NO) RECNO from t_vhs_chassis_dtls WHERE TCD_CHASSIS_NO ='" . $newChassisNo . "' OR( TCD_BU ='" . $_REQUEST['chcAddBU'] . "' AND TCD_GVW = '" . $_REQUEST['chcAddGVW'] . "' AND TCD_WB = '" . $_REQUEST['chcAddWB'] . "' AND TCD_MONTH = '" . $_REQUEST['chcAddMonth'] . "' AND TCD_YR = '" . $_REQUEST['chcAddYear'] . "' AND TCD_LH_RH = '" . $_REQUEST['chcAddLR'] . "' AND TCD_LOCN = '" . $_REQUEST['chcAddPlant'] . "')");
    if ($row["RECNO"][0]) {
        return 'This Chassis number can\'t be generated as this chassis number already exist in system!';
    } else {
*/
        $rtnMsg = saveChassisNo($newChassisDtls);
        //sentMailChassisGenNotify();
        return $rtnMsg;
    //}
}

function saveChassisNo($newChassisDtls) {
    $strSql = "INSERT INTO T_VHS_CHASSIS_DTLS ";
    $strSql .= " ( ";
    $strSql .= "   TCD_CHASSIS_NO ";
    $strSql .= " , TCD_BU ";
    $strSql .= " , TCD_GVW ";
    $strSql .= " , TCD_WB ";
    $strSql .= " , TCD_MONTH ";
    $strSql .= " , TCD_YR ";
    $strSql .= " , TCD_LH_RH ";
    $strSql .= " , TCD_LOCN ";
    $strSql .= " , TCD_SLNO ";
    $strSql .= " , TCD_ACT_FLG ";
    $strSql .= " , TCD_CRT_BY ";
    $strSql .= " , TCD_CRT_TS ";
    $strSql .= " , TCD_UPD_BY ";
    $strSql .= " , TCD_UPD_TS ";
    $strSql .= " , TCD_IS_PDI_DONE,TCD_OLD_CHASSIS,TCD_INVOICE,TCD_INV_DATE,TCD_TYRE,TCD_PROTO_NO,TCD_PROJ_CODE,TCD_MODEL,TCD_WBS_LIST,TCD_VC_REL,TCD_VC_NO,TCD_ENGINE";
    $strSql .= " ) ";
    $strSql .= " VALUES ";
    $strSql .= " ( ";
    $strSql .= "'" . $newChassisDtls['TCD_CHASSIS_NO'] . "'";
    $strSql .= " , '" . $_REQUEST['chcAddBU'] . "', ";
    $strSql .= $_REQUEST['chcAddGVW'] . ",";
    $strSql .= $_REQUEST['chcAddWB'] . ",";
    $strSql .= $_REQUEST['chcAddMonth'] . ",";
    $strSql .= $_REQUEST['chcAddYear'] . ",";
    $strSql .= "'" . $_REQUEST['chcAddLR'] . "' ";
    $strSql .= " , '" . $_REQUEST['chcAddPlant'] . "', ";
    $strSql .= $newChassisDtls['TCD_SLNO'] . ",";
    $strSql .= "1,";
    $strSql .= $_SESSION['userSessionInfo']['TUS_UID'];
    $strSql .= " , SYSDATE ,";
    $strSql .= $_SESSION['userSessionInfo']['TUS_UID'];
    $strSql .= " , SYSDATE ";
    $strSql .= ",0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL ) ";

    $obj = new db_connect;
    $obj->db_insert($strSql);
    $obj->free();

    //Email sent to the user who generate the chassis
    $_REQUEST['chassisNo'] = $newChassisDtls['TCD_CHASSIS_NO'];
    $emailTemplate = new emailTemplate();
    $emailTempCont = $emailTemplate->chassisGenDone($_SESSION['userSessionInfo']['TUS_NAME']);
    $sent = @mail($_SESSION['userSessionInfo']["TUS_EMAIL_ID"], $emailTempCont['subject'], $emailTempCont['body'], $emailTempCont['headers']);

    return 'Chassis No:'.$newChassisDtls['TCD_CHASSIS_NO'].' Generated Successfully!';
}

function chassisDetailsList() {
    $sql = "SELECT";
    $sql .= "   TCD_CHASSIS_NO ";
    $sql .= " , TCD_BU ";
    $sql .= " , TCD_GVW ";
    $sql .= " , TCD_WB ";
    $sql .= " , TO_CHAR(TO_DATE(TCD_MONTH, 'MM'), 'Month') AS TCD_MONTH ";
    $sql .= " , TO_CHAR(TO_DATE(TCD_YR, 'YY'), 'YYYY') AS TCD_YR ";
    $sql .= " , TCD_LH_RH ";
    $sql .= ", NVL(CASE
                WHEN TCD_LOCN = 'J'
                   THEN 'JSR'
                WHEN TCD_LOCN = 'P'
                   THEN 'PUN'
                WHEN TCD_LOCN = 'L'
                   THEN 'LKO'
             END,' ') AS TCD_LOCN ";
    $sql .= " , rownum TCD_SLNO ";
    $sql .= " , TCD_ACT_FLG ";
    $sql .= " , TCD_CRT_BY ";
    $sql .= " , TCD_CRT_TS ";
    $sql .= " , TCD_UPD_BY ";
    $sql .= " , TCD_UPD_TS ";
    $sql .= " , nvl(TCD_ENGINE,' ') TCD_ENGINE ";
    $sql .= " , nvl(TCD_INVOICE,' ') TCD_INVOICE ";
    $sql .= " , nvl(TO_CHAR(TCD_INV_DATE,'dd-Mon-yyyy'),' ') TCD_INV_DATE ";
    $sql .= " , nvl(TCD_OLD_CHASSIS,' ') TCD_OLD_CHASSIS ";
    $sql .= " , nvl(TCD_WBS_LIST,' ') TCD_WBS_LIST ";
    $sql .= " , nvl(TCD_TYRE,' ') TCD_TYRE  ";
    $sql .= " , nvl(TCD_PROJ_CODE,' ') TCD_PROJ_CODE  ";
    $sql .= " , nvl(TCD_MODEL,' ') TCD_MODEL   ";
    $sql .= " , nvl(TCD_VC_NO,' ') TCD_VC_NO   ";
    $sql .= " , DECODE(nvl(TCD_VC_REL,'0'),'1','Yes','No') TCD_VC_REL , nvl(DECODE(TCD_PROTO_NO,null,' ',TCD_PROTO_NO),'') TCD_PROTO_NO";
    $sql .= " FROM T_VHS_CHASSIS_DTLS WHERE TCD_IS_PDI_DONE = 0 ";
    if ($_REQUEST['searchBU']) {
        $sql .= "AND TCD_BU ='" . $_REQUEST['searchBU'] . "'";
    }
    if ($_REQUEST['searchGVW']) {
        $sql .= "AND TCD_GVW ='" . $_REQUEST['searchGVW'] . "'";
    }
    if ($_REQUEST['searchWB']) {
        $sql .= "AND TCD_WB ='" . $_REQUEST['searchWB'] . "'";
    }
    if ($_REQUEST['searchYR']) {
        $sql .= "AND TCD_YR ='" . $_REQUEST['searchYR'] . "'";
    }
    if ($_REQUEST['searchMON']) {
        $sql .= "AND TCD_MONTH ='" . $_REQUEST['searchMON'] . "'";
    }
    if ($_REQUEST['searchLR']) {
        $sql .= "AND TCD_LH_RH ='" . $_REQUEST['searchLR'] . "'";
    }
    if ($_REQUEST['searchCHSNO']) {
        $sql .= "AND TCD_CHASSIS_NO ='" . $_REQUEST['searchCHSNO'] . "'";
    }
    if ($_REQUEST['CreatedFrom']) {
        $sql .= " AND TRUNC(TCD_CRT_TS) >=TO_DATE('" . $_REQUEST['CreatedFrom'] . "','DD-MM-YY') ";
    }
    if ($_REQUEST['CreatedTo']) {
        $sql .= " AND TRUNC(TCD_CRT_TS) <= TO_DATE('" . $_REQUEST['CreatedTo'] . "','DD-MM-YY') ";
    }
    if ($_REQUEST['searchEngineNo']) {
        $sql .= "AND TCD_ENGINE ='" . $_REQUEST['searchEngineNo'] . "'";
    }
    if ($_REQUEST['searchWBSList']) {
        $sql .= "AND TCD_WBS_LIST ='" . $_REQUEST['searchWBSList'] . "'";
    }
    if ($_REQUEST['searchVCNo']) {
        $sql .= "AND TCD_VC_NO ='" . $_REQUEST['searchVCNo'] . "'";
    }

    $sql .= "ORDER BY TCD_SLNO ASC";
    $obj = new db_connect;
    $obj->db_query($sql);
    $returnArr = array();
    while ($row = $obj->db_fetch_arrayAssoc()) {
        $returnArr['ChassisDtls'][] = $row;
    }
    $obj->free();
    return $returnArr;
}

function updateChassis() {
    $res = "1";
    $strSql = " UPDATE T_VHS_CHASSIS_DTLS  SET TCD_OLD_CHASSIS = '" . $_REQUEST['subOLDCHSVal'] . "'
                ,TCD_INVOICE='" . $_REQUEST['subINVNOVal'] . "'
                ,TCD_INV_DATE= '" . $_REQUEST['subINVDATEVal'] . "'
                ,TCD_TYRE= '" . $_REQUEST['edtTYREVal'] . "'
                ,TCD_PROJ_CODE= '" . $_REQUEST['subPROJCODEVal'] . "'
                ,TCD_MODEL= '" . $_REQUEST['subMODELVal'] . "'
                ,TCD_WBS_LIST= '" . $_REQUEST['edtWBSLISTVal'] . "'
                ,TCD_VC_REL= '" . $_REQUEST['rdbval'] . "'
                ,TCD_PROTO_NO = '" . $_REQUEST['subProtoVal'] . "'
                ,TCD_VC_NO= '" . $_REQUEST['rdbVC'] . "'
                ,TCD_ENGINE ='" . $_REQUEST['subENGINEVal'] . "'
                WHERE TCD_CHASSIS_NO = '" . $_REQUEST['chsno'] . "' ";
    $obj = new db_connect;
    $obj->db_insert($strSql);
    $obj->free();
    $res = "0";
    return $res;
}

/*
 * Send mail to all PAE when a new chassis will generate.
 * @@ Both PAE mechanical and PAE electrical will get email.
 * @@ Proto Assembly Engineer(Mechanical)----->Role ID: 8
 * @@ Proto Assembly Engineer(Electrical)----->Role ID: 11
 */

function sentMailChassisGenNotify() {
    $sql = "SELECT
                T_VHS_USERS.tus_uid userid,
                INITCAP(T_VHS_USERS.tus_name) username,
                T_VHS_USERS.TUS_EMAIL_ID email
            FROM
                T_VHS_USERS,
                t_erc_role_user
            WHERE
                T_VHS_USERS.tus_uid = t_erc_role_user.tru_user_id
            AND t_erc_role_user.tru_role_id in(7,8,11)
            ORDER BY T_VHS_USERS.tus_name";
    $obj = new db_connect;
    $obj->db_query($sql);
    $returnArr = array();
    $emailTemplate = new emailTemplate();
    while ($row = $obj->db_fetch_arrayAssoc()) {
        $emailTempCont = $emailTemplate->chassisGenDone($row['USERNAME']);
        $sent = @mail($row['EMAIL'], $emailTempCont['subject'], $emailTempCont['body'], $emailTempCont['headers']);
    }
    $obj->free();
}

?>