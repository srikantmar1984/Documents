<?php include("./process_common_class.php"); ?>
<input type="hidden" id="hfPageTitle" value="Joint Inspection Form" screen_id="">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<div class="Grid" style="text-align: left;">
    <form name="iirreport" class="iirreport" id="logInc">
        <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td colspan="3">
                        <span>
                            <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                            <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select Chassis No--</option>
                                <?php
                                $chassisDtlArr = $process->chassisPending();
                                foreach ($chassisDtlArr as $value) {
//                                    echo '<option data-modelType="' . $value['MODEL_TYPE'] . '" value="' . $value['CHASSIS_NO'] . '" data-modelTypeNo="' . $value['MODEL_TYPE_NO'] . '" data-protoTypeNo="' . $value['PROTO_TYP_NO'] . '" data-enggNo="' . $value['ENG_NO'] . '" data-wbsNo="' . $value['WBS_NO'] . '" data-projectCode="' . $value['PROJECT_CODE'] . '">' . $value['CHASSIS_NO'] . '</option>';
                                    echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>
                    </td>
                </tr>
            </tbody>
            <tr style="height:40px">
                <td colspan="3" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>VEHICLE JOINT INSPECTION SIGN-OFF SHEET</b>
                    </span>
                </td>
            </tr>
        </table>
<!--        <table id="bdyJIForm" style="display: none;background-color: #EFF3FB;">
            <?php // echo $process->pdiCheckList(); ?> 
        </table>-->
        <div id="tabMenuVHO" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
            <!--Tabs are added dynamically here-->
        </div>

        <div id="jiEntryFormBtn" style="margin:10px;display: none">
            <a href="javascript:void(0);" class="kks-linkbutton l-btn,confirm" align="left" onclick="confirmClear();">
                <span style="text-align:left;" >Clear All</span>
            </a>	

            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" onclick="saveJi('saveData');">
                <span  style="text-align:left;" >Save data</span>
            </a>
            <a href="javascript:void(0);" class="kks-linkbutton l-btn" align="left" id="linkSubmitPaps" onclick="saveJi('submitData');">
                <span  style="text-align:left;" >Submit</span>				 
            </a>
        </div>

    </form>
</div>
<div id="dd"></div>
<script type="text/javascript">
    var url = wwwRoot + "process/jientry_action.php";
    $(function () {
        $('.layout-button-left').trigger('click');
        $("#ddlChassis").change(function () {
             var tabNos = $('.tabs >li').length;
            for (i = 0; i < tabNos; i++) {
                $("#tabMenuVHO").tabs('close', 0);
            }
            if ($(this).val()) {
                //ajax call for ji list
               var menuid = $("#urlMenuID").val();
                $.post(url, {action: "JIDETAILS", chassisNo: $(this).val(),menuid:menuid}, function () {
                }, 'JSON').done(function (data) { console.log(data);
                    var resTable = '';
                    $.each(data.CHECKDTLS, function (indexTab, tabDetails) {
                        var resTable = '<table style="background-color: #EFF3FB;">';
                        resTable += "<thead><tr><th style='width:2%'>SL.NO.</th><th>Parameters</th><th>Checked on Vehicle</th><th>OK or NOT OK</th><th>Remarks</th></tr></thead>";
                        var parntInc = 0;
                        $.each(tabDetails, function (indexPrnt, parentDetails) {
                            if ($.type(parentDetails) == 'object') {
                            parntInc++;
                                var childInc = 0;
                                //Thead
                                if (parentDetails.TCH_INCRIMENTAL) {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr"+parentDetails.TCH_CHK_ID+"\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr"+parentDetails.TCH_CHK_ID+"\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                                    resTable += "<tbody><tr class='trid"+parentDetails.TCH_CHK_ID+"' id='addmoreTr"+parentDetails.TCH_CHK_ID+"'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt addMoreParam" ></td>';
                                    if(parentDetails.TCH_DATA_TYPE == 'file'){
                                        resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,'+parentDetails.TCH_CHK_ID+');" width="150Px"  value="Upload File"/></td>';
                                        txtRemark = '';
                                    }else{
                                        resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt vehicleParam" ></td>';
                                        txtRemark = '<textarea maxlength="1900" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                    }
//#################################################################################################                         
                                        $setValArr = ["OK", "NOT OK"];
                                            resTable += '<td>';
                                            $setValArr.forEach(function ($value, $key) {
                                                $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                                resTable += '<label for="checkPDI' + ($key + 1) +parentDetails.TCH_CHK_ID+ '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) +parentDetails.TCH_CHK_ID+'"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
//                                                resTable += '<label for="checkPDI' + ($key + 1) + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                            });
                                            resTable += '</td>';
//################################################################################################      
                                    
                                    resTable += '<td>'+txtRemark+'</td>';
                                    resTable += "</tr></tbody>";
                                } else {
                                    resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='4'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                                }
                                //Tbody
                                $.each(parentDetails, function (index, childArr) {
                                    childInc++;
                                    if ($.type(childArr) == 'object') {
                                        txtRemark = '<textarea maxlength="1900" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                                        resTable += "<tbody><tr id='trid"+childArr.TCH_CHK_ID+"' class='trid"+childArr.TCH_CHK_ID+"'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";
                                       
                                        if (childArr.TCH_DATA_TYPE == 'text') {
                                            resTable += '<td><input style="width:80%" type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt vehicleParam" ></td>';
                                        }else if (childArr.TCH_DATA_TYPE == 'file') {
                                            resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,'+childArr.TCH_CHK_ID+');" width="150Px"  value="Upload File"/></td>';
                                            txtRemark = '';
                                        }else{
                                            resTable += '<td></td>';
                                        }
                                         $setValArr = ["OK", "NOT OK"];
//                                            console.log($setValArr);
                                            resTable += '<td>';
                                            $setValArr.forEach(function ($value, $key) {
                                                $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                                resTable += '<label for="checkPDI' + ($key + 1) +childArr.TCH_CHK_ID+ '" id="lblPDI' + ($key + 1)  + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) +childArr.TCH_CHK_ID + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                            });
                                            resTable += '</td>';
                                        resTable += '<td>'+txtRemark+'</td>';
                                        resTable += "</tr></tbody>";
                                    }
                                })
                            }
                        })
//                        console.log(indexPr);
//                        console.log(element);
                        resTable += "</table>";
                                $('#tabMenuVHO').tabs('add',{
                                    title:indexTab,
                                    content:resTable,
                                    closable:false
                                });
                       
                    })
//                    $("#tabMenuVHO").html(resHtmlStr).show();
                
                $("#tabMenuVHO").tabs('select', 0);
                        })
                $("#pdiEnggType").trigger('change');
                $("#txtModelNo").val($('option:selected', $(this)).data('modeltypeno')).attr('readonly', true);
                $("#jiEntryFormBtn").show();
            } else {
                $("#txtModelNo").val('').attr('readonly', true);
                $("#jiEntryFormBtn").hide();
            }
        })
    })
    
    function saveJi(type) {
//    alert($('input[name=chessisType]:checked').val());return false;
        var totalField = $('.checkpdiInpt').length;
        var totalRadio = $(':radio[class="checkpdiInpt"]').length;
        var totalText = totalField - totalRadio;
        var totalRadioBlck = totalRadio / 2;
        var checkedRadio = $(':radio[class="checkpdiInpt"]:checked').length;
        if (type == "submitData") {
            alert(checkedRadio+"######"+totalRadioBlck);
            if (checkedRadio != totalRadioBlck) {
                alert("Please check all PDI checklist!");
                return false;
            }
//            var cntTxt = 0;
//            $(':text[class="checkpdiInpt"]').each(function () {
//                if (!$(this).val()) {
//                    cntTxt = 1;
//                }
//            })
//            if (cntTxt) {
//                alert("Please check all PDI checklist!");
//                return false;
//            }
        }
        var chassisNo = $('#ddlChassis').val();
//        var modelNo = $('#txtModelNo').val().trim();
//        var protoTypeNo = $('#txtProtoType').val().trim();
//        var enggNo = $('#txtEngineNo').val().trim();
//        var projectName = $('#txtProjNo').val().trim();
//        var wbsNo = $('#txtWBSNo').val().trim();
//        var enggType = $("#pdiEnggType").val();
        var checklistObj = [];
        var jiStatus = 1;
        $('.checkpdiInpt').each(function () {
            var remarks = $(this).closest('tr').find('.txtFieldTextBox').val();
            var vehicleParam = $(this).closest('tr').find('.vehicleParam').val();
            var addMoreParam = $(this).closest('tr').find('.addMoreParam').val();
//            alert($(this).closest('tbody tr').length);
//            if($(this).closest('tbody > tr').length>1){
//                alert($(this).closest('tbody > tr').length);
//            }
            if ($(this).is(':checked')) {
                var photolistObj = [];
                $(this).closest('tbody').find('.addMorePhotoTr').each(function(){
    //                alert($(this).find(".photoName").val());
                    var photoName = $(this).find(".photoName").val();
                    photolistObj.push({photoName:$(this).find(".photoName").val(),photoDesc:$(this).find(".photoDesc").val()});
                })
                
                if($(this).val() =="NOT OK")
                    jiStatus = 2;
                checklistObj.push({checkListId: $(this).attr('checklist_id'), val: $(this).val(), remarks: remarks,vehicleParam:vehicleParam,addMoreParam:addMoreParam,photolistObj:photolistObj});
            }
//            if ($(this).is(':text') && $(this).val()) {
//                checklistObj.push({checkListId: $(this).attr('checklist_id'), val: $(this).val(), remarks: remarks});
//            }
        })
//        console.log(checklistObj);return false;
        $.post(url,
                {
                    type: type,
                    chassisNo: chassisNo,
                    checklistObj: checklistObj,
                    chassisType:$('input[name=chessisType]:checked').val(),
                    jiStatus:jiStatus,
                    action: 'saveJIChkList'
                }).done(function (data) {
            alert(data);return false;
//            window.location.href = wwwRoot + "home.php?menuid=14";
            openUrl(wwwRoot + "process/jientry.php?menuid=18");
        })

    }
</script>