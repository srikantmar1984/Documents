<?php include("./process_common_class.php"); ?>

<input type="hidden" id="hfPageTitle" value="PDI Form Approval" screen_id="">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<div class="Grid" style="text-align: left;">
    <form id="pdiAprove"  enctype="multipart/form-data" action="process/pdiform_action.php?action=pdiapproval" method="post" >
        <table class="" width="100%" cellpadding="0" cellspacing="0" id="tblGeneraldata" >
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td colspan="4">
                        <span>
                            <label for="ddlChassis" id="lblYes" ><b>Chassis No:</b></label>
                            <select id="ddlChassis" name="ddlChassis" style="width:15%;"  class="ddlFieldDropdown">
                                <option value="">--Select Chassis No--</option>
                                <?php
                                $chassisDtlArr = $process->chassisPending();
                                foreach ($chassisDtlArr as $value) {
                                    if ($value['PENDSTATEID'] == 4)
                                        echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                                }
                                ?> 
                            </select>
                        </span>
                    </td>
                </tr>
                <tr style="height:24px">
                    <td colspan="4">
                        <!--###########################################
                        ########## Chassis Details Start ##############
                        ###########################################-->
                        <?php include("ajax_chassis_details.php"); ?>
                        <!--###########################################
                        ############## Chassis Details End ############
                        ###########################################-->
                    </td>
                </tr>
            </tbody>
            <tr style="height:40px">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>PDI CHECKLIST FOR ERC PROTO VEHICLES</b>
                    </span>
                </td>
            </tr>
        </table>
        <div id="tabMenuVHO" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
            <!--Tabs are added dynamically here-->
        </div>
        <table class="chassisDtlSpan assignTable" width="100%" cellpadding="0" cellspacing="0" style="display: none" >

            <tr style="height:40px">
                <td colspan="4" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                    <span class="lblHeadLabel" style="text-decoration:underline;margin-right: 10px">
                        <b>Appoval Process</b>
                    </span>
                </td>
            </tr>
            <tbody id="bdyGeneraldata" style="background-color: #EFF3FB;" >
                <tr style="height:24px">
                    <td style="width: 20%" class="hideLastComent">
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Last Comment By: </b><b style="color: #3637FE" id="pendUserName"></b></label>
                        </span>
                    </td>
                    <td class="hideLastComent">
                        <span style="display: none" class="chassisDtlSpan" >
                            <textarea placeholder="Last Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="last_comment" rows="2" maxlength="1900" disabled="disabled"></textarea>
                        </span>
                    </td>
                    <td style="width: 20%">
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>Comment for Approve/Reject:</b></label>
                        </span>
                    </td>
                    <td>
                        <span style="display: none" class="chassisDtlSpan" >
                            <textarea placeholder="Please Put Your Comment" style="word-wrap: break-word;width: 95%" class="txtFieldTextBox" id="current_comment" rows="2" maxlength="1900"></textarea>
                        </span>
                    </td>
                </tr>
                <tr style="height:24px">
                    <td style="width: 20%">
                        <span style="display: none" class="chassisDtlSpan" >
                            <label for="ddlResponsibleEngg" id="lblModelNo" ><b>FIR Document Upload:</b></label>
                        </span>
                    </td>
                    <td colspan="3">
                        <input type="file" name="firUploadDco" id="firUploadDco" />
                    </td>
                </tr>
                <tr style="height:24px">
                    <td colspan="4">

                    </td>
                </tr>
            </tbody>
        </table>
        <!--###########################################
        ############## FIR Details Start ##############
        ###########################################-->
        <?php include("ajax_fir_details.php"); ?>
        <!--###########################################
        ############## FIR Details End ################
        ###########################################-->
        <div id="checklistFormBtn" style="margin:10px;display: none">
            <a href="javascript:void(0);" class="kks-linkbutton l-btn confirm" iconCls="icon-approved" align="left" onclick="pdiApproved('approved');">
                <span style="text-align:left;" >Approved</span>
            </a>
            <a href="javascript:void(0);" class="kks-linkbutton l-btn" iconCls="icon-rejected" align="left" onclick="pdiApproved('rejected');">
                <span  style="text-align:left;" >Reject</span>
            </a>
        </div>

    </form>
</div>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript">
var url = wwwRoot + "process/pdiform_action.php";
$(function () {
    $("#tabMenuVHO :input").attr("disabled", true);
    $('.layout-button-left').trigger('click');
    //  ======================================================On Chassis change fill chassis details======================================================================================= 
    $("#ddlChassis").change(function () {
        if ($(this).val()) {

            $('#tabMenuVHO').tabs('close', 0);
            $('#tabMenuVHO').tabs('close', 0);
            $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan").show();
            tabGenerate();
        } else {

            $("#tabMenuVHO").tabs('close', 0);
            $("#tabMenuVHO").tabs('close', 0);
            $("#vhdFormBtn").hide();
            $(".chassisDtlSpan,#bdyCheckList,#pdiTypeSpan,#bdyCheckList,#checklistFormBtn,#ajaxChassisInfoTbl,#ajaxFirInfoTbl").hide();
        }
    });
});

function tabGenerate() {
    //ajax call for PDI list
    var menuid = $("#urlMenuID").val();
    $.post(url, {action: "pdiCheckList", chassisNo: $("#ddlChassis").val(), menuid: menuid}, function () {
    }, 'JSON').done(function (data) { //console.log(data);return false;

        var resTable = '';
        $.each(data.checkpointData, function (indexTab, tabDetails) {
            var resTable = '<table style="background-color: #EFF3FB;">';
            var parntInc = 0;
            $.each(tabDetails, function (indexPrnt, parentDetails) {
                if ($.type(parentDetails) == 'object') {
                    parntInc++;
                    var childInc = 0;
                    //Thead
                    if (parentDetails.TCH_INCRIMENTAL) {
                        resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='2'>" + parentDetails.TCH_CHECK_POINT + "</th><th><a style='width:10%' href='javascript:void(0)' class='addMore' ><img onclick='addmoreRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Add More\" src=\"images/add1.png\"></a><a style='width:20%;display:none' href='javascript:void(0)' class='removeRr' ><img onclick='removeRow(this,\"addmoreTr" + parentDetails.TCH_CHK_ID + "\")' style='height:20px' title=\"Remove Last Row\" src=\"images/delete1.png\"></a></th></tr></thead>";
                        resTable += "<tbody><tr class='trid" + parentDetails.TCH_CHK_ID + "' id='addmoreTr" + parentDetails.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + '.1</td><td><input style="width:30%" placeholder="Parameters" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                        if (parentDetails.TCH_DATA_TYPE == 'file') {
                            resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + parentDetails.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                            txtRemark = '';
                        } else {
                            resTable += '<td><input style="width:80%" placeholder="Value" type="text" name="checkPDI_' + parentDetails.TCH_CHK_ID + '" checklist_id="' + parentDetails.TCH_CHK_ID + '"  id="checkPDI' + (indexPrnt + 1) + '" class="checkpdiInpt" ></td>';
                            txtRemark = '<textarea maxlength="1900" id="remarkBox_' + parentDetails.TCH_CHK_ID + '" rows="2" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                        }
                        resTable += '<td>' + txtRemark + '</td>';
                        resTable += "</tr></tbody>";
                    } else {
                        resTable += "<thead><tr><th style='width:2%'>" + parntInc + "</th><th colspan='3'>" + parentDetails.TCH_CHECK_POINT + "</th></tr></thead>";
                    }
                    //Tbody
                    $.each(parentDetails, function (index, childArr) {
                        childInc++;
                        if ($.type(childArr) == 'object') {
                            txtRemark = '<textarea maxlength="1900" rows="2" id="remarkBox_' + childArr.TCH_CHK_ID + '" class="txtFieldTextBox" style="word-wrap: break-word;width:95%" placeholder="Remarks"></textarea>';
                            resTable += "<tbody><tr id='trid" + childArr.TCH_CHK_ID + "' class='trid" + childArr.TCH_CHK_ID + "'><td style='width:2%'>" + parntInc + "." + childInc + "</td><td>" + childArr.TCH_CHECK_POINT + "</td>";

                            if (childArr.TCH_DATA_TYPE == 'text' || childArr.TCH_DATA_TYPE == 'date') {
                                resTable += '<td><input type="text" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + (index + 1) + '" class="checkpdiInpt" ></td>';
                            } else if (childArr.TCH_DATA_TYPE == 'radio') {
                                $setValArr = childArr.TCH_VALUE_SET.split("##");
                                resTable += '<td>';
                                $setValArr.forEach(function ($value, $key) {
                                    $colr = $value == "OK" ? "#5E9C00" : ($value == "NOT OK" ? "#ff0000" : "#0000ff");
                                    resTable += '<label for="checkPDI' + ($key + 1) + '" id="lblPDI' + ($key + 1) + '" ><input type="radio" name="checkPDI_' + childArr.TCH_CHK_ID + '" checklist_id="' + childArr.TCH_CHK_ID + '"  id="checkPDI' + ($key + 1) + '"  value="' + $value + '" class="checkpdiInpt"><b style="color:' + $colr + ';">' + $value + '<b></label>';
                                });
                                resTable += '</td>';
                            } else if (childArr.TCH_DATA_TYPE == 'file') {
                                resTable += '<td><input type="button" name="upload" id="btnPhographs"  onClick= "uploadFile(this,' + childArr.TCH_CHK_ID + ');" width="150Px"  value="Upload File"/></td>';
                                txtRemark = '';
                            }

                            resTable += '<td>' + txtRemark + '</td>';
                            resTable += "</tr></tbody>";
                        }
                    })
                }
            })
            resTable += "</table>";
//              console.log(resTable);
            $('#tabMenuVHO').tabs('add', {
                title: indexTab,
                content: resTable,
                closable: false
            });
            if (!$.isEmptyObject(data.AJAXCHASSISDTLS)) {
                $("#ajaxChassisNo").html(data.AJAXCHASSISDTLS.CHASSSISNO);
                $("#ajaxModelNo").html(data.AJAXCHASSISDTLS.TCD_MODEL);
                $("#ajaxProtoType").html(data.AJAXCHASSISDTLS.TCD_PROTO_NO);
                $("#ajaxWBSNo").html(data.AJAXCHASSISDTLS.TCD_WBS_LIST);
                $("#ajaxProjCode").html(data.AJAXCHASSISDTLS.TCD_PROJ_CODE);
                $("#ajaxVCNo").html(data.AJAXCHASSISDTLS.TCD_VC_NO);
                $("#ajaxChassisInfoTbl").show();
            }
            if (!$.isEmptyObject(data.AJAXFIRDTLS)) {
                $("#ajaxSLNo").html(1);
                $("#ajaxFileName").html(data.AJAXFIRDTLS.TEU_FILE_NAME);
                $("#ajaxType").html(data.AJAXFIRDTLS.TEU_ULD_TYPE);
                var actStr = '<div class="ajax-file-upload-red" onclick="deleteFir(' + '\'' + data.AJAXFIRDTLS.TEU_CHASSIS_NO + '\'' + ',' + '\'' + data.AJAXFIRDTLS.TEU_FILE_NAME + '\'' + ',' + '\'' + data.AJAXFIRDTLS.TEU_SL_NO + '\'' + ')">Delete</div>';
                actStr += '<div class="ajax-file-upload-green"><a href="' + data.AJAXFIRDTLS.TEU_FILE_PATH + '" style="color:#fff;text-decoration: none;" target="_blank">View</a></div>';
                $("#ajaxAct").html(actStr);
                $("#ajaxFirInfoTbl").show();
            }
            if ($.isEmptyObject(data.AJAXFIRDTLS)) {
                $("#ajaxFirInfoTbl").hide();
            }
        })

        if (!$.isEmptyObject(data.checkpointValue)) {
            $('#txtModelNo').val(data.checkpointValue[0].TLD_MODEL_NO).attr('disabled', 'disabled');
            $('#txtProtoType').val(data.checkpointValue[0].TLD_PROTO_TYPE).attr('disabled', 'disabled');
            $('#txtEngineNo').val(data.checkpointValue[0].TLD_ENGINE_NO).attr('disabled', 'disabled');
            $('#txtProjNo').val(data.checkpointValue[0].TLD_PROJECT_NAME).attr('disabled', 'disabled');
            $('#txtWBSNo').val(data.checkpointValue[0].TLD_WBS_NO).attr('disabled', 'disabled');
            $.each(data.checkpointValue, function (chkKey, chkVal) {
                $('input[type="text"][name="checkPDI_' + chkVal.TCD_CHK_ID + '"]').val(chkVal.TCD_VALUE);
                $('input[name="checkPDI_' + chkVal.TCD_CHK_ID + '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
                $("#remarkBox_" + chkVal.TCD_CHK_ID).val(chkVal.TCD_REMARKS);
            })
        }
        if (!$.isEmptyObject(data.LASTCOMMENT)) {
            $("#last_comment").val(data.LASTCOMMENT.REMARK);
            $("#pendUserName").html(data.LASTCOMMENT.PENDUSERNAME);
        } else {
            $(".hideLastComent").hide();
            $("#current_comment").css('width', '50%');
        }
        $("#tabMenuVHO").tabs('select', 0);
        $('#tabMenuVHO').find('input, textarea, button, select').attr('disabled', 'disabled');

    })
    $("#checklistFormBtn").show();
}

function pdiApproved(ptype) {
    if (ptype == 'approved') {
        if (!$("#firUploadDco").val()) {
            var confrmMsg = 'Are you sure want to approve this PDI without FIR upload?';
        } else {
            var confrmMsg = 'Are you sure want to approve this PDI?';
        }

    } else {
        if (!$("#current_comment").val()) {
            alert('Please enter comment for rejection!');
            return false;
        }
        var confrmMsg = 'Are you sure want to reject this PDI?';
    }
    var confBox = confirm(confrmMsg);
    if (confBox) {
        $("#pdiAprove").ajaxSubmit({
            data: {
                processType: ptype,
                chassisNo: $("#ddlChassis").val(),
                currComment: $("#current_comment").val()
            },
            success: function (response, status, xh) {
                alert(response);
                openUrl(wwwRoot + "process/pdiApproval.php?menuid=24");
            }
        });
    }
}

function deleteFir(chassisNo, fileName, slNo) {
    var confBox = confirm('Are you sure want to delete the fir file?');
    if (confBox) {
        $.post(url, {action: "deleteFir", chassisNo: chassisNo, fileName: fileName, slNo: slNo}, function () {
        }).done(function (data) {
            if (data) {
                $("#ajaxFirInfoTbl").hide();
                alert('FIR file deleted successfully.');
            }
        })
    }
}
</script>