<script type="text/javascript" src="js/jquery.form.js"></script>
<script>
    $(document).ready(function ($) {

        $('#FileUploader').on('submit', function (e)
        {
            e.preventDefault();
            if ($("#mFile").val() == '')
            {
                alert('Please select image ');
                return false;
            }
            if ($('#uploadFileTitle').val() == "")
            {
                alert("Please enter Description");
                return false;
            }
            var ext = $('#mFile').val().split('.').pop().toLowerCase();
            if ($.inArray(ext, ['jpg', 'png', 'bmp', 'gif']) == -1)
            {
                alert('Sorry, Only jpg,png,bmp and gif formats are supported');
                return false;
            }
            $('#uploadButton').attr('disabled', ''); // disable upload button
            $("#output").html('<div style="padding:10px"><img src="images/spinner3.gif" alt="Please Wait"/> <span>Uploading...</span></div>');
            $(this).ajaxSubmit({
                success: afterSuccess //call function after success
            });
        });
    });

    function afterSuccess(response, status, xh) {
        $('#FileUploader').resetForm();  // reset form
        $('#uploadButton').removeAttr('disabled'); //enable submit button
        $(".uploadTrCrnt").after(response).removeClass('uploadTrCrnt');
        $('#dd').dialog('close');
    }

</script>
<div id="UploadForm">
    <div id="output"></div>
    <form id="FileUploader"  enctype="multipart/form-data" action="process/upload_photo_action.php" method="post" >
      <!--<div style="position:relative; float:right; margin-top:-15px; margin-right:-10px;"><a id="btnClose" href="#" ><img src="images/winclose.png" width="20" height="20" title="Close" /></a></div>-->
        <table width="100%">
            <tr>
                <td><span class="mandatory">*</span>Description</td><td><textarea name="uploadFileTitle" id="uploadFileTitle"  style="width:90%" ></textarea></td>
            </tr>
            <tr>
                <td>File</td><td><input type="file" name="mFile" id="mFile"  style="width:90%" /></td>
            </tr>
            <tr>
                <td colspan="2" align="center"> <button type="submit" class="blue-button" id="uploadButton">Upload</button></td>
            </tr>

        </table>


        <input type="hidden" name="hidecheckID" id="hidecheckID"  value="<?php echo $_REQUEST['checkID']; ?>" />
        <input type="hidden" name="hidechassisNo" id="hidechassisNo"  value="<?php echo $_REQUEST['chassisNo']; ?>" />
        <div class="spacer"></div>
    </form>
</div>