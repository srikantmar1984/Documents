<?php

###########################################################################################
###################### HTML Table for Team Status Start ################################
###########################################################################################   


$sql = "SELECT  
            TEU_FILE_NAME DOCNM,TEU_ULD_TYPE DOCTYP, TEU_FILE_PATH LINK
        FROM T_VHS_EXT_UPLOAD
        WHERE TEU_CHASSIS_NO = '{$_REQUEST['chassisNo']}' AND TEU_ACT_FLG = 1";


$obj = new db_connect;
$obj->db_query($sql);
$statusDetails = array();
while ($row = $obj->db_fetch_arrayAssoc()) {
    $statusDetails[] = $row;
}
$docstatusHtml = '<div class="kks-panel" title="Document Details" data-options="collapsible:true,collapsed:true"> 
    <div class="Grid">
        <table cellpadding="0" cellspacing="0" id="tblDOCStatus">
            <thead>
                <tr>
                    <th>Document type</th>
                    <th>Document Name</th>
                    <th>Link</th>
                </tr>
            </thead>
            <tbody>';
?>
<?php

foreach ($statusDetails as $key => $value) {
    $docstatusHtml .= '<tr>
                            <td>'.$value['DOCTYP'].'</td>
                            <td>'.$value['DOCNM'].'</td>
                            <td><a href="'.$value['LINK'].'" style="color:#00f;text-decoration: none;" target="_blank">View</a> </td>                                    
                        </tr>';
}
$docstatusHtml .= '</tbody></table>';
$docstatusHtml .= ' </div></div>';

###########################################################################################
###################### HTML Table for Team  Status End ##################################
########################################################################################### 
?>