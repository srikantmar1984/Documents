<?php
include_once('./process_common_class.php');
date_default_timezone_set("Asia/Calcutta");

if (isset($_REQUEST['action'])) {
    if (($_REQUEST['action'] == 'JIDETAILS')) {
        echo json_encode(jiSignOff());
    }
}

function jiSignOff() {
    $sql = "Select 
                TCH_CHK_ID,
                TCH_CHECK_POINT,
                TCH_ACT_FLG,
                TCH_DATA_TYPE,
                TCH_PARENT_ID,
                TCH_VALUE_SET,
                TCH_INCRIMENTAL
            FROM 
                T_VHS_CHECK_HEAD
            WHERE
                TCH_TAB_ID = 427
                AND TCH_ACT_FLG = 1
                ORDER BY TCH_CHK_ID ASC ";
    $obj = new db_connect;
    $obj->db_query($sql);
    $resTable = '';
    $returnArr = array();
    while ($row = $obj->db_fetch_arrayAssoc()) {
        if(!$row['TCH_PARENT_ID'])
        $returnArr[$row['TCH_CHK_ID']] = $row;
        else
            $returnArr[$row['TCH_PARENT_ID']][]=$row;
    }
    $obj->free();
//    print_r($returnArr1);exit;
//    print_r($returnArr);exit;
    return $returnArr;
}
?>