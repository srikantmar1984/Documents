<?php include("./process_common_class.php"); ?>
<style>
    .section, .filter 
    {
        color: #003366;
        font-family: Verdana;
        font-size: 8Pt;
        font-weight: normal;
    } 

    .section  table
    {
        width:100%;	
        border-spacing:1px;
    }
    .section > table > tbody > tr , .trheader
    {
        height:22px;
        background-color: #EFF3FB;	
        text-align: left;
    }
    .section > table > tbody > tr:first-child, .trheader
    {		
        text-align: left;	
    }
    .section > table > tbody > tr:first-child > td , .trheader>td
    {	
        background-color: #FFFFE6; 	
    }
    .section > table > tbody > tr:first-child > td:first-child , .trheader>td:first-child
    {	
        padding-left:10px;	
    }
    .section > table > tbody > tr:first-child > td:first-child > span:first-child, .trheader>td:first-child>span:first-child
    {	
        color: #663300;
        font-family: Arial, Sans-Serif;
        font-size: 8Pt;
        font-weight: bold;
        text-decoration: underline;
    }

    .section textarea
    {
        resize:none;
        width:98%;	
    }
    .section input[type="text"]
    {
        width:98%;
    }
    .section select
    {
        width:98%;
    }
    .filter > table ,.section > table
    {	
        width:100%;	
    }
    .filter > table > tbody > tr , .section > table > tbody > tr
    {
        height:24px;
        background-color: #EFF3FB;	
        text-align: left;
    }
    .trheader > td , .section > table > tbody > tr:first-child
    {	
        background-color: #FFFFE6; 	
        text-align: left;	
    }

    .trheader > td span
    {
        color: #003366;
        font-family: Verdana;
        font-size: 8Pt;
        font-weight: normal;	
    }

    .trheader > td:first-child + td > span  
    {
        width:13%;
        display:inline-block;	
    }
    .trheader > td:first-child + td > span  > span
    {
        font-weight:bold;
    }
    .trheader > td:first-child , .section > table > tbody > tr:first-child > td:first-child
    {	
        text-align: left;	
        padding-left:10px;	
    }
    .trheader > td:first-child > span:first-child , .section > table > tbody > tr:first-child > td:first-child > span:first-child
    {	
        color: #663300;
        font-family: Arial, Sans-Serif;
        font-size: 8Pt;
        font-weight: bold;
        text-decoration: underline;
    }

    .filter textarea , .section textarea
    {
        resize:none;
        width:99%;	
    }
    .filter input[type="text"] , .section input[type="text"]
    {
        width:98%;
    }
    .filter select , .section select
    {
        width:98%;
    }

    .tdcap
    {
        text-align:left;
        vertical-align:middle;
        padding-left:5px;	
    }
    .tdcap > span:first-child
    {
        color: #003366;
        font-family: Verdana;
        font-size: 8Pt;
        font-weight: normal;
    } 
    .tdfield
    {
        text-align:left;
        padding-left:5px;	
        padding-right:5px;	
    }

    .gridheader th
    {
        color:white;	
        font-weight:bold;	
        background-color:#507CD1 !important;
        background-image: none !important;	
    }

    .gridrow td
    {
        background-color:#EFF3FB !important;
    }


    #display_content{
        height:100%;
        width:100%;
    }


    /*----- Tabs -----*/

    .mytabs 
    {
        margin:0;
        padding:0;
        width:100%;	
    }

    /*----- Tabs Tables Head and Rows */

    .mytabs table.tbldata
    {
        width:100%;
        color: #003366;
        font-family: Verdana;
        font-size: 8Pt;	
        /*//border:solid 1px #cccccc;*/	
    }
    .mytabs table.tbldata tbody>tr
    {
        height:22px;			
    }
    .mytabs table.tbldata tbody .trhead
    {
        height:24px;			
    }
    .mytabs table.tbldata tbody .trhead>td
    {	
        color:white;	
        /*//font-weight:bold;*/
        background-color:#507CD1;
        padding-left:5px;
    }
    .mytabs table.tbldata tbody .trsubhead>td
    {	
        background-color:#D1E3FA;	
        padding-left:5px;
    }
    .mytabs table.tbldata tbody .trsubsubhead>td
    {	
        background-color: #EFF3FB;;	
        padding-left:5px;
    }
    .mytabs table.tbldata tbody>tr>td
    {
        border-bottom:solid 1px #cccccc;		
    }
    .mytabs table.tbldata tbody>tr>td>p
    {
        margin-top:0px;		
        margin-bottom:0px;		
        line-height:18px;
    }

    .mytabs table.tbldata tbody>tr:last>td
    {
        border-bottom:none;
    }
    /*----- Tab Links -----*/

    /* Clearfix */

    .tab-links:after 
    {
        display:block;
        clear:both;
        content:'';
    }

    .tab-links
    {
        padding:0px 2px;
        margin:5px 0px 4px 0px;
    }
    .tab-links li 
    {
        margin:0px 1px;
        float:left;
        list-style:none;		
    }

    .tab-links a.istab, a.isclose 
    {
        padding:5px 5px;
        background:#DBDCE6;
        color: #003366;
        font-family: Verdana;
        font-size: 8Pt;
        font-weight: normal;
        text-decoration:none;		
    }
    .tab-links a.istab
    {
        border-top:1px solid #ccc;
        border-left:1px solid #ccc;
    }

    .tab-links a.isclose
    {	
        border-top:1px solid #ccc;
        border-right:1px solid #ccc;
    }

    .tab-links a:hover 
    {
        color:#E26140;	
        text-decoration:none;
    }

    .mytabs li.active a, li.active a:hover 
    {
        background:#fff;
        color:#4c4c4c;	
        font-weight:bold;
    }

    /*----- Content of Tabs -----*/

    .tab-content 
    {
        background:#fff;
        padding:5px;
        border:1px solid #ccc;
    }

    .tab 
    {
        display:none;
    }

    .tab.active 
    {
        display:block;
    }
</style>
<input type="hidden" id="hfPageTitle" value="View Details" screen_id="">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<div id="tabFilter" class="kks-tabs"  data-options="border:false" >
    <div title="Search" data-options="iconCls:'icon-search'" >				
        <form id="frmfilter" >
            <div id="filterid" style="height: 80px">
                <div class="filter filterhead">								
                    <table width="100%"  cellpadding="1" cellspacing="1">
                        <tr class="trheader">		
                            <td colspan="5">
                                <span>Search Criteria</span>					
                            </td>
                            <td style="text-align:right;padding-right:5px;">
                                <a href="javascript:void(0)" class="toggleExpand" onclick="toggleExpand(this);" ><img src="./images/collapse.jpg" alt="expand/collapse" /></a>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="filter filterrow">			
                    <table width="100%"  cellpadding="1" cellspacing="1">				
                        <tr>		
                            <td class="tdcap" style="width:15%;">
                                <span>Chassis No. </span>
                            </td>
                            <td class="tdfield" style="width:20%;">                                
                                <select id="ddlFilterChassisNo" class="ddlFieldDropdown">
                                    <option value="">All</option>
                                    <?php
                                    $chassisDtlArr = $process->fillAllChassis();
                                    foreach ($chassisDtlArr as $value) {
                                        echo '<option value="' . $value['CHASSSISNO'] . '" >' . $value['CHASSSISNO'] . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                            <td class="tdcap" style="width:10%;">
                                <span>Status </span>
                            </td>
                            <td class="tdfield" style="width:20%;">
                                <select id="ddlFilterStatus" class="ddlFieldDropdown">
                                    <option value="">All</option>
                                    <?php
                                    $statusArr = $process->fillAllStatus();
                                    foreach ($statusArr as $value) {
                                        echo '<option value="' . $value['STATEID'] . '" >' . $value['STATENAME'] . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                            <td class="tdcap" style="width:15%;">
                                <span>Logged Date</span>                                    
                            </td>
                            <td class="tdfield">
                                <input type="text" id="txtFilterLoggedFrom" class="datepicker txtFieldTextBox" style="width:46%" >
                                <input type="text" id="txtFilterLoggedTo" class="datepicker txtFieldTextBox" style="width:46%" >
                            </td>
                        </tr>
                        <tr>		
                            <td colspan="6">
                                <input type="reset" value="Clear All" id="cmdClearAll" class="button">
                                &nbsp;
                                <input type="button" value="Search" id="cmdSearch" class="button">
                                &nbsp;
                            </td>

                        </tr>				
                    </table> 
                </div>
            </div>			
            <div id="resultid" style="overflow:auto;display:none;">
                <div class="Grid">
                    <table id="tblViewData" cellpadding="0" cellspacing="0" style="table-layout: fixed; ">
                        <thead>
                            <tr class="gridheader">
                                <th width="100px" data-prefid="1">Chassis No.</th>
                                <th width="100px" data-prefid="1">Pending With User</th>
                                <th width="70px"  data-prefid="8">Log Date</th>				
                                <th width="70px"  data-prefid="8">Current Status</th>				
                                <th width="50px"  data-prefid="2">Model No.</th>
                                <th width="100px"  data-prefid="3">Proto Type</th>
                                <th width="50px"  data-prefid="4">Engine No.</th>
                                <th width="155px"  data-prefid="5">WBS No.</th>
                                <th width="150px"  data-prefid="6">Project Name</th>
                                <th width="70px"  data-prefid="7">Budget Code</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </form>
    </div>
</div>

<script language="javascript">
    var url = wwwRoot + "process/view_details_action.php";
    $(function () {

        $('.layout-button-left').trigger('click');
        $('.datepicker').datepick({showOnFocus: true, dateFormat: 'dd-M-yyyy'});

        $('#cmdClearAll').die('click').live('click', function () {
            $('#resultid').css('display', 'none');
            $('#lblFilterSumRecords').html('0');
            $('#lblFilterSumContacts').html('0');
            $('#lblFilterSumObservations').html('0');
            $('#lblFilterSumSA').html('0');
            $('#lblFilterSumSC').html('0');
            $('#lblFilterSumUA').html('0');
            $('#lblFilterSumUC').html('0');
        });

        $('#cmdSearch').die('click').live('click', function () {
            var chassisNo = $("#ddlFilterChassisNo").val();
            var stateId = $("#ddlFilterStatus").val();
            var fromDate = $("#txtFilterLoggedFrom").val().trim();
            var toDate = $("#txtFilterLoggedTo").val().trim();
            $.post(url, {chassisNo: chassisNo, stateId: stateId, fromDate: fromDate, toDate: toDate, action: 'searchViewDetail'}, function () {
            }, 'JSON').done(function (data) {
                if (!$.isEmptyObject(data)) {
                    var tableStr = "";
                    $.each(data, function (indexTab, logDetails) {
                        if (logDetails.PENDUSER == '()') {
                            logDetails.PENDUSER = '';
                        }
                        tableStr += '<tr class="gridrow">';
                        tableStr += '<td data-prefid="1"><a href="javascript:void(0);" style="font-weight:bold;" title="Log Details" onclick=show_data("' + logDetails.TLD_LOG_NO + '","' + logDetails.TLD_LOG_NO + '","' + logDetails.TLD_LOG_NO + '")>' + logDetails.TLD_LOG_NO + '</a></td>';
                        tableStr += '<td data-prefid="2">' + logDetails.PENDUSER + '</td>';
                        tableStr += '<td data-prefid="9">' + logDetails.TLD_CRT_TS + '</td>';
                        tableStr += '<td data-prefid="9">' + logDetails.TSH_STATE_NAME + '</td>';
                        tableStr += '<td data-prefid="2">' + logDetails.MODEL + '</td>';
                        tableStr += '<td data-prefid="3">' + logDetails.PROTO_NO + '</td>';
                        tableStr += '<td data-prefid="4">' + logDetails.TLD_ENGINE_NO + '</td>';
                        tableStr += '<td data-prefid="6">' + logDetails.WBS_LIST + '</td>';
                        tableStr += '<td data-prefid="7">' + logDetails.PROJ + '</td>';
                        tableStr += '<td data-prefid="8">' + logDetails.TLD_BUGET_CODE + '</td>';
                        tableStr += '</tr>';
                        $('#resultid').show();
                    })
                    $('#tblViewData tbody').html(tableStr);
                } else {
                    alert("No records found !");
                    $('#resultid').hide();
                }
            })
        });

        var heightid = $('#display_content').height() - $('#filterid').height() - 29;
        $("#resultid").height(heightid);
        resizeObsDiv();

        $('div.panel-header').mouseleave(function () {
            resizeObsDiv();
        });

        $('div.layout-panel').mouseenter(function () {
            resizeObsDiv();
        });

        $('#tabFilter .tabs').die('click').live('click', function () {
            resizeObsDiv();
        });

        $('.contactexpand').die('click').live('click', function () {
            if ($(this).hasClass("toggleExpand")) {
                $(this).removeClass("toggleExpand");
                $(this).addClass("toggleCollapse");
                var src = $(this).find("img").attr("src");
                src = src.replace("collapse", "expand");
                $(this).find("img").attr("src", src);
                $(this).closest("tr").next().hide();
            } else {
                $(this).removeClass("toggleCollapse");
                $(this).addClass("toggleExpand");
                var src = $(this).find("img").attr("src");
                src = src.replace("expand", "collapse");
                $(this).find("img").attr("src", src);
                $(this).closest("tr").next().show();
            }
        });
    });

    function resizeObsDiv() {
        if ($('#hfPageTitle').attr("screen_id") == "viewobservations_aspx") {
            $('#tabFilter').width($('#display_content').width());
            $('#tabFilter .tabs-header').width($('#display_content').width());
            $('#tabFilter .tabs-wrap').width($('#display_content').width());
            $('#tabFilter .tabs-panels').width($('#display_content').width());
            $('#tabFilter .panel').width($('#display_content').width());
            $('#tabFilter .panel-body').width($('#display_content').width());
            $('.obs td>div').width($('#display_content').width() - 18);
        }
    }

    function toggleExpand(objthis) {
        if ($(objthis).hasClass("toggleExpand")) {
            $(objthis).removeClass("toggleExpand");
            $(objthis).addClass("toggleCollapse");
            var src = $(objthis).find("img").attr("src");
            src = src.replace("collapse", "expand");
            $(objthis).find("img").attr("src", src);

            resizeObsDiv();
            $('div[class~="filterrow"]').slideToggle("fast", function () {
                $('#filterid').height('52px');
                var heightid = $('#display_content').height() - $('#filterid').height() - 29;
                $("#resultid").height(heightid);

            });
        } else {
            $(objthis).removeClass("toggleCollapse");
            $(objthis).addClass("toggleExpand");
            var src = $(objthis).find("img").attr("src");
            src = src.replace("expand", "collapse");
            $(objthis).find("img").attr("src", src);
            $('#filterid').height('80px');
            var heightid = $('#display_content').height() - $('#filterid').height() - 29;
            $("#resultid").height(heightid);
            $('div[class~="filterrow"]').slideToggle("fast");
            resizeObsDiv();

        }
    }

    function show_data(logno) {
        $.post(url, {chassisNo: logno, action: 'satusDetail'}, function () {
        }, 'JSON').done(function (data) {
            if ($('#tabFilter').tabs('exists', 'Details')) {
                $('#tabFilter').tabs('close', 1);
            }

            $('#tabFilter').tabs('add', {title: 'Details', iconCls: 'icon-view', content: data.HTMLCONT, closable: true});
            resizeObsDiv();
            if (!$.isEmptyObject(data.FILLDATA)) {
                $.each(data.FILLDATA, function (chkKey, chkVal) {
                    if (typeof chkVal[0] != 'undefined') {
                        var checkIdCrnt = chkVal[0].TJD_CHK_ID;
                        if (chkVal.length > 1) {
                            for (i = 0; i < chkVal.length; i++) {
                                i > 0 ? addmoreRow("#addmoreTr" + chkKey, "addmoreTr" + chkKey) : '';
                            }
                            for (i = 0; i < chkVal.length; i++) {
                                var vehParms = chkVal[i].TJD_VEH_PARAM.split('###');
                                $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('.addMoreParam').val(vehParms[0]);
                                $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('.vehicleParam').val(vehParms[1]);
                                $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find('input[checklist_id="' + chkKey + '"][value="' + chkVal[i].TJD_VALUE + '"]').prop('checked', true);
                                $("#addmoreTr" + chkKey).parent().find("tr").eq(i).find("#remarkBox_" + chkKey).val(chkVal[i].TJD_REMARKS);
                            }
                        } else {
                            if (chkVal[0].TJD_VEH_PARAM) {
                                var vehParms = chkVal[0].TJD_VEH_PARAM.split('###');
                                $(".trid" + chkKey).find('.addMoreParam').val(vehParms[0]);
                                $(".trid" + chkKey).find('.vehicleParam').val(vehParms[1]);
                            }
                            $('input[name="checkPDI_' + chkKey + '"][value="' + chkVal[0].TJD_VALUE + '"]').prop('checked', true);
                            $("#remarkBox_" + chkKey).val(chkVal[0].TJD_REMARKS);
                        }
                        //Image file Loading
                        $.each(chkVal[0], function (keyFile, childFile) {
                            if ($.type(childFile) == 'object') {
                                var imgTr = '<tr class="addMorePhotoTr" style="background-color:#FFFFFF"><td></td>';
                                imgTr += '<td><img style="height:119Px;width:200Px;" src="' + wwwRoot + childFile.TFD_FILE_PATH + '"></td>';
                                imgTr += '<td><input type="hidden" style="width:80%" value="' + childFile.TFD_FILE_TITLE + '" checklist_id="' + checkIdCrnt + '" class="photoName"><textarea maxlength="1900" rows="2" class="photoDesc" style="word-wrap: break-word;width:95%" placeholder="Photo Description">' + childFile.TFD_FILE_DESC + '</textarea></td>';
                                imgTr += '<td colspan="2"><a href="javascript:void(0);" class="statusChange" id="btnDeactFile">Delete Image</a></td>';
                                imgTr += '</tr>';
                                $(".trid" + checkIdCrnt).after(imgTr);
                            }
                        })
                    } else {
                        $('input[type="text"][name="checkPDI_' + chkVal.TCD_CHK_ID + '"]').val(chkVal.TCD_VALUE);
                        $('input[name="checkPDI_' + chkVal.TCD_CHK_ID + '"][value="' + chkVal.TCD_VALUE + '"]').prop('checked', true);
                        $("#remarkBox_" + chkVal.TCD_CHK_ID).val(chkVal.TCD_REMARKS);
                    }
                })
            }
            $('#details_div').find('input, textarea, button, select').attr('disabled', 'disabled');
        });
    }

</script>