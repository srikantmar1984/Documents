<div class="kks-panel" title="Chassis Info" data-options="collapsible:true"> 
    <!--<div class="kks-panel" title="Chassis Info" data-options="collapsible:true,collapsed:true">--> 
    <div class="Grid"> 

        <table id="ajaxChassisInfoTbl" cellpadding="0" cellspacing="0" style="display: none">
            <thead>
                <tr>
                    <th width="5%">Chassis No</th>
                    <th width="15%">Model No</th>
                    <th width="15%">Proto Type</th>
                    <th width="15%">WBS No</th>
                    <th width="15%">Project Code</th>
                    <th width="15%">VC No</th>                                                        
                </tr>
            </thead>
            <tbody>
                <tr class="trAdd editTblTR" style="background-color: rgb(247, 246, 243); font-weight: bolder;">
                    <td id="ajaxChassisNo"></td>
                    <td id="ajaxModelNo"></td>
                    <td id="ajaxProtoType"></td>
                    <td id="ajaxWBSNo"></td>
                    <td id="ajaxProjCode"></td>
                    <td id="ajaxVCNo"></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>