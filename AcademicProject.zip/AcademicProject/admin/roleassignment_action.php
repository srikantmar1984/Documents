<?php

$ref = 'on';
include("../db_classes/commanvar.php");
include("../db_classes/class.db.php");
date_default_timezone_set("Asia/Calcutta");

if ($_REQUEST['act'] == 'Ajax') {

    if ($_SESSION['Org'] == $_REQUEST['org'] && $_SESSION['Unit'] == $_REQUEST['vunit'] && $_SESSION['Locn'] == $_REQUEST['locn']) {

        $strSql = "SELECT ";
        $strSql .= "   A.ScreenID ";
        $strSql .= " , A.ScreenName ";
        $strSql .= " , A.ScreenAppName ";
        $strSql .= " , NVL(B.tra_acc_level,0) AccessPrivilege ";
        $strSql .= " FROM ";
        $strSql .= "     ( ";
        $strSql .= "         SELECT ";
        $strSql .= "               t1.tcr_scr_id ScreenID ";
        $strSql .= "             , t1.tcr_name ScreenName ";
        $strSql .= "             , CASE WHEN LENGTH(t2.tap_sht_name)>0 THEN '('||t2.tap_sht_name||')' ELSE t2.tap_sht_name END ScreenAppName ";
        $strSql .= "         FROM ";
        $strSql .= "               t_sos_screens t1 ";
        $strSql .= "             , t_sos_applications t2 ";
        $strSql .= "         WHERE ";
        $strSql .= "               t1.tcr_act_flg = 'Active' ";
        $strSql .= "             AND t1.tcr_app_id = t2.tap_id(+) ";
        $strSql .= "     ) A ";
        $strSql .= "     , ( ";
        $strSql .= "         SELECT ";
        $strSql .= "               tra_scr_id  ";
        $strSql .= "             , tra_acc_level ";
        $strSql .= "         FROM ";
        $strSql .= "               t_sos_role_assign ";
        $strSql .= "         WHERE ";
        $strSql .= "               tra_org_id = '" . $_SESSION['Org'] . "' ";
        $strSql .= "             AND tra_unit_id = '" . $_SESSION['Unit'] . "' ";
        $strSql .= "             AND tra_locn_id = '" . $_SESSION['Locn'] . "' ";
        $strSql .= "             AND tra_role_id = '" . $_REQUEST['role_id'] . "' ";
        $strSql .= "       ) B ";
        $strSql .= " WHERE ";
        $strSql .= "   A.ScreenID = B.tra_scr_id(+) ";
        $strSql .= " ORDER BY ";
        $strSql .= "   A.ScreenAppName, A.ScreenName ASC";
    } else {
        $strSql = "SELECT ";
        $strSql .= "   A.ScreenID ";
        $strSql .= " , A.ScreenName ";
        $strSql .= " , A.ScreenAppName ";
        $strSql .= " , NVL(B.tra_acc_level,0) AccessPrivilege ";
        $strSql .= " FROM ";
        $strSql .= "     ( ";
        $strSql .= "         SELECT ";
        $strSql .= "               t1.tcr_scr_id ScreenID ";
        $strSql .= "             , t1.tcr_name ScreenName ";
        $strSql .= "             , CASE WHEN LENGTH(t2.tap_sht_name)>0 THEN '('||t2.tap_sht_name||')' ELSE t2.tap_sht_name END ScreenAppName ";
        $strSql .= "         FROM ";
        $strSql .= "               t_sos_screens t1 ";
        $strSql .= "             , t_sos_applications t2 ";
        $strSql .= "         WHERE ";
        $strSql .= "               t1.tcr_act_flg = 'Active' ";
        $strSql .= "             AND t1.tcr_app_id = t2.tap_id(+) ";
        $strSql .= "     ) A ";
        $strSql .= "     , ( ";
        $strSql .= "         SELECT ";
        $strSql .= "               tra_scr_id  ";
        $strSql .= "             , tra_acc_level ";
        $strSql .= "         FROM ";
        $strSql .= "               t_sos_role_assign_oth ";
        $strSql .= "         WHERE ";
        $strSql .= "               tra_org_id = '" . $_SESSION['Org'] . "' ";
        $strSql .= "             AND tra_unit_id = '" . $_SESSION['Unit'] . "' ";
        $strSql .= "             AND tra_locn_id = '" . $_SESSION['Locn'] . "' ";
        $strSql .= "             AND tra_oth_org_id = '" . $_REQUEST['org'] . "' ";
        $strSql .= "             AND tra_oth_unit_id = '" . $_REQUEST['vunit'] . "' ";
        $strSql .= "             AND tra_oth_locn_id = '" . $_REQUEST['locn'] . "' ";
        $strSql .= "             AND tra_role_id = '" . $_REQUEST['role_id'] . "' ";
        $strSql .= "       ) B ";
        $strSql .= " WHERE ";
        $strSql .= "   A.ScreenID = B.tra_scr_id(+) ";
        $strSql .= " ORDER BY ";
        $strSql .= "   A.ScreenAppName, A.ScreenName ASC";
    }
    $obj = new db_connect;
    $obj->db_query($strSql);
    $Screens = '';
    $check1 = "";
    $check2 = "";
    $check3 = "";
    $check4 = "";
    while ($row = $obj->db_fetch_array()) {
        $Screens .= '<tr>
					<td><input id="chkScreenId" type="checkbox" name="ScreenId[]" value="' . $row[0] . '" ></td>
					<td>' . $row[2] . ' ' . $row[1] . '</td>';
        if ($row[3] == 0) {
            $check1 = "checked";
        } else if ($row[3] == 1) {
            $check2 = "checked";
        } else if ($row[3] == 2) {
            $check3 = "checked";
        } else if ($row[3] == 3) {
            $check4 = "checked";
        }
        $Screens .= '<td><input id="accessNone" type="radio" name="access' . $row[0] . '" value="0" ' . $check1 . '>None</td>
                    <td><input id="accessRead" type="radio" name="access' . $row[0] . '" value="1" ' . $check2 . '>Read</td>
                    <td><input id="accessWrite" type="radio" name="access' . $row[0] . '" value="2" ' . $check3 . ' >Write</td>
                    <td><input id="accessFull" type="radio" name="access' . $row[0] . '" value="3" ' . $check4 . ' >Full Access</td>
                    </tr>';
    }
    $obj->free();

    echo $Screens;
}

if ($_REQUEST['act'] == 'Save') {



    /* String strSelRoles = "";
      String strSelScreens = "";

      String strNoneScreens = "";
      String strReadScreens = "";
      String strWriteScreens = "";
      String strFullScreens = "";
      String strAllScreens = "";


      // Check if Role Selected

      for (int intCtr = 0; intCtr < grdRoles.Rows.Count; intCtr++)
      {
      CheckBox chkSelect = (CheckBox)grdRoles.Rows[intCtr].FindControl("chkSelect");
      if (chkSelect.Checked)
      {
      Label lblRoleID = (Label)grdRoles.Rows[intCtr].FindControl("lblRoleID");
      if (strSelRoles.Length > 0)
      {
      strSelRoles += ",";
      }
      strSelRoles += "'" + lblRoleID.Text + "'";
      blnRolesChecked = true;
      }
      }

      if (!blnRolesChecked)
      {
      lblAccessError.Text = "Caution...! Please select one or more Roles.";
      return;
      }


      // Check if Screens Selected


      for (int intCtr = 0; intCtr < grdRoleAssignment.Rows.Count; intCtr++)
      {
      CheckBox chkSelect = (CheckBox)grdRoleAssignment.Rows[intCtr].FindControl("chkSelect");
      if (chkSelect.Checked)
      {
      Label lblScreenID = (Label)grdRoleAssignment.Rows[intCtr].FindControl("lblScreenID");
      if (strSelScreens.Length > 0)
      {
      strSelScreens += ",";
      }
      strSelScreens += "'" + lblScreenID.Text + "'";
      blnScreensChecked = true;
      }
      }

      if (!blnScreensChecked)
      {
      lblAccessError.Text = "Caution...! Please select one or more Screens.";
      return;
      }

      for (int intCtr = 0; intCtr < grdRoleAssignment.Rows.Count; intCtr++)
      {
      CheckBox chkSelect = (CheckBox)grdRoleAssignment.Rows[intCtr].FindControl("chkSelect");
      if (chkSelect.Checked)
      {
      RadioButton rdbNone = (RadioButton)grdRoleAssignment.Rows[intCtr].FindControl("rdbNone");
      RadioButton rdbRead = (RadioButton)grdRoleAssignment.Rows[intCtr].FindControl("rdbRead");
      RadioButton rdbWrite = (RadioButton)grdRoleAssignment.Rows[intCtr].FindControl("rdbWrite");
      RadioButton rdbFullAccess = (RadioButton)grdRoleAssignment.Rows[intCtr].FindControl("rdbFullAccess");
      HiddenField hdnAccessPrivilege = (HiddenField)grdRoleAssignment.Rows[intCtr].FindControl("hdnAccessPrivilege");
      Label lblScreenID = (Label)grdRoleAssignment.Rows[intCtr].FindControl("lblScreenID");

      String strCurrSel = "0";
      if (rdbNone.Checked == true) { strCurrSel = "0"; }
      if (rdbRead.Checked == true) { strCurrSel = "1"; }
      if (rdbWrite.Checked == true) { strCurrSel = "2"; }
      if (rdbFullAccess.Checked == true) { strCurrSel = "3"; }

      switch (strCurrSel)
      {
      case "1":
      if (strReadScreens.Length > 0)
      {
      strReadScreens += ",";
      }
      strReadScreens += "'" + lblScreenID.Text + "'";
      break;
      case "2":
      if (strWriteScreens.Length > 0)
      {
      strWriteScreens += ",";
      }
      strWriteScreens += "'" + lblScreenID.Text + "'";
      break;
      case "3":
      if (strFullScreens.Length > 0)
      {
      strFullScreens += ",";
      }
      strFullScreens += "'" + lblScreenID.Text + "'";
      break;
      default:
      if (strNoneScreens.Length > 0)
      {
      strNoneScreens += ",";
      }
      strNoneScreens += "'" + lblScreenID.Text + "'";
      break;
      }

      if (strAllScreens.Length > 0)
      {
      strAllScreens += ",";
      }
      strAllScreens += "'" + lblScreenID.Text + "'";
      }
      }


      int intError = 0;
      String strRetval = "";


      if ($_SESSION['Org'] == $_REQUEST['org'] && $_SESSION['Unit'] == $_REQUEST['vunit'] && $_SESSION['Locn'] == $_REQUEST['locn'])
      {
      // Update all to 0 level

      $strSql = "UPDATE t_sos_role_assign ";
      $strSql .= " SET ";
      $strSql .= "   tra_acc_level = 0 ";
      $strSql .= " , tra_upd_by = '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , tra_upd_ts = SYSDATE ";
      $strSql .= " WHERE ";
      $strSql .= "   tra_role_id IN (" + strSelRoles + ") ";
      $strSql .= " AND tra_scr_id IN (" + strSelScreens + ") ";
      $strSql .= " AND tra_org_id = '" + lblOrgID.Text + "' ";
      $strSql .= " AND tra_unit_id = '" + lblUnitID.Text + "' ";
      $strSql .= " AND tra_locn_id = '" + lblLocnID.Text + "' ";

      strRetval = objTrans.PutData(strSql, oraTrans);
      if (strRetval.Substring(0, 1) != "0")
      {
      intError++;
      }

      // Insert new screens

      $strSql = "INSERT INTO t_sos_role_assign ";
      $strSql .= " ( ";
      $strSql .= "   tra_role_id ";
      $strSql .= " , tra_scr_id ";
      $strSql .= " , tra_acc_level ";
      $strSql .= " , tra_crt_by ";
      $strSql .= " , tra_crt_ts ";
      $strSql .= " , tra_upd_by ";
      $strSql .= " , tra_upd_ts ";
      $strSql .= " , tra_org_id ";
      $strSql .= " , tra_unit_id ";
      $strSql .= " , tra_locn_id ";
      $strSql .= " ) ";
      $strSql .= " SELECT ";
      $strSql .= "   X.RoleID ";
      $strSql .= " , X.ScreenID ";
      $strSql .= " , 0 ";
      $strSql .= " , '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , SYSDATE ";
      $strSql .= " , '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , SYSDATE ";
      $strSql .= " , '" + lblOrgID.Text + "' ";
      $strSql .= " , '" + lblUnitID.Text + "' ";
      $strSql .= " , '" + lblLocnID.Text + "' ";
      $strSql .= " FROM ";
      $strSql .= "     ( ";
      $strSql .= "         SELECT ";
      $strSql .= "               A.RoleID ";
      $strSql .= "             , C.ScreenID ";
      $strSql .= "         FROM ";
      $strSql .= "               ( SELECT tro_role_id RoleID FROM t_sos_roles WHERE tro_role_id IN (" + strSelRoles + ") ) A ";
      $strSql .= "             , ( SELECT tcr_scr_id ScreenID FROM t_sos_screens WHERE tcr_scr_id IN (" + strAllScreens + ") ) C ";
      $strSql .= "     ) X ";
      $strSql .= "     , ( ";
      $strSql .= "         SELECT ";
      $strSql .= "               tra_role_id RoleID ";
      $strSql .= "             , tra_scr_id ScreenID ";
      $strSql .= "         FROM ";
      $strSql .= "               t_sos_role_assign ";
      $strSql .= "         WHERE ";
      $strSql .= "               tra_org_id = '" + lblOrgID.Text + "' ";
      $strSql .= "             AND tra_unit_id = '" + lblUnitID.Text + "' ";
      $strSql .= "             AND tra_locn_id = '" + lblLocnID.Text + "' ";
      $strSql .= "     ) Y ";
      $strSql .= " WHERE ";
      $strSql .= "   X.RoleID = Y.RoleID (+) ";
      $strSql .= " AND X.ScreenID = Y.ScreenID(+) ";
      $strSql .= " AND CASE NVL(Y.ScreenID,'False') WHEN 'False' THEN 'False' ELSE 'True' END = 'False' ";

      strRetval = objTrans.PutData(strSql, oraTrans);
      if (strRetval.Substring(0, 1) != "0")
      {
      intError++;
      }

      // Update 1

      if (strReadScreens.Length > 0)
      {
      $strSql = "UPDATE t_sos_role_assign ";
      $strSql .= " SET ";
      $strSql .= "   tra_acc_level = 1 ";
      $strSql .= " , tra_upd_by = '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , tra_upd_ts = SYSDATE ";
      $strSql .= " WHERE ";
      $strSql .= "   tra_role_id IN (" + strSelRoles + ") ";
      $strSql .= " AND tra_scr_id IN (" + strReadScreens + ") ";
      $strSql .= " AND tra_org_id = '" + lblOrgID.Text + "' ";
      $strSql .= " AND tra_unit_id = '" + lblUnitID.Text + "' ";
      $strSql .= " AND tra_locn_id = '" + lblLocnID.Text + "' ";

      strRetval = objTrans.PutData(strSql, oraTrans);
      if (strRetval.Substring(0, 1) != "0")
      {
      intError++;
      }
      }

      // Update 2

      if (strWriteScreens.Length > 0)
      {
      $strSql = "UPDATE t_sos_role_assign ";
      $strSql .= " SET ";
      $strSql .= "   tra_acc_level = 2 ";
      $strSql .= " , tra_upd_by = '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , tra_upd_ts = SYSDATE ";
      $strSql .= " WHERE ";
      $strSql .= "   tra_role_id IN (" + strSelRoles + ") ";
      $strSql .= " AND tra_scr_id IN (" + strWriteScreens + ") ";
      $strSql .= " AND tra_org_id = '" + lblOrgID.Text + "' ";
      $strSql .= " AND tra_unit_id = '" + lblUnitID.Text + "' ";
      $strSql .= " AND tra_locn_id = '" + lblLocnID.Text + "' ";

      strRetval = objTrans.PutData(strSql, oraTrans);
      if (strRetval.Substring(0, 1) != "0")
      {
      intError++;
      }
      }


      // Update 3

      if (strFullScreens.Length > 0)
      {
      $strSql = "UPDATE t_sos_role_assign ";
      $strSql .= " SET ";
      $strSql .= "   tra_acc_level = 3 ";
      $strSql .= " , tra_upd_by = '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , tra_upd_ts = SYSDATE ";
      $strSql .= " WHERE ";
      $strSql .= "   tra_role_id IN (" + strSelRoles + ") ";
      $strSql .= " AND tra_scr_id IN (" + strFullScreens + ") ";
      $strSql .= " AND tra_org_id = '" + lblOrgID.Text + "' ";
      $strSql .= " AND tra_unit_id = '" + lblUnitID.Text + "' ";
      $strSql .= " AND tra_locn_id = '" + lblLocnID.Text + "' ";

      strRetval = objTrans.PutData(strSql, oraTrans);
      if (strRetval.Substring(0, 1) != "0")
      {
      intError++;
      }
      }
      }
      else
      {
      // Update all to 0 level

      $strSql = "UPDATE t_sos_role_assign_oth ";
      $strSql .= " SET ";
      $strSql .= "   tra_acc_level = 0 ";
      $strSql .= " , tra_upd_by = '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , tra_upd_ts = SYSDATE ";
      $strSql .= " WHERE ";
      $strSql .= "   tra_role_id IN (" + strSelRoles + ") ";
      $strSql .= " AND tra_scr_id IN (" + strSelScreens + ") ";
      $strSql .= " AND tra_org_id = '" + Session["OrgID"].ToString() + "' ";
      $strSql .= " AND tra_unit_id = '" + Session["UnitID"].ToString() + "' ";
      $strSql .= " AND tra_locn_id = '" + Session["LocnID"].ToString() + "' ";
      $strSql .= " AND tra_oth_org_id = '" + lblOrgID.Text + "' ";
      $strSql .= " AND tra_oth_unit_id = '" + lblUnitID.Text + "' ";
      $strSql .= " AND tra_oth_locn_id = '" + lblLocnID.Text + "' ";

      strRetval = objTrans.PutData(strSql, oraTrans);
      if (strRetval.Substring(0, 1) != "0")
      {
      intError++;
      }

      // Insert new screens

      $strSql = "INSERT INTO t_sos_role_assign_oth ";
      $strSql .= " ( ";
      $strSql .= "   tra_role_id ";
      $strSql .= " , tra_scr_id ";
      $strSql .= " , tra_acc_level ";
      $strSql .= " , tra_crt_by ";
      $strSql .= " , tra_crt_ts ";
      $strSql .= " , tra_upd_by ";
      $strSql .= " , tra_upd_ts ";
      $strSql .= " , tra_org_id ";
      $strSql .= " , tra_unit_id ";
      $strSql .= " , tra_locn_id ";
      $strSql .= " , tra_oth_org_id ";
      $strSql .= " , tra_oth_unit_id ";
      $strSql .= " , tra_oth_locn_id ";
      $strSql .= " ) ";
      $strSql .= " SELECT ";
      $strSql .= "   X.RoleID ";
      $strSql .= " , X.ScreenID ";
      $strSql .= " , 0 ";
      $strSql .= " , '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , SYSDATE ";
      $strSql .= " , '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , SYSDATE ";
      $strSql .= " , '" + Session["OrgID"].ToString() + "' ";
      $strSql .= " , '" + Session["UnitID"].ToString() + "' ";
      $strSql .= " , '" + Session["LocnID"].ToString()  + "' ";
      $strSql .= " , '" + lblOrgID.Text + "' ";
      $strSql .= " , '" + lblUnitID.Text + "' ";
      $strSql .= " , '" + lblLocnID.Text + "' ";
      $strSql .= " FROM ";
      $strSql .= "     ( ";
      $strSql .= "         SELECT ";
      $strSql .= "               A.RoleID ";
      $strSql .= "             , C.ScreenID ";
      $strSql .= "         FROM ";
      $strSql .= "               ( SELECT tro_role_id RoleID FROM t_sos_roles WHERE tro_role_id IN (" + strSelRoles + ") ) A ";
      $strSql .= "             , ( SELECT tcr_scr_id ScreenID FROM t_sos_screens WHERE tcr_scr_id IN (" + strAllScreens + ") ) C ";
      $strSql .= "     ) X ";
      $strSql .= "     , ( ";
      $strSql .= "         SELECT ";
      $strSql .= "               tra_role_id RoleID ";
      $strSql .= "             , tra_scr_id ScreenID ";
      $strSql .= "         FROM ";
      $strSql .= "               t_sos_role_assign_oth ";
      $strSql .= "         WHERE ";
      $strSql .= "               tra_org_id = '" + Session["OrgID"].ToString() + "' ";
      $strSql .= "             AND tra_unit_id = '" + Session["UnitID"].ToString() + "' ";
      $strSql .= "             AND tra_locn_id = '" + Session["LocnID"].ToString() + "' ";
      $strSql .= "             AND tra_oth_org_id = '" + lblOrgID.Text + "' ";
      $strSql .= "             AND tra_oth_unit_id = '" + lblUnitID.Text + "' ";
      $strSql .= "             AND tra_oth_locn_id = '" + lblLocnID.Text + "' ";
      $strSql .= "     ) Y ";
      $strSql .= " WHERE ";
      $strSql .= "   X.RoleID = Y.RoleID (+) ";
      $strSql .= " AND X.ScreenID = Y.ScreenID(+) ";
      $strSql .= " AND CASE NVL(Y.ScreenID,'False') WHEN 'False' THEN 'False' ELSE 'True' END = 'False' ";

      strRetval = objTrans.PutData(strSql, oraTrans);
      if (strRetval.Substring(0, 1) != "0")
      {
      intError++;
      }

      // Update 1

      if (strReadScreens.Length > 0)
      {
      $strSql = "UPDATE t_sos_role_assign_oth ";
      $strSql .= " SET ";
      $strSql .= "   tra_acc_level = 1 ";
      $strSql .= " , tra_upd_by = '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , tra_upd_ts = SYSDATE ";
      $strSql .= " WHERE ";
      $strSql .= "   tra_role_id IN (" + strSelRoles + ") ";
      $strSql .= " AND tra_scr_id IN (" + strReadScreens + ") ";
      $strSql .= " AND tra_org_id = '" + Session["OrgID"].ToString() + "' ";
      $strSql .= " AND tra_unit_id = '" + Session["UnitID"].ToString() + "' ";
      $strSql .= " AND tra_locn_id = '" + Session["LocnID"].ToString() + "' ";
      $strSql .= " AND tra_oth_org_id = '" + lblOrgID.Text + "' ";
      $strSql .= " AND tra_oth_unit_id = '" + lblUnitID.Text + "' ";
      $strSql .= " AND tra_oth_locn_id = '" + lblLocnID.Text + "' ";

      strRetval = objTrans.PutData(strSql, oraTrans);
      if (strRetval.Substring(0, 1) != "0")
      {
      intError++;
      }
      }

      // Update 2

      if (strWriteScreens.Length > 0)
      {
      $strSql = "UPDATE t_sos_role_assign_oth ";
      $strSql .= " SET ";
      $strSql .= "   tra_acc_level = 2 ";
      $strSql .= " , tra_upd_by = '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , tra_upd_ts = SYSDATE ";
      $strSql .= " WHERE ";
      $strSql .= "   tra_role_id IN (" + strSelRoles + ") ";
      $strSql .= " AND tra_scr_id IN (" + strWriteScreens + ") ";
      $strSql .= " AND tra_org_id = '" + Session["OrgID"].ToString() + "' ";
      $strSql .= " AND tra_unit_id = '" + Session["UnitID"].ToString() + "' ";
      $strSql .= " AND tra_locn_id = '" + Session["LocnID"].ToString() + "' ";
      $strSql .= " AND tra_oth_org_id = '" + lblOrgID.Text + "' ";
      $strSql .= " AND tra_oth_unit_id = '" + lblUnitID.Text + "' ";
      $strSql .= " AND tra_oth_locn_id = '" + lblLocnID.Text + "' ";

      strRetval = objTrans.PutData(strSql, oraTrans);
      if (strRetval.Substring(0, 1) != "0")
      {
      intError++;
      }
      }


      // Update 3

      if (strFullScreens.Length > 0)
      {
      $strSql = "UPDATE t_sos_role_assign_oth ";
      $strSql .= " SET ";
      $strSql .= "   tra_acc_level = 3 ";
      $strSql .= " , tra_upd_by = '" + Session["PNo"].ToString() + "' ";
      $strSql .= " , tra_upd_ts = SYSDATE ";
      $strSql .= " WHERE ";
      $strSql .= "   tra_role_id IN (" + strSelRoles + ") ";
      $strSql .= " AND tra_scr_id IN (" + strFullScreens + ") ";
      $strSql .= " AND tra_org_id = '" + Session["OrgID"].ToString() + "' ";
      $strSql .= " AND tra_unit_id = '" + Session["UnitID"].ToString() + "' ";
      $strSql .= " AND tra_locn_id = '" + Session["LocnID"].ToString() + "' ";
      $strSql .= " AND tra_oth_org_id = '" + lblOrgID.Text + "' ";
      $strSql .= " AND tra_oth_unit_id = '" + lblUnitID.Text + "' ";
      $strSql .= " AND tra_oth_locn_id = '" + lblLocnID.Text + "' ";

      strRetval = objTrans.PutData(strSql, oraTrans);
      if (strRetval.Substring(0, 1) != "0")
      {
      intError++;
      }
      }
      }
      }
      catch
      {
      intError++;
      }

      if (intError <= 0)
      {
      objTrans.commitTrans(oraTrans);
      lblAccessError.Text = "Information...! Role Assignment saved successfully.";
      fillScreens();
      }
      else
      {
      objTrans.rollbackTrans(oraTrans);
      lblAccessError.Text = "Warning...! Role Assignment not saved.";
      return;
      }
     */
}
?>