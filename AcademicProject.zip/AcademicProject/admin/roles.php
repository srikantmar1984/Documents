<script type="text/javascript" >
    $(document).ready(function () {
        $("#btnAdd").click(function (event) {
            event.preventDefault();
            validate();
            var RoleName = $("#txtRoleName").val();
            var desc = $("#txtDesc").val();
            var appId = $("#ddlApp").val();
            var appName = $("#ddlApp option:selected").text();
            var status = $("#ddlStatus").val();

            $.post(location.hostname + "/../admin/roles_action.php",
                    {
                        roleName: RoleName,
                        desc: desc,
                        status: status,
                        appId: appId,
                        appName: appName,
                        act: "Add"
                    }, function (data)
            {
                var str = data.indexOf("Error");
                if (str == '-1')
                {
                    $("#res").append(data);
                    var i = 1;
                    $('#res td:nth-child(1)').each(function () {

                        $(this).text(i++);
                    });

                    $("#txtRoleName").val("");
                    $("#txtDesc").val("");
                } else
                {
                    alert('Error During Submit !');
                    hideProgress();
                    exit();
                }
                return false;

            });


        });

        $('#btnEdit').die('click').live('click', function () {
            if ($("#tr_clone").html() != '') {
                alert("Please complete your previous action!");
            } else {
                var parent = $(this).parent().parent();

                //Clone the selected Row
                var clone = parent.clone();
                $("#tr_clone").html(clone);

                var appid = $(this).attr('appId');
                var roleId = $(this).attr('roleId');


                var ch = parent.find("#rolename");
                ch.html('<input id="txtRoleName" type="text" value="' + ch.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');

                var ch2 = parent.find("#desc");
                ch2.html('<input id="txtdes" type="text" value="' + ch2.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');

                var ch3 = parent.find("#appName");
                ch3.html('<select id="ddlEApp" name="ddlEApp" style="width:99%" class="ddlFieldDropdown"></select>');
                //Copy Dropdownlist to another Dwopdownlist
                $('#ddlApp option').clone().appendTo('#ddlEApp');
                $("#ddlEApp").val(appid);

                var ch4 = parent.find("#status");
                var status = (ch4.text() === "Active") ? '<option value="Active" selected="true">Active</option><option value="InActive">InActive</option>' : '<option value="Active">Active</option><option value="InActive" selected="true" >InActive</option>';
                ch4.html('<select id="ddlStatus" name="ddlStatus" style="width:99%" class="ddlFieldDropdown">' + status + '</select>');

                var ch5 = parent.find("#action");
                ch5.html('<a id="btnUpdate" roleId="' + roleId + '" appId="' + appid + '" href="javascript:void(0)"><img src="images/accept.png" title="Update"  /></a> &nbsp; <a id="btnCancel" href="javascript:void(0)"><img src="images/cancel.png" title="Cancel"  /></a>');

            }

        });

        $('#btnUpdate').die('click').live('click', function () {
            var appIdOld = $(this).attr('appId');
            var roleId = $(this).attr('roleId');

            var parent = $(this).parent().parent();

            var RoleName = parent.find("#txtRoleName").val();
            var desc = parent.find("#txtdes").val();
            var appId = parent.find("#ddlEApp").val();
            var appName = parent.find("#ddlEApp option:selected").text();
            var status = parent.find("#ddlStatus").val();

            var ch = parent.find("#rolename");
            var ch2 = parent.find("#desc");
            var ch3 = parent.find("#appName");
            var ch4 = parent.find("#status");
            var ch5 = parent.find("#action");


            $.post(location.hostname + "/../admin/roles_action.php",
                    {
                        roleId: roleId,
                        roleName: RoleName,
                        desc: desc,
                        status: status,
                        appId: appId,
                        appIdOld: appIdOld,
                        appName: appName,
                        act: 'Update'
                    }, function (data)
            {
                var str = data.indexOf("Error");
                if (str == '-1') {
                    alert('change sucessfully');
                    ch.html(RoleName);
                    ch2.html(desc);
                    ch3.html(appName);
                    ch4.html(status);
                    ch5.html('<a  id="btnEdit" roleId="' + roleId + '" appId="' + appId + '" href="javascript:void(0)"><img src="images/edit.png" title="Edit"  /></a>');
                    $("#tr_clone").html('');
                } else {
                    alert('Error During Submit !');
                    hideProgress();
                    exit();
                }
                return false;

            });



        });


        $('#btnCancel').die('click').live('click', function () {

            var parent = $(this).parent().parent();
            var clone = $("#tr_clone").html();
            //Replace <tr> Tag in IE
            clone = clone.replace('<TR>', '');
            clone = clone.replace('</TR>', '');
            parent.html(clone.replace('<tr>', ''));
            $("#tr_clone").html('');

        });


    });

    function clone() {
        $('#ddlApp option').clone().appendTo('#ddlSrcApp');
    }
    function searchData() {
        var RoleName = $("#txtSrcRoleName").val();
        var appId = $("#ddlSrcApp").val();
        var status = $("#ddlSrcStatus").val();

        $.post(location.hostname + "/../admin/roles_action.php",
                {
                    roleName: RoleName,
                    status: status,
                    appId: appId,
                    act: 'Ajax'
                }, function (data)
        {
            var str = data.indexOf("Error");
            if (str == '-1') {
                $("#res").html(data);
            } else {
                alert('Error During Submit !');
                hideProgress();
                exit();
            }
            return false;

        });
    }
</script>
<input type="hidden" id="hfPageTitle" value="Roles Detail" screen_id="roles_aspx">
<input type="hidden" id="hfAccessLevel" value="">	  								
<?php include 'admin_class.php'; ?>
<div id="mainContent" >  
    <form action="" method="post" name="frmRoles" id="frmRoles">
        <table cellpadding="0" cellspacing="3" width="99%" style="line-height:20px">
            <tr>
                <td colspan="8" align="left"><b><u>Filter Condition </u></b></td>
            </tr>
            <tr>
                <td>Role Name</td>
                <td><input name="txtSrcRoleName" id="txtSrcRoleName" type="text" style="width:99%" width="99%" class="txtFieldTextBox " /></td>
                <td width="1%">&nbsp;</td>
                <td>Application  Name</td>
                <td><select id="ddlSrcApp" name="ddlSrcApp" style="width:99%" class="ddlFieldDropdown">
                        <option value="All">All</option>
                    </select></td>
                <td width="1%">&nbsp;</td>
                <td>Status</td>
                <td><select id="ddlSrcStatus" name="ddlSrcStatus" style="width:99%" class="ddlFieldDropdown">
                        <option value="All">All</option>
                        <option value="Active">Active</option>
                        <option value="InActive">InActive</option>
                    </select></td>
            </tr>
            <tr>
                <td colspan="8" align="left"> <a href="javascript:void(0)" class="kks-linkbutton" onclick="searchData()">Search</a></td>
            </tr>

        </table>
        <div class="Grid">
            <table cellpadding="0" cellspacing="0" id="grdRoels">
                <thead>
                    <tr>
                        <th width="4%">Sr.No</th>
                        <th width="25%">Role Name</th>
                        <th width="30%">Description</th>
                        <th width="25%">Application Name</th>
                        <th width="8%">Status</th>
                        <th width="8%">Action</th>
                    </tr>
                </thead>
                <tbody id="res">
                    <?php echo $admin->AllRole() ?>       
                </tbody>
                <tbody id="footer">
                    <tr style="background-color: rgb(247, 246, 243); font-weight: bolder;">
                        <td ></td>
                        <td><input name="txtRoleName" id="txtRoleName" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td>
                        <td ><input name="txtDesc" id="txtDesc" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td>
                        <td ><select id="ddlApp" name="ddlApp" style="width:99%" class="ddlFieldDropdown">
                                <?php echo $admin->fillApp() ?>   
                            </select></td>
                        <td ><select id="ddlStatus" name="ddlStatus" style="width:99%" class="ddlFieldDropdown">
                                <option value="Active">Active</option>
                                <option value="InActive">InActive</option>
                            </select></td>
                        <td width="8%"><a id="btnAdd" href="javascript:void(0)"><img src="images/add.png"  title="Add"/></a></td>
                    </tr>
                </tbody>
                <tbody id="tr_clone" style="display:none"></tbody>
            </table>
        </div>   
    </form>
</div>


<?php
echo"<script>clone();</script>";
?>		