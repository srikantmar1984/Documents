<?php

$ref = 'on';
include("../db_classes/commanvar.php");
include("../db_classes/class.db.php");
date_default_timezone_set("Asia/Calcutta");
if ($_REQUEST['act'] == 'Ajax') {
    subMenuList($_REQUEST['id']);
}
if ($_REQUEST['act'] == 'Add') {
    $obj = new db_connect;
    $row = $obj->db_reader("Select nvl(max(to_number(tmt_id)),0)+1 ID from T_VHS_MENU_TABS ");

    $strSql = "INSERT INTO T_VHS_MENU_TABS";
    $strSql .= " ( ";
    $strSql .= "    tmt_id ";
    $strSql .= "  , tmt_name ";
    $strSql .= "  , tmt_slno ";
    $strSql .= "  , tmt_application_id ";
    $strSql .= "  , tmt_parent_id ";
    $strSql .= "  , tmt_desc ";
    $strSql .= "  , tmt_path ";
    $strSql .= "  , tmt_act_flg ";
    $strSql .= "  , tmt_crt_by ";
    $strSql .= "  , tmt_crt_ts ";
    $strSql .= "  , tmt_upd_by ";
    $strSql .= "  , tmt_upd_ts ";
    $strSql .= " ) ";
    $strSql .= " VALUES ";
    $strSql .= " ( ";

    $strSql .= $row["ID"][0];
    $strSql .= "  , '" . $_REQUEST["MenuName"] . "' ";
    $strSql .= "  ,  (Select nvl(max(to_number(tmt_slno)),0)+1  from T_VHS_MENU_TABS ) ";
    if ($_REQUEST["AppId"]) {
        $strSql .= " , " . $_REQUEST["AppId"];
    } else {
        $strSql .= " , NULL ";
    }
    if ($_REQUEST["parentId"] == "0") {
        $strSql .= "  , NULL ";
    } else {
        $strSql .= "  , '" . $_REQUEST["parentId"] . "' ";
    }
    $strSql .= "  , '" . $_REQUEST["MenuName"] . "' ";
    $strSql .= "  , '" . $_REQUEST["urlData"] . "' ";
    $strSql .= "  , " . $_REQUEST["status"];
    $strSql .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
    $strSql .= "  , SYSDATE ";
    $strSql .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
    $strSql .= "  , SYSDATE ";
    $strSql .= " ) ";
    $obj = new db_connect;
    $obj->db_insert($strSql);
    $obj->free();

    echo '<tr parent_id="' . $_REQUEST['parentId'] . '" child_id="' . $row["ID"][0] . '"><td></td><td>' . $_REQUEST["MenuName"] . '</td><td>' . $_REQUEST["urlData"] . '</td><td>' . $_REQUEST["AppName"] . '</td><td>' . $_REQUEST["status"] . '</td><td id="action"><a id="btnEdit" href="javascript:void(0)" attr="' . $row["ID"][0] . '" parentid="' . $_REQUEST['parentId'] . '"><img src="images/edit.png" title="Edit"  /></a></td></tr>';

    die();
}
if ($_REQUEST['act'] == 'Update') {
    $strSql = "UPDATE T_VHS_MENU_TABS ";
    $strSql .= " SET tmt_name = '" . $_REQUEST["MenuName"] . "' ";
    $strSql .= " , tmt_path = '" . $_REQUEST["urlData"] . "' ";
    $strSql .= " , tmt_act_flg = '" . $_REQUEST["status"] . "' ";
    $strSql .= " , tmt_upd_by = '" . $_SESSION['userSessionInfo']['TUS_UID'] . "' ";
    $strSql .= " , tmt_upd_ts = SYSDATE ";
    if ($_REQUEST["AppId"]) {
        $strSql .= " , tmt_application_id = " . $_REQUEST["AppId"];
    } else {
        $strSql .= " , tmt_application_id = NULL ";
    }
    $strSql .= " WHERE tmt_id = " . $_REQUEST["id"];

    $obj = new db_connect;
    $obj->db_insert($strSql);
    $obj->free();

    die();
}
if ($_REQUEST['act'] == 'AjaxMenu') {
    if ($_SESSION['userSessionInfo']["TUS_PLNT"] == $_REQUEST['plantId']) {
        $strSql = "SELECT ";
        $strSql .= " tma_menu_id, ";
        $strSql .= " tma_access_level ";
        $strSql .= " FROM  ";
        $strSql .= " T_VHS_MENU_ACCESS ";
        $strSql .= " WHERE  ";
        $strSql .= " tma_plant_id = '" . $_REQUEST['plantId'] . "' ";
        $strSql .= " AND tma_role_id = '" . $_REQUEST['role_id'] . "' ";
        $strSql .= " AND tma_act_flg = 1 ";
    } else {
        $strSql = "SELECT ";
        $strSql .= " a.tma_menu_id ";
        $strSql .= " FROM  ";
        $strSql .= " T_VHS_MENU_ACCESS a ,T_VHS_MENU_ACCESS_OTH b";
        $strSql .= " WHERE  ";
        $strSql .= " b.TMA_PLANT_ID = " . $_SESSION['userSessionInfo']["TUS_PLNT"];
        $strSql .= " AND b.TMA_OTH_PLANT_ID = '" . $_REQUEST['plantId'] . "' ";
        $strSql .= " AND b.tma_role_id = '" . $_REQUEST['role_id'] . "' ";
        $strSql .= " AND b.tma_act_flg = 1 ";
        $strSql .= " AND a.tma_menu_id = b.tma_menu_id(+) ";
    }

    $obj = new db_connect;
    $obj->db_query($strSql);
    $menus = array();
    $accessLvl = array();
    while ($row = $obj->db_fetch_array()) {
        $menus[] = $row[0];
        $accessLvl['menuid' . $row[0]] = $row[1];
    }
    $obj->free();
    $resArr['menuId'] = $menus;
    $resArr['accessLevel'] = $accessLvl;
    echo json_encode($resArr);
    die();
}

if ($_REQUEST['act'] == 'SaveMenu') {

    $accessMapArr = array_columnDup($_REQUEST['accessVal'], 'accessLvl', 'menu_id');
    $str = "";
    if ($_SESSION['userSessionInfo']["TUS_PLNT"] == $_REQUEST['plantId']) {
        $tableName = "T_VHS_MENU_ACCESS";
        $strOthPlntCol = " ";
        $strOthPlntVal = " ";
    } else {
        $tableName = "T_VHS_MENU_ACCESS_OTH";
        $strOthPlntCol = "   tma_oth_plant_id, ";
        $strOthPlntVal = $_REQUEST['plantId'] . ", ";
    }

    /*
     * STEP-1 : @@@ Delete All assigned menu from T_VHS_MENU_ACCESS or from T_VHS_MENU_ACCESS_OTH
     * STEP-2 : @@@ Insert All assign menu into T_VHS_MENU_ACCESS or from T_VHS_MENU_ACCESS_OTH
     */
    //STEP-1
    $sqlDelMenu = "DELETE FROM " . $tableName;
    $sqlDelMenu .= " WHERE TMA_PLANT_ID = " . $_REQUEST['plantId'];
    $sqlDelMenu .= " AND TMA_ROLE_ID IN( " . $_REQUEST['roles'] . ")";
//    $sqlDelMenu .= " AND TMA_MENU_ID IN( " . $_REQUEST['menus'] .")";
    $obj = new db_connect;
    $obj->db_query($sqlDelMenu);
    $obj->free();
    $str .= $sqlDelMenu . '<br/>';
    //STEP-2
    $rolesArr = array_unique(explode(',', $_REQUEST['roles']));
    $menusArr = array_unique(explode(',', $_REQUEST['menus']));
    foreach ($rolesArr as $eachRoleId) {
        foreach ($menusArr as $eachMenuId) {
            $sqlInsertMenu = "INSERT INTO " . $tableName;
            $sqlInsertMenu .= " ( ";
            $sqlInsertMenu .= "  tma_menu_id, ";
            $sqlInsertMenu .= "   tma_role_id, ";
            $sqlInsertMenu .= "   tma_plant_id, ";
            $sqlInsertMenu .= $strOthPlntCol;
            $sqlInsertMenu .= "tma_act_flg, ";
            $sqlInsertMenu .= "tma_crt_by, ";
            $sqlInsertMenu .= "tma_crt_ts, ";
            $sqlInsertMenu .= "tma_upd_by, ";
            $sqlInsertMenu .= "tma_access_level, ";
            $sqlInsertMenu .= " tma_upd_ts ";
            $sqlInsertMenu .= " ) ";
            $sqlInsertMenu .= " VALUES ";
            $sqlInsertMenu .= " ( ";
            $sqlInsertMenu .= $eachMenuId . ", ";
            $sqlInsertMenu .= $eachRoleId . ", ";
            $sqlInsertMenu .= $_SESSION['userSessionInfo']["TUS_PLNT"] . ", ";
            $sqlInsertMenu .= $strOthPlntVal;
            $sqlInsertMenu .= "1, ";
            $sqlInsertMenu .= $_SESSION['userSessionInfo']['TUS_UID'] . ", ";
            $sqlInsertMenu .= " SYSDATE, ";
            $sqlInsertMenu .= $_SESSION['userSessionInfo']['TUS_UID'] . ", ";
            $sqlInsertMenu .= $accessMapArr[$eachMenuId];
            $sqlInsertMenu .= ", SYSDATE ";
            $sqlInsertMenu .= " ) ";
            $obj1 = new db_connect;
            $obj1->db_insert($sqlInsertMenu);
//            $obj->free();
            $str .= $sqlInsertMenu . '<br/>';
        }
    }
    $obj1->free();
    echo $str;
    exit;
}

if ($_REQUEST['act'] == "updateRoles") {
    $sqlUpdRole = "UPDATE T_VHS_ROLES ";
    $sqlUpdRole .= "SET TER_NAME = '" . $_REQUEST['roleName'] . "'";
    $sqlUpdRole .= ",TER_ACT_FLG = " . $_REQUEST['status'];
    $sqlUpdRole .= ",TER_UPD_BY = " . $_SESSION['userSessionInfo']['TUS_UID'];
    $sqlUpdRole .= ",TER_UPD_TS = SYSDATE";
    $sqlUpdRole .= " WHERE TER_ID = " . $_REQUEST['roleId'];
    $obj = new db_connect;
    $obj->db_insert($sqlUpdRole);
    $obj->free();
    echo "success";
    exit;
}

if ($_REQUEST['act'] == "addRoles") {
    $obj = new db_connect;
    $row = $obj->db_reader("Select nvl(max(to_number(TER_ID)),0)+1 ID from T_VHS_ROLES ");

    $sqlAddRole = "INSERT INTO T_VHS_ROLES (";
    $sqlAddRole .= " TER_ID";
    $sqlAddRole .= ",TER_NAME";
    $sqlAddRole .= ",TER_ACT_FLG";
    $sqlAddRole .= ",TER_CRT_BY";
    $sqlAddRole .= ",TER_CRT_TS";
    $sqlAddRole .= ",TER_UPD_BY";
    $sqlAddRole .= ",TER_UPD_TS";
    $sqlAddRole .= ") VALUES(";
    $sqlAddRole .= $row["ID"][0];
    $sqlAddRole .= ",'" . $_REQUEST['roleName'] . "'";
    $sqlAddRole .= "," . $_REQUEST['roleStatus'];
    $sqlAddRole .= "," . $_SESSION['userSessionInfo']['TUS_UID'];
    $sqlAddRole .= ", SYSDATE";
    $sqlAddRole .= "," . $_SESSION['userSessionInfo']['TUS_UID'];
    $sqlAddRole .= ", SYSDATE";
    $sqlAddRole .= ") ";
    $obj = new db_connect;
    $obj->db_insert($sqlAddRole);
    $obj->free();
    $res = '<tr><td class="roleNameClm">' . $_REQUEST['roleName'] . '</td><td class="statusClm activeTd">' . $_REQUEST['roleStatusStr'] . '</td><td class="action"><a class="btnEditRole" href="javascript:void(0)" roleid="' . $row["ID"][0] . '"><img src="images/edit.png" title="Edit"  /></a></td></tr>';
    echo $res;
    exit;
}

if ($_REQUEST['act'] == "reorder") {
    $menusMapArr = array_columnDup($_REQUEST['slnoChIdObj'], 'slno', 'menuId');
    foreach ($menusMapArr as $menuId => $slno) {
        $strSql = "UPDATE T_VHS_MENU_TABS ";
        $strSql .= " SET TMT_SLNO = " . $slno;
        $strSql .= " , tmt_upd_by = '" . $_SESSION['userSessionInfo']['TUS_UID'] . "' ";
        $strSql .= " , tmt_upd_ts = SYSDATE ";
        $strSql .= " WHERE tmt_id = " . $menuId;
        $obj = new db_connect;
        $obj->db_insert($strSql);
        $obj->free(); //echo $strSql;
    }
    subMenuList($_REQUEST['parentId']);
    exit;
}

function array_columnDup($input = null, $columnKey = null, $indexKey = null) {
    // Using func_get_args() in order to check for proper number of
    // parameters and trigger errors exactly as the built-in array_columnDup()
    // does in PHP 5.5.
    $argc = func_num_args();
    $params = func_get_args();

    if ($argc < 2) {
        trigger_error("array_columnDup() expects at least 2 parameters, {$argc} given", E_USER_WARNING);
        return null;
    }

    if (!is_array($params[0])) {
        trigger_error(
                'array_columnDup() expects parameter 1 to be array, ' . gettype($params[0]) . ' given', E_USER_WARNING
        );
        return null;
    }

    if (!is_int($params[1]) && !is_float($params[1]) && !is_string($params[1]) && $params[1] !== null && !(is_object($params[1]) && method_exists($params[1], '__toString'))
    ) {
        trigger_error('array_columnDup(): The column key should be either a string or an integer', E_USER_WARNING);
        return false;
    }

    if (isset($params[2]) && !is_int($params[2]) && !is_float($params[2]) && !is_string($params[2]) && !(is_object($params[2]) && method_exists($params[2], '__toString'))
    ) {
        trigger_error('array_columnDup(): The index key should be either a string or an integer', E_USER_WARNING);
        return false;
    }

    $paramsInput = $params[0];
    $paramsColumnKey = ($params[1] !== null) ? (string) $params[1] : null;

    $paramsIndexKey = null;
    if (isset($params[2])) {
        if (is_float($params[2]) || is_int($params[2])) {
            $paramsIndexKey = (int) $params[2];
        } else {
            $paramsIndexKey = (string) $params[2];
        }
    }

    $resultArray = array();

    foreach ($paramsInput as $row) {
        $key = $value = null;
        $keySet = $valueSet = false;

        if ($paramsIndexKey !== null && array_key_exists($paramsIndexKey, $row)) {
            $keySet = true;
            $key = (string) $row[$paramsIndexKey];
        }

        if ($paramsColumnKey === null) {
            $valueSet = true;
            $value = $row;
        } elseif (is_array($row) && array_key_exists($paramsColumnKey, $row)) {
            $valueSet = true;
            $value = $row[$paramsColumnKey];
        }

        if ($valueSet) {
            if ($keySet) {
                $resultArray[$key] = $value;
            } else {
                $resultArray[] = $value;
            }
        }
    }

    return $resultArray;
}

function subMenuList($requestId = NULL) {
    $obj = new db_connect;
    if ($requestId == "0") {
        $strSql = "SELECT 
                                        tmt_id MenuID, 
                                        tmt_name MenuName, 
                                        tmt_path RelPath, 
                                        tmt_slno SlNo, NVL(tea_sht_name,'') Application, 
                                        tmt_act_flg Status 
                                    FROM 
                                        T_VHS_MENU_TABS , 
                                        T_VHS_APPLICATION  
                                    WHERE 
                                        TMT_PARENT_ID IS NULL  
                                        AND tmt_application_id = tea_id(+) 
                                    ORDER BY tmt_slno ASC";
    } else {
        $strSql = "SELECT 
                                        tmt_id MenuID, 
                                        tmt_name MenuName, 
                                        tmt_path RelPath, 
                                        tmt_slno SlNo,NVL(tea_sht_name,'') Application, 
                                        tmt_act_flg Status 
                                    FROM 
                                        T_VHS_MENU_TABS, 
                                        T_VHS_APPLICATION  
                                    WHERE  
                                        TMT_PARENT_ID = '" . $requestId . "' 
                                        AND tmt_application_id = tea_id(+)   
                                    ORDER BY tmt_slno ASC";
    }
    $obj->db_query($strSql);
    $i = 0;
    $res = '';
    $res .= '<tr><td></td><td ><input name="txtMenuName" id="txtMenuName" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td><td><input name="txtUrl" id="txtUrl" type="text" style="width:99%" width="99%" class="txtFieldTextBox" /></td>';
    $res .= '<td><select id="ddlApplication" name="ddlApplication" style="width:99%" class="ddlFieldDropdown">
			<option value="">Common</option>';
    $obj1 = new db_connect;
    $obj1->db_query("SELECT  tea_id,tea_sht_name FROM T_VHS_APPLICATION WHERE tea_act_flg = 1");
    $Cols = '';
    while ($row1 = $obj1->db_fetch_array()) {
        $Cols .= '<option value="' . $row1[0] . '" >' . $row1[1] . '</option>';
    }
    $obj1->free();
    $res .= $Cols . '</select>';

    $res .= '</td>
			<td><select id="ddlStatus" name="ddlStatus" style="width:99%" class="ddlFieldDropdown"><option value="1">Active</option><option value="0">InActive</option></select></td><td><a id="btnAdd" href="javascript:void(0)" parentid="' . $requestId . '" onclick="saveMenu()"><img src="images/add.png"  title="Add"/></td></tr>';

    while ($row = $obj->db_fetch_array()) {
        $status = 'InActive';
        $appName = 'Common';
        if ($row[5] == 1) {
            $status = 'Active';
        }
        if ($row[4]) {
            $appName = $row[4];
        }
        $res .= '<tr parent_id="' . $requestId . '" child_id="' . $row[0] . '"><td>' . ++$i . '</td><td id="menu">' . $row[1] . '</td><td id="url">' . $row[2] . '</td><td id="app">' . $appName . '</td><td id="status">' . $status . '</td><td id="action"><a id="btnEdit" href="javascript:void(0)" attr="' . $row[0] . '" parentid="' . $requestId . '"><img src="images/edit.png" title="Edit"  /></a></td></tr>';
    }
    $obj->free();
    echo $res;

    die();
}

?>