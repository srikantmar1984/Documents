<?php

$ref = 'on';
include("../db_classes/commanvar.php");
include("../db_classes/class.db.php");
include("./emailTemplates.php");
date_default_timezone_set("Asia/Calcutta");
if ($_REQUEST['act'] == 'App') {
    $obj = new db_connect;
    $strSql = "SELECT ";
    $strSql .= " t1.TEA_ID ";
    $strSql .= ",t1.TEA_NAME ";
    $strSql .= " ,Decode (nvl(t2.tau_act_flg,0),0,'False','True') Status ";
    $strSql .= " FROM ";
    $strSql .= " T_VHS_APPLICATION t1, ";
    $strSql .= "(SELECT TAU_USER_ID,TAU_APPLICATION_ID,TAU_ACT_FLG from  t_erc_app_user ";
    $strSql .= " WHERE TAU_USER_ID='" . $_REQUEST['userId'] . "' and TAU_ACT_FLG=1 )t2 ";
    $strSql .= " WHERE ";
    $strSql .= " t1.TEA_ID=t2.TAU_APPLICATION_ID(+) ";
    $strSql .= " AND t1.TEA_ACT_FLG=1 ";
    $strSql .= "ORDER BY TEA_NAME Asc ";

    $obj->db_query($strSql);
    $res = '';
    while ($row = $obj->db_fetch_array()) {
        $res .= '<tr>';
        $res .= '<td width="5%"><input id="chkUpdApp" AppId="' . $row[0] . '" type="checkbox" name="chkUpdApp[]" value="' . $row[0] . '" ';
        if ($row[2] == "True") {
            $res .= 'checked=checked';
        }
        $res .= ' ></td><td>';
        $res .= $row[1];
        $res .= '</td></tr>';
    }
    $obj->free();


    echo $res;

    die();
} else if ($_REQUEST['act'] == 'Role') {
    $obj = new db_connect;
    $strSql = " Select TER_ID,TER_NAME as RoleName ";
    $strSql .= " FROM T_VHS_ROLES, ";
    $strSql .= "(select TRU_ROLE_ID from t_erc_role_user where TRU_USER_ID='" . $_REQUEST['userId'] . "' AND TRU_ACT_FLG = 1)t1 ";
    $strSql .= " WHERE t1.TRU_ROLE_ID=T_VHS_ROLES.TER_ID ";
    $strSql .= " And TER_ACT_FLG=1 ";

    $obj->db_query($strSql);
    $res = '';
    while ($row = $obj->db_fetch_array()) {
        $res .= '<tr><td>' . $row[1] . ' </td><td width="5%"><a id="btnDel" href="#" role_id="' . $row[0] . '"><img src="images/delete.png"></a></td></tr>';
    }
    $obj->free();


    echo $res;

    die();
} else if ($_REQUEST['act'] == 'AssignRole') {
    $obj = new db_connect;
    $strSql = "Select count(TRU_ROLE_ID) From  t_erc_role_user  WHERE TRU_USER_ID = '" . $_REQUEST['userId'] . "' AND TRU_ROLE_ID = '" . $_REQUEST['role_id'] . "' ";
    $obj->db_query($strSql);
    while ($row = $obj->db_fetch_array()) {
        if ($row[0] > 0) {
            $strSql = "UPDATE t_erc_role_user SET TRU_ACT_FLG = 1 WHERE TRU_USER_ID = '" . $_REQUEST['userId'] . "' AND TRU_ROLE_ID = '" . $_REQUEST['role_id'] . "' ";
        } else {
            $strSql = "INSERT INTO ";
            $strSql .= " t_erc_role_user ";
            $strSql .= " ( ";
            $strSql .= "   TRU_ROLE_ID ";
            $strSql .= " , TRU_USER_ID ";
            $strSql .= " , TRU_ACT_FLG ";
            $strSql .= " , TRU_CRT_BY ";
            $strSql .= " , TRU_CRT_TS ";
            $strSql .= " , TRU_UPD_BY ";
            $strSql .= " , TRU_UPD_TS ";
            $strSql .= " ) ";
            $strSql .= " Values ";
            $strSql .= " ( ";
            $strSql .= "   " . $_REQUEST['role_id'];
            $strSql .= " , " . $_REQUEST['userId'];
            $strSql .= " , 1 ";
            $strSql .= " , " . $_SESSION['userSessionInfo']["TUS_UID"];
            $strSql .= " , SYSDATE ";
            $strSql .= " , " . $_SESSION['userSessionInfo']["TUS_UID"];
            $strSql .= " , SYSDATE ";
            $strSql .= " ) ";
        }
        $obj1 = new db_connect;
        $obj1->db_insert($strSql);
        $obj1->free();
    }
    $obj->free();
    die('Role Assigned Sucessfully!');
} else if ($_REQUEST['act'] == 'DelRole') {

    $strSql = "UPDATE t_erc_role_user SET TRU_ACT_FLG = 0 WHERE TRU_USER_ID = '" . $_REQUEST['userId'] . "' AND TRU_ROLE_ID = '" . $_REQUEST['role_id'] . "' ";
    $obj1 = new db_connect;
    $obj1->db_insert($strSql);
    $obj1->free();
    die('Role Delete Sucessfully!');
} else if ($_REQUEST['act'] == 'AssignApp') {
    $obj = new db_connect;
    $strSql = "Select count(TAU_APPLICATION_ID) From  T_ERC_APP_USER  WHERE TAU_USER_ID = '" . $_REQUEST['userId'] . "' AND TAU_APPLICATION_ID = '" . $_REQUEST['app_id'] . "' ";
    $obj->db_query($strSql);
    while ($row = $obj->db_fetch_array()) {
        if ($row[0] > 0) {
            $strSql = "UPDATE T_ERC_APP_USER SET TAU_ACT_FLG = '" . $_REQUEST['act_flg'] . "' WHERE TAU_USER_ID = '" . $_REQUEST['userId'] . "' AND TAU_APPLICATION_ID = '" . $_REQUEST['app_id'] . "' ";
        } else {
            $strSql = "INSERT INTO T_ERC_APP_USER ";
            $strSql .= " ( ";
            $strSql .= "   TAU_USER_ID ";
            $strSql .= " , TAU_APPLICATION_ID ";
            $strSql .= " , TAU_ACT_FLG ";
            $strSql .= " , TAU_CRT_BY ";
            $strSql .= " , TAU_CRT_TS ";
            $strSql .= " , TAU_UPD_BY ";
            $strSql .= " , TAU_UPD_TS ";
            $strSql .= " ) ";
            $strSql .= " Values ";
            $strSql .= " ( ";
            $strSql .= $_REQUEST['userId'];
            $strSql .= " , " . $_REQUEST['app_id'];
            $strSql .= " , 1 ";
            $strSql .= " , " . $_SESSION['userSessionInfo']["TUS_UID"];
            $strSql .= " , SYSDATE ";
            $strSql .= " , " . $_SESSION['userSessionInfo']["TUS_UID"];
            $strSql .= " , SYSDATE ";
            $strSql .= " ) ";
        }

        $obj1 = new db_connect;
        $obj1->db_insert($strSql);
        $obj1->free();
    }
    $obj->free();
    die('Application Assigned Sucessfully!');
} else if ($_REQUEST['act'] == 'AllUserList') {
    $obj = new db_connect;
    $strSql = "SELECT ";
    $strSql .= " t1.TUS_UID UserID, ";
    $strSql .= " t1.tus_pno PersonalNo ";
    $strSql .= ", t1.tus_name UserName ";
    $strSql .= ", t2.TED_NAME Department ";
    $strSql .= ", t1.tus_email_id EmailID ";
    $strSql .= ", nvl(t1.TUS_EXT,'N/A') ExtensionNo ";
    $strSql .= ", nvl(t1.TUS_MOBILE,'N/A') MobileNo ";
    $strSql .= ", CASE
                WHEN t1.tus_act_flg = 1
                   THEN 'Active'
                WHEN t1.tus_act_flg != 1
                   THEN 'InActive'
             END AS Status ";
    $strSql .= ", (SELECT tus_name FROM T_VHS_USERS WHERE TUS_UID = t1.tus_crt_by) CreatedBy ";
    $strSql .= ", TO_CHAR(t1.tus_crt_ts, 'dd-Mon-yyyy') CreatedOn ";
    $strSql .= ", t4.TEP_NAME PlantName ";
    $strSql .= " FROM ";
    $strSql .= " T_VHS_USERS t1 ";
    $strSql .= ", T_VHS_DEPARTMENTS t2 ";
    $strSql .= ", t_erc_plant t4 ";
    $strSql .= " WHERE ";
    $strSql .= " t1.TUS_DEPT_ID = t2.TED_ID ";
    $strSql .= " AND t1.TUS_PLNT = '" . $_REQUEST['plantId'] . "' ";
    $strSql .= " AND t1.TUS_PLNT = t4.TEP_ID ";

    if ($_REQUEST['Pno']) {
        $strSql .= " AND t1.tus_pno LIKE '%" . $_REQUEST['Pno'] . "%' ";
    }
    if ($_REQUEST['UserName']) {
        $strSql .= " AND UPPER(t1.tus_name) LIKE '%" . strtoupper($_REQUEST['UserName']) . "%' ";
    }
    if ($_REQUEST['Status'] != "All") {
        $strSql .= " AND t1.tus_act_flg = '" . $_REQUEST['Status'] . "' ";
    }
    if ($_REQUEST['Dept']) {
        $strSql .= " AND t1.tus_dept_id = '" . $_REQUEST['Dept'] . "' ";
    }
    if ($_REQUEST['Email']) {
        $strSql .= " AND UPPER(t1.tus_email_id) LIKE '%" . strtoupper($_REQUEST['Email']) . "%' ";
    }
    if ($_REQUEST['ExtNo']) {
        $strSql .= " AND t1.tus_ext LIKE '%" . $_REQUEST['ExtNo'] . "%' ";
    }
    if ($_REQUEST['Mobile']) {
        $strSql .= " AND t1.tus_mobile LIKE '%" . $_REQUEST['Mobile'] . "%' ";
    }

    if ($_REQUEST['CreatedFrom']) {
        $strSql .= " AND TRUNC(t1.tus_crt_ts) >= '" . $_REQUEST['CreatedFrom'] . "' ";
    }
    if ($_REQUEST['CreatedTo']) {
        $strSql .= " AND TRUNC(t1.tus_crt_ts) <= '" . $_REQUEST['CreatedTo'] . "' ";
    }
    if (@$_REQUEST['Role']) {
        $strSql .= " AND t1.tus_uid in (SELECT tru_user_id FROM t_erc_role_user WHERE tru_role_id  IN ('" . str_replace(',', "','", implode(",", $_REQUEST['Role'])) . "') ) ";
    }
    if ($_REQUEST['App']) {
        $strSql .= " AND t1.tus_uid in (SELECT TAU_USER_ID FROM T_ERC_APP_USER WHERE TAU_APPLICATION_ID = '" . $_REQUEST['App'] . "') ";
    }

    $strSql .= " ORDER BY ";
    $strSql .= " t1.tus_name ASC";
    $result = $obj->db_query($strSql);
    $resReturn = array();
    while ($row = $obj->db_fetch_assoc($result)) {
        $resReturn['Users'] = $row;
    }
    $obj->free();
    echo json_encode($resReturn);
    die();
} else if ($_REQUEST['act'] == 'UpdateUser') {
    $strSql = "UPDATE T_VHS_USERS ";
    $strSql .= " SET TUS_NAME = '" . $_REQUEST['userName'] . "' ";
    $strSql .= " , TUS_DEPT_ID = '" . $_REQUEST['dept'] . "' ";
    $strSql .= " , TUS_EMAIL_ID = '" . $_REQUEST['email'] . "' ";
    $strSql .= " , TUS_EXT = '" . $_REQUEST['extNo'] . "' ";
    $strSql .= " , TUS_MOBILE = '" . $_REQUEST['mobile'] . "' ";
    if ($_REQUEST['status'] == "Active") {
        $status = 1;
    } else if ($_REQUEST['status'] == "InActive") {
        $status = 0;
    } else if ($_REQUEST['status'] == "Pending") {
        $status = 2;
    } else if ($_REQUEST['status'] == "Rejected") {
        $status = 3;
    }
    $strSql .= " , TUS_ACT_FLG = " . $status;
    $strSql .= " , tus_crt_by = NVL(tus_crt_by," . $_SESSION['userSessionInfo']["TUS_UID"] . ")";
    $strSql .= " , tus_crt_ts = NVL(tus_crt_ts, SYSDATE) ";
    $strSql .= " , tus_upd_by = " . $_SESSION['userSessionInfo']["TUS_UID"];
    $strSql .= " , tus_upd_ts = SYSDATE ";
    $strSql .= " , tus_pass = '" . md5($_REQUEST['pno']) . "'";
    $strSql .= " , TUS_PLNT = " . $_REQUEST['plantId'];
    $strSql .= " WHERE TUS_UID = " . $_REQUEST['userId'];
    $obj1 = new db_connect;
    $obj1->db_insert($strSql);
    $obj1->free();
    die('success');
} else if ($_REQUEST['act'] == "userInfoLdap") {
    $user = 'ann912799';
    $userSrch = 'pgg92824';
    $password = 'Madhu@Apr@2016';
    #########################################################################
    #########################################################################
    #########################################################################
    $ldap_hostDomain = array("tmsndinf01.tmindia.tatamotors.com" => "@tmindia.tatamotors.com", "tmsndinf02.tmindia.tatamotors.com" => "@tmindia.tatamotors.com", "tmsndinf03.tmindia.tatamotors.com" => "@tmindia.tatamotors.com", "PMPAD03.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com", "PMPAD01.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com", "PMPAD02.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com", "PMPAD04.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com", "HNJAD01.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com", "ttpneinf02.ttglobal.tatatechnologies.com" => "@ttglobal.tatatechnologies.com", "ttpnerca01.ttglobal.tatatechnologies.com" => "@ttglobal.tatatechnologies.com");
    $ldap_dns = array("@tmindia.tatamotors.com" => "DC=tmindia,DC=tatamotors,DC=com", "@ttglobal.tatatechnologies.com" => "DC=ttglobal,DC=tatatechnologies,DC=com", "@MYTTL.tatatechnologies.com" => "DC=MYTTL,DC=tatatechnologies,DC=com");
    $result = array();
    $attr = array("extensionattribute1", "samaccountname", "mail", "givenname", "sn", "physicaldeliveryofficename");
    foreach ($ldap_hostDomain as $key => $value) {
        $ldapConn = ldap_connect($key);
        if ($ldapConn) {
            //-----------Added to make PHP 5.3 compatible with ldap---------//
            ldap_set_option($ldapConn, LDAP_OPT_REFERRALS, 0);
            ldap_set_option($ldapConn, LDAP_OPT_PROTOCOL_VERSION, 3);
            //-------------------------------------------------------------//
            if ($bind = @ldap_bind($ldapConn, $user . $value, $password)) {
                $filter = "(name=" . $user . ")";
                $ldapResult = ldap_search($ldapConn, $ldap_dns[$value], $filter, $attr) or exit("Unable to search LDAP server");
                $entries = ldap_get_entries($ldapConn, $ldapResult) or exit("Unable to find entries LDAP server");
//                    print_r($entries);
                if ($entries['count']) {
                    echo $key . "<br/>";
                    echo $value;
                    $result = array(
                        "uname" => $entries[0]['givenname'][0] . ' ' . $entries[0]['sn'][0],
                        "employeeid" => $entries[0]['extensionattribute1'][0],
                        "samaccountname" => $entries[0]['samaccountname'][0],
                        "mail" => $entries[0]['mail'][0],
                        "givenname" => $entries[0]['givenname'][0],
                        "sn" => $entries[0]['sn'][0],
                        "location" => substr($entries[0]['physicaldeliveryofficename'][0], 4)
                    );
                }
                ldap_unbind($ldapConn);
                break;
            }
        } else {
            ldap_unbind($ldapConn);
        }
    }
    #########################################################################
    print_r($result);exit;
    if ($result) {
        //check email
        $sqlToEmailChk = "SELECT * FROM t_sos_users WHERE TRIM(UPPER(tus_email_id)) = TRIM(UPPER('" . $result['mail'] . "')) ";
        $obj = new db_connect;
        $res = $obj->db_query($sqlToEmailChk);
        while ($row = $obj->db_fetch_assoc($res)) {
            $output = $row;
        }
        if ($output[0]['CNT']) {
            $returnArr['err_msg'] = "Email ID already exist";
        }
    } else {
        $returnArr['err_msg'] = "Please Enter Valid Personal Number!";
    }
} else if ($_REQUEST['act'] == "createUser") {
    if (empty($_REQUEST['txtCrtPno'])) {
        echo "<b style='color:red'>Please Enter Personal Number!</b>";
        exit;
    } elseif (empty($_REQUEST['txtCrtUserName'])) {
        echo "<b style='color:red'>Please Enter User Name!</b>";
        exit;
    } elseif (empty($_REQUEST['ddlCrtdept'])) {
        echo "<b style='color:red'>Please Select Department!</b>";
        exit;
    } elseif (empty($_REQUEST['txtCrtEmail'])) {
        echo "<b style='color:red'>Please Enter Email ID!</b>";
        exit;
    } elseif (empty($_REQUEST['txtCrtMobile'])) {
        echo "<b style='color:red'>Please Enter Mobile No!</b>";
        exit;
    } elseif (empty($_REQUEST['chkUpdApp'])) {
        echo "<b style='color:red'>Please Select at least one application!</b>";
        exit;
    } elseif (empty($_REQUEST['assgnRoleCrt'])) {
        echo "<b style='color:red'>Please Assign at least one Role!</b>";
        exit;
    }
    //Insert new user info to the user table.
    $obj = new db_connect;
    $row = $obj->db_reader("Select nvl(max(to_number(TUS_UID)),0)+1 ID from T_VHS_USERS ");
    $sql = "INSERT INTO T_VHS_USERS  (
        TUS_UID,
        tus_pno,
        tus_name,
        tus_dept_id,
        tus_email_id,
        tus_pass,
        TUS_EXT,
        TUS_MOBILE,
        tus_act_flg,
        tus_crt_by,
        tus_crt_ts,
        tus_upd_by,
        tus_upd_ts,
        TUS_PLNT )
    VALUES (
        " . $row["ID"][0] . ",
        '" . $_REQUEST['txtCrtPno'] . "',
        '" . $_REQUEST['txtCrtUserName'] . "',
        " . $_REQUEST['ddlCrtdept'] . ",
        '" . $_REQUEST['txtCrtEmail'] . "',
        '" . md5($_REQUEST['txtCrtPno']) . "',
        '" . $_REQUEST['txtCrtExt'] . "',
        '" . $_REQUEST['txtCrtMobile'] . "',
        " . $_REQUEST['ddlCrtStatus'] . ",
        " . $_SESSION['userSessionInfo']["TUS_UID"] . ",
        SYSDATE,
        " . $_SESSION['userSessionInfo']["TUS_UID"] . ",
        SYSDATE,
        " . $_SESSION['userSessionInfo']["TUS_PLNT"] . "
        ) ";
    $obj = new db_connect;
    $obj->db_query($sql);
    //Insert application to the user and application mapping table.
    foreach ($_REQUEST['chkUpdApp'] as $appID) {
        $sqlAppUser = "INSERT INTO T_ERC_APP_USER ";
        $sqlAppUser .= " ( ";
        $sqlAppUser .= "   TAU_USER_ID ";
        $sqlAppUser .= " , TAU_APPLICATION_ID ";
        $sqlAppUser .= " , TAU_ACT_FLG ";
        $sqlAppUser .= " , TAU_CRT_BY ";
        $sqlAppUser .= " , TAU_CRT_TS ";
        $sqlAppUser .= " , TAU_UPD_BY ";
        $sqlAppUser .= " , TAU_UPD_TS ";
        $sqlAppUser .= " ) ";
        $sqlAppUser .= " VALUES ";
        $sqlAppUser .= " ( ";
        $sqlAppUser .= "   '" . $row["ID"][0] . "' ";
        $sqlAppUser .= " , " . $appID;
        $sqlAppUser .= " , 1 ";
        $sqlAppUser .= " , " . $_SESSION['userSessionInfo']["TUS_UID"];
        $sqlAppUser .= " , SYSDATE ";
        $sqlAppUser .= " , " . $_SESSION['userSessionInfo']["TUS_UID"];
        $sqlAppUser .= " , SYSDATE ";
        $sqlAppUser .= " ) ";
        $obj->db_query($sqlAppUser);
    }
    //Insert role to the user role mapping table.
    foreach ($_REQUEST['assgnRoleCrt'] as $roleID) {
        $sqlAppUser = "INSERT INTO T_ERC_ROLE_USER ";
        $sqlAppUser .= " ( ";
        $sqlAppUser .= "   TRU_USER_ID ";
        $sqlAppUser .= " , TRU_ROLE_ID ";
        $sqlAppUser .= " , TRU_ACT_FLG ";
        $sqlAppUser .= " , TRU_CRT_BY ";
        $sqlAppUser .= " , TRU_CRT_TS ";
        $sqlAppUser .= " , TRU_UPD_BY ";
        $sqlAppUser .= " , TRU_UPD_TS ";
        $sqlAppUser .= " ) ";
        $sqlAppUser .= " VALUES ";
        $sqlAppUser .= " ( ";
        $sqlAppUser .= "   " . $row["ID"][0];
        $sqlAppUser .= " , " . $roleID;
        $sqlAppUser .= " , 1 ";
        $sqlAppUser .= " , " . $_SESSION['userSessionInfo']["TUS_UID"];
        $sqlAppUser .= " , SYSDATE ";
        $sqlAppUser .= " , " . $_SESSION['userSessionInfo']["TUS_UID"];
        $sqlAppUser .= " , SYSDATE ";
        $sqlAppUser .= " ) ";
        $obj->db_query($sqlAppUser);
    }
    //Send mail to the user.

    $to = $_REQUEST['txtCrtEmail'];
    $emailTemp = new EmailTemplateClass();
    $mailCont = $emailTemp->createUser();
    $sent = @mail($to, $mailCont['subject'], $mailCont['body'], $mailCont['header']);
    if ($sent) {
        die("Your email attachment send successfully.");
    } else {
        die("Sorry but the email could not be sent. Please try again!");
    }
}

function ldapUserSearchEx($user = NULL, $password = NULL, $searchUser = NULL) {
    $basedn = array('dmdName=users,dc=foo,dc=fr', 'dmdName=users,dc=bar,dc=com');  // two basedn
    $filter = "(employeeid=1695)";
    $attributes = array();

    $cnx = ldap_connect('localhost', 389); // single connection
    ldap_set_option($cnx, LDAP_OPT_PROTOCOL_VERSION, 3);

    ldap_bind($cnx, 'uid=root,dc=foo,dc=fr', 'password');  // authentication on two BDB
    ldap_bind($cnx, 'uid=root,dc=bar,dc=com', 'password');

    $search = ldap_search(array($cnx, $cnx), $basedn, $filter, $attributes);  // search
    for ($i = 0; $i < count($search); $i++) {
        print_r(ldap_get_entries($cnx, $search[$i]));
        print "\n";
    }
}

function ldapUserSearchTest($user = NULL, $password = NULL, $searchUser = NULL) {
    $ldap_hostDomain = array(
        "tmsndinf01.tmindia.tatamotors.com" => "@tmindia.tatamotors.com",
        "tmsndinf02.tmindia.tatamotors.com" => "@tmindia.tatamotors.com",
        "tmsndinf03.tmindia.tatamotors.com" => "@tmindia.tatamotors.com",
        "PMPAD03.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "PMPAD04.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "HNJAD01.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "PMPAD01.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "PMPAD02.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
//        "PMPAD03.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "ttpneinf02.ttglobal.tatatechnologies.com" => "@ttglobal.tatatechnologies.com",
        "ttpnerca01.ttglobal.tatatechnologies.com" => "@ttglobal.tatatechnologies.com",
    );
    $ldap_dns = array(
        "@tmindia.tatamotors.com" => "DC=tmindia,DC=tatamotors,DC=com",
        "@ttglobal.tatatechnologies.com" => "DC=ttglobal,DC=tatatechnologies,DC=com",
        "@MYTTL.tatatechnologies.com" => "DC=MYTTL,DC=tatatechnologies,DC=com"
    );
    $ldapConn = ldap_connect("PMPAD03.MYTTL.tatatechnologies.com");
    $attr = array();
    if ($ldapConn) {
//        echo 1233;exit;
        ldap_set_option($ldapConn, LDAP_OPT_REFERRALS, 0);
        ldap_set_option($ldapConn, LDAP_OPT_PROTOCOL_VERSION, 3);
        if ($bind = @ldap_bind($ldapConn, $user . "@MYTTL.tatatechnologies.com", $password)) {
            $filter = "(employeeid=$searchUser)";
//            $ldapResult = ldap_search($ldapConn,"DC=MYTTL,DC=tatatechnologies,DC=com", $filter, array()) or exit("Unable to search LDAP server");
//                $entries = ldap_get_entries($ldapConn, $ldapResult);
//                echo $key."@@@@@".$value;
//                print_r($entries);exit;
            foreach ($ldap_hostDomain as $key => $value) {
                $filter = "(employeeid=$searchUser)";
//                $filter = "(employeeid=1695)";
                $ldapResult = ldap_search($ldapConn, $ldap_dns[$value], $filter, $attr) or exit("Unable to search LDAP server");
                $entries = ldap_get_entries($ldapConn, $ldapResult);
//                echo $key."@@@@@".$value;
                print_r($entries);
                exit;
            }
        }
    }
}

function ldapUserSearch1111($user = NULL, $password = NULL, $searchUser = NULL) {
    $ldap_hostDomain = array(
        "tmsndinf01.tmindia.tatamotors.com" => "@tmindia.tatamotors.com",
        "tmsndinf02.tmindia.tatamotors.com" => "@tmindia.tatamotors.com",
        "tmsndinf03.tmindia.tatamotors.com" => "@tmindia.tatamotors.com",
        "PMPAD03.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "PMPAD04.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "HNJAD01.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "PMPAD01.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "PMPAD02.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
//        "PMPAD03.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "ttpneinf02.ttglobal.tatatechnologies.com" => "@ttglobal.tatatechnologies.com",
        "ttpnerca01.ttglobal.tatatechnologies.com" => "@ttglobal.tatatechnologies.com",
    );
    $ldap_dns = array(
        "@tmindia.tatamotors.com" => "DC=tmindia,DC=tatamotors,DC=com",
        "@ttglobal.tatatechnologies.com" => "DC=ttglobal,DC=tatatechnologies,DC=com",
        "@MYTTL.tatatechnologies.com" => "DC=MYTTL,DC=tatatechnologies,DC=com"
    );
    $result = array();
    $attr = array();
    $attr1 = array(
        "employeeid",
        "displayname",
        "department",
        "samaccountname",
        "mail",
        "company",
        "title",
        "givenname",
        "sn",
        "mobile",
        "physicaldeliveryofficename",
    );
    foreach ($ldap_hostDomain as $key => $value) {
        $ldapConn = ldap_connect($key);
        if ($ldapConn) {
            //-----------Added to make PHP 5.3 compatible with ldap---------//
            ldap_set_option($ldapConn, LDAP_OPT_REFERRALS, 0);
            ldap_set_option($ldapConn, LDAP_OPT_PROTOCOL_VERSION, 3);
            //-------------------------------------------------------------//
            if ($bind = @ldap_bind($ldapConn, $user . $value, $password)) {
                $filter = "(employeeid=$searchUser)";
//                $filter = "(employeeid=1695)";
                $ldapResult = ldap_search($ldapConn, $ldap_dns[$value], $filter, $attr) or exit("Unable to search LDAP server");
                $entries = ldap_get_entries($ldapConn, $ldapResult);
//                echo $key."@@@@@".$value;
//                print_r($entries);exit;
                if ($entries['count']) {
                    $result = array(
                        "uname" => $entries[0]['givenname'][0] . ' ' . $entries[0]['sn'][0],
                        "employeeid" => $entries[0]['employeeid'][0],
                        "displayname" => $entries[0]['displayname'][0],
//                    "department"=>$entries[0]['department'][0],
                        "samaccountname" => $entries[0]['samaccountname'][0],
                        "mail" => $entries[0]['mail'][0],
                        "company" => $entries[0]['company'][0],
                        "title" => $entries[0]['title'][0],
                        "givenname" => $entries[0]['givenname'][0],
                        "sn" => $entries[0]['sn'][0],
                        "mobile" => $entries[0]['mobile'][0],
                        "location" => substr($entries[0]['physicaldeliveryofficename'][0], 4)
                    );
                }
                ldap_unbind($ldapConn);
                break;
            } else {
                ldap_unbind($ldapConn);
            }
        }
    }
    return $result;
//    return json_encode($result);
}

function ldapUserSearch($user = NULL, $password = NULL, $searchUser = NULL) {
//    echo 'No record found';exit;
    $ldap_hostDomain = array(
        "tmsndinf01.tmindia.tatamotors.com" => "DC=tmindia,DC=tatamotors,DC=com",
        "tmsndinf02.tmindia.tatamotors.com" => "DC=tmindia,DC=tatamotors,DC=com",
        "tmsndinf03.tmindia.tatamotors.com" => "DC=tmindia,DC=tatamotors,DC=com",
        "HNJAD01.MYTTL.tatatechnologies.com" => "DC=MYTTL,DC=tatatechnologies,DC=com",
        "PMPAD04.MYTTL.tatatechnologies.com" => "DC=MYTTL,DC=tatatechnologies,DC=com",
        "PMPAD01.MYTTL.tatatechnologies.com" => "DC=MYTTL,DC=tatatechnologies,DC=com",
        "PMPAD02.MYTTL.tatatechnologies.com" => "DC=MYTTL,DC=tatatechnologies,DC=com",
        "PMPAD03.MYTTL.tatatechnologies.com" => "DC=MYTTL,DC=tatatechnologies,DC=com",
        "ttpnerca01.ttglobal.tatatechnologies.com" => "DC=ttglobal,DC=tatatechnologies,DC=com",
        "ttpneinf02.ttglobal.tatatechnologies.com" => "DC=ttglobal,DC=tatatechnologies,DC=com",
    );
    $ldap_dn = explode("/", "DC=tmindia,DC=tatamotors,DC=com/DC=tmindia,DC=tatamotors,DC=com/DC=tmindia,DC=tatamotors,DC=com/DC=ttglobal,DC=tatatechnologies,DC=com/DC=ttglobal,DC=tatatechnologies,DC=com/	DC=MYTTL,DC=tatatechnologies,DC=com/DC=MYTTL,DC=tatatechnologies,DC=com/DC=MYTTL,DC=tatatechnologies,DC=com/DC=MYTTL,DC=tatatechnologies,DC=com/DC=MYTTL,DC=tatatechnologies,DC=com/DC=MYTTL,DC=tatatechnologies,DC=com");
    $basedn = array(
        "DC=tmindia,DC=tatamotors,DC=com",
        "DC=ttglobal,DC=tatatechnologies,DC=com",
        "DC=MYTTL,DC=tatatechnologies,DC=com"
    );
//    $basedn=array('dmdName=users,dc=foo,dc=fr','dmdName=users,dc=bar,dc=com');  // two basedn
//$filter='(&(objectClass=inetOrgPerson)(uid=*))';  // single filter
    $filter = "(employeeid=$searchUser)";
    $attributes = array('displayname', 'sn');
    foreach ($ldap_hostDomain as $host => $dn) {
        $cnx = ldap_connect($host); // single connection
        if ($cnx) {
            echo $host . "\n";
            ldap_set_option($cnx, LDAP_OPT_REFERRALS, 0);
            ldap_set_option($cnx, LDAP_OPT_PROTOCOL_VERSION, 10);
            $search = ldap_search($cnx, $basedn, $filter, $attributes);
            print_r($search);
            echo "\n";
        }
//    ldap_set_option($cnx, LDAP_OPT_PROTOCOL_VERSION, 3);
//    $search = ldap_search($cnx,$dn,$filter,$attributes);
////    print_r($search);exit;
////        for($i=0;$i<count($search);$i++){
//            print_r(ldap_get_entries($cnx,$search));
//            print "\n";//exit;
////        }
    }
    exit;
    $cnx = ldap_connect('localhost', 389); // single connection
    ldap_set_option($cnx, LDAP_OPT_PROTOCOL_VERSION, 3);

//ldap_bind($cnx,'uid=root,dc=foo,dc=fr','password');  // authentication on two BDB
//ldap_bind($cnx,'uid=root,dc=bar,dc=com','password');

    $search = ldap_search(array($cnx, $cnx, $cnx), $basedn, $filter, $attributes);  // search
// result
    for ($i = 0; $i < count($search); $i++) {
        print_r(ldap_get_entries($cnx, $search[$i]));
        print "\n";
    }
    exit('test');
    $ldap_hostDomain = array(
        "tmsndinf01.tmindia.tatamotors.com" => "@tmindia.tatamotors.com",
        "tmsndinf02.tmindia.tatamotors.com" => "@tmindia.tatamotors.com",
        "tmsndinf03.tmindia.tatamotors.com" => "@tmindia.tatamotors.com",
        "PMPAD03.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "PMPAD01.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "PMPAD02.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "PMPAD04.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "HNJAD01.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
//        "PMPAD03.MYTTL.tatatechnologies.com" => "@MYTTL.tatatechnologies.com",
        "ttpneinf02.ttglobal.tatatechnologies.com" => "@ttglobal.tatatechnologies.com",
        "ttpnerca01.ttglobal.tatatechnologies.com" => "@ttglobal.tatatechnologies.com",
    );
    $ldap_dns = array(
        "@tmindia.tatamotors.com" => "DC=tmindia,DC=tatamotors,DC=com",
        "@ttglobal.tatatechnologies.com" => "DC=ttglobal,DC=tatatechnologies,DC=com",
        "@MYTTL.tatatechnologies.com" => "DC=MYTTL,DC=tatatechnologies,DC=com"
    );
    $result = array();
    $attr = array();
    $attr1 = array(
        "employeeid",
        "displayname",
        "department",
        "samaccountname",
        "mail",
        "company",
        "title",
        "givenname",
        "sn",
        "mobile",
        "physicaldeliveryofficename",
    );
    foreach ($ldap_hostDomain as $key => $value) {

        $ldapConn = ldap_connect($key);
        if ($ldapConn) {
            //-----------Added to make PHP 5.3 compatible with ldap---------//
            ldap_set_option($ldapConn, LDAP_OPT_REFERRALS, 0);
            ldap_set_option($ldapConn, LDAP_OPT_PROTOCOL_VERSION, 3);
            //-------------------------------------------------------------//
//            if($bind = @ldap_bind($ldapConn, $user . $value, $password)){
            $filter = "(employeeid=$searchUser)";
//                $filter = "(employeeid=1695)";
            $ldapResult = ldap_search($ldapConn, $ldap_dns[$value], $filter, $attr) or exit("Unable to search LDAP server");
            $entries = ldap_get_entries($ldapConn, $ldapResult) or exit("Unable to find entries LDAP server");
//                echo $key."@@@@@".$value;
            print_r($entries); //exit;
            if ($entries['count']) {
                $result = array(
                    "uname" => $entries[0]['givenname'][0] . ' ' . $entries[0]['sn'][0],
                    "employeeid" => $entries[0]['employeeid'][0],
                    "displayname" => $entries[0]['displayname'][0],
//                    "department"=>$entries[0]['department'][0],
                    "samaccountname" => $entries[0]['samaccountname'][0],
                    "mail" => $entries[0]['mail'][0],
                    "company" => $entries[0]['company'][0],
                    "title" => $entries[0]['title'][0],
                    "givenname" => $entries[0]['givenname'][0],
                    "sn" => $entries[0]['sn'][0],
                    "mobile" => $entries[0]['mobile'][0],
                    "location" => substr($entries[0]['physicaldeliveryofficename'][0], 4)
                );
            }
            ldap_unbind($ldapConn);
//                break;
//            }
        } else {
            ldap_unbind($ldapConn);
        }
    }
    return $result;
//    return json_encode($result);
}

?>