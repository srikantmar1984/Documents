<script type="text/javascript" >
    var url = wwwRoot + "/admin/department_action.php";
    $(document).ready(function () {
        $('.layout-button-left').trigger('click');
        $("#btnAdd").click(function (event) {
            event.preventDefault();
            validate();
            var deptName = $("#txtName").val();
            var status = $("#ddlStatus").val();
            var statusStr = $("#ddlStatus option:selected").text();
            $('#res td:nth-child(2)').each(function () {
                if ($(this).text() === deptName) {
                    alert("Duplicate Department Name");
                    exit();
                }
            });
            $.post(url, {
                deptName: deptName,
                status: status,
                statusStr:statusStr,
                act: "Add"
            },
            function (data) {
                var str = data.indexOf("Error");
                if (str == '-1') {
                    $("#res").append(data);
                    var i = 1;
                    $('#res td:nth-child(1)').each(function () {
                        $(this).text(i++);
                    });
                    $("#txtName").val("");
                } else {
                    alert('Error During Submit !');
                    hideProgress();
                    exit();
                }
                return false;
            });
        });

        $('#btnEdit').die('click').live('click', function () {
            if ($("#tr_clone").html() != '') {
                alert("Please complete your previous action!");
            } else {
                var deptid = $(this).attr('deptid');
                var parent = $(this).parent().parent();
                //Clone the selected Row
                var clone = parent.clone();
                $("#tr_clone").html(clone);
                var ch = parent.find("#deptName");
                ch.html('<input id="txtEDeptName" type="text" value="' + ch.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');
                var ch2 = parent.find("#desc");
                ch2.html('<input id="txtEdes" type="text" value="' + ch2.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');
                var ch4 = parent.find("#status");
                var status = (ch4.text() === "Active") ? '<option value="1" selected="true">Active</option><option value="0">InActive</option>' : '<option value="1">Active</option><option value="0" selected="true" >InActive</option>';
                ch4.html('<select id="ddlEStatus" name="ddlStatus" style="width:99%" class="ddlFieldDropdown">' + status + '</select>');

                var ch5 = parent.find("#action");
                ch5.html('<a id="btnUpdate" deptId="' + deptid + '" href="javascript:void(0)"><img src="images/accept.png" title="Update"  /></a> &nbsp; <a id="btnCancel" href="javascript:void(0)"><img src="images/cancel.png" title="Cancel"  /></a>');
            }
        });

        $('#btnUpdate').die('click').live('click', function () {
            var deptid = $(this).attr('deptid');
            var parent = $(this).parent().parent();
            var deptName = parent.find("#txtEDeptName").val();
            var status = parent.find("#ddlEStatus").val();
            var statusStr = parent.find("#ddlEStatus option:selected").text();
            var ch = parent.find("#deptName");
            var ch4 = parent.find("#status");
            var ch5 = parent.find("#action");
            if(!deptName){
                alert("Please enter department name!");
                return false;
            }
            $.post(url,
                    {
                        deptId: deptid,
                        deptName: deptName,
                        status: status,
                        act: 'Update'
                    },
            function (data) {
                var str = data.indexOf("Error");
                if (str == '-1') {
                    alert('change sucessfully');
                    ch.html(deptName);
                    ch4.html(statusStr);
                    ch5.html('<a  id="btnEdit" deptId="' + deptid + '" href="javascript:void(0)"><img src="images/edit.png" title="Edit"  /></a> ');
                    $("#tr_clone").html('');
                } else {
                    alert('Error During Submit !');
                    hideProgress();
                    exit();
                }
                return false;

            });
        });


        $('#btnCancel').die('click').live('click', function ()
        {


            var parent = $(this).parent().parent();
            var clone = $("#tr_clone").html();
            //Replace <tr> Tag in IE
            clone = clone.replace('<TR>', '');
            clone = clone.replace('</TR>', '');
            parent.html(clone.replace('<tr>', ''));
            $("#tr_clone").html('');

        });


    });

</script>
<input type="hidden" id="hfPageTitle" value="Department Details" screen_id="department_aspx">
<input type="hidden" id="hfAccessLevel" value="">	 								
<?php include 'admin_class.php'; ?>
<div id="mainContent" >  
    <form action="" method="post" name="frmDepartment" id="frmDepartment">
        <div class="Grid">
            <table cellpadding="0" cellspacing="0" id="grdDepartment">
                <thead>
                    <tr>
                        <th width="5%">Sr.No</th>
                        <th width="60%">Department Name</th>
                        <th width="10%">Status</th>
                        <th width="10%">Action</th>
                    </tr>
                </thead>
                <tbody id="res">
                    <?php echo $admin->departments($_SESSION['userSessionInfo']["TUS_PLNT"]) ?>      
                </tbody>
                <tbody id="footer">
                    <tr style="background-color: rgb(247, 246, 243); font-weight: bolder;">
                        <td width="4%" id="sno"></td>
                        <td width="25%"><input name="txtDeptName" id="txtName" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td>
                        <!--<td width="30%"><input name="txtDesc" id="txtDesc" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td>-->
                        <td width="7%"><select id="ddlStatus" name="ddlStatus" style="width:99%" class="ddlFieldDropdown">
                                <option value="1">Active</option>
                                <option value="0">InActive</option>
                            </select></td>
                        <td width="10%"><a id="btnAdd" href="javascript:void(0)"><img src="images/add.png"  title="Add"/></a></td>
                    </tr>

                </tbody>
                <tbody id="tr_clone" style="display:none"></tbody>
            </table>
        </div>   
    </form>
</div>
