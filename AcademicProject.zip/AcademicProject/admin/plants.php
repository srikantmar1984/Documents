<script type="text/javascript" >
    $(document).ready(function () {
        $('.layout-button-left').trigger('click');
        $("#btnAdd").click(function (event) {
            event.preventDefault();
            validate();
            var plantName = $("#txtPlantNameAdd").val();
            var status = $("#ddlStatusAdd").val();
            $('#res td:nth-child(2)').each(function () {
                if ($(this).text() === plantName) {
                    alert("Duplicate Plant");
                    exit();
                }
            });
            $.post(wwwRoot + "/admin/plants_action.php",
                    {
                        plantName: plantName,
                        status: status,
                        act: "Add"
                    }, function (data)
            {
                var str = data.indexOf("Error");
                if (str == '-1') {
                    $("#res").append(data);
                    var i = 1;
                    $('#res td:nth-child(1)').each(function () {
                        $(this).text(i++);
                    });
                    $("#txtPlantNameAdd").val("");
                } else {
                    alert('Error During Submit !');
                    hideProgress();
                    exit();
                }
                return false;
            });
        });

        $('#btnEdit').die('click').live('click', function () {
            if ($("#tr_clone").html() != '') {
                alert("Please complete your previous action!");
            } else {
                var plantId = $(this).attr('plantid');
                var parent = $(this).parent().parent();

                //Clone the selected Row
                var clone = parent.clone();
                $("#tr_clone").html(clone);

                var ch = parent.find("#plantName");
                ch.html('<input id="txtPlantName" type="text" value="' + ch.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');

                var ch4 = parent.find("#status");
                var status = (ch4.text() === "Active") ? '<option value="1" selected="true">Active</option><option value="0">InActive</option>' : '<option value="1">Active</option><option value="0" selected="true" >InActive</option>';
                ch4.html('<select id="ddlStatus" name="ddlStatus" style="width:99%" class="ddlFieldDropdown">' + status + '</select>');

                var ch5 = parent.find("#action");
                ch5.html('<a id="btnUpdate" plantId="' + plantId + '" href="javascript:void(0)"><img src="images/accept.png" title="Update"  /></a> &nbsp; <a id="btnCancel" href="javascript:void(0)"><img src="images/cancel.png" title="Cancel"  /></a>');
            }
        });

        $('#btnUpdate').die('click').live('click', function () {
            var plantId = $(this).attr('plantid');
            var parent = $(this).parent().parent();
            var plantName = parent.find("#txtPlantName").val();
            var status = parent.find("#ddlStatus").val();
            var statusStr = parent.find("#ddlStatus option:selected").text()
            var ch = parent.find("#plantName");
            var ch4 = parent.find("#status");
            var ch5 = parent.find("#action");
            $.post(wwwRoot + "/admin/plants_action.php",
                    {
                        plantId: plantId,
                        plantName: plantName,
                        status: status,
                        act: 'Update'
                    }, function (data)
            {
                var str = data.indexOf("Error");
                if (str == '-1')
                {
                    alert('change sucessfully');
                    ch.html(plantName);
                    ch4.html(statusStr);
                    ch5.html('<a  id="btnEdit" plantid="' + plantId + '" href="javascript:void(0)"><img src="images/edit.png" title="Edit"  /></a> ');
                    $("#tr_clone").html('');
                } else
                {
                    alert('Error During Submit !');
                    hideProgress();
                    exit();
                }
                return false;

            });
        });


        $('#btnCancel').die('click').live('click', function () {
            var parent = $(this).parent().parent();
            var clone = $("#tr_clone").html();
            //Replace <tr> Tag in IE
            clone = clone.replace('<TR>', '');
            clone = clone.replace('</TR>', '');
            parent.html(clone.replace('<tr>', ''));
            $("#tr_clone").html('');

        });


    });

</script>

<input type="hidden" id="hfPageTitle" value="Plants Detail" screen_id="">
<input type="hidden" id="hfAccessLevel" value="">	   								
<?php include 'admin_class.php'; ?>
<div id="mainContent" >  
    <form action="" method="post" name="frmPlant" id="frmPlant">
        <div class="Grid">
            <table cellpadding="0" cellspacing="0" id="grdPlant">
                <thead>
                    <tr>
                        <th width="5%">Sr.No</th>
                        <th width="40%">Plant Name</th>
                        <!--<th width="25%">Short Name</th>-->
                        <th width="20%">Status</th>
                        <th width="10%">Action</th>
                    </tr>
                </thead>
                <tbody id="res">
                    <?php echo $admin->plantsListing() ?>       
                </tbody>
                <tbody id="footer">
                    <tr style="background-color: rgb(247, 246, 243); font-weight: bolder;">
                        <td></td>
                        <td><input name="txtPlantNameAdd" id="txtPlantNameAdd" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td>
                        <!--<td><input name="txtShortName" id="txtShortName" type="text" style="width:99%" maxlength="3"  width="99%" class="txtFieldTextBox required" /></td>-->
                        <td><select id="ddlStatusAdd" name="ddlStatusAdd" style="width:99%" class="ddlFieldDropdown">
                                <option value="1">Active</option>
                                <option value="0">InActive</option>
                            </select></td>
                        <td><a id="btnAdd" href="javascript:void(0)"><img src="images/add.png"  title="Add"/></a></td>
                    </tr>
                </tbody>
                <tbody id="tr_clone" style="display:none"></tbody>
            </table>
        </div>   
    </form>
</div>
