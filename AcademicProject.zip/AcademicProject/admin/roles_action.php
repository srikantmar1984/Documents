<?php

$ref = 'on';
include("../db_classes/commanvar.php");
include("../db_classes/class.db.php");
date_default_timezone_set("Asia/Calcutta");

if ($_REQUEST["act"] == 'Add') {
    $obj = new db_connect;
    $row = $obj->db_reader("Select nvl(max(to_number(tro_role_id)),0)+1 ID from t_sos_roles ");
    $id = $row["ID"][0];

    $strSql = "INSERT INTO t_sos_roles ";
    $strSql .= " ( ";
    $strSql .= "   tro_role_id ";
    $strSql .= " , tro_role_name ";
    $strSql .= " , tro_desc ";
    $strSql .= " , tro_slno ";
    $strSql .= " , tro_act_flg ";
    $strSql .= " , tro_crt_by ";
    $strSql .= " , tro_crt_ts ";
    $strSql .= " , tro_upd_by ";
    $strSql .= " , tro_upd_ts ";
    $strSql .= " , tro_app_id ";
    $strSql .= " ) ";
    $strSql .= " VALUES ";
    $strSql .= " ( ";
    $strSql .= "   '" . $id . "' ";
    $strSql .= " , '" . $_REQUEST["roleName"] . "' ";
    $strSql .= " , '" . $_REQUEST["desc"] . "' ";
    $strSql .= " ,  (Select nvl(max(to_number(tro_slno)),0)+1 ID from t_sos_roles) ";
    $strSql .= " , '" . $_REQUEST["status"] . "' ";
    $strSql .= " , '" . $_SESSION['Pno'] . "' ";
    $strSql .= " , SYSDATE ";
    $strSql .= " , '" . $_SESSION['Pno'] . "' ";
    $strSql .= " , SYSDATE ";
    $strSql .= " , '" . $_REQUEST["appId"] . "' ";
    $strSql .= " ) ";


    $obj = new db_connect;
    $obj->db_insert($strSql);
    $obj->free();


    echo '<tr><td></td><td id="rolename">' . $_REQUEST["roleName"] . '</td><td id="desc">' . $_REQUEST["desc"] . '</td><td id="appName">' . $_REQUEST["appName"] . '</td><td id="status">' . $_REQUEST["status"] . '</td><td id="action"><a id="btnEdit" roleId="' . $id . '" appId="' . $_REQUEST["appId"] . '" href="javascript:void(0)"><img src="images/edit.png" title="Edit"  /></a></td></tr>';
} else if ($_REQUEST["act"] == 'Update') {
    $strSql = "UPDATE t_sos_roles ";
    $strSql .= " SET tro_role_name = '" . $_REQUEST["roleName"] . "' ";
    $strSql .= " , tro_desc = '" . $_REQUEST["desc"] . "' ";
    $strSql .= " , tro_act_flg = '" . $_REQUEST["status"] . "' ";
    $strSql .= " , tro_upd_by = '" . $_SESSION['Pno'] . "' ";
    $strSql .= " , tro_upd_ts = SYSDATE ";
    $strSql .= " , tro_app_id = '" . $_REQUEST["appId"] . "' ";
    $strSql .= " WHERE tro_role_id = '" . $_REQUEST["roleId"] . "' ";
    $strSql .= " AND tro_app_id = '" . $_REQUEST["appIdOld"] . "' ";

    $obj = new db_connect;
    $obj->db_insert($strSql);
    $obj->free();
} else if ($_REQUEST["act"] == 'Ajax') {

    $strSql = "SELECT t1.tro_slno SlNo, t1.tro_role_id RoleID, t1.tro_role_name RoleName, t1.tro_desc Description, t3.tap_app_name ApplicationName,t1.tro_act_flg Status, t2.tus_name CreatedBy, TO_CHAR(t1.tro_crt_ts,'dd-Mon-yyyy') CreatedOn,t1.TRO_APP_ID AppId FROM t_sos_roles t1, t_sos_users t2 ,t_sos_applications t3 WHERE t1.tro_app_id=t3.tap_id AND t1.tro_crt_by = t2.tus_pno(+) ";

    if ($_REQUEST["roleName"] != "") {
        $strSql .= " AND t1.tro_role_name LIKE '" . $_REQUEST["roleName"] . "%'";
    }
    if ($_REQUEST["appId"] != "All") {
        $strSql .= " AND t1.tro_app_id = '" . $_REQUEST["appId"] . "'";
    }
    if ($_REQUEST["status"] != "All") {
        $strSql .= " AND t1.tro_act_flg = '" . $_REQUEST["status"] . "'";
    }
    $strSql .= " ORDER BY t1.TRO_APP_ID , t1.tro_slno ASC";

    $obj = new db_connect;
    $obj->db_query($strSql);
    $res = '';
    $i = 0;
    while ($row = $obj->db_fetch_array()) {
        $res .= '<tr><td>' . ++$i . '</td><td id="rolename">' . $row[2] . '</td><td id="desc">' . $row[3] . '</td><td id="appName">' . $row[4] . '</td><td id="status">' . $row[5] . '</td><td id="action"><a id="btnEdit" roleId="' . $row[1] . '" appId="' . $row[8] . '"  href="javascript:void(0)"><img src="images/edit.png"  title="Delete"/></a></td></tr>';
    }
    $obj->free();

    echo $res;
}
?>