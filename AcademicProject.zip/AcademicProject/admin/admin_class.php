<?php

$ref = 'on';
include("../db_classes/commanvar.php");
include("../db_classes/class.db.php");

class Adminclass {

    public function __construct() {
        if (isset($_SESSION['Logout'])) {
            unset($_SESSION['Logout']);
            echo "<script>document.location.href='../" . $PROJECTNAME . "/index.php'</script>";
        }
    }

    public function Menus($chkbox = "false") {
        $obj = new db_connect;
        $obj->db_query("SELECT tmt_id , tmt_name, tmt_slno , tmt_act_flg FROM T_VHS_MENU_TABS WHERE tmt_parent_id IS NULL ORDER BY tmt_slno ASC");
        if ($chkbox == "false") {
            $res = ' <ul id="tt" class="kks-tree" data-options="animate:true,lines:true"><li><span ><a id="menu" attr="0" onclick=search_submenu("0") >Tab</a></span><ul>';
        } else {
            $res = ' <ul id="tt" class="kks-tree" data-options="animate:true,lines:true,checkbox:true"><li><span ><a id="menu" attr="0" parent_id>Tab</a></span><ul>';
        }
        while ($row = $obj->db_fetch_array()) {
            $submenu = $this->SubMenu($row[0]);
            if ($submenu == "<ul></ul>") {
                $res .= '<li><span><a id="menu"  attr="' . $row[0] . '" onclick=search_submenu("' . $row[0] . '")>' . $row[1] . '</a></span>';
            } else {
                $res .= '<li state="closed"><span ><a id="menu" attr="' . $row[0] . '" onclick=search_submenu("' . $row[0] . '")>' . $row[1] . '</a></span>';
                $res .= $submenu;
            }
            $res .= '</li>';
        }
        $obj->free();
        return $res . '</ul></li></ul>';
    }

    public function SubMenu($strMasterId) {
        $obj1 = new db_connect;
        $obj1->db_query("SELECT tmt_id , tmt_name, tmt_slno , tmt_act_flg FROM T_VHS_MENU_TABS WHERE tmt_parent_id = '" . $strMasterId . "' ORDER BY tmt_slno ASC");
        $res = '<ul>';
        while ($row1 = $obj1->db_fetch_array()) {
            $submenu = $this->SubMenu($row1[0]);
            if ($submenu == "<ul></ul>") {
                $res .= '<li><span ><a id="menu" attr="' . $row1[0] . '" onclick=search_submenu("' . $row1[0] . '")>' . $row1[1] . '</a></span>';
            } else {
                $res .= '<li state="closed"><span ><a id="menu" attr="' . $row1[0] . '" onclick=search_submenu("' . $row1[0] . '")>' . $row1[1] . '</a></span>';
                $res .= $submenu;
            }
            $res .= '</li>';
        }
        $res .= '</ul>';

        $obj1->free();
        return $res;
    }

    public function roles() {
        $strSql = "SELECT ";
        $strSql .= "   TER_ID RoleID ";
        $strSql .= " , TER_NAME RoleName ";
        $strSql .= " FROM ";
        $strSql .= "   T_VHS_ROLES t1 ";
        $strSql .= " WHERE ";
        $strSql .= " TER_ACT_FLG =1 ";
        $strSql .= " ORDER BY ";
        $strSql .= "  TER_ID ASC ";

        $obj = new db_connect;
        $obj->db_query($strSql);
        $res = '';
        while ($row = $obj->db_fetch_array()) {
            $res .= '<tr><td><input class="chkrole" type="checkbox" value="' . $row[0] . '"><a id="lnkrole" style="text-decoration:none; color:black; font-weight:bold;"  href="javascript:void(0)"  roleid="' . $row[0] . '">' . $row[1] . '</a></td></tr>';
        }
        $obj->free();
        return $res;
    }

    public function plants() {
        $strSql = "SELECT ";
        $strSql .= "   TEP_ID PlantID, ";
        $strSql .= "   TEP_NAME PlantName ";
        $strSql .= " FROM ";
        $strSql .= "   t_erc_plant ";
        $strSql .= " WHERE ";
        $strSql .= "   TEP_ACT_FLG = 1 ";
        $strSql .= " ORDER BY ";
        $strSql .= "   TEP_ID ASC ";

        $obj = new db_connect;
        $obj->db_query($strSql);
        $res = '';
        while ($row = $obj->db_fetch_array()) {
            $res .= '<tr><td><a class="lnklocations" style="text-decoration:none; color:black; font-weight:bold;" href="javascript:void(0)" plantid="' . $row[0] . '" >' . $row[1] . '</a></td></tr>';
        }
        $obj->free();
        return $res;
    }

    public function CheckMenu() {
        $obj = new db_connect;
        $obj->db_query("SELECT tmt_id , tmt_name, tmt_parent_id FROM T_VHS_MENU_TABS WHERE tmt_parent_id IS NULL ORDER BY tmt_slno ASC");

        $res = ' <ul id="tt1" class="kks-tree" data-options="animate:true,lines:true,checkbox:true"><li><span ><a id="chkmenu" menu_id=""  parent_id>Tab</a></span><ul>';
        while ($row = $obj->db_fetch_array()) {
            $submenu = $this->CheckSubMenu($row[0]);
            if ($submenu == "<ul></ul>") {
                $res .= '<li><span><a id="chkmenu"  menu_id="' . $row[0] . '" parent_id="' . $row[2] . '">' . $row[1] . '</a> <span style="margin-left:50px;" spanmenu_id="' . $row[0] . '">(<b>Access:</b> <input name="accessVal' . $row[0] . '" class="accessVal' . $row[0] . '" type="radio" value="0"/><b style="color:green">Read</b> <input name="accessVal' . $row[0] . '" class="accessVal' . $row[0] . '" type="radio" value="1" /><b style="color:red">Write </b><input name="accessVal' . $row[0] . '" class="accessVal' . $row[0] . '" type="radio" value="2" /><b style="color:blue">All</b> )</span></span>';
            } else {
                $res .= '<li state="closed"><span><a id="chkmenu" menu_id="' . $row[0] . '" parent_id="' . $row[2] . '">' . $row[1] . '</a> <span style="margin-left:50px;" spanmenu_id="' . $row[0] . '">(<b>Access:</b> <input name="accessVal' . $row[0] . '" class="accessVal' . $row[0] . '" type="radio" value="0"/><b style="color:green">Read</b> <input name="accessVal' . $row[0] . '" class="accessVal' . $row[0] . '" type="radio" value="1" /><b style="color:red">Write </b><input name="accessVal' . $row[0] . '" class="accessVal' . $row[0] . '" type="radio" value="2" /><b style="color:blue">All</b> )</span></span>';
                $res .= $submenu;
            }
            $res .= '</li>';
        }
        $obj->free();
        return $res . '</ul></li></ul>';
    }

    public function CheckSubMenu($strMasterId) {
        $obj1 = new db_connect;
        $obj1->db_query("SELECT tmt_id , tmt_name,tmt_parent_id FROM T_VHS_MENU_TABS WHERE tmt_parent_id = '" . $strMasterId . "' ORDER BY tmt_slno ASC");
        $res = '<ul>';
        while ($row1 = $obj1->db_fetch_array()) {
            $submenu = $this->CheckSubMenu($row1[0]);
            if ($submenu == "<ul></ul>") {
                $res .= '<li><span ><a id="chkmenu" menu_id="' . $row1[0] . '" parent_id="' . $row1[2] . '">' . $row1[1] . '</a><span style="margin-left:50px;" spanmenu_id="' . $row1[0] . '" >(<b>Access:</b> <input name="accessVal' . $row1[0] . '" class="accessVal' . $row1[0] . '" type="radio" value="0" /><b style="color:green">Read</b> <input name="accessVal' . $row1[0] . '" class="accessVal' . $row1[0] . '" type="radio" value="1" /><b style="color:red">Write </b><input name="accessVal' . $row1[0] . '" class="accessVal' . $row1[0] . '" class="accessVal' . $row1[0] . '" type="radio" value="2" /><b style="color:blue">All</b> )</span></span>';
            } else {
                $res .= '<li state="closed"><span ><a id="chkmenu" menu_id="' . $row1[0] . '" parent_id="' . $row1[2] . '">' . $row1[1] . '</a><span style="margin-left:50px;" spanmenu_id="' . $row1[0] . '">(<b>Access:</b> <input name="accessVal' . $row1[0] . '" class="accessVal' . $row1[0] . '" class="accessVal' . $row1[0] . '" type="radio" value="0" /><b style="color:green">Read</b> <input name="accessVal' . $row1[0] . '" class="accessVal' . $row1[0] . '" type="radio" value="1" /><b style="color:red">Write </b><input name="accessVal' . $row1[0] . '" class="accessVal' . $row1[0] . '" type="radio" value="2" /><b style="color:blue">All</b> )</span></span>';
                $res .= $submenu;
            }
            $res .= '</li>';
        }
        $res .= '</ul>';

        $obj1->free();
        return $res;
    }

    public function configItems($data = NULL) {
        $sql = <<<EOD
            SELECT
                t1.tcd_slno SlNo,
                t1.tcd_id ItemID, 
                t1.TCD_VALUE ItemName,
                t1.TCD_DESC ItemDesc,
                t1.TCD_TYPE ConfType, 
             CASE
                WHEN t1.tcd_act_flg = 1
                   THEN 'Active'
                WHEN t1.tcd_act_flg != 1
                   THEN 'InActive'
             END AS Status
            FROM
                T_VHS_CODES t1
            WHERE
                t1.TCD_PARENT_ID IS NULL
                AND (t1.TCD_PLANT_ID = {$_SESSION['userSessionInfo']["TUS_PLNT"]} OR t1.TCD_PLANT_ID IS NULL )
            
EOD;
        if ($data['act'] == "searchItem") {
            $itemName = strtoupper($data['itemName']);
            $desc = strtoupper($data['desc']);
            if ($itemName) {
                $sql .= <<<EOD
                AND UPPER(t1.TCD_VALUE) LIKE '%{$itemName}%'
EOD;
            }
            if ($desc) {
                $sql .= <<<EOD
                AND UPPER(t1.TCD_DESC) LIKE '%{$desc}%'
EOD;
            }
            if ($data['status'] != "") {
                $sql .= <<<EOD
                AND t1.tcd_act_flg = {$data['status']}
EOD;
            }
        }
        $sql .= <<<EOD
                ORDER BY t1.tcd_slno ASC
EOD;
        $obj = new db_connect;
        $obj->db_query($sql);
        $res = '';
        $i = 0;
        while ($row = $obj->db_fetch_array()) {
            $res .= '<tr>'
                    . '<td id="slno">' . $row['SLNO'] . '</td>'
                    . '<td id="ITEMNAME">' . $row['ITEMNAME'] . '</td>'
                    . '<td id="ITEMDESC">' . $row['ITEMDESC'] . '</td>'
                    . '<td id="CONFTYPE">' . $row['CONFTYPE'] . '</td>'
                    . '<td id="STATUS">' . $row['STATUS'] . '</td>'
                    . '<td id="action"><a id="btnEdit" itemId="' . $row['ITEMID'] . '"   href="javascript:void(0)"><img src="images/edit.png"  title="Edit"/></a></td>'
                    . '</tr>';
        }
        $obj->free();
        return $res;
    }

    public function subConfigItems($data = NULL) {  //echo 'aruni';exit;
        $sql = <<<EOD
            SELECT
                t1.tcd_slno SlNo,
                t1.tcd_id SubItemID,
                t1.TCD_VALUE SubItemName,
                t1.TCD_DESC SubItemDesc,
                t1.TCD_PARENT_ID ItemID,
                t3.TCD_VALUE ItemName,
                t1.TCD_TYPE ConfType, 
             CASE
                WHEN t1.tcd_act_flg = 1
                   THEN 'Active'
                WHEN t1.tcd_act_flg != 1
                   THEN 'InActive'
             END AS Status
            FROM
                T_VHS_CODES t1,
                T_VHS_CODES t3
            WHERE
                t1.TCD_PARENT_ID = t3.tcd_id 
                AND t1.TCD_PARENT_ID IS NOT NULL
                AND t3.TCD_PARENT_ID IS NULL
                AND t3.tcd_act_flg = 1
                AND (t1.TCD_PLANT_ID = {$_SESSION['userSessionInfo']["TUS_PLNT"]} OR t1.TCD_PLANT_ID IS NULL )
            
EOD;
        if ($data['act'] == "searchSubItem") {
            $itemId = $data['itemId'];
            $subItemName = strtoupper($data['subItemName']);
            if ($itemId != "All") {
                $sql .= <<<EOD
                AND t1.TCD_PARENT_ID = '{$itemId}'
EOD;
            }
            if ($subItemName) {
                $sql .= <<<EOD
                AND UPPER(t1.TCD_VALUE) LIKE '%{$subItemName}%'
EOD;
            }
            if ($data['status'] != "All") {
                $sql .= <<<EOD
                AND t1.tcd_act_flg = '{$data['status']}'
EOD;
            }
        }
        $sql .= <<<EOD
                ORDER BY t3.tcd_slno, t1.tcd_slno ASC
EOD;
        $obj = new db_connect;
        $obj->db_query($sql);
        $res = '';
        $i = 0;
        while ($row = $obj->db_fetch_array()) {
            $res .= '<tr>'
                    . '<td id="slno">' . $row['SLNO'] . '</td>'
                    . '<td id="SUBITEMNAME">' . $row['SUBITEMNAME'] . '</td>'
                    . '<td id="SUBITEMDESC">' . $row['SUBITEMDESC'] . '</td>'
                    . '<td id="ITEMNAME">' . $row['ITEMNAME'] . '</td>'
                    . '<td id="CONFTYPE">' . $row['CONFTYPE'] . '</td>'
                    . '<td id="STATUS">' . $row['STATUS'] . '</td>'
                    . '<td id="action"><a id="btnEditSubCat" subitemId="' . $row['SUBITEMID'] . '"  itemId="' . $row['ITEMID'] . '" href="javascript:void(0)"><img src="images/edit.png"  title="Edit"/></a></td>'
                    . '</tr>';
        }
        $obj->free();
        return $res;
    }

    public function fillItemName() {
        $strSql = "SELECT 
                tcd_id, 
                tcd_value, 
                tcd_slno 
            FROM 
                T_VHS_CODES 
            WHERE 
                tcd_parent_id IS NULL 
                AND (tcd_plant_id = {$_SESSION['userSessionInfo']["TUS_PLNT"]} OR tcd_plant_id IS NULL )
                AND tcd_act_flg = 1 ORDER BY tcd_slno ASC";
        $obj = new db_connect;
        $obj->db_query($strSql);
        $res = '';
        $i = 0;
        while ($row = $obj->db_fetch_array()) {
            $res .= '<option  value="' . $row["TCD_ID"] . '">' . $row["TCD_VALUE"] . '</option>';
        }
        $obj->free();
        return $res;
    }

    public function GenDropDown($sql = "", $selVal = "") {
        $obj = new db_connect;
        $obj->db_query($sql);
        $Cols = '';
        while ($row = $obj->db_fetch_array()) {
            $Cols .= '<option value="' . $row[0] . '" ';
            if ($row[0] == $selVal) {
                $Cols .= ' selected';
            }
            $Cols .= ' >' . $row[1] . '</option>';
        }
        $obj->free();
        return $Cols;
    }

    public function plantsListing() {
        $strSql = "SELECT ";
        $strSql .= "   TEP_ID PlantID, ";
        $strSql .= "   TEP_NAME PlantName ";
        $strSql .= ", CASE
                WHEN TEP_ACT_FLG = 1
                   THEN 'Active'
                WHEN TEP_ACT_FLG != 1
                   THEN 'InActive'
             END AS Status ";
        $strSql .= " FROM ";
        $strSql .= "   t_erc_plant ";
        $strSql .= " ORDER BY ";
        $strSql .= "   TEP_ID ASC ";

        $obj = new db_connect;
        $obj->db_query($strSql);
        $res = '';
        while ($row = $obj->db_fetch_array()) {
            $res .= '<tr><td>' . $row[0] . '</td><td id="plantName">' . $row[1] . '</td><td id="status">' . $row[2] . '</td><td id="action"><a id="btnEdit" plantId="' . $row[0] . '" href="javascript:void(0)"><img src="images/edit.png"  title="Edit"/></a></td></tr>';
        }
        $obj->free();
        return $res;
    }

    public function tabListing() {

        $strOutput = "";
        $strSql = "SELECT 
				  TCD_ID,
				  TCD_PARENT_ID,
				  TCD_VALUE

				  FROM 
				  T_VHS_CODES
				  
				  WHERE  
				  TCD_ACT_FLG = 1 
				  AND TCD_PARENT_ID = 424 
				  ORDER BY TCD_SLNO ASC";
        $obj = new db_connect;
        $obj->db_query($strSql);
        $strOutput .= '<table  style="background-color:#EFF3FB;">';
        while ($row = $obj->db_fetch_array()) {
            $strOutput .= '<tr>';
            $strOutput .= '<td id="tabsTd"><a style="text-decoration:none;color:black;" href="javascript:void(0);" tabId="' . $row[0] . '" onclick="getMappedMenus(this);">' . $row[2] . '</a></td>';
            $strOutput .= '</tr>';
        }

        $strOutput .= '<td>';
        $strOutput .= '</td>';
        $strOutput .= '</table>';
        return $strOutput;
    }

    public function menuAssignToTab($tabId = NULL) {
        $strOutput = "";
        $strSql = "";
        $strSql .= "SELECT ";
        $strSql .= "t1.TTS_ID,";
        $strSql .= "t1.TTS_TAB_ID,";
        $strSql .= "t1.TTS_MENU_ID,";
        $strSql .= "t2.TMT_ID,";
        $strSql .= "t2.TMT_NAME,";
        $strSql .= "t1.TTS_ACCESS_LEVEL";
        $strSql .= " FROM T_VHS_TAB_MENU t1,T_VHS_MENU_TABS t2";
        $strSql .= " WHERE";
        $strSql .= " t1.TTS_MENU_ID = t2.TMT_ID";
        $strSql .= " AND t1.TTS_ACT_FLG = 1";
        $strSql .= " AND t2.TMT_ACT_FLG  = 1 ";
        if ($tabId) {
            $strSql .= " AND t1.TTS_TAB_ID  = $tabId ";
        }
        $obj = new db_connect;
        $obj->db_query($strSql);
        $strOutput .= '<table  style="background-color:#EFF3FB;" id="tblMappedMenus">';
        while ($row = $obj->db_fetch_array()) {
            $deptId = $row[0];
            $strOutput .= '<tr>';
            $strOutput .= '<td width="85%" data-menuid="' . $row[2] . '" class="menuAssigned"><div class="menuNameDiv">' . $row[4] . '</div>';
            if ($row[5] == 0) {
                $strOutput .= '<div style="float:right;margin-right:150px"><input type="radio" value="0" class="radioAcc accessVal' . $row[2] . '" name="accessVal' . $row[2] . '" checked="checked"><b style="color:green">Read</b> <input type="radio" value="1" class="radioAcc accessVal' . $row[2] . '" name="accessVal' . $row[2] . '"><b style="color:red">Write </b><input type="radio" value="2" class="radioAcc accessVal' . $row[2] . '" name="accessVal' . $row[2] . '"><b style="color:blue">None</b> </div>';
            } else if ($row[5] == 1) {
                $strOutput .= '<div style="float:right;margin-right:150px"><input type="radio" value="0" class="radioAcc accessVal' . $row[2] . '" name="accessVal' . $row[2] . '"><b style="color:green">Read</b> <input type="radio" value="1" class="radioAcc accessVal' . $row[2] . '" name="accessVal' . $row[2] . '" checked="checked"><b style="color:red">Write </b><input type="radio" value="2" class="radioAcc accessVal' . $row[2] . '" name="accessVal' . $row[2] . '"><b style="color:blue">None</b> </div>';
            } else {
                $strOutput .= '<div style="float:right;margin-right:150px"><input type="radio" value="0" class="radioAcc accessVal' . $row[2] . '" name="accessVal' . $row[2] . '"><b style="color:green">Read</b> <input type="radio" value="1" class="radioAcc accessVal' . $row[2] . '" name="accessVal' . $row[2] . '"><b style="color:red">Write </b><input type="radio" value="2" class="radioAcc accessVal' . $row[2] . '" name="accessVal' . $row[2] . '" checked="checked"><b style="color:blue">None</b> </div>';
            }
            $strOutput .= '</td>';
            $strOutput .= '<td>';
            $strOutput .= '<a class="gridHyperlink" href="javascript:void(0);" tabId="' . $tabId . '" menuId="' . $row[2] . '" onclick="deleteMenu(this);">Delete</a>';
            $strOutput .= '</td>';
            $strOutput .= '</tr>';
        }
        $strOutput .= '<tr>';
        $strOutput .= '<td width="85%"  id="lastTr">';
        $strOutput .= '<select  id="ddlMenu">';
        $strOutput .= '<option value="">Select</option>';
        $strOutput .= $this->GenDropDown("SELECT tmt_id , tmt_name, tmt_slno , tmt_act_flg FROM T_VHS_MENU_TABS WHERE TMT_ACT_FLG = 1  ORDER BY tmt_slno ASC");
        $strOutput .= '</select>';
        $strOutput .= '</td>';
        $strOutput .= '<td>';
        $strOutput .= '<a class="gridHyperlink" href="javascript:void(0);" tabId="' . $tabId . '"  onclick="addNewMenu(this);">Add</a>';
        $strOutput .= '</td>';
        $strOutput .= '</table>';
        return $strOutput;
    }

    public function array_columnDup($input = null, $columnKey = null, $indexKey = null) {
        // Using func_get_args() in order to check for proper number of
        // parameters and trigger errors exactly as the built-in array_columnDup()
        // does in PHP 5.5.
        $argc = func_num_args();
        $params = func_get_args();

        if ($argc < 2) {
            trigger_error("array_columnDup() expects at least 2 parameters, {$argc} given", E_USER_WARNING);
            return null;
        }

        if (!is_array($params[0])) {
            trigger_error(
                    'array_columnDup() expects parameter 1 to be array, ' . gettype($params[0]) . ' given', E_USER_WARNING
            );
            return null;
        }

        if (!is_int($params[1]) && !is_float($params[1]) && !is_string($params[1]) && $params[1] !== null && !(is_object($params[1]) && method_exists($params[1], '__toString'))
        ) {
            trigger_error('array_columnDup(): The column key should be either a string or an integer', E_USER_WARNING);
            return false;
        }

        if (isset($params[2]) && !is_int($params[2]) && !is_float($params[2]) && !is_string($params[2]) && !(is_object($params[2]) && method_exists($params[2], '__toString'))
        ) {
            trigger_error('array_columnDup(): The index key should be either a string or an integer', E_USER_WARNING);
            return false;
        }

        $paramsInput = $params[0];
        $paramsColumnKey = ($params[1] !== null) ? (string) $params[1] : null;

        $paramsIndexKey = null;
        if (isset($params[2])) {
            if (is_float($params[2]) || is_int($params[2])) {
                $paramsIndexKey = (int) $params[2];
            } else {
                $paramsIndexKey = (string) $params[2];
            }
        }

        $resultArray = array();

        foreach ($paramsInput as $row) {
            $key = $value = null;
            $keySet = $valueSet = false;

            if ($paramsIndexKey !== null && array_key_exists($paramsIndexKey, $row)) {
                $keySet = true;
                $key = (string) $row[$paramsIndexKey];
            }

            if ($paramsColumnKey === null) {
                $valueSet = true;
                $value = $row;
            } elseif (is_array($row) && array_key_exists($paramsColumnKey, $row)) {
                $valueSet = true;
                $value = $row[$paramsColumnKey];
            }

            if ($valueSet) {
                if ($keySet) {
                    $resultArray[$key] = $value;
                } else {
                    $resultArray[] = $value;
                }
            }
        }

        return $resultArray;
    }

    public function rolesListingTable() {
        $strSql = "SELECT ";
        $strSql .= "   TER_ID RoleID ";
        $strSql .= " , TER_NAME RoleName ";
        $strSql .= ", CASE
                WHEN TER_ACT_FLG = 1
                   THEN 'Active'
                WHEN TER_ACT_FLG != 1
                   THEN 'InActive'
             END AS Status ";
        $strSql .= " FROM ";
        $strSql .= "   T_VHS_ROLES ";
        $strSql .= " WHERE ";
        $strSql .= " TER_ACT_FLG =1 ";
        $strSql .= " ORDER BY ";
        $strSql .= "  TER_ID ASC ";

        $obj = new db_connect;
        $obj->db_query($strSql);
        $res = '';
        while ($row = $obj->db_fetch_array()) {
            $res .= '<tr>';
            $res .= '<td class="roleNameClm">' . $row[1] . '</td>';
            $res .= '<td class="statusClm">' . $row[2] . '</td>';
            $res .= '<td class="action"><a class="btnEditRole" href="javascript:void(0)" roleid="' . $row[0] . '"><img src="images/edit.png" title="Edit"  /></a></td>';

            $res .= '</tr>';
        }
        $res .= '<tr><td ><input placeholder="Enter Role Name" name="txtMenuName" id="txtRoleName" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td><td><select name="ddlStatus" style="width:99%" class="ddlFieldDropdown ddlStatusRole"><option value="1">Active</option><option value="0">InActive</option></select></td><td><a id="btnAddRole" href="javascript:void(0)"  onclick="saveRole()"><img src="images/add.png"  title="Add"/></td></tr>';
        $obj->free();
        return $res;
    }

    public function departments($plantId) {
        $obj = new db_connect;
        $obj->db_query("SELECT TED_ID, TED_NAME, CASE WHEN TED_ACT_FLG = 1 THEN 'Active' WHEN TED_ACT_FLG != 1 THEN 'InActive' END AS Status FROM T_VHS_DEPARTMENTS WHERE TED_PLANT=$plantId ORDER BY TED_NAME");
        $tr = '';
        $i = 1;
        while ($row = $obj->db_fetch_array()) {
            $tr .= '<tr><td>' . $i++ . '</td><td id="deptName">' . $row[1] . '</td><td id="status">' . $row[2] . '</td><td id="action"><a id="btnEdit" deptId="' . $row[0] . '" href="javascript:void(0)"><img src="images/edit.png" title="Edit"  /></a></td></tr>';
        }
        $obj->free();
        return $tr;
    }

    public function checklists($data = NULL) {
        $sql = <<<EOD
            SELECT NVL(t2.TCD_VALUE,'Not Assign') TABNAME ,
                t2.TCD_ID TABID,
                t1.TCH_CHK_ID,
                t1.TCH_SLNO,
                t1.TCH_CHECK_POINT,
                CASE
                WHEN t1.TCH_ACT_FLG = 1
                   THEN 'Active'
                WHEN t1.TCH_ACT_FLG != 1
                   THEN 'InActive'
                END AS Status,
                TO_CHAR(t1.TCH_EFFT_FROM,'dd-Mon-yyyy') TCH_EFFT_FROM,
                TO_CHAR(t1.TCH_EFFT_TO,'dd-Mon-yyyy') TCH_EFFT_TO,
                t1.TCH_PARENT_ID,
                NVL(t1.TCH_DATA_TYPE,'Not Assign') TCH_DATA_TYPE,
                t1.TCH_VALUE_SET,
                t1.TCH_INCRIMENTAL,
                t1.TCH_FORM_TYPE,
                t1.TCH_TAB_ID,
                nvl(t3.TCH_CHECK_POINT,'<b style="color:red">PARENT</b>') PARENTNAME
            FROM T_VHS_CHECK_HEAD t1,
                T_VHS_CODES t2,
                T_VHS_CHECK_HEAD t3
            WHERE T1.TCH_TAB_ID = t2.TCD_ID(+)
                AND T1.TCH_PARENT_ID = t3.TCH_CHK_ID(+)
            
EOD;
        if ($data['act'] == "searchCheckList") {
            $itemName = strtoupper($data['checkPoint']);
            if ($itemName) {
                $sql .= <<<EOD
                AND UPPER(t1.TCH_CHECK_POINT) LIKE '%{$itemName}%'
EOD;
            }
            if ($data['tabId'] != "") {
                $sql .= <<<EOD
                AND t1.TCH_TAB_ID = {$data['tabId']}
EOD;
            }
            if ($data['status'] != "") {
                $sql .= <<<EOD
                AND t1.TCH_ACT_FLG = {$data['status']}
EOD;
            }
        }
        $sql .= " ORDER BY T1.TCH_PARENT_ID DESC, T1.TCH_SLNO ASC,T3.TCH_SLNO ASC";
        $obj = new db_connect;
        $obj->db_query($sql);
        $res = '';
        $returnArr = array();
        while ($row = $obj->db_fetch_array()) {
            $orgArr[] = $row;
            if (!$row['TCH_PARENT_ID'])
                $returnArr[$row['TCH_CHK_ID']] = $row;
            else
                $returnArr[$row['TCH_PARENT_ID']][] = $row;
        }
        foreach ($returnArr as $rowPr) {
            $setVal = '';
            $srtIncmnt = '';
            if (isset($rowPr['TABNAME'])) {
                if (@$rowPr['TCH_VALUE_SET']) {
                    $setVal = implode(',', explode('##', $rowPr['TCH_VALUE_SET']));
                }
                if (@$rowPr['TCH_INCRIMENTAL']) {
                    $srtIncmnt = '<input type="checkbox" id="" class="" value="1" checked="checked" disabled="disabled">';
                }
                $slnoStyle = '';
                if (preg_match('/PARENT/', @$rowPr['PARENTNAME'])) {
                    $trStyle = "style='background-color: #f2f2f2;'";
                    $slnoStyle = "style='color:red;font-weight:bold'";
                }

                $res .= '<tr ' . @$trStyle . '>'
                        . '<td id="TCH_SLNO" ' . $slnoStyle . '>' . @$rowPr['TCH_SLNO'] . '</td>'
                        . '<td id="TCH_CHECK_POINT">' . @$rowPr['TCH_CHECK_POINT'] . '</td>'
                        . '<td id="PARENTNAME">' . @$rowPr['PARENTNAME'] . '</td>'
                        . '<td id="TABNAME">' . @$rowPr['TABNAME'] . '</td>'
                        . '<td id="TCH_DATA_TYPE">' . ucfirst(@$rowPr['TCH_DATA_TYPE']) . '</td>'
                        . '<td id="TCH_VALUE_SET">' . $setVal . '</td>'
                        . '<td id="TCH_EFFT_FROM">' . @$rowPr['TCH_EFFT_FROM'] . '</td>'
                        . '<td id="TCH_EFFT_TO">' . @$rowPr['TCH_EFFT_TO'] . '</td>'
                        . '<td id="TCH_INCRIMENTAL" style="text-align:center">' . $srtIncmnt . '</td>'
                        . '<td id="STATUS">' . @$rowPr['STATUS'] . '</td>'
                        . '<td id="action"><a id="btnEditChkList" checklistid="' . @$rowPr['TCH_CHK_ID'] . '"   href="javascript:void(0)"><img src="images/edit.png"  title="Edit"/></a></td>'
                        . '</tr>';
            }

            if (count($rowPr) != count($rowPr, COUNT_RECURSIVE)) {
                foreach ($rowPr as $rowChld) {
                    if (is_array($rowChld)) {
                        $setVal = '';
                        $srtIncmnt = '';
                        if ($rowChld['TCH_VALUE_SET']) {
                            $setVal = implode(',', explode('##', $rowChld['TCH_VALUE_SET']));
                        }
                        if ($rowChld['TCH_INCRIMENTAL']) {
                            $srtIncmnt = '<input type="checkbox" id="" class="" value="1" checked="checked" disabled="disabled">';
                        }

                        $res .= '<tr>'
                                . '<td id="TCH_SLNO">' . $rowChld['TCH_SLNO'] . '</td>'
                                . '<td id="TCH_CHECK_POINT">' . $rowChld['TCH_CHECK_POINT'] . '</td>'
                                . '<td id="PARENTNAME">' . $rowChld['PARENTNAME'] . '</td>'
                                . '<td id="TABNAME">' . $rowChld['TABNAME'] . '</td>'
                                . '<td id="TCH_DATA_TYPE">' . ucfirst($rowChld['TCH_DATA_TYPE']) . '</td>'
                                . '<td id="TCH_VALUE_SET">' . $setVal . '</td>'
                                . '<td id="TCH_EFFT_FROM">' . $rowChld['TCH_EFFT_FROM'] . '</td>'
                                . '<td id="TCH_EFFT_TO">' . $rowChld['TCH_EFFT_TO'] . '</td>'
                                . '<td id="TCH_INCRIMENTAL" style="text-align:center">' . $srtIncmnt . '</td>'
                                . '<td id="STATUS">' . $rowChld['STATUS'] . '</td>'
                                . '<td id="action"><a id="btnEditChkList" checklistid="' . $rowChld['TCH_CHK_ID'] . '"   href="javascript:void(0)"><img src="images/edit.png"  title="Edit"/></a></td>'
                                . '</tr>';
                    }
                }
            }
        }
        $obj->free();
        return $res;
    }

}

$admin = new Adminclass();
?>