<?php

ini_set('post_max_size ', '128M'); // or you could use 1G
$ref = 'on';
include("admin_class.php");
date_default_timezone_set("Asia/Calcutta");

if (!isset($_SESSION['userSessionInfo']['TUS_UID'])) {
    unset($_SESSION['Logout']);
    echo $_SESSION['userSessionInfo']['TUS_UID'];
    exit;
}
if (isset($_REQUEST["act"])) {
    switch ($_REQUEST["act"]) {
        case "update":
            echo update_item($_REQUEST);
            break;
        case "addItem":
            echo add_item($_REQUEST);
            break;
        case "searchItem":
            echo $admin->configItems($_REQUEST);
            break;
        case "updateSubItem":
            echo update_subItem($_REQUEST);
            break;
        case "addSubItem":
            echo add_subItem($_REQUEST);
            break;
        case "searchSubItem":
            echo $admin->subConfigItems($_REQUEST);
            break;
        default:
            echo "Something Wrong! Please Contact System Admin";
    }
}

function update_item($data) {
    if ($data['confType'] == "C") {
        $tcd_plant_id = "NULL";
    } else {
        $tcd_plant_id = $_SESSION['userSessionInfo']["TUS_PLNT"];
    }
    $sqlUpdate = <<<EOD
            UPDATE 
                T_VHS_CODES
            SET 
                tcd_value = '{$data['itemName']}', 
                tcd_desc = '{$data['itemDesc']}', 
                tcd_slno = {$data['slNo']}, 
                tcd_act_flg = {$data['status']}, 
                tcd_upd_by = {$_SESSION['userSessionInfo']['TUS_UID']}, 
                tcd_upd_ts = SYSDATE, 
                tcd_type = '{$data['confType']}', 
                tcd_plant_id = $tcd_plant_id
            WHERE 
                tcd_id = {$data['itemid']}
EOD;
    $obj = new db_connect;
    $obj->db_query($sqlUpdate);
    $obj->free();
    return '0';
}

function add_item($data) {
    if ($data['confType'] == "C") {
        $tcd_plant_id = "NULL";
    } else {
        $tcd_plant_id = $_SESSION['userSessionInfo']["TUS_PLNT"];
    }
    $obj = new db_connect;
    $row = $obj->db_reader("Select nvl(max(to_number(TCD_ID)),0)+1 ID from T_VHS_CODES ");
    $sqlInsert = <<<EOD
        INSERT INTO
                T_VHS_CODES
                    (
                        tcd_id,
                        tcd_parent_id,
                        tcd_slno,
                        tcd_act_flg,
                        tcd_type,
                        tcd_plant_id,
                        tcd_value,
                        tcd_desc,
                        tcd_crt_by,
                        tcd_crt_ts,
                        tcd_upd_by,
                        tcd_upd_ts
                    )
        VALUES
            (
                {$row["ID"][0]},
                NULL,
                {$data['slNo']},
                {$data['status']},
                '{$data['confType']}',
                $tcd_plant_id,
                '{$data['itemName']}',
                '{$data['itemDesc']}',
                {$_SESSION['userSessionInfo']['TUS_UID']},
                SYSDATE,
                {$_SESSION['userSessionInfo']['TUS_UID']},
                SYSDATE
            ) 
EOD;
    $obj = new db_connect;
    $obj->db_insert($sqlInsert);
    $obj->free();
    $data['status'] = 1 ? "Active" : "InActive";
    $returnStr = <<<EOD
            <tr>
                <td id="slno">{$data['slNo']}</td>
                <td id="ITEMNAME">{$data['itemName']}</td>
                <td id="ITEMDESC">{$data['itemDesc']}</td>
                <td id="CONFTYPE">{$data['confType']}</td>
                <td id="STATUS">{$data['status']}</td>
                <td id="action"><a href="javascript:void(0)" itemid="{$row["ID"][0]}" id="btnEdit"><img title="Edit" src="images/edit.png"></a></td>
            </tr>
EOD;
    return $returnStr;
}

function update_subItem($data) {
    if ($data['confType'] == "C") {
        $tcd_plant_id = "NULL";
    } else {
        $tcd_plant_id = $_SESSION['userSessionInfo']["TUS_PLNT"];
    }

    $sqlUpdate = <<<EOD
            UPDATE 
                T_VHS_CODES
            SET 
                tcd_value = '{$data['subItemName']}', 
                tcd_desc = '{$data['itemDesc']}', 
                tcd_parent_id = {$data['itemid']},
                tcd_id = {$data['subitemid']},
                tcd_slno = {$data['slNo']},
                tcd_act_flg = {$data['status']},
                tcd_upd_by = {$_SESSION['userSessionInfo']['TUS_UID']},
                tcd_upd_ts = SYSDATE,
                tcd_type = '{$data['confType']}', 
                tcd_plant_id = $tcd_plant_id
            WHERE 
                tcd_id = {$data['subitemid']}
EOD;
    $obj = new db_connect;
    $obj->db_query($sqlUpdate);
    $obj->free();
    return '0';
}

function add_subItem($data) {
    if ($data['confType'] == "C") {
        $tcd_plant_id = "NULL";
    } else {
        $tcd_plant_id = $_SESSION['userSessionInfo']["TUS_PLNT"];
    }
    $obj = new db_connect;
    $tcdIdNew = $obj->db_reader("Select nvl(max(to_number(TCD_ID)),0)+1 ID from T_VHS_CODES ");
    $sqlInsert = <<<EOD
        INSERT INTO
                T_VHS_CODES
                    (
                        tcd_id,
                        tcd_parent_id,
                        tcd_slno,
                        tcd_act_flg,
                        tcd_type,
                        tcd_plant_id,
                        tcd_value,
                        tcd_desc,
                        tcd_crt_by,
                        tcd_crt_ts,
                        tcd_upd_by,
                        tcd_upd_ts
                    )
        VALUES
            (
                {$tcdIdNew["ID"][0]},
                {$data['parentItemId']},
                {$data['slNo']},
                {$data['status']},
                '{$data['confType']}',
                $tcd_plant_id,
                '{$data['subItemName']}',
                '{$data['subItemDesc']}',
                {$_SESSION['userSessionInfo']['TUS_UID']},
                SYSDATE,
                {$_SESSION['userSessionInfo']['TUS_UID']},
                SYSDATE
            ) 
EOD;

    $obj = new db_connect;
    $obj->db_insert($sqlInsert);
    $obj->free();
    $data['status'] = 1 ? "Active" : "InActive";
    $returnStr = <<<EOD
            <tr>
                <td id="slno">{$data['slNo']}</td>
                <td id="SUBITEMNAME">{$data['subItemName']}</td>
                <td id="SUBITEMDESC">{$data['subItemDesc']}</td>
                <td id="ITEMNAME">{$data['itemName']}</td>
                <td id="CONFTYPE">{$data['confType']}</td>
                <td id="STATUS">{$data['status']}</td>
                <td id="action"><a id="btnEditSubCat" subitemId="{$tcdIdNew["ID"][0]}" itemId="{$data['parentItemId']}" href="javascript:void(0)"><img src="images/edit.png"  title="Edit"/></a></td>
            </tr>
EOD;
    return $returnStr;
}

?>