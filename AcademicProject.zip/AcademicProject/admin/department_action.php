<?php

$ref = 'on';
include("../db_classes/commanvar.php");
include("../db_classes/class.db.php");
date_default_timezone_set("Asia/Calcutta");

if ($_REQUEST["act"] == 'Add') {
    $obj = new db_connect;
    $row = $obj->db_reader("Select nvl(max(to_number(TED_ID)),0)+1 ID from T_VHS_DEPARTMENTS ");
    $id = $row["ID"][0];

    $strSql = "INSERT INTO T_VHS_DEPARTMENTS ";
    $strSql .= " ( ";
    $strSql .= "   TED_ID ";
    $strSql .= " , TED_NAME ";
    $strSql .= " , TED_ACT_FLG ";
    $strSql .= " , TED_PLANT ";
    $strSql .= " , TED_CRT_BY ";
    $strSql .= " , TED_CRT_TS ";
    $strSql .= " , TED_UPD_BY ";
    $strSql .= " , TED_UPD_TS ";
    $strSql .= " ) ";
    $strSql .= " VALUES ";
    $strSql .= " ( ";
    $strSql .= $id;
    $strSql .= " , '" . $_REQUEST["deptName"] . "', ";
    $strSql .= $_REQUEST["status"] . ",";
    $strSql .= $_SESSION['userSessionInfo']["TUS_PLNT"] . ",";
    $strSql .= $_SESSION['userSessionInfo']['TUS_UID'];
    $strSql .= " , SYSDATE ,";
    $strSql .= $_SESSION['userSessionInfo']['TUS_UID'];
    $strSql .= " , SYSDATE ";
    $strSql .= " ) ";


    $obj = new db_connect;
    $obj->db_insert($strSql);
    $obj->free();

    echo '<tr><td></td><td id="deptName">' . $_REQUEST["deptName"] . '</td><td id="status">' . $_REQUEST["statusStr"] . '</td><td id="action"><a id="btnEdit" deptId="' . $id . '" href="javascript:void(0)"><img src="images/edit.png" title="Edit"  /></a></td></tr>';
    exit;
} else if ($_REQUEST["act"] == 'Update') {
    $strSql = "UPDATE T_VHS_DEPARTMENTS ";
    $strSql .= " SET TED_NAME = '" . $_REQUEST["deptName"] . "'";
    $strSql .= " , TED_ACT_FLG = '" . $_REQUEST["status"] . "' ";
    $strSql .= " , TED_UPD_BY = '" . $_SESSION['userSessionInfo']['TUS_UID'] . "' ";
    $strSql .= " , TED_UPD_TS = SYSDATE ";
    $strSql .= " WHERE TED_ID = '" . $_REQUEST["deptId"] . "' ";
    $obj = new db_connect;
    $obj->db_insert($strSql);
    $obj->free();
}
?>