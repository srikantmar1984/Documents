<input type="hidden" id="hfPageTitle" value="Check Points" screen_id="configitems_aspx">
<?php include 'admin_class.php'; ?>
<div id="tabFilter" class="kks-tabs"  data-options="border:false" >
    <div title="Search" data-options="iconCls:'icon-search'" >  
        <form action="" method="post" name="frmRoles" id="frmChkList">
            <div id="filterid">
                <div class="filter filterhead">								
                    <table width="100%"  cellpadding="1" cellspacing="1">
                        <tr class="trheader">		
                            <td>
                                <span>Search Criteria</span>					
                            </td>
                            <td style="text-align:right;padding-right:5px;">
                                <a href="javascript:void(0)" class="toggleExpand" onclick="toggleExpand(this);" ><img src="./images/collapse.jpg" alt="expand/collapse" /></a>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="filter filterrow">
                    <table cellpadding="0" cellspacing="1" width="99%" style="line-height:20px">
                        <tr>
                            <td class="tdcap" style="width:15%;">Check Point Name</td>
                            <td class="tdfield" style="width:20%;">
                                <input name="txtSrcChkPnt" id="txtSrcChkPnt" type="text" style="width:99%" width="99%" class="txtFieldTextBox " />
                            </td>
                            <td class="tdcap" style="width:10%;">Tab Name</td>
                            <td class="tdfield" style="width:20%;">
                                <select id="ddlFilterTabId" class="ddlFieldDropdown">
                                    <option value="">All</option>
                                    <?php
                                    $sql = $strSql = "SELECT TCD_ID,TCD_VALUE FROM T_VHS_CODES WHERE TCD_ACT_FLG = 1 AND TCD_PARENT_ID = 424 ORDER BY TCD_SLNO ASC";
                                    echo $admin->GenDropDown($sql);
                                    ?>
                                </select>
                            </td>
                            <td class="tdcap" style="width:15%;">Status</td>
                            <td class="tdfield" style="width:20%;"><select id="ddlSrcChkPntStatus" name="ddlSrcNotfyStatus" style="width:99%" class="ddlFieldDropdown">
                                    <option value="">All</option>
                                    <option value="1">Active</option>
                                    <option value="0">InActive</option>
                                </select></td>
                        </tr>
                        <tr>
                            <td style="height: 40px" class="tdfield" colspan="6" align="left"> <a href="javascript:void(0)" class="kks-linkbutton" onclick="searchCheckPointData()">Search</a></td>
                        </tr>
                        <tr style="height: 25Px;">
                            <td colspan="20" style="background-color: #FFFFE6; padding-left: 5px; text-align: left;">
                                <span class="label-vhs"><mark>Note:</mark></span>
                                <span><mark style="color: red;margin-bottom: 5px;">***Please put comma while entering multiple value in 'Set Value'.&nbsp;&nbsp;  <b>Just like :- OK,NOT OK,NA</b></mark> </span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </form>
        <div class="Grid">
            <form action="" method="post" name="frmAddChkLst" id="frmAddChkLst">
                <table cellpadding="0" cellspacing="0" id="grdRoels">
                    <thead>
                        <tr>
                            <th width="5%">SL.No.</th>
                            <th width="23%">Check Point</th>
                            <th width="23%">Parent Check Point</th>
                            <th width="10%">Tab Name</th>
                            <th width="5%">Data Type</th>
                            <th width="10%">Set Value</th>
                            <th width="5%">Effect From</th>
                            <th width="5%">Effect To</th>
                            <th width="5%">Incremental</th>
                            <th width="5%">Status</th>
                            <th width="5%">Action</th>
                        </tr>
                    </thead>
                    <tbody id="footer" class="addForm">
                        <tr style="background-color: rgb(247, 246, 243); font-weight: bolder;">
                            <td><input name="addSlno" id="addSlno" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td>
                            <td><input name="addCheckPoint" id="addCheckPoint" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td>
                            <td>
                                <select id="addParentId" name="addParentId" style="width:99%" class="ddlFieldDropdown">
                                    <option value="">--Select Parent(if applicable)--</option>
                                    <?php
                                    $sql = $strSql = "SELECT TCH_CHK_ID,TCH_CHECK_POINT FROM T_VHS_CHECK_HEAD WHERE TCH_ACT_FLG = 1 ORDER BY TCH_CHK_ID ASC";
                                    echo $admin->GenDropDown($sql);
                                    ?>
                                </select>
                            </td>
                            <td>
                                <select id="addTabId" name="addTabId" style="width:99%" class="ddlFieldDropdown">
                                    <?php
                                    $sql = $strSql = "SELECT TCD_ID,TCD_VALUE FROM T_VHS_CODES WHERE TCD_ACT_FLG = 1 AND TCD_PARENT_ID = 424 ORDER BY TCD_SLNO ASC";
                                    echo $admin->GenDropDown($sql);
                                    ?>
                                </select>
                            </td>
                            <td>
                                <select id="addDataType" name="addDataType" style="width:99%" class="ddlFieldDropdown">
                                    <option value="">None</option>
                                    <option value="Text">Text</option>
                                    <option value="Radio">Radio</option>
                                    <option value="Dropdown">DropDown</option>
                                    <option value="CheckBox">CheckBox</option>
                                    <option value="File">File</option>
                                </select>
                            </td>
                            <td><input name="addSetValue" id="addSetValue" type="text" style="width:99%" width="99%" class="txtFieldTextBox" /></td>
                            <td><input name="addEffectFrom" id="addEffectFrom" type="text" style="width:99%" width="99%" class="txtFieldTextBox required datepicker" /></td>
                            <td><input name="addEffectTo" id="addEffectTo" type="text" style="width:99%" width="99%" class="txtFieldTextBox" disabled="disabled" value="01-Jan-9999"/></td>
                            <td style="text-align:center"><input type="checkbox" id="addIncremnt" class="" value="1"></td>
                            <td >
                                <select id="addStatus" name="addStatus" style="width:99%" class="ddlFieldDropdown">
                                    <option value="1">Active</option>
                                    <option value="0">InActive</option>
                                </select>
                            </td>
                            <td width="8%"><a id="btnAddChkPnt" href="javascript:void(0)"><img src="images/add.png"  title="Add"/></a></td>
                        </tr>
                    </tbody>
                    <tbody id="res">
                        <?php echo $admin->checklists() ?>       
                    </tbody>

                    <tbody id="tr_clone" style="display:none"></tbody>
                </table>
            </form>
        </div>   

    </div>
</div>
</div>
<script type="text/javascript" >
    var url = wwwRoot + "/admin/checkpoint_action.php";
    $(document).ready(function () {
        $('.layout-button-left').trigger('click');
        $('.datepicker').live('focus', function () {
            $(this).datepick({showOnFocus: true, dateFormat: 'dd-M-yyyy'
            }).attr('readonly', 'readonly');
        });
        $("#btnAddChkPnt").die('click').click(function (event) {
            validateItem('addForm');
            var parentTr = $(this).closest('tr');
            var slNo = $("#addSlno").val().trim();
            var checkPnt = $("#addCheckPoint").val().trim();
            var parentId = $("#addParentId").val().trim();
            var tabId = $("#addTabId").val().trim();
            var dataType = $("#addDataType").val().trim();
            var setVal = $("#addSetValue").val().trim();
            var effectFrm = $("#addEffectFrom").val().trim();
            var effectTo = $("#addEffectTo").val().trim();
            var status = $("#addStatus").val().trim();
            var incremental = '';
            if ($('#addIncremnt').is(":checked")) {
                incremental = $("#addIncremnt").val().trim();
            }
            $.ajax({
                type: 'POST', url: url,
                data: {
                    act: 'addCheckList',
                    slNo: slNo,
                    checkPnt: checkPnt,
                    parentId: parentId,
                    tabId: tabId,
                    dataType: dataType,
                    setVal: setVal, effectFrm: effectFrm,
                    effectTo: effectTo,
                    incremental: incremental,
                    status: status
                },
                success: function (data, textStatus, jqXHR) {
                    if (textStatus == "success") {
                        searchCheckPointData();
                        $('#frmAddChkLst')[0].reset();
                        $("#tr_clone").html('');
                    }
                }
            });
        });

        $('#btnEditChkList').die('click').live('click', function () {
            if ($("#tr_clone").html() != '') {
                alert("Please complete your previous action!");
            } else {
                var parentTr = $(this).closest('tr');
                $("#tr_clone").html(parentTr.clone());
                var chkLstId = $(this).attr('checklistid');
                var td0 = parentTr.find("#TCH_SLNO");
                td0.html('<input id="editSlno" type="text" value="' + td0.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');
                var td1 = parentTr.find("#TCH_CHECK_POINT");
                td1.html('<input id="editCheckPoint" type="text" value="' + td1.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');
                var td2 = parentTr.find("#PARENTNAME");
                var td2Text = td2.text().trim();
                td2.html($("#addParentId").clone().attr({'id': 'editParentId', 'name': 'editParentId'}));
                if (td2Text != "PARENT") {
                    $("#editParentId option:contains('" + td2Text + "')").attr('selected', true);
                }
                var td3 = parentTr.find("#TABNAME");
                var td3Text = td3.text().trim();
                td3.html($("#addTabId").clone().attr({'id': 'editTabId', 'name': 'editTabId'}));
                if (td3Text != "Not Assign") {
                    $("#editTabId option:contains('" + td3Text + "')").attr('selected', true);
                }
                var td4 = parentTr.find("#TCH_DATA_TYPE");
                var td4Text = td4.text().trim();
                td4.html($("#addDataType").clone().attr({'id': 'editDataType', 'name': 'editDataType'}));
                if (td4Text != "Not Assign") {
                    $("#editDataType option:contains('" + td4Text + "')").attr('selected', true);
                }
                var td5 = parentTr.find("#TCH_VALUE_SET");
                td5.html('<input id="editSetValue" type="text" value="' + td5.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');
                var td6 = parentTr.find("#TCH_EFFT_FROM");
                td6.html('<input id="editEffectFrom" type="text" value="' + td6.text() + '" style="width:99%"  class="txtFieldTextBox required datepicker"  />');
                var td7 = parentTr.find("#TCH_EFFT_TO");
                td7.html('<input id="editEffectTo" type="text" value="' + td7.text() + '" style="width:99%"  class="txtFieldTextBox required datepicker"  />');
                var td8 = parentTr.find("#TCH_INCRIMENTAL");
                var strChk = '';
                if (td8.find('input').length) {
                    strChk = 'checked="checked"';
                }
                td8.html('<input type="checkbox" value="1" class=""' + strChk + ' id="addIncremnt">');
                var ch9 = parentTr.find("#STATUS");
                var status = (ch9.text() === "Active") ? '<option value="1" selected="true">Active</option><option value="0">InActive</option>' : '<option value="1">Active</option><option value="0" selected="true" >InActive</option>';
                ch9.html('<select id="ddlStatus" name="ddlStatus" style="width:99%" class="ddlFieldDropdown">' + status + '</select>');
                var ch10 = parentTr.find("#action");
                ch10.html('<a id="btnUpdateChkLst" checklistid="' + chkLstId + '" href="javascript:void(0)"><img src="images/accept.png" title="Update"  /></a> &nbsp; <a id="btnCancel" href="javascript:void(0)"><img src="images/cancel.png" title="Cancel"  /></a>');
            }
        });

        $('#btnUpdateChkLst').die('click').live('click', function () {
            var checkListId = $(this).attr('checklistid');
            var parent = $(this).closest('tr');
            var slNo = parent.find("#editSlno").val().trim();
            var checkPnt = parent.find("#editCheckPoint").val().trim();
            var parentId = parent.find("#editParentId").val().trim();
            var tabId = parent.find("#editTabId").val().trim();
            var dataType = parent.find("#editDataType").val().trim();
            var setVal = parent.find("#editSetValue").val().trim();
            var effectFrm = parent.find("#editEffectFrom").val().trim();
            var effectTo = parent.find("#editEffectTo").val().trim();
            var incremental = '';
            if (parent.find("#addIncremnt").is(":checked")) {
                incremental = parent.find("#addIncremnt").val().trim();
            }
            var status = parent.find("#ddlStatus").val().trim();
            var statusText = parent.find("#ddlStatus option:selected").text();
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    act: 'updateCheckList',
                    slNo: slNo,
                    checkListId: checkListId,
                    checkPnt: checkPnt,
                    parentId: parentId,
                    tabId: tabId,
                    dataType: dataType,
                    setVal: setVal,
                    effectFrm: effectFrm,
                    effectTo: effectTo,
                    incremental: incremental, status: status
                },
                success: function (data, textStatus, jqXHR) {
                    if (textStatus == "success") {
                        searchCheckPointData();
                        $("#tr_clone").html('');
                    }
                }
            });
        });

        $('#btnCancel').die('click').live('click', function () {
            var parent = $(this).closest('tr');
            parent.replaceWith($("#tr_clone").html());
            $("#tr_clone").html('');

        });
    });

    function validateItem(tblId) {
        $("." + tblId + " .required").each(function () {
            var isValid = 0;
            if ($(this).attr('type') == 'text') {
                if (!$(this).val().trim()) {
                    isValid = 1;
                }
            } else if ($(this).attr('type') == 'checkbox') {
                if (!$(this).is(':checked')) {
                    isValid = 1;
                }
            }
            if (isValid) {
                $(this).addClass('error');
                $(this).focus();
                alert('Please fill all * mark field or red border mark field');
                exit();
            } else {
                $(this).removeClass('error');
            }

        });
    }

    function searchCheckPointData() {
        var checkPoint = $("#txtSrcChkPnt").val().trim();
        var tabId = $("#ddlFilterTabId").val().trim();
        var status = $("#ddlSrcChkPntStatus").val();
        $.ajax({
            type: 'POST',
            url: url,
            data: {
                act: 'searchCheckList',
                checkPoint: checkPoint,
                tabId: tabId,
                status: status
            }, success: function (data, textStatus, jqXHR) {
                if (textStatus == "success") {
                    var str = data.indexOf("Error");
                    if (str == '-1') {
                        $("#res").html(data);
                    } else {
                        alert('Error During Submit !');
                        hideProgress();
                        exit();
                    }
                }
            }
        });
    }
</script>