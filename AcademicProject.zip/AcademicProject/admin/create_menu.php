<style type="text/css">
    .activeTd{color:green!important;font-weight: bold!important; }
    .errorTd{color:red!important;font-weight: bold!important;}
</style>
<script type="text/javascript">
    $(function () {
        $('.sorted_table').sortable({
            containerSelector: 'table',
            itemPath: '> tbody',
            itemSelector: 'tr',
            placeholder: '<tr class="placeholder"/>',
            onDrop: function ($item, container, _super) {
                var slnoChIdObj = [];
                var parentId = $item.attr('parent_id');
                $item.closest('table').find('tbody tr').each(function (i, row) {
                    row = $(row);
                    if ($(this).attr('child_id')) {
                        slnoChIdObj.push({'slno': row.index(), 'menuId': $(this).attr('child_id')})

                    }
                })
                if (!$.isEmptyObject(slnoChIdObj)) {
                    $.post(url, {slnoChIdObj: slnoChIdObj, parentId: parentId, act: "reorder"}, function (data) {
                        var str = data.indexOf("Query Error");
                        if (str == '-1') {
                            $("#res").html(data);
                        } else {
                            alert('Error !');
                        }
                        return false;
                    })
                }

            }
        });
        $('.layout-button-left').trigger('click');
        $(".statusClm").each(function () {
            if ($(this).text().trim() == "Active") {
                $(this).removeClass('errorTd');
                $(this).addClass('activeTd');
            } else {
                $(this).removeClass('activeTd');
                $(this).addClass('errorTd');
            }
        })
    })
    var url = wwwRoot + "/admin/menu_action.php";
    $("#btnSelectMenu").click(function () {
        $("#allMenu > option:selected").each(function () {
            $(this).remove().appendTo("#SelectedMenu");
        });
    });

    $("#btnRemoveMenu").click(function () {
        $("#SelectedMenu > option:selected").each(function () {
            $(this).remove().appendTo("#allMenu");
        });
    });

    function search_submenu(vId) {
        $.post(url, {id: vId, act: 'Ajax'},
                function (data) {
                    var str = data.indexOf("Query Error");
                    if (str == '-1') {
                        $("#res").html(data);
                    } else {
                        alert('Error !');
                        exit();
                    }
                    return false;

                }
        );
    }
    function saveMenu() {
        var parentId = $("#btnAdd").attr('parentid');

        var MenuName = $("#txtMenuName").val();
        var urlData = $("#txtUrl").val();
        var status = $("#ddlStatus").val();
        var AppId = $("#ddlApplication").val();
        var AppName = $("#ddlApplication option:selected").text();
        $.post(url,
                {
                    MenuName: MenuName,
                    urlData: urlData,
                    AppId: AppId,
                    AppName: AppName,
                    status: status,
                    parentId: parentId,
                    act: 'Add'
                }, function (data)
        {
            var str = data.indexOf("Query Error");
            if (str == '-1')
            {
                $("#res").append(data);

                var i = 1;
                $('#res td:nth-child(1)').each(function () {

                    $(this).text(i++);
                });

                $("#txtMenuName").val("");
                $("#txtUrl").val("");
            } else
            {
                alert('Error During Insert !');
                exit();
            }
            return false;

        });
    }
    $('#btnEdit').die('click').live('click', function () {
        var menu_id = $(this).attr('attr');
        var parent = $(this).parent().parent();
        var ch = parent.find("#menu");
        ch.html('<input id="txtEMenu" type="text" value="' + ch.text() + '" style="width:99%"  class="txtFieldTextBox"  />');
        var ch1 = parent.find("#url");
        ch1.html('<input id="txtEurl" type="text" value="' + ch1.text() + '" style="width:99%"  class="txtFieldTextBox"  />');

        var ch2 = parent.find("#app");


        var app_list = '<select id="ddlEapp" name="ddlEapp" style="width:99%" class="ddlFieldDropdown">';
        var i = 0;
        $('#ddlApplication option').each(function () {
            var thevalue = $(this).val();
            var thetext = $(this).text();
            app_list += '<option  value="' + thevalue + '" ';
            if (thetext === ch2.text())
            {
                app_list += ' selected';
            }
            app_list += ' >' + thetext + '</option>';

        });
        app_list += '</select>';
        ch2.html(app_list);

        var ch3 = parent.find("#status");
        var status = (ch3.text() === "Active") ? '<option value="1" selected="true">Active</option><option value="0">InActive</option>' : '<option value="1">Active</option><option value="0" selected="true" >InActive</option>';
        ch3.html('<select id="ddlStatus" name="ddlStatus" style="width:99%" class="ddlFieldDropdown">' + status + '</select>');
        var ch4 = parent.find("#action");
        ch4.html('<a id="btnUpdate" href="javascript:void(0)" attr="' + menu_id + '"><img src="images/accept.png" title="Update"  /></a> &nbsp; <a id="btnCancel" href="javascript:void(0)" attr="' + menu_id + '"><img src="images/cancel.png" title="Cancel"  /></a>');


    });

    $('#btnCancel').die('click').live('click', function () {
        var menu_id = $(this).attr('attr');

        var parent = $(this).parent().parent();
        var ch = parent.find("#menu");
        ch.html(parent.find("#txtEMenu").val());
        var ch1 = parent.find("#url");
        ch1.html(parent.find("#txtEurl").val());
        var ch0 = parent.find("#app");
        ch0.html(parent.find("#ddlEapp option:selected").text());
        var ch2 = parent.find("#status");
        ch2.html(parent.find("#ddlStatus").val());
        var ch3 = parent.find("#action");
        ch3.html('<a id="btnEdit" href="javascript:void(0)"  attr="' + menu_id + '" ><img src="images/edit.png" title="Edit" /></a>');
    });

    $('#btnUpdate').die('click').live('click', function () {
        var menu_id = $(this).attr('attr');

        var parent = $(this).parent().parent();

        var ch = parent.find("#menu");
        var menuname = parent.find("#txtEMenu").val();
        ch.html(menuname);

        var ch1 = parent.find("#url");
        var urldata = parent.find("#txtEurl").val();
        ch1.html(urldata);

        var ch2 = parent.find("#app");
        var app_id = parent.find("#ddlEapp").val();
        var app_name = parent.find("#ddlEapp option:selected").text();
        ch2.html(app_name);

        var ch3 = parent.find("#status");
        var status = parent.find("#ddlStatus").val();
        var statusTxt = parent.find("#ddlStatus option:selected").text();
        ch3.html(statusTxt);

        $.post(url,
                {
                    id: menu_id,
                    MenuName: menuname,
                    urlData: urldata,
                    AppId: app_id,
                    status: status,
                    act: 'Update'
                }, function (data)
        {
            var str = data.indexOf("Query Error");
            if (str == '-1')
            {
                alert('change sucessfully');
                var ch3 = parent.find("#action");
                ch3.html('<a id="btnEdit" href="javascript:void(0)" attr="' + menu_id + '"><img src="images/edit.png" title="Edit"  /></a> ');
            } else
            {
                alert('Error During Insert !');
                exit();
            }
            return false;
        });
    });


    $('#chkroles').die('click').live('change', function () {
        if ($(this).attr("checked")) {
            $(":checkbox").each(function () {
                $(this).attr("checked", "");
            });
        } else {
            $(":checkbox").each(function () {
                $(this).removeAttr("checked");
            });
        }

    });

    $('#lnkrole').die('click').live('click', function () {
        $('#resRole tr').each(function () {
            $(this).css("background-color", "");
            $(this).find(".chkrole").removeAttr("checked");
        });

        var p = $(this).parent().parent();
        p.find(".chkrole").attr("checked", "");
        p.css("background-color", "#d1ddf1");
        $.post(url,
                {
                    role_id: $(this).attr('roleid'),
                    plantId: $(".selectPlant a").attr('plantid'),
                    act: 'AjaxMenu'
                }, function (data) {
            var str = data.indexOf("Query Error");
            if (str == '-1') {
                parseObj = $.parseJSON(data);
                var menuArr = parseObj.menuId;
                var accLvlArr = parseObj.accessLevel;
                $('#resMenu ul li').each(function () {
                    var menuId = $(this).find("#chkmenu").attr('menu_id');
                    if ($.inArray(menuId, menuArr) != -1) {
                        $(this).find(".accessVal" + menuId).each(function () {
                            if ($(this).val() == accLvlArr["menuid" + menuId]) {
                                $(this).attr('checked', true);
                            }
                        })
                        $(this).find(".tree-checkbox").removeClass("tree-checkbox0").addClass("tree-checkbox1");
                    } else {
                        $(this).find(".tree-checkbox").removeClass("tree-checkbox1").addClass("tree-checkbox0");
                    }
                });
            } else {
                alert('Error !');
            }
            return false;

        });
    });

    $('.lnklocations').die('click').live('click', function () {
        $('#resLocation tr').each(function () {
            $(this).css("background-color", "");
            $(this).removeClass("selectPlant");
        });
        var p = $(this).parent().parent();
        p.css("background-color", "#d1ddf1");
        p.addClass("selectPlant");

        $(":checkbox").each(function () {
            $(this).removeAttr("checked");
        });

        var plantId = $(this).attr('plantid');
        $("#hfPlantId").val(plantId);
    });

    function setPlant(plantId) {
        $('#resLocation tr').each(function () {
            var id = $(this).find(".lnklocations");
            if (id.attr('plantid') == plantId)
            {
                $(this).css("background-color", "#d1ddf1");
                $(this).addClass("selectPlant");
                $("#hfPlantId").val(plantId);
            }
        });
    }

    function save() {

        var strSelRoles = '';
        $(":checkbox.chkrole").each(function () {
            if ($(this).attr("checked")) {
                if (strSelRoles != '') {
                    strSelRoles += ',';
                }
                strSelRoles += $(this).val();
            }
        });

        var nodes = $('#tt1').tree('getChecked');
        var strMenus = '';
        var preMasId = '';
        var accessObj = [];
        for (var i = 0; i < nodes.length; i++) {

            if (strMenus != '') {
                strMenus += ',';
            }
            var mas_str = nodes[i].text.indexOf("parent_id");
            var subStrData = nodes[i].text.substring(mas_str + 8);
            var Master_Id = subStrData.substring(0, subStrData.indexOf('"'));
            if (preMasId != Master_Id && Master_Id != "")
            {
                if (isNaN(Master_Id) == false)
                    strMenus += Master_Id + ',';
            }
            preMasId = Master_Id;

            var menuIndex = nodes[i].text.indexOf("menu_id");
            var menuStrData = nodes[i].text.substring(menuIndex + 9);
            var Menu_Id = menuStrData.substring(0, menuStrData.indexOf('"'));
            strMenus += Menu_Id;

//      ########################### ACCESS LEVEL START ############################
            var parsed = $('<div/>').append(nodes[i].text);
            var menuId = parsed.find('a').attr('menu_id');
            var isAccess = 0;
            $(".accessVal" + menuId).each(function () {
                if ($(this).is(":checked")) {
                    isAccess = 1;
                    accessObj.push({'menu_id': menuId, 'accessLvl': $(this).val()});
                }
            });
            if (!isAccess) {
                accessObj.push({'menu_id': menuId, 'accessLvl': "0"});
            }

//      ########################### ACCESS LEVEL END ##############################

        }

//        #######################
        var nodes = $('#tt1').tree('getChecked', 'indeterminate');
        var strMenus2 = '';
        var preMasId = '';
        for (var i = 0; i < nodes.length; i++) {
            if (strMenus2 != '') {
                strMenus2 += ',';
            }
            var mas_str = nodes[i].text.indexOf("parent_id");
            var subStrData = nodes[i].text.substring(mas_str + 8);
            var Master_Id = subStrData.substring(0, subStrData.indexOf('"'));
            if (preMasId != Master_Id && Master_Id != "")
            {
                if (isNaN(Master_Id) == false)
                    strMenus2 += Master_Id + ',';
            }
            preMasId = Master_Id;

            var menuIndex = nodes[i].text.indexOf("menu_id");
            var menuStrData = nodes[i].text.substring(menuIndex + 9);
            var Menu_Id = menuStrData.substring(0, menuStrData.indexOf('"'));
//            console.log(nodes[i]);

            strMenus2 += Menu_Id;
//      ########################### ACCESS LEVEL START ############################
            var parsed = $('<div/>').append(nodes[i].text);
            var menuId = parsed.find('a').attr('menu_id');
            var isAccess = 0;
            $(".accessVal" + menuId).each(function () {
                if ($(this).is(":checked")) {
                    isAccess = 1;
                    accessObj.push({'menu_id': menuId, 'accessLvl': $(this).val()});
                }
            });
            if (!isAccess) {
                accessObj.push({'menu_id': menuId, 'accessLvl': "0"});
            }
//      ########################### ACCESS LEVEL END ##############################

        }
        if (strMenus2) {
            strMenus += "," + strMenus2;
        }
        if (strMenus == "" || strSelRoles == "")
        {
            alert("Select atleast one Menu And Role");

        } else
        {
            $.post(url,
                    {
                        roles: strSelRoles,
                        menus: strMenus,
                        accessVal: accessObj,
                        plantId: $("#hfPlantId").val(),
                        act: 'SaveMenu'
                    }, function (data) {
                var str = data.indexOf("Query Error");
                if (str == '-1')
                {

                    alert('Information...! Menu Access saved successfully.');
                } else
                {
                    alert('Warning...! Menu Access not saved.');
                }

            });
        }

    }

//######################################Role Tab Functionality Start##############################################
    $(".btnEditRole").die('click').live('click', function () {
        if ($('#clone_role_tr').html()) {
            alert('Please complete your previous action!');
            return false;
        }
        var roleId = $(this).attr('roleid');
        var parentTr = $(this).closest('tr');
        $('#clone_role_tr').html($(this).closest('tr').clone());
        var roleNameRow = parentTr.find('.roleNameClm');
        roleNameRow.html('<input id="txtRoleNameEdit" type="text" value="' + roleNameRow.text() + '" style="width:99%"  class="txtFieldTextBox"  />');
        var statusRow = parentTr.find('.statusClm');
        var status = (statusRow.text() === "Active") ? '<option value="1" selected="true">Active</option><option value="0">InActive</option>' : '<option value="1">Active</option><option value="0" selected="true" >InActive</option>';
        statusRow.html('<select id="ddlStatusRoleEdit" name="ddlStatusRoleEdit" style="width:99%" class="ddlFieldDropdown">' + status + '</select>');
        var actionColm = parentTr.find(".action");
        actionColm.html('<a class="btnUpdateRole" href="javascript:void(0)" roleid="' + roleId + '"><img src="images/accept.png" title="Update"  /></a> &nbsp; <a class="btnCancelRole" href="javascript:void(0)" roleid="' + roleId + '"><img src="images/cancel.png" title="Cancel"  /></a>');
    })
    $(".btnCancelRole").die('click').live('click', function () {
        var cloneVal = $('#clone_role_tr').html();
        $(this).closest('tr').replaceWith(cloneVal);
        $('#clone_role_tr').html('');
    })
    $(".btnUpdateRole").die('click').live('click', function () {
        var roleId = $(this).attr('roleid');
        var parentTr = $(this).closest('tr');
        var roleName = parentTr.find('#txtRoleNameEdit').val();
        var status = parentTr.find('#ddlStatusRoleEdit').val();
        var statusStr = parentTr.find('#ddlStatusRoleEdit option:selected').text();
        if (!roleName) {
            alert("Please Enter Role Name!");
            parentTr.find('#txtRoleNameEdit').addClass('error').focus();
            return false;
        }
        $.post(url, {roleId: roleId, roleName: roleName, status: status, act: "updateRoles"}, function (data) {
            if (data == "success") {
                parentTr.find(".roleNameClm").html(roleName);
                parentTr.find(".statusClm").html(statusStr);
                parentTr.find(".action").html('<a roleid="' + roleId + '" href="javascript:void(0)" class="btnEditRole"><img title="Edit" src="images/edit.png"></a>');
                $('#clone_role_tr').html('');
                alert('Role Updated Successfully!');
            } else {
                alert('Due to some server issue update is not successfull. Please try afer sometimes!');
            }
            return false;
        })
    })
    function saveRole() {
        validate();
        var roleName = $("#txtRoleName").val().trim();
        var roleStatus = $(".ddlStatusRole").val().trim();
        var roleStatusStr = $(".ddlStatusRole option:selected").text().trim();
        $.post(url, {roleName: roleName, roleStatus: roleStatus, roleStatusStr: roleStatusStr, act: "addRoles"}, function (data) {
            var str = data.indexOf("Query Error");
            if (str == '-1') {
                $('#resRoleList tr:last').before(data);
                $("#txtRoleName").val('');
                alert('Role Added Successfully!');
            } else {
                alert('Due to some server issue update is not successfull. Please try afer sometimes!');
            }
            return false;
        })

    }
//######################################Role Tab Functionality End################################################


</script>
<?php include 'admin_class.php'; ?>
<input type="hidden" id="hfPageTitle" value="Menu Assignment" screen_id="create_menu_php">
<div id="tabMenu" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
    <div title="Menu" data-options="iconCls:'icon-view'" style="padding:10px"> 		
        <form id="frmMenus" name="frmMenus" method="post">
            <div class="Grid">
                <table cellpadding="0" cellspacing="0">
                    <thead>
                        <tr>
                            <th width="30%">Menu</th>
                            <th>Sub Menu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td valign="top">
                                <?php echo $admin->menus(); ?>  
                            </td>
                            <td valign="top">

                                <div class="Grid">
                                    <table cellpadding="0" cellspacing="0" id="grdMenu" class="sorted_table">
                                        <tbody id="res">
                                        </tbody>
                                    </table>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>                  
        </form>
    </div>
    <div title="Role" data-options="iconCls:'icon-role'" style="padding:10px">
        <div class="Grid">
            <table cellpadding="0" cellspacing="0" id="grdRoleTab">
                <thead>
                    <tr>
                        <th width="60%">Role Name</th>
                        <th width="20%">Status</th>
                        <th width="20%">Action</th>
                    </tr>
                </thead>
                <tbody id="resRoleList">
                    <?php echo $admin->rolesListingTable(); ?>
                </tbody>
                <tbody id="clone_role_tr" style="display: none;"></tbody>
            </table>
        </div>
    </div>
    <div title="Access Privilege" data-options="iconCls:'icon-access'" style="padding:10px">
        <form id="frmMenusAccess" name="frmMenusAccess" method="post">
            <input type="hidden" id="hfRole_id">
            <input type="hidden" id="hfPlantId">
            <div class="Grid">
                <table cellpadding="0" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th width="40%"></th>
                            <th width="60%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td valign="top"> 
                                <div class="Grid" style="height:auto;overflow:auto">
                                    <table cellpadding="0" cellspacing="0" id="grdRoles">
                                        <thead>
                                            <tr>
                                                <th><input id="chkroles" type="checkbox"> Access Roles</th>
                                            </tr>
                                        </thead>    
                                        <tbody id="resRole">
                                            <?php echo $admin->roles(); ?> 
                                        </tbody>
                                    </table>
                                </div>
                                <br>
                                <br>
                                <div class="Grid" style="height:200px;overflow:auto">
                                    <table cellpadding="0" cellspacing="0" id="grdLocation">
                                        <thead>
                                            <tr>
                                                <th>Access Plants</th>
                                            </tr>
                                        </thead>
                                        <tbody id="resLocation">

                                            <?php echo $admin->plants(); ?> 
                                        </tbody>
                                    </table>
                                </div> 
                                <br> 
                                &nbsp; <a href="javascript:void(0)" class="kks-linkbutton" onclick="save()">Save Changes</a>

                            </td>
                            <td valign="top"> 
                                <div class="Grid">
                                    <table cellpadding="0" cellspacing="0" id="grdMenu">
                                        <tbody>
                                            <tr>
                                                <td id="resMenu">
                                                    <?php echo $admin->CheckMenu(); ?> 
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </td>
                        </tr>
                    </tbody> 
                </table>
            </div>      
        </form>
    </div>
</div>   
<div id="error"></div>
<br>
<?php echo "<script>setPlant(" . $_SESSION['userSessionInfo']["TUS_PLNT"] . ")</script>" ?>