<script type="text/javascript">
$(document).ready(function(){
	getDetails();
});

	function getDetails(){		
		$.post(location.hostname+"/../admin/profile_action.php",{			
			action	:'getDetails'
			},function(data){
				$("#details").html(data);			   
			});
	}
	
	function updateChanges(){		
		if($("#password").val().length>0){
			var err = "";
			if($("#password").val().length>10){
				err = "  Password cannote be greater than 10 digits";	
				$("#password").focus();
				$("#passwordError").text(err);
				return false;
			}			
		}
				
		validate();
		var useval =[];		
		useval.push({
			'pno'	:$("#pno").val(),
			'name'	:$("#name").val(),
			'emailId' : $("#emailId").val(),
			'password' : $("#password").val(),
			'mobile' : $("#mobile").val(),
			'extension' : $("#extension").val(),
			'department' : $("#department :selected").val(),
			'designation' : $("#designation :selected").val()			
			});
		
		$.post(location.hostname+"/../admin/profile_action.php",
		{
			userValues	:useval,
			action		: 'updateUser'
		},function(data){
			alert(data);
		});
		
	}
</script>

<style>
	
</style>

<input type="hidden" id="hfPageTitle" value="Profile" screen_id="profile_php" />
<div class="Grid">
	<table cellpadding="0"cellspacing="0" id="details"></table>
</div>