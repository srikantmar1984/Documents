<?php

$ref = 'on';
include("../db_classes/commanvar.php");
include("../db_classes/class.db.php");
date_default_timezone_set("Asia/Calcutta");

if ($_REQUEST["act"] == 'Add') {
    $obj = new db_connect;
    $row = $obj->db_reader("Select nvl(max(to_number(TEP_ID)),0)+1 ID from t_erc_plant ");
    $id = $row["ID"][0];

    $strSql = "INSERT INTO t_erc_plant ";
    $strSql .= " ( ";
    $strSql .= "   TEP_ID ";
    $strSql .= " , TEP_NAME ";
    $strSql .= " , TEP_ACT_FLG ";
    $strSql .= " , TEP_CRT_BY ";
    $strSql .= " , TEP_CRT_TS ";
    $strSql .= " , TEP_UPD_BY ";
    $strSql .= " , TEP_UPD_TS ";
    $strSql .= " ) ";
    $strSql .= " VALUES ";
    $strSql .= " ( ";
    $strSql .= $id;
    $strSql .= " , '" . $_REQUEST["plantName"] . "' ";
    $strSql .= " , '" . $_REQUEST["status"] . "' ";
    $strSql .= " , " . $_SESSION['userSessionInfo']["TUS_UID"];
    $strSql .= " , SYSDATE ";
    $strSql .= " , " . $_SESSION['userSessionInfo']["TUS_UID"];
    $strSql .= " , SYSDATE ";
    $strSql .= " ) ";



    $obj = new db_connect;
    $obj->db_insert($strSql);
    $obj->free();

    $stts = $_REQUEST["status"] == 1 ? 'Active' : 'Inactive';
    echo '<tr><td></td><td id="plantName">' . $_REQUEST["plantName"] . '</td><td id="status">' . $stts . '</td><td id="action"><a id="btnEdit" plantid="' . $id . '" href="javascript:void(0)"><img src="images/edit.png"  title="Edit"/></a></td></tr>';
} else if ($_REQUEST["act"] == 'Update') {
    $strSql = "UPDATE t_erc_plant ";
    $strSql .= " SET TEP_NAME = '" . $_REQUEST["plantName"] . "' ";
    $strSql .= " , TEP_ACT_FLG = " . $_REQUEST["status"];
    $strSql .= " , TEP_UPD_BY = " . $_SESSION['userSessionInfo']["TUS_UID"];
    $strSql .= " , TEP_UPD_TS = SYSDATE ";
    $strSql .= " WHERE TEP_ID = " . $_REQUEST["plantId"];

    $obj = new db_connect;
    $obj->db_insert($strSql);
    $obj->free();
}
?>