<script type="text/javascript" src="js/jquery.kksui.min.js"></script>
<input type="hidden" id="hfPageTitle" value="User Details" screen_id="users_aspx">
<input type="hidden" id="hfAccessLevel" value="0">									
<?php include 'admin_class.php'; ?>
<div id="mainContent" style="text-align:left">
    <div  class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
        <!--###############################USER SEARCH TAB START##################################################-->
        <div title="Search" data-options="iconCls:'icon-search'" style="padding:10px"> 		
            <input type="hidden" id="hfPlantId" value="<?php echo $_SESSION['userSessionInfo']["TUS_PLNT"]; ?>" >	
            <form id="frmUsers" name="frmUsers" method="post">
                <table width="100%">
                    <tr>
                        <td>
                            <span class="lblFieldLabel">PersonalNo </span></td><td width="2%">&nbsp;
                        </td>
                        <td width="25%">
                            <input type="text" id="txtPno" name="txtPno" class="txtFieldTextBox" title="Personal No" PlaceHolder="Personal No" style="width:98%;" />
                        </td>
                        <td align="right">
                            <span class="lblFieldLabel">User Name </span></td><td width="2%">&nbsp;
                        </td>
                        <td width="25%">
                            <input type="text" id="txtUserName" name="txtUserName" class="txtFieldTextBox" title="User Name" PlaceHolder="User Name" style="width:98%;" />
                        </td>
                        <td align="right">
                            <span class="lblFieldLabel">Status </span></td><td width="2%">&nbsp;
                        </td>
                        <td width="20%">
                            <select id="ddlStatus" name="ddlStatus" style="width:99%;"  class="ddlFieldDropdown"> 
                                <option value="All">All</option>
                                <option value="1">Active</option>
                                <option value="0">InActive</option>
                                <option value="2">Pending</option>
                                <option value="3">Rejected</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><span class="lblFieldLabel">Department  </span></td><td width="2%">&nbsp;</td>
                        <td width="25%"> <select id="ddldept" name="ddldept" style="width:99%;"  class="ddlFieldDropdown"> 
                                <option value="">All</option>
                                <?php
                                $sql = "SELECT ted_id, ted_name FROM T_VHS_DEPARTMENTS  WHERE ted_plant = " . $_SESSION['userSessionInfo']["TUS_PLNT"] . " ORDER BY ted_name ASC ";
                                echo $admin->GenDropDown($sql);
                                ?>
                            </select> 

                        </td>
                        <td align="right"><span class="lblFieldLabel">Application  </span></td><td width="2%">&nbsp;</td>
                        <td width="20%"><select id="ddlApp" name="ddlApp" style="width:99%;"  class="ddlFieldDropdown"> 
                                <option value="">All</option>
                                <?php
                                $sql = "SELECT TEA_ID,TEA_SHT_NAME from  T_VHS_APPLICATION where tea_act_flg=1";
                                echo $admin->GenDropDown($sql);
                                ?>
                            </select> </td>

                        <td align="right"><span class="lblFieldLabel">Role  </span></td><td width="2%">&nbsp;</td>
                        <td> 
                            <select id="ddlRole" name="searchUserRole[]" style="width:99%;"  class="ddlFieldDropdown" multiple="multiple"> 
                            <!--<select id="searchUserRole" name="searchUserRole[]" style="width:99%;" class="ddlFieldDropdown" multiple="multiple">--> 
                                <!--<option value="">All</option>-->
                                <?php
                                $sql = "SELECT TER_ID,TER_NAME FROM T_VHS_ROLES WHERE TER_ACT_FLG=1 ";
                                echo $admin->GenDropDown($sql);
                                ?>
                            </select> </td>
                    </tr>
                    <tr>
                        <td><span class="lblFieldLabel">Email ID</span></td><td width="2%">&nbsp;</td>
                        <td width="25%"> <input type="text" id="txtEmail" name="txtEmail" class="txtFieldTextBox" title="Email ID" PlaceHolder="Email ID" style="width:98%;" /></td>
                        <td align="right"><span class="lblFieldLabel">Mobile No</span></td><td width="2%">&nbsp;</td>
                        <td width="20%"><input type="text" id="txtMobile" name="txtMobile" class="txtFieldTextBox"  style="width:98%;" title="Mobile No" PlaceHolder="Mobile No" /> </td>
                        <td align="right"><span class="lblFieldLabel">Extension No </span></td><td width="2%">&nbsp;</td>
                        <td width="20%"><input type="text" id="txtExt" name="txtExt" class="txtFieldTextBox" title="Extension No" PlaceHolder="Extension No" style="width:98%;" /> </td>
                    </tr>
                    <tr>
                        <td><span class="lblFieldLabel">Created On </span></td><td width="2%">&nbsp;</td>
                        <td> <input id="txtFrom" name="txtFrom"  class="kks-datebox" data-options="formatter:myformatter"  /> To <input id="txtTo" name="txtTo"  class="kks-datebox" data-options="formatter:myformatter"  /></td>

                    </tr>
                    <tr height="15">

                    </tr>
                    <tr>
                        <td colspan="8"> &nbsp; <a href="javascript:void(0)" class="kks-linkbutton" onclick="searchData()">Search</a>  &nbsp; <a href="javascript:void(0)" class="kks-linkbutton" onclick="clearUser()">Clear All</a></td>
                    </tr>
                </table>
                <div class="Grid">
                    <table cellpadding="0" cellspacing="0"  id="grduser" style="padding-right:8px;">
                        <thead>
                            <tr>
                                <th width="2%"></th>
                                <th >Personal No</th>
                                <th>User Name</th>
                                <th>Department</th>
                                <th>EmailID</th>
                                <th>MobileNo</th>
                                <th>ExtensionNo</th>
                                <th>Status</th>
                                <th>CreatedBy</th>
                                <th>LocationName</th>
                                <th>CreatedOn</th>
                            </tr>
                        </thead>
                        <tbody id="res">

                        </tbody>
                    </table>
                </div>           
            </form>

        </div>
        <!--###############################USER SEARCH TAB END##################################################-->
        <!--###############################USER DETAILS TAB START##################################################-->
        <div title="Details" data-options="iconCls:'icon-view'" style="padding:10px;">
            <div id="divUserDetails" class="Grid" style="display:none">

                <table border="0" cellpadding="0" cellspacing="0" style="width: 100%; vertical-align:top">
                    <tbody>
                        <tr style="height: 22Px;">
                            <td colspan="6" style=" padding-left: 5px;">
                                <b><u>Old Values</u></b>
                            </td>
                        </tr>
                        <tr>
                            <td width="11%">
                                <span  class="lblFieldLabel">PersonalNo</span>
                            </td>
                            <td width="33%">
                                <span id="lblUpdOldPersonalNoVal" class="lblFieldLabel" style="font-weight:bold;"></span>
                            </td>
                            <td width="7%">
                                <span  class="lblFieldLabel">User Name</span>
                            </td>
                            <td width="25%" >
                                <span id="lblUpdOldUserNameVal" class="lblFieldLabel" style="font-weight:bold;"></span>
                            </td>
                            <td width="9%">
                                <span  class="lblFieldLabel">Status</span>
                            </td>
                            <td width="15%" >
                                <span id="lblUpdOldStatusVal" class="lblFieldLabel" style="font-weight:bold;">Active</span>
                            </td>
                        </tr>
                        <tr>
                            <td width="11%">
                                <span  class="lblFieldLabel">Department</span>
                            </td>
                            <td width="33%">
                                <span id="lblUpdOldDepartmentVal" class="lblFieldLabel" style="font-weight:bold;"></span>
                            </td>
                            <td width="7%">
                                <span class="lblFieldLabel">Email ID</span>
                            </td>
                            <td colspan="3" >
                                <span id="lblUpdOldEmailVal" class="lblFieldLabel" style="font-weight:bold;"></span>
                            </td>
                        </tr>
                        <tr>
                            <td width="11%"><span class="lblFieldLabel">Plant</span></td>
                            <td width="33%">
                                <span id="lblUpdOldPlntVal" class="lblFieldLabel" style="font-weight:bold;"></span>
                            </td>
                            <td width="7%">
                                <span class="lblFieldLabel">Mobile No</span>
                            </td>
                            <td width="25%" >
                                <span id="lblUpdOldMobileVal" class="lblFieldLabel" style="font-weight:bold;"></span>
                            </td>
                            <td width="9%">
                                <span  class="lblFieldLabel">Extension No</span>
                            </td>
                            <td width="15%" >
                                <span id="lblUpdOldExtnVal" class="lblFieldLabel" style="font-weight:bold;"></span>
                            </td>
                        </tr>
                        <tr>
                            <td width="11%">
                                <span  class="lblFieldLabel">Created By</span>
                            </td>
                            <td width="33%">
                                <span id="lblUpdOldCrtByVal" class="lblFieldLabel" style="font-weight:bold;"></span>
                            </td>
                            <td width="7%">
                                <span class="lblFieldLabel">Created On</span>
                            </td>
                            <td colspan="3" >
                                <span id="lblUpdOldCrtDtVal" class="lblFieldLabel" style="font-weight:bold;"></span>
                            </td>
                        </tr>
                        <tr>
                            <td width="11%"><span class="lblFieldLabel">Access to Applications</span></td>
                            <td width="33%" valign="top">
                                <table  id="grdApplications"></table>
                            </td>
                            <td width="7%"><span class="lblFieldLabel">Assign Role</span></td>
                            <td colspan="3" rowspan="2" valign="top">
                                <table  id="grdRole"></table>
                            </td>
                        </tr>
                        <tr style="height: 22Px;">
                            <td colspan="6" style=" padding-left: 5px;">
                                <b><u>New Values</u></b>
                            </td>
                        </tr>
                        <tr>
                            <td width="11%">
                                <span  class="lblFieldLabel">PersonalNo</span>
                            </td>
                            <td width="33%">
                                <span id="lblUpdPersonalNo" class="lblFieldLabel" style="font-weight:bold;"></span>
                                <input type="hidden" value="" id="currntUserId" />
                            </td>
                            <td width="7%">
                                <span  class="lblFieldLabel">User Name</span>
                            </td>
                            <td width="25%" >
                                <input type="text" id="txtUpdUserName" name="txtUpdUserName" class="txtFieldTextBox"  style="width:98%;" /> 
                            </td>
                            <td width="9%">
                                <span  class="lblFieldLabel">Status</span>
                            </td>
                            <td width="15%" >
                                <select id="ddlUpdStatus" name="ddlUpdStatus" style="width:99%;"  class="ddlFieldDropdown"> 
                                    <option value="Active">Active</option>
                                    <option value="InActive">InActive</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Rejected">Rejected</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td width="11%">
                                <span  class="lblFieldLabel">Department</span>
                            </td>
                            <td width="33%">
                                <select id="ddlUpddept" name="ddlUpddept" style="width:99%;"  class="ddlFieldDropdown"> 
                                    <?php
                                    $sql = "SELECT ted_id, ted_name FROM T_VHS_DEPARTMENTS  WHERE ted_plant = " . $_SESSION['userSessionInfo']["TUS_PLNT"] . " ORDER BY ted_name ASC ";
                                    echo $admin->GenDropDown($sql);
                                    ?>
                                </select> 
                            </td>
                            <td width="7%">
                                <span class="lblFieldLabel">Email ID</span>
                            </td>
                            <td colspan="3" >
                                <input type="text" id="txtUpdEmail" name="txtUpdEmail" class="txtFieldTextBox"  style="width:98%;" /> 
                            </td>
                        </tr>
                        <tr>
                            <td width="9%"><span class="lblFieldLabel">Plant</span></td>
                            <td width="15%" >
                                <select id="ddlUpdPlant" name="ddlUpdPlant" style="width:99%;"  class="ddlFieldDropdown"> 
                                    <?php
                                    $sql = "SELECT TEP_ID, TEP_NAME FROM T_ERC_PLANT WHERE TEP_ACT_FLG = 1 AND TEP_ID = " . $_SESSION['userSessionInfo']["TUS_PLNT"];
                                    echo $admin->GenDropDown($sql);
                                    ?>
                                </select> 
                            </td>
                            <td width="7%">
                                <span class="lblFieldLabel">Mobile No</span>
                            </td>
                            <td width="25%" >
                                <input type="text" id="txtUpdMobile" name="txtUpdMobile" class="txtFieldTextBox"  style="width:98%;" /> 
                            </td>
                            <td width="9%">
                                <span  class="lblFieldLabel">Extension No</span>
                            </td>
                            <td width="15%" >
                                <input type="text" id="txtUpdExt" name="txtUpdExt" class="txtFieldTextBox"  style="width:98%;" /> 
                            </td>
                        </tr>
                        <tr>
                            <td width="11%">
                                <span  class="lblFieldLabel">Created By</span>
                            </td>
                            <td width="33%">
                                <input type="text" id="txtUpdCrtBy" disabled  name="txtUpdCrtBy" class="txtFieldTextBox"  style="width:98%;" /> 
                            </td>
                            <td width="7%">
                                <span class="lblFieldLabel">Created On</span>
                            </td>
                            <td colspan="3" >
                                <input type="text" id="txtUpdCrtdt" disabled name="txtUpdCrtdt" class="txtFieldTextBox"  style="width:98%;" /> 
                            </td>
                        </tr>
                        <tr>
                            <td width="11%"><span class="lblFieldLabel">Access to Applications</span></td>
                            <td width="33%" valign="top">
                                <table  id="grdUpdApplications">
                                </table>
                            </td>
                            <td width="7%"><span class="lblFieldLabel">Assign Role</span></td>
                            <td colspan="3" rowspan="2" valign="top">
                                <table id="grdUpdRole">
                                    <thead>
                                        <tr>
                                            <th>
                                                <select id="ddlUpdRole" name="ddlUpdRole" style="width:99%;"  class="ddlFieldDropdown">
                                                    <?php
                                                    // echo $admin->fillRoles($_SESSION['Pno']); 
                                                    $sql = "SELECT TER_ID,TER_NAME FROM T_VHS_ROLES WHERE TER_ACT_FLG=1 ";
                                                    echo $admin->GenDropDown($sql);
                                                    ?>
                                                </select>
                                            </th>
                                            <th><a id="btnAdd" href="#"><img src="images/add.png" title="Add"></a></th>
                                        </tr>
                                    </thead>
                                    <tbody id="resRole"></tbody>
                                </table>    	
                            </td>
                        </tr>
                    </tbody>
                </table>

                <br>
                <a id="btnUpdate" href="javascript:void(0)" class="kks-linkbutton" onclick="updateUser()"  >Update</a>

            </div>
        </div>
        <!--###############################USER DETAILS TAB END##################################################-->
        <!--###############################CREATE USER TAB START##################################################-->
        <div title="Create User" data-options="iconCls:'icon-add'" style="padding:10px;">
            <div id="divUserDetails" class="Grid" >
                <form id="crtUserFrm" method="post">
                    <table border="0" cellpadding="0" cellspacing="0" style="width: 100%; vertical-align:top">
                        <tbody>
                            <tr style="height: 22Px;">
                                <td colspan="6" style=" padding-left: 5px;">
                                    <b><u>Create User</u></b>
                                </td>
                            </tr>
                            <tr>
                                <td width="11%">
                                    <span  class="lblFieldLabel">PersonalNo</span>
                                </td>
                                <td width="33%">
                                    <input type="text" id="txtCrtPno" name="txtCrtPno" class="txtFieldTextBox kks-validatebox" required="true"  style="width:98%;" /> 
                                </td>
                                <td width="7%">
                                    <span  class="lblFieldLabel">User Name</span>
                                </td>
                                <td width="25%" >
                                    <input type="text" id="txtCrtUserName" name="txtCrtUserName" class="txtFieldTextBox kks-validatebox" required="true" style="width:98%;" /> 
                                </td>
                                <td width="9%">
                                    <span  class="lblFieldLabel">Status</span>
                                </td>
                                <td width="15%" >
                                    <select id="ddlCrtStatus" name="ddlCrtStatus" style="width:99%;"  class="ddlFieldDropdown"> 
                                        <option value="1">Active</option>
                                        <option value="0">InActive</option>
                                        <option value="2">Pending</option>
                                        <option value="3">Rejected</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td width="11%">
                                    <span  class="lblFieldLabel">Department</span>
                                </td>
                                <td width="33%">
                                    <select id="ddlCrtdept" name="ddlCrtdept" style="width:99%;"  class="ddlFieldDropdown kks-validatebox" required="true">
                                        <option value="">Select</option>
                                        <?php
                                        $sql = "SELECT ted_id, ted_name FROM T_VHS_DEPARTMENTS  WHERE ted_plant = " . $_SESSION['userSessionInfo']["TUS_PLNT"] . " ORDER BY ted_name ASC ";
                                        echo $admin->GenDropDown($sql);
                                        ?>
                                    </select> 
                                </td>
                                <td width="7%">
                                    <span class="lblFieldLabel">Email ID</span>
                                </td>
                                <td colspan="1" >
                                    <input type="text" id="txtCrtEmail" name="txtCrtEmail" class="txtFieldTextBox kks-validatebox" required="true" validType="email" style="width:98%;" /> 
                                </td>
                            </tr>
                            <tr>
                                <td width="11%"><span class="lblFieldLabel">Plant</span></td>
                                <td width="33%" >
                                    <select id="ddlCrtOrg" name="ddlCrtOrg" style="width:99%;"  class="ddlFieldDropdown"> 
                                        <?php
                                        $sql = "SELECT TEP_ID, TEP_NAME FROM T_ERC_PLANT WHERE TEP_ACT_FLG = 1 AND TEP_ID = " . $_SESSION['userSessionInfo']["TUS_PLNT"];
                                        echo $admin->GenDropDown($sql);
                                        ?>
                                    </select> 
                                </td>
                                <td width="7%">
                                    <span class="lblFieldLabel">Mobile No</span>
                                </td>
                                <td width="25%" >
                                    <input type="text" id="txtCrtMobile" name="txtCrtMobile" class="txtFieldTextBox kks-validatebox" required="true" style="width:98%;" /> 
                                </td>
                                <td width="9%">
                                    <span  class="lblFieldLabel">Extension No</span>
                                </td>
                                <td width="15%" >
                                    <input type="text" id="txtCrtExt" name="txtCrtExt" class="txtFieldTextBox"  style="width:98%;" /> 
                                </td>
                            </tr>
                            <tr>
                                <td width="11%">
                                    <span  class="lblFieldLabel">Created By</span>
                                </td>
                                <td width="33%">
                                    <input type="text" id="txtCrtCrtBy" disabled  name="txtCrtCrtBy" class="txtFieldTextBox"  style="width:98%;" value="<?php echo $_SESSION['userSessionInfo']["TUS_NAME"]; ?>" /> 
                                </td>
                                <td width="7%">
                                    <span class="lblFieldLabel">Created On</span>
                                </td>
                                <td colspan="3" >
                                    <input type="text" id="txtCrtCrtdt" disabled name="txtCrtCrtdt" class="txtFieldTextBox"  style="width:98%;" value="<?php echo date('d-M-Y'); ?>" /> 
                                </td>
                            </tr>
                            <tr>
                                <td width="11%"><span class="lblFieldLabel">Access to Applications</span></td>
                                <td width="33%" valign="top">
                                    <table  id="grdCrtApplications">
                                    </table>
                                </td>
                                <td width="7%"><span class="lblFieldLabel">Assign Role</span></td>
                                <td colspan="3" rowspan="2" valign="top">
                                    <table id="grdCrtRole">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <select id="ddlCrtRole" name="ddlCrtRole" style="width:99%;"  class="ddlFieldDropdown">
                                                        <?php
                                                        $sql = "SELECT TER_ID,TER_NAME FROM T_VHS_ROLES WHERE TER_ACT_FLG=1 ";
                                                        echo $admin->GenDropDown($sql);
                                                        ?>
                                                    </select>
                                                </th>
                                                <th><a id="btnAddCrt" href="javascript:void(0)"><img src="images/add.png" title="Add"></a></th>
                                            </tr>
                                        </thead>
                                        <tbody id="resRoleCrt"></tbody>
                                    </table>    	
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <br>
                    <a id="btnCreate" href="javascript:void(0)" class="kks-linkbutton" onclick="$('#crtUserFrm').submit()"  >Create</a>
                </form>
            </div>
        </div> 
        <!--###############################CREATE USER TAB END##################################################-->


    </div>
</div>
<div id="error"></div>

<link rel="stylesheet" type="text/css" href="js/multiple-select-master/multiple-select.css" />
<script src="js/multiple-select-master/jquery.multiple.select.js" type="text/javascript"></script>
<script type="text/javascript" >
$(document).ready(function () {
    initMultiselect();

    $('.layout-button-left').trigger('click');
    $('#tabMenu').tabs('disableTab', 'Details');
    /*
     * Function access_application is called here to fetch all application to display in create user tab
     * @@@ First @para is 0 (Zero) as no userid available in 0;
     */
    access_application(0, "grdCrtApplications", 'edit');
    /*
     * View User Details for edit/update user info
     * Landing to Details info of User.
     */
    $("#btnPno").die('click').live('click', function () {
        $('.icon-view').parent().css('display', '');
        var pno = $(this).attr('pno');
        var userId = $(this).attr('userid');
        $("#lblUpdOldPersonalNoVal").html("");
        $("#lblUpdPersonalNo").html("");
        $("#lblUpdOldUserNameVal").html("");
        $("#txtUpdUserName").val("");
        $("#lblUpdOldDepartmentVal").html("");
        $("#lblUpdOldEmailVal").html("");
        $("#txtUpdEmail").val("");
        $("#lblUpdOldMobileVal").html("");
        $("#txtUpdMobile").val("");
        $("#lblUpdOldExtnVal").html("");
        $("#txtUpdExt").val("");
        $("#lblUpdOldStatusVal").html("");
        $("#lblUpdOldCrtByVal").html("");
        $("#txtUpdCrtBy").val("");
        $("#lblUpdOldPlntVal").html("");
        $("#lblUpdOldCrtDtVal").html("");
        $("#txtUpdCrtdt").val("");

        $("#lblUpdOldDomainVal").html("");
        $("#currntUserId").val(userId);
        var i = 0;
        var obj = $("#" + pno + " td").each(function () {
            i++;
            switch (i) {
                case 2:
                    $("#lblUpdOldPersonalNoVal").html($(this).text());
                    $("#lblUpdPersonalNo").html($(this).text());

                    break;
                case 3:
                    $("#lblUpdOldUserNameVal").html($(this).text());
                    $("#txtUpdUserName").val($(this).text());
                    break;
                case 4:
                    $("#lblUpdOldDepartmentVal").html($(this).text());
                    $("#ddlUpddept option:contains(" + $(this).text() + ")").attr('selected', true);
                    break;
                case 5:
                    $("#lblUpdOldEmailVal").html($(this).text());
                    $("#txtUpdEmail").val($(this).text());
                    break;
                case 6:
                    $("#lblUpdOldMobileVal").html($(this).text());
                    $("#txtUpdMobile").val($(this).text());

                    break;
                case 7:
                    $("#lblUpdOldExtnVal").html($(this).text());
                    $("#txtUpdExt").val($(this).text());
                    break;
                case 8:
                    $("#lblUpdOldStatusVal").html($(this).text());
                    $("#ddlUpdStatus option[value='" + $(this).text() + "']").attr("selected", true);
                    break;
                case 9:
                    $("#lblUpdOldCrtByVal").html($(this).text());
                    $("#txtUpdCrtBy").val($(this).text());
                    break;
                case 10:
                    $("#lblUpdOldPlntVal").html($(this).text());
                    break;
                case 11:
                    $("#lblUpdOldCrtDtVal").html($(this).text());
                    $("#txtUpdCrtdt").val($(this).text());
                    break;
                default:

            }
        });

        access_application(userId, "grdApplications,#grdUpdApplications", 'update');
        $('#grdApplications input:checkbox').attr('disabled', true);
        $.post(wwwRoot + "/admin/users_action.php", {userId: userId, act: 'Role'},
                function (data) {
                    $('#grdRole').html(data);
                    //remove second column
                    $('#grdRole tr td:nth-child(2)').each(function () {
                        $(this).remove();
                    });
                    $('#resRole').html(data);

                });

        $('#divUserDetails').css('display', '');
        $('.kks-tabs').tabs('select', 'Details');

    });

    /*
     * Add roles to the user in Detail user page 
     * @@@This is called while user is updated/edited
     */
    $("#btnAdd").die('click').live('click', function () {
        var pno = $("#lblUpdPersonalNo").html();
        var userId = $("#currntUserId").val().trim();
        var role = $("#ddlUpdRole option:selected").text();
        var isExist = false;
        $('#resRole td:nth-child(1)').each(function () {
            if ($(this).text().trim() == role.trim()) {
                alert("Role Already Added");
                isExist = true;
                return false;
            }
        });
        if (!isExist) {
            $.post(wwwRoot + "/admin/users_action.php", {userId: userId, pno: pno, role_id: $("#ddlUpdRole").val(), act: 'AssignRole'}, function (data) {
                $('#resRole').append('<tr><td>' + role + ' </td><td width="5%"><a id="btnDel" href="#" role_id="' + $("#ddlUpdRole").val() + '"><img src="images/delete.png"></a></td></tr>');
                alert(data);
            });
        }
    });

    /*
     * Delete roles to the user in Detail user page 
     * @@@This is called while user is updated/edited
     */
    $("#btnDel").die('click').live('click', function () {
        var userId = $("#currntUserId").val().trim();
        var role_id = $(this).attr("role_id");
        $.post(wwwRoot + "/admin/users_action.php", {userId: userId, role_id: role_id, act: 'DelRole'},
                function (data) {
                    alert(data);
                });
        $(this).parent().parent().remove();
    });

    /*
     * Assign Application to the user in Detail user page 
     * @@@This is called while user is updated/edited
     */
    $("#chkUpdApp").die('click').live('click', function () {
        var userId = $("#currntUserId").val().trim();
        var app_id = $(this).attr("appid");
        var act_flg = $(this).attr("checked");
        if (act_flg == undefined) {
            act_flg = 0;
        } else {
            act_flg = 1;
        }
        $.post(wwwRoot + "/admin/users_action.php", {userId: userId, app_id: app_id, act_flg: act_flg, act: 'AssignApp'}, function (data) {
            alert(data);
        });

    });
    /*
     * Add roles to to the user in Create user page 
     * @@@This is called while user is newly added
     */
    $("#btnAddCrt").die('click').live('click', function () {
        var role = $("#ddlCrtRole option:selected").text();
        var role_id = $("#ddlCrtRole").val();
        var cnt = 1;
        $('#resRoleCrt td:nth-child(1)').each(function () {
            if ($(this).text().trim() == role.trim()) {
                alert("Role Already Added");
                cnt = 0;
            }
        });
        if (cnt) {
            $('#resRoleCrt').append('<tr><td>' + role + ' </td><td width="5%"><a id="btnDelCrt" href="#" role_id="' + role_id + '"><img src="images/delete.png"></a><input type="hidden" name="assgnRoleCrt[]" value="' + role_id + '"></td></tr>');
        }
    });

    /*
     * Delete roles to to the user in Create user page 
     * @@@This is called while user is newly added
     */
    $("#btnDelCrt").die('click').live('click', function () {
        $(this).parent().parent().remove();
    });
    /*
     * User Information from LDAP after entering the pno (LDAP user ID)
     * @@@This is called while user is newly added
     */
    $("#txtCrtPno111").focusout(function () {
//        $("#txtCrtPno").focusout(function () {
        var pno = $("#txtCrtPno").val().trim();
        $.post(wwwRoot + "/admin/users_action.php", {pno: pno, act: 'userInfoLdap'}, function (data) {
            if (jQuery.type(data) == 'string') {
                alert(data);
                return false;
            }
            parseDataObj = $.parseJSON(data);
            console.log(data);
            if (!$.isEmptyObject(parseDataObj)) {
                $("#txtCrtUserName").val(parseDataObj.uname);
                $("#txtCrtEmail").val(parseDataObj.mail);
                $("#txtCrtMobile").val(parseDataObj.mobile);
            } else {

            }

        });
    })

    /*
     * Submit Create User Form
     * @@@This is called while user is newly added
     */
    $('#crtUserFrm').form({
        url: wwwRoot + "/admin/users_action.php?act=createUser",
        onSubmit: function () {
//                    console.log( $(this).form('validate'));
            return $(this).form('validate');
        },
        success: function (data) {
            $.messager.alert('Information...!', '<b style="color:green">' + data + '</b>', 'info');
            $('#crtUserFrm')[0].reset();
        }
    });

});
/**
 * Function to provides the accessed application by the user
 * @@userId--->user unique id in db
 * @@putId--->ID of the container where to put the data
 */
function access_application(userId, putId, type) {
    $.post(location.hostname + "/../admin/users_action.php", {userId: userId, act: 'App'},
            function (data) {
                $('#' + putId).html(data);
                if (type == "update") {
                    $('#grdApplications input:checkbox').attr('disabled', true);
                } else if (type == "edit") {
                    $('#' + putId + ' input:checkbox').removeAttr('id');
                    $('#' + putId + ' input:checkbox').attr('class', 'chkCrtApp');
                }

            });
}
/*
 * Search Users according to the searching criteria
 */
function searchData() {
    $('.icon-view').parent().css('display', 'none');
    $.post(wwwRoot + "/admin/users_action.php",
            {
                plantId: $("#hfPlantId").val().trim(),
                Pno: $("#txtPno").val().trim(),
                UserName: $("#txtUserName").val().trim(),
                Status: $("#ddlStatus").val().trim(),
                Dept: $("#ddldept").val().trim(),
                Email: $("#txtEmail").val().trim(),
                Role: $("#ddlRole").multipleSelect("getSelects"),
//                    Role: $("#ddlRole").val().trim(),
                ExtNo: $("#txtExt").val().trim(),
                Mobile: $("#txtMobile").val().trim(),
                CreatedFrom: $('input[name=txtFrom]').val().trim(),
                CreatedTo: $('input[name=txtTo]').val().trim(),
                App: $("#ddlApp").val().trim(),
                act: "AllUserList"
            },
            function (data) {
                data = jQuery.parseJSON(data);
                $('#res').empty();
                if (data.Users != undefined) {
                    if (data.Users.length > 0) {
                        $.each(data['Users'], function (i, user) {
                            $('#res').append('<tr id="' + user['PERSONALNO'] + '"><td><input id="btnPno" class="gridButton" type="button" value="..." pno="' + user['PERSONALNO'] + '" userId="' + user['USERID'] + '"  /></td><td>' + user['PERSONALNO'] + '</td><td>' + user['USERNAME'] + '</td><td>' + user['DEPARTMENT'] + '</td><td>' + user['EMAILID'] + '</td><td>' + user['MOBILENO'] + '</td><td>' + user['EXTENSIONNO'] + '</td><td>' + user['STATUS'] + '</td><td>' + user['CREATEDBY'] + '</td><td>' + user['PLANTNAME'] + '</td><td>' + user['CREATEDON'] + '</td></tr>');
                        });
//                    SetAccessLevel($("#hfAccessLevel").val());
                    } else {
                        $.each(data, function (i, user) {
                            $('#res').append('<tr id="' + user.PERSONALNO + '"><td><input id="btnPno" class="gridButton" type="button" value="..." pno="' + user.PersonalNo + '" userId="' + user['USERID'] + '" /></td><td>' + user.PersonalNo + '</td><td>' + user.UserName + '</td><td>' + user.Department + '</td><td>' + user.Designation + '</td><td>' + user.EmailID + '</td><td>' + user.MobileNo + '</td><td>' + user.ExtensionNo + '</td><td>' + user.Status + '</td><td>' + user.CreatedBy + '</td><td>' + user.LocationName + '</td><td>' + user.OrgName + '</td><td>' + user.UnitName + '</td><td>' + user.CreatedOn + '</td><td>' + user.Domain + '</td></tr>');
                        });
//                    SetAccessLevel($("#hfAccessLevel").val());
                    }
                } else {
                    alert('No Data Found');
                }
            });
}

function hideDetail() {
    $('.icon-view').parent().css('display', 'none');
}
/*
 * Update User Information
 */
function updateUser() {
    var userId = $("#currntUserId").val().trim();
    var pno = $("#lblUpdPersonalNo").html().trim();
    var userName = $("#txtUpdUserName").val();
    var status = $("#ddlUpdStatus").val();
    var dept = $("#ddlUpddept").val();
    var email = $("#txtUpdEmail").val();
    var desig = $("#ddlUpdDeg").val();
    var mobile = $("#txtUpdMobile").val();
    var extNo = $("#txtUpdExt").val();
    var domain = $("#ddlUpdDomain").val();
    var unit = $("#ddlUpdUnit").val();
    var plantId = $("#ddlUpdPlant").val();
    $.post(wwwRoot + "/admin/users_action.php",
            {
                userId: userId,
                pno: pno,
                userName: userName,
                status: status,
                dept: dept,
                email: email,
                desig: desig,
                mobile: mobile,
                extNo: extNo,
                domain: domain,
                unit: unit,
                plantId: plantId,
                act: 'UpdateUser'
            },
            function (data) {
                if (data == "success") {
                    searchData();
                    $.messager.alert('Information...!', '<b style="color:green">User Information updated successfully.</b>', 'info');
                    $("#" + pno + " td #btnPno").trigger('click');
                } else {
                    $.messager.alert('Caution...!', '<b style="color:red">Unable to update user.Please try after sometimes. </b>', 'error');
                }

            });

}

function clearUser() {
    $('#frmUsers')[0].reset();
    $('#res').html('');
}
function initMultiselect() {
    $("#ddlRole").multipleSelect({
        width: '100%',
        placeholder: 'All',
        maxHeight: 100,
        selectAll: true,
        placeholder: "Select Role",
        filter: true,
    });
    $('.ms-drop').css('width', '100%');
    $("#ddlRole").multipleSelect("checkAll");
}
</script>
<?php echo "<script> hideDetail();  </script>" ?>
<?php // echo "<script> findAccessLevel(); hideDetail();  </script>"   ?>
