<script type="text/javascript" >
    $('#chkroles').live('change', function () {
        if ($(this).attr("checked")) {
            $(":checkbox#chkrole").each(function () {
                $(this).attr("checked", "");
            });
        } else {
            $(":checkbox#chkrole").each(function () {
                $(this).removeAttr("checked");
            });
        }

    });

    $('#chkScreen').live('change', function () {
        if ($(this).attr("checked")) {
            $(":checkbox#chkScreenId").each(function () {
                $(this).attr("checked", "");
            });
        } else {
            $(":checkbox#chkScreenId").each(function () {
                $(this).removeAttr("checked");
            });
        }

    });

    $('#None').live('change', function () {
        if ($(this).attr("checked")) {
            $(":radio#accessNone").each(function () {
                $(this).attr("checked", "");
            });
        } else {
            $(":radio#accessNone").each(function () {
                $(this).removeAttr("checked");
            });
        }

    });

    $('#Read').live('change', function () {
        if ($(this).attr("checked")) {
            $(":radio#accessRead").each(function () {
                $(this).attr("checked", "");
            });
        } else {
            $(":radio#accessRead").each(function () {
                $(this).removeAttr("checked");
            });
        }

    });

    $('#Write').live('change', function () {
        if ($(this).attr("checked")) {
            $(":radio#accessWrite").each(function () {
                $(this).attr("checked", "");
            });
        } else {
            $(":radio#accessWrite").each(function () {
                $(this).removeAttr("checked");
            });
        }

    });
    $('#Full').live('change', function () {
        if ($(this).attr("checked")) {
            $(":radio#accessFull").each(function () {
                $(this).attr("checked", "");
            });
        } else {
            $(":radio#accessFull").each(function () {
                $(this).removeAttr("checked");
            });
        }

    });

    $('#lnkrole').live('click', function () {
        $('#resRole tr').each(function () {

            $(this).css("background-color", "");
            $(this).find("#chkrole").removeAttr("checked");
        });

        var p = $(this).parent().parent();
        p.find("#chkrole").attr("checked", "");
        p.css("background-color", "#d1ddf1");


        $.post(location.hostname + "/../admin/roleassignment_action.php",
                {
                    role_id: $(this).attr('roleid'),
                    locn: $("#hfLocn").val(),
                    org: $("#hfOrg").val(),
                    vunit: $("#hfUnit").val(),
                    act: 'Ajax'
                }, function (data)
        {
            var str = data.indexOf("Query Error");
            if (str == '-1')
            {
                $("#resScreen").html(data);

            } else
            {
                alert('Error !');
                exit();
            }
            return false;

        });




    });

    $('#lnklocations').live('click', function () {
        $('#resLocation tr').each(function () {
            $(this).css("background-color", "");
        });
        var p = $(this).parent().parent();
        p.css("background-color", "#d1ddf1");

        $(":checkbox").each(function () {
            $(this).removeAttr("checked");
        });

        var locn = $(this).attr('locn');
        var org = $(this).attr('orgid');
        var vunit = $(this).attr('unit');

        $("#hfLocn").val(locn);
        $("#hfOrg").val(org);
        $("#hfUnit").val(vunit);
    });

    function setLocation(vLocn, vOrg, vUnit) {
        $('#resLocation tr').each(function () {
            var id = $(this).find("#lnklocations");
            if (id.attr('orgid') == vOrg && id.attr('unit') == vUnit && id.attr('locn') == vLocn) {
                $(this).css("background-color", "#d1ddf1");
                $("#hfLocn").val(vLocn);
                $("#hfOrg").val(vOrg);
                $("#hfUnit").val(vUnit);
            }
        });
    }

    function save() {

        var strSelRoles = '';
        $(":checkbox#chkrole").each(function () {
            if ($(this).attr("checked")) {

                if (strSelRoles != '') {
                    strSelRoles += ',';
                }
                strSelRoles += $(this).val();
            }
        });

        var strSelScreens = '';
        $(":checkbox#chkScreenId").each(function () {
            if ($(this).attr("checked")) {
                if (strSelScreens != '') {
                    strSelScreens += ',';
                }
                strSelScreens += $(this).val();

            }
        });

        var strNoneScreens = "";
        var strReadScreens = "";
        var strWriteScreens = "";
        var strFullScreens = "";
        var strAllScreens = "";

        $(":checkbox#chkScreenId").each(function () {
            if ($(this).attr("checked")) {
                var sid = $(this).val()
                var strCurrSel = "0";
                var parent = $(this).parent().parent();
                if (parent.find("#accessNone").attr("checked")) {
                    strCurrSel = "0";
                } else if (parent.find("#accessRead").attr("checked")) {
                    strCurrSel = "1";
                } else if (parent.find("#accessWrite").attr("checked")) {
                    strCurrSel = "2";
                } else {
                    strCurrSel = "3";
                }

                switch (strCurrSel) {
                    case "1":
                        if (strReadScreens != '') {
                            strReadScreens += ',';
                        }
                        strReadScreens += "'" + sid + "'";
                        break;
                    case "2":
                        if (strWriteScreens != '') {
                            strWriteScreens += ",";
                        }
                        strWriteScreens += "'" + sid + "'";
                        break;
                    case "3":
                        if (strFullScreens != '') {
                            strFullScreens += ",";
                        }
                        strFullScreens += "'" + sid + "'";
                        break;
                    default:
                        if (strNoneScreens != '') {
                            strNoneScreens += ",";
                        }
                        strNoneScreens += "'" + sid + "'";
                        break;
                }

                if (strAllScreens != '') {
                    strAllScreens += ",";
                }
                strAllScreens += "'" + sid + "'";
            }
        });

        console.log('role ' + strSelRoles);
        console.log('screen ' + strSelScreens);
        console.log(strWriteScreens);
        console.log('alls ' + strAllScreens);
    }

</script>
<input type="hidden" id="hfPageTitle" value="Role Assignment" screen_id="roleassignment_php">    								
<?php include 'admin_class.php'; ?>
<div id="mainContent" style="text-align:left">
    <form id="frmRoleAssign" name="frmRoleAssign" method="post">
        <input type="hidden" id="hfLocn">
        <input type="hidden" id="hfOrg">
        <input type="hidden" id="hfUnit">
        <div class="Grid">
            <table cellpadding="0" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th width="40%"></th>
                        <th width="60%"></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td valign="top"> 
                            <div class="Grid" style="height:500px;overflow:auto">
                                <table cellpadding="0" cellspacing="0" id="grdRoles">
                                    <thead>
                                        <tr>
                                            <th><input id="chkroles" type="checkbox"> Access Roles</th>
                                            <th>Application</th>
                                        </tr>
                                    </thead>    
                                    <tbody id="resRole">
                                        <?php echo $admin->roles(); ?> 
                                    </tbody>
                                </table>
                            </div>
                            <br>
                            <br>
                            <div class="Grid" style="height:200px;overflow:auto">
                                <table cellpadding="0" cellspacing="0" id="grdLocation">
                                    <thead>
                                        <tr>
                                            <th>Access Locations</th>
                                        </tr>
                                    </thead>
                                    <tbody id="resLocation">

                                        <?php echo $admin->Locations(); ?> 
                                    </tbody>
                                </table>
                            </div> 
                            <br> 
                            &nbsp; <a href="javascript:void(0)" class="kks-linkbutton" onclick="save()">Save Changes</a>

                        </td>
                        <td valign="top"> 
                            <div class="Grid">
                                <table cellpadding="0" cellspacing="0" id="grdSrceen">
                                    <thead>
                                        <tr>
                                            <th width="3%"><input id="chkScreen" type="checkbox"></th>
                                            <th>Screen Name</th>
                                            <th width="10%"><input id="None" type="radio" name="access" value="0">None</th>
                                            <th width="10%"><input id="Read" type="radio" name="access" value="1">Read </th>
                                            <th width="10%"><input id="Write" type="radio" name="access" value="2">Write </th>
                                            <th width="15%"><input id="Full" type="radio" name="access" value="3">Full Access </th>
                                        </tr>
                                    </thead> 
                                    <tbody id="resScreen">
                                    </tbody>
                                </table>
                            </div>
                        </td>
                    </tr>
                </tbody> 
            </table>
        </div>      
    </form>  
</div>
<?php echo "<script>setLocation(" . $_SESSION["Locn"] . "," . $_SESSION["Org"] . "," . $_SESSION["Unit"] . ")</script>" ?>	