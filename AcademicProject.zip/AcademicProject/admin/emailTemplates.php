<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class EmailTemplateClass {
    function createUser() {
        $returnArr['subject'] = "User activation Notification of Vehicle Handover System";
        $returnArr['body'] = "<p>We have successfully activated your profile in ERC Portal.The URL to access Online ERC is ".HOST_PATH." .<br/>Kindly use your Domain ID and Domain Password for Login into the Portal. <br/>In case of any query kindly contact on EXT:(0657)-669-3811.</p>";
        $returnArr['header'] = "MIME-Version: 1.0" . "\r\n" . "Content-type:text/html;charset=UTF-8" . "\r\n". "From:ERC Portal" . "\r\n";
        return $returnArr;
    }
    function updateUser() {
        $returnArr['subject'] = "User activation Notification of Vehicle Handover System";
        $returnArr['body'] = "<p>We have successfully activated your profile in ERC Portal.The URL to access Online ERC is ".HOST_PATH." .<br/>Kindly use your Domain ID and Domain Password for Login into the Portal. <br/>In case of any query kindly contact on EXT:(0657)-669-3811.</p>";
        $returnArr['header'] = "MIME-Version: 1.0" . "\r\n" . "Content-type:text/html;charset=UTF-8" . "\r\n". "From:ERC Portal" . "\r\n";
        return $returnArr;
    }

}

$emailTemp = new EmailTemplateClass();
?>