<?php

ini_set('post_max_size ', '128M'); // or you could use 1G
$ref = 'on';
include("admin_class.php");
date_default_timezone_set("Asia/Calcutta");
/* * ************************ Action Events ************************ */
if (!isset($_SESSION['userSessionInfo']['TUS_UID'])) {
    unset($_SESSION['Logout']);
    echo $_SESSION['userSessionInfo']['TUS_UID'];
    exit;
}
if (isset($_REQUEST["act"])) {
    switch ($_REQUEST["act"]) {
        case "mappedMenus":
            echo $admin->menuAssignToTab($_REQUEST['tabId']);
            break;
        case "saveMenu":
            echo saveTabMenu();
            break;
        default:
            echo "Something Wrong! Please Contact System Admin";
    }
}

function saveTabMenu() {
    $admin = new Adminclass();
    $accessMapArr = $admin->array_columnDup($_REQUEST['accessVal'], 'accessLvl', 'menu_id');
    /*
     * STEP-1 : @@@ Delete All assigned menu from t_vhs_tab_menu 
     * STEP-2 : @@@ Insert All assign menu into t_vhs_tab_menu
     */
    //STEP-1
    $sqlDelMenu = "DELETE FROM T_VHS_TAB_MENU";
    $sqlDelMenu .= " WHERE TTS_TAB_ID = " . $_REQUEST['tabId'];
    $obj = new db_connect;
    $obj->db_query($sqlDelMenu);
    $obj->free();
    $obj = new db_connect;
    $row = $obj->db_reader("Select nvl(max(to_number(TTS_ID)),0)+1 ID from T_VHS_TAB_MENU ");
    $id = $row["ID"][0];

    foreach ($_REQUEST['menuIds'] as $eachMenuId) {

        $sqlSaveMenu = <<<EOD
            INSERT INTO T_VHS_TAB_MENU(
                TTS_ID,
                TTS_TAB_ID,
                TTS_MENU_ID,
                TTS_CRT_BY,
                TTS_CRT_TS,
                TTS_ACT_FLG,
                TTS_ACCESS_LEVEL
            )VALUES(
                {$id},
                {$_REQUEST['tabId']},
                {$eachMenuId},
                {$_SESSION['userSessionInfo']['TUS_UID']},
                SYSDATE,
                1,
                {$accessMapArr[$eachMenuId]}
            )
EOD;
        $id++;
        $obj = new db_connect;
        $obj->db_query($sqlSaveMenu);
    }
    $obj->free();
    return '0';
}

?>