<?php

ini_set('post_max_size ', '128M');
$ref = 'on';
include("admin_class.php");
date_default_timezone_set("Asia/Calcutta");

if (!isset($_SESSION['userSessionInfo']['TUS_UID'])) {
    unset($_SESSION['Logout']);
    echo $_SESSION['userSessionInfo']['TUS_UID'];
    exit;
}
if (isset($_REQUEST["act"])) {
    switch ($_REQUEST["act"]) {
        case "searchCheckList":
            echo $admin->checklists($_REQUEST);
            break;
        case "addCheckList":
            echo add_checkListHead();
            break;
        case "updateCheckList":
            echo update_checkListHead();
            break;
        default:
            echo "Something Wrong! Please Contact to the Support Team";
    }
}

function add_checkListHead() {
    $setVal = implode('##', explode(',', $_REQUEST["setVal"]));
    $sqlAddChck = "INSERT INTO T_VHS_CHECK_HEAD( 
                        TCH_SLNO, 
                        TCH_CHK_ID, 
                        TCH_CHECK_POINT,
                        TCH_ACT_FLG,
                        TCH_TAB_ID,
                        TCH_PARENT_ID,
                        TCH_DATA_TYPE,
                        TCH_VALUE_SET,
                        TCH_INCRIMENTAL,
                        TCH_EFFT_FROM,
                        TCH_EFFT_TO,
                        TCH_CRT_BY,
                        TCH_CRT_TS,
                        TCH_UPD_BY,
                        TCH_UPD_TS
                        ) ";
    $sqlAddChck .= " VALUES ( ";
    $sqlAddChck .= "'" . $_REQUEST['slNo'] . "', ";
    $sqlAddChck .= "(Select nvl(max(to_number(TCH_CHK_ID)),0)+1  from T_VHS_CHECK_HEAD ) ";
    $sqlAddChck .= "  , '" . $_REQUEST["checkPnt"] . "' ";
    $sqlAddChck .= "  , " . $_REQUEST["status"];
    $sqlAddChck .= "  , " . $_REQUEST["tabId"];
    $sqlAddChck .= "  , '" . $_REQUEST["parentId"] . "'";
    $sqlAddChck .= "  , '" . strtolower($_REQUEST["dataType"]) . "' ";
    $sqlAddChck .= "  , '" . $setVal . "' ";
    $sqlAddChck .= "  , '" . $_REQUEST["incremental"] . "'";
    $sqlAddChck .= "  , TO_DATE('" . $_REQUEST['effectFrm'] . "','dd-Mon-yyyy') ";
    $sqlAddChck .= "  , TO_DATE('" . $_REQUEST['effectTo'] . "','dd-Mon-yyyy') ";
    $sqlAddChck .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
    $sqlAddChck .= "  , SYSDATE ";
    $sqlAddChck .= "  , " . $_SESSION['userSessionInfo']['TUS_UID'];
    $sqlAddChck .= "  , SYSDATE ";
    $sqlAddChck .= " ) ";
    $obj = new db_connect;
    $obj->db_insert($sqlAddChck);
    $obj->free();
    return 'success';
}

function update_checkListHead() {
    $setVal = implode('##', explode(',', $_REQUEST["setVal"]));
    $sqlUpdChck = <<<EOD
            UPDATE 
                T_VHS_CHECK_HEAD
            SET 
EOD;
    $sqlUpdChck .= " TCH_SLNO = '" . $_REQUEST['slNo'] . "',";
    $sqlUpdChck .= " TCH_CHECK_POINT = '" . $_REQUEST['checkPnt'] . "',";
    $sqlUpdChck .= " TCH_ACT_FLG = " . $_REQUEST['status'] . ",";
    $sqlUpdChck .= " TCH_TAB_ID = " . $_REQUEST['tabId'] . ",";
    $sqlUpdChck .= " TCH_PARENT_ID = '" . $_REQUEST['parentId'] . "',";
    $sqlUpdChck .= " TCH_DATA_TYPE = '" . strtolower($_REQUEST["dataType"]) . "',";
    $sqlUpdChck .= " TCH_VALUE_SET = '" . $setVal . "',";
    $sqlUpdChck .= " TCH_INCRIMENTAL = '" . $_REQUEST['incremental'] . "',";
    $sqlUpdChck .= " TCH_EFFT_FROM = TO_DATE('" . $_REQUEST['effectFrm'] . "','dd-Mon-yyyy'),";
    $sqlUpdChck .= " TCH_EFFT_TO = TO_DATE('" . $_REQUEST['effectTo'] . "','dd-Mon-yyyy'),";
    $sqlUpdChck .= " TCH_UPD_BY = " . $_SESSION['userSessionInfo']['TUS_UID'] . ",";
    $sqlUpdChck .= " TCH_UPD_TS = SYSDATE ";
    $sqlUpdChck .= " WHERE";
    $sqlUpdChck .= " TCH_CHK_ID = " . $_REQUEST['checkListId'];
    $obj = new db_connect;
    $obj->db_query($sqlUpdChck);
    $obj->free();
    return 'success';
}

?>