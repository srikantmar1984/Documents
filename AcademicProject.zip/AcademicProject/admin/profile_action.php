<?php
include 'admin_class.php';
$ref='on';
date_default_timezone_set("Asia/Calcutta");
	 	
	if(isset($_REQUEST['action'])){
		
		if(($_REQUEST['action'] == 'getDetails')){
			echo getDetails();
		}
		
		// update user
		if(($_REQUEST['action'] == 'updateUser')){			
			echo updateUser($_REQUEST['userValues']);
		}
	}
	
	
	
	function getDetails(){
            echo "<pre>";
		$output = "";		
		$obj = new db_connect;
		$sql = "SELECT t1.*,t2.* FROM T_VHS_USERS t1,T_ERC_ROLE_USER t2  WHERE t1.TUS_UID = '".$_SESSION['userSessionInfo']['TUS_UID']."' AND t1.TUS_UID = t2.TRU_USER_ID ";
		$result = $obj->db_reader($sql);		
//            print_r($result);exit;
		
		//head part 
		$output .= '<thead>';
		$output .= '<tr>';
		$output .= '<th colspan="4">My Profile <span style="float:right;">Created on : '.$result['TUS_CRT_TS'][0].'&nbsp;</span></th>';
		$output .= '</tr>';
		$output .= '</thead>';
		
		// body part
		$output .= '<tbody>';
		$output .= '<tr>';		
		$output .= '<td width="10%">Name</td>';		
		$output .= '<td width="40%"><input type="text" value ="'.$result['TUS_NAME'][0].'" style="width:100%" id="name" class="required"/></td>';
		$output .= '<td width="10%">Personal Number</td>';
		$output .= '<td><input type="text" value ="'.$result['TUS_PNO'][0].'" style="width:100%" disabled= "disabled" id="pno"/></td>';
		$output .= '</tr>';
		
		$output .= '<tr>';		
		$output .= '<td width="10%">Email id</td>';
		$output .= '<td width="40%"><input type="text" value ="'.$result['TUS_EMAIL_ID'][0].'" style="width:100%"  class="txtFieldTextBox " id="emailId" /></td>';
		$output .= '<td width="13%">Change password</td>';            
		$output .= '<td colspan="3"><input type="password" style="width:100%" id="password" /><span class="mandatory" id="passwordError"></span></td>';
		$output .= '</tr>';
		
		$output .= '<tr>';		
		$output .= '<td width="10%">Mobile</td>';
		$output .= '<td width="40%"><input type="text" value ="'.$result['TUS_MOBILE'][0].'" style="width:100%"  class="txtFieldTextBox " id="mobile"/></td>';
		$output .= '<td width="10%">Extension</td>';            
		$output .= '<td width="40%"><input type="text" value ="'.$result['TUS_EXT'][0].'" style="width:100%"  class="txtFieldTextBox " id="extension"/></td>';
		$output .= '</tr>';
		
			$output .= '<tr>';
			$output .= '<td>Department</td>';
			$output .= '<td width="40%"><select class="ddlFieldDropdown " style="width:100%" id="department">'.fillFunctions("Department",$result['TUS_DEPT_ID'][0]).'</select></td>';
			$output .= '<td>Designation</td>';
			$output .= '<td width="40%"><select class="ddlFieldDropdown " style="width:100%" id="designation"></select></td>';
//			$output .= '<td width="40%"><select class="ddlFieldDropdown " style="width:100%" id="designation">'.fillFunctions("Designations",$result['TUS_DESG_ID'][0]).'</select></td>';
			$output .= '</tr>';
		
		$output .= '<tr>';		
		$output .= '<td>Plant</td>';
		$output .= '<td width="40%"><select class="ddlFieldDropdown " disabled style="width:100%">'.fillFunctions("Plant",$result['TUS_PLNT'][0]).'</select></td>';
		$output .= '<td>Role</td>';
		$output .= '<td width="40%"><select class="ddlFieldDropdown " disabled style="width:100%">'.fillFunctions("Role",$result['TRU_ROLE_ID'][0]).'</select></td>';
		$output .= '</tr>';
				
		$output .= '<tr>
					<td colspan="4"><button onclick="updateChanges();">Update Changes</button></td>
				</tr>';
		$output .= '</tbody>';	
		
			
		return $output;		
	}
		
	function fillFunctions($type,$selected){
		switch($type){
			case 'Department':
				$sql = "SELECT TED_ID,TED_NAME FROM T_VHS_DEPARTMENTS WHERE TED_PLANT = '".$_SESSION['userSessionInfo']['TUS_PLNT']."'  ORDER BY TED_NAME ";				
				break;
			case 'Designations':
				$sql = "SELECT tdg_desg_id,tdg_desg_name FROM t_sos_designations WHERE tdg_locn_id = '".$_SESSION['Locn']."' AND tdg_org_id = '".$_SESSION['Org']."' AND tdg_unit_id = '".$_SESSION['Unit']."' ";
				break;			
			case 'Plant':
				$sql = "SELECT TEP_ID, TEP_NAME FROM t_erc_plant WHERE TEP_ID = '".$_SESSION['userSessionInfo']['TUS_PLNT']."' ";
				break;
			case 'Organisation':
				$sql = "SELECT tdg_desg_id,tdg_desg_name FROM t_sos_designations WHERE tdg_locn_id = '".$_SESSION['Locn']."' AND tdg_org_id = '".$_SESSION['Org']."' AND tdg_unit_id = '".$_SESSION['Unit']."' ";
				break;
			case 'Role':
				$sql = "SELECT tro_role_id,tro_role_name ||'('||tap_sht_name||')'as RoleName FROM T_sos_ROLES, t_sos_applications WHERE tro_app_id=tap_id And tro_act_flg='Active' ";
				break;
		}
		
		$obj = new db_connect;
		$obj->db_query($sql);		
		$output = '';
		$selectedValue = '';
		$output .= '<option>Not Assigned</option>';
		while($row = $obj->db_fetch_array()){
			if(isset($selected) AND ($row[0]== $selected) ){
				$selectedValue = "selected";
			}else{
				$selectedValue = "";
			}
			$output .= '<option value="'.$row[0].'" '.$selectedValue.' >';
			$output .= $row[1];
			$output .= '</option>';
		}
		
		return $output;
		
	}
	
	function updateUser($values)
	{
		$obj = new db_connect;				
		$admin = new Adminclass();
	
		$values = $admin->sanitize($values);

		
		foreach($values as $key=>$val)
		{
			$sql = "UPDATE 
					t_sos_users ";
			$sql .=" SET 
			     		tus_name = '".$val['name']."'  
			     		,tus_email_id  = '".$val['emailId']."'  
			     		, tus_mobile_no  = '".$val['mobile']."'  
			     		, tus_ext_no  = '".$val['extension']."'  
			     		, tus_dept_id  = '".$val['department']."'  
			     		, tus_desg_id  = '".$val['designation']."'  
			     		, tus_upd_by= '".$_SESSION['Pno']."'  
			     		, tus_upd_ts = SYSDATE	";
						
		     	if(!empty($val['password']))
				{
		     		//$pwd = md5($val['password']);
					$sql .=", tus_pass = ercvalidation.encryptdata('".$val['password']."',trunc(tus_crt_ts)) ";	
				}
			
			$sql .=" WHERE tus_pno = '".$val['pno']."' ";
		}	
		
		if($obj->db_query_return($sql))
		{			
			$obj->db_query($sql);
			return "Update Successfully";
			$obj->free();
		}
		else
		{
			return "Error Occured in saving data";
		}
	}
	
	
// print custom error to a file
	/*if($err = error_get_last()){
		$custom_error = 'Line : '.$err['line'].' - '.$err['file'].' - '.$err['message'].' - Time : '.date('d-M-Y H:m:s a')."\n" ;
		$filename = '../logs/errorlog'.date('d-M-y').'.php';
		error_log($custom_error,3,$filename);
	}*/