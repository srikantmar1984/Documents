<input type="hidden" id="hfPageTitle" value="Configuration Items" screen_id="configitems_aspx">
<input type="hidden" id="hfAccessLevel" value="">	  								
<?php include 'admin_class.php'; ?>
<div id="tabMenu" class="kks-tabs" data-options="border:false" style=" width:auto;height:auto">
    <div title="Items" data-options="iconCls:'icon-search'" style="padding:10px"> 
        <div id="mainContent" >  
            <form action="" method="post" name="frmRoles" id="frmRoles">
                <div id="filterid">
                    <div class="filter filterhead">								
                        <table width="100%"  cellpadding="1" cellspacing="1">
                            <tr class="trheader">		
                                <td>
                                    <span>Search Criteria</span>					
                                </td>
                                <td style="text-align:right;padding-right:5px;">
                                    <a href="javascript:void(0)" class="toggleExpand" onclick="toggleExpand(this);" ><img src="./images/collapse.jpg" alt="expand/collapse" /></a>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="filter filterrow">
                        <table cellpadding="0" cellspacing="1" width="99%" style="line-height:20px">
                            <tr>
                                <td colspan="8" align="left"><b><u>Filter Condition </u></b></td>
                            </tr>
                            <tr>
                                <td align="center">Item Name</td>
                                <td><input name="seachItemName" id="seachItemName" type="text" style="width:99%" width="99%" class="txtFieldTextBox " /></td>
                                <td width="1%">&nbsp;</td>
                                <td align="center">Description</td>
                                <td><input name="seachDesc" id="seachDesc" type="text" style="width:99%" width="99%" class="txtFieldTextBox " /></td>
                                <td width="1%">&nbsp;</td>
                                <td>Status</td>
                                <td><select id="seachStatus" name="seachStatus" style="width:99%" class="ddlFieldDropdown">
                                        <option value="">All</option>
                                        <option value="1">Active</option>
                                        <option value="0">InActive</option>
                                    </select></td>
                            </tr>
                            <tr>
                                <td colspan="8" align="left"> <a href="javascript:void(0)" class="kks-linkbutton" onclick="searchData()">Search</a></td>
                            </tr>

                        </table>
                    </div>
                </div>

                <div class="Grid">
                    <table cellpadding="0" cellspacing="0" id="grdRoels">
                        <thead>
                            <tr>
                                <th width="4%">Sr.No</th>
                                <th width="25%">Item Name</th>
                                <th width="25%">Item Desc</th>
                                <th width="8%">Conf Type</th>
                                <th width="10%">Status</th>
                                <th width="8%">Action</th>
                            </tr>
                        </thead>
                        <tbody id="res">
                            <?php echo $admin->configItems() ?>       
                        </tbody>
                        <tbody id="footer" class="itemTbl">
                            <tr style="background-color: rgb(247, 246, 243); font-weight: bolder;">
                                <td ><input name="addSlNo" id="addSlNo" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td>
                                <td><input name="addItemName" id="addItemName" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td>
                                <td><input name="addItemDesc" id="addItemDesc" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" /></td>
                                <td ><select id="addConfType" name="addConfType" style="width:99%" class="ddlFieldDropdown">
                                        <option value="C">C</option>
                                        <option value="A">A</option>
                                        <option value="N">N</option>
                                    </select></td>
                                <td ><select id="addStatus" name="addStatus" style="width:99%" class="ddlFieldDropdown">
                                        <option value="1">Active</option>
                                        <option value="0">InActive</option>
                                    </select></td>
                                <td width="8%"><a id="btnAdd" href="javascript:void(0)"><img src="images/add.png"  title="Add"/></a></td>
                            </tr>
                        </tbody>
                        <tbody id="tr_clone" style="display:none"></tbody>
                    </table>
                </div>   
            </form>
        </div>
    </div>
    <div title="Sub Items" data-options="iconCls:'icon-search'" style="padding:10px">
        <div id="mainContent" >  
            <form action="" method="post" name="frmRoles" id="frmRoles">
                <div id="filterid">
                    <div class="filter filterhead">								
                        <table width="100%"  cellpadding="1" cellspacing="1">
                            <tr class="trheader">		
                                <td>
                                    <span>Search Criteria</span>					
                                </td>
                                <td style="text-align:right;padding-right:5px;">
                                    <a href="javascript:void(0)" class="toggleExpand" onclick="toggleExpand(this);" ><img src="./images/collapse.jpg" alt="expand/collapse" /></a>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="filter filterrow">
                        <table cellpadding="0" cellspacing="1" width="99%" style="line-height:20px">
                            <tr>
                                <td colspan="8" align="left"><b><u>Filter Condition </u></b></td>
                            </tr>
                            <tr>
                                <td align="center">Item Name</td>
                                <td>
                                    <select id="searchItemNameSub" name="searchItemNameSub" style="width:99%" class="ddlFieldDropdown">
                                        <option value="All">All</option>
                                        <?php echo $admin->fillItemName() ?> 
                                    </select>
                                </td>
                                <td width="1%">&nbsp;</td>
                                <td>Sub Item</td>
                                <td><input name="searchSubItemNameSub" id="searchSubItemNameSub" type="text" style="width:99%" width="99%" class="txtFieldTextBox " /></td>
                                <td width="1%">&nbsp;</td>
                                <td>Status</td>
                                <td><select id="searchStatusSub" name="searchStatusSub" style="width:99%" class="ddlFieldDropdown">
                                        <option value="All">All</option>
                                        <option value="1">Active</option>
                                        <option value="0">InActive</option>
                                    </select></td>
                            </tr>
                            <tr>
                                <td colspan="8" align="left"> <a href="javascript:void(0)" class="kks-linkbutton" onclick="searchSubItemData()">Search</a></td>
                            </tr>

                        </table>
                    </div>
                </div>

                <div class="Grid">
                    <table cellpadding="0" cellspacing="0" id="grdRoels">
                        <thead>
                            <tr>
                                <th width="4%">Sr.No</th>
                                <th width="15%">Sub Item Name</th>
                                <th width="10%">Description</th>
                                <th width="25%">Item</th>
                                <th width="8%">Conf Type</th>
                                <th width="10%">Status</th>
                                <th width="8%">Action</th>
                            </tr>
                        </thead>
                        <tbody id="subres">
                            <?php echo $admin->subConfigItems() ?>       
                        </tbody>
                        <tbody id="footer_sub" class="subItemTbl" >
                            <tr style="background-color: rgb(247, 246, 243); font-weight: bolder;">
                                <td>
                                    <input name="addSlNoSub" id="addSlNoSub" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" />
                                </td>
                                <td>
                                    <input name="addSubItemNameSub" id="addSubItemNameSub" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" />
                                </td>
                                <td>
                                    <input name="addDescSub" id="addDescSub" type="text" style="width:99%" width="99%" class="txtFieldTextBox required" />
                                </td>
                                <td>
                                    <select id="addItemNameSub" name="addItemNameSub" style="width:99%" class="ddlFieldDropdown">
                                        <?php echo $admin->fillItemName() ?>   
                                    </select>
                                </td>
                                <td>
                                    <select id="addConfTypeSub" name="addConfTypeSub" style="width:99%" class="ddlFieldDropdown">
                                        <option value="C">C</option>
                                        <option value="A">A</option>
                                        <option value="N">N</option>
                                    </select>
                                </td>
                                <td>
                                    <select id="addStatusSub" name="addStatusSub" style="width:99%" class="ddlFieldDropdown">
                                        <option value="1">Active</option>
                                        <option value="0">InActive</option>
                                    </select>
                                </td>
                                <td width="8%">
                                    <a id="btnAddSubCat" href="javascript:void(0)"><img src="images/add.png"  title="Add"/></a>
                                </td>
                            </tr>
                        </tbody>
                        <tbody id="tr_clone_sub" style="display:none"></tbody>
                    </table>
                </div>   
            </form>
        </div>
    </div>
</div>
<script type="text/javascript" >
    $(document).ready(function () {
        $('.layout-button-left').trigger('click');
        $("#btnAdd").click(function (event) {
            event.preventDefault();
            validateItem('itemTbl');
            var slNo = $("#addSlNo").val().trim();
            var itemName = $("#addItemName").val().trim();
            var itemDesc = $("#addItemDesc").val().trim();
            var confType = $("#addConfType").val().trim();
            var status = $("#addStatus").val().trim();
            $.ajax({
                type: 'POST',
                url: wwwRoot + "/admin/configitems_action.php",
                data: {
                    act: 'addItem',
                    slNo: slNo,
                    itemDesc: itemDesc,
                    itemName: itemName,
                    confType: confType,
                    status: status,
                },
                success: function (data, textStatus, jqXHR) {
                    if (textStatus == "success")
                    {
                        var str = data.indexOf("Error");
                        if (str == '-1') {
                            $("#res").append(data);
                            $("#addSlNo,#addItemDesc,#addItemName").val('');
                            $("#addConfType").val('C');
                            $("#addStatus").val('1');
                        } else {
                            alert('Error During Submit !');
                            hideProgress();
                            exit();
                        }
                    }
                }
            });
        });

        $('#btnEdit').die('click').live('click', function () {
            if ($("#tr_clone").html() != '') {
                alert("Please complete your previous action!");
            } else {
                var parent = $(this).parent().parent();

                //Clone the selected Row
                var clone = parent.clone();
                $("#tr_clone").html(clone);

                var itemId = $(this).attr('itemId');

                var ch = parent.find("#ITEMNAME");
                ch.html('<input id="itemNameVal" type="text" value="' + ch.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');

                var chSlno = parent.find("#slno");
                chSlno.html('<input id="slnoVal" type="text" value="' + chSlno.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');

                var ch2 = parent.find("#CONFTYPE");
                var selectConfType = ch2.text().trim();
                ch2.html('<select id="conftypeVal" name="conftypeVal" style="width:99%" class="ddlFieldDropdown"><option value="C">C</option><option value="A">A</option><option value="N">N</option></select>');
                $("#conftypeVal").val(selectConfType);

                var ch3 = parent.find("#ITEMDESC");
                ch3.html('<input id="itemdesceVal" type="text" value="' + ch3.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');

                var ch4 = parent.find("#STATUS");
                var status = (ch4.text() === "Active") ? '<option value="1" selected="true">Active</option><option value="0">InActive</option>' : '<option value="1">Active</option><option value="0" selected="true" >InActive</option>';
                ch4.html('<select id="ddlStatus" name="ddlStatus" style="width:99%" class="ddlFieldDropdown">' + status + '</select>');

                var ch6 = parent.find("#action");
                ch6.html('<a id="btnUpdate" itemId="' + itemId + '" href="javascript:void(0)"><img src="images/accept.png" title="Update"  /></a> &nbsp; <a id="btnCancel" href="javascript:void(0)"><img src="images/cancel.png" title="Cancel"  /></a>');

            }

        });

        $('#btnUpdate').die('click').live('click', function () {
            var itemid = $(this).attr('itemid');
            var parent = $(this).parent().parent();
            var slNo = parent.find("#slnoVal").val().trim();
            var itemName = parent.find("#itemNameVal").val().trim();
            var confType = parent.find("#conftypeVal").val().trim();
            var itemDesc = parent.find("#itemdesceVal").val().trim();
            var status = parent.find("#ddlStatus").val().trim();
            var statusText = parent.find("#ddlStatus option:selected").text();

            $.ajax({
                type: 'POST',
                url: wwwRoot + "/admin/configitems_action.php",
                data: {
                    act: 'update',
                    itemid: itemid,
                    itemDesc: itemDesc,
                    slNo: slNo,
                    itemName: itemName,
                    status: status,
                    confType: confType
                },
                success: function (data, textStatus, jqXHR) {
                    if (textStatus == "success")
                    {
                        if (data == '0') {
                            alert('change sucessfully');
                            parent.find("#slno").html(slNo);
                            parent.find("#ITEMNAME").html(itemName);
                            parent.find("#CONFTYPE").html(confType);
                            parent.find("#ITEMDESC").html(itemDesc);
                            parent.find("#STATUS").html(statusText);
                            parent.find("#action").html('<a  id="btnEdit" itemId="' + itemid + '"  href="javascript:void(0)"><img src="images/edit.png" title="Edit"  /></a>');
                            $("#tr_clone").html('');
                        } else {
                            alert('Error During Submit !');
                        }
                    }
                }
            });
        });


        $('#btnCancel').die('click').live('click', function () {

            var parent = $(this).parent().parent();
            var clone = $("#tr_clone").html();
            //Replace <tr> Tag in IE
            clone = clone.replace('<TR>', '');
            clone = clone.replace('</TR>', '');
            parent.html(clone.replace('<tr>', ''));
            $("#tr_clone").html('');

        });
//        ####################################SUB ITEMS START##########################################
        $("#btnAddSubCat").click(function (event) {
            event.preventDefault();
            validateItem('subItemTbl');

            var slNo = $("#addSlNoSub").val().trim();
            var subItemName = $("#addSubItemNameSub").val().trim();
            var subItemDesc = $("#addDescSub").val().trim();
            var parentItemId = $("#addItemNameSub").val().trim();
            var confType = $("#addConfTypeSub").val().trim();
            var status = $("#addStatusSub").val().trim();
            var itemName = $("#addItemNameSub option:selected").text();
            $.ajax({
                type: 'POST',
                url: wwwRoot + "/admin/configitems_action.php",
                data: {
                    act: 'addSubItem',
                    slNo: slNo,
                    subItemName: subItemName,
                    subItemDesc: subItemDesc,
                    parentItemId: parentItemId,
                    confType: confType,
                    status: status,
                    itemName: itemName
                },
                success: function (data, textStatus, jqXHR) {
                    if (textStatus == "success")
                    {
                        var str = data.indexOf("Error");
                        if (str == '-1') {
                            $("#subres").append(data);
                            $("#addSlNoSub,#addSubItemNameSub,#addDescSub").val('');
                            $("#addConfTypeSub").val('C');
                            $("#addAppIdSub").val('');
                            $("#addStatusSub").val('Active');
                        } else {
                            alert('Error During Submit !');
                            hideProgress();
                            exit();
                        }
                    }
                }
            });
        });

        $('#btnEditSubCat').die('click').live('click', function () {
            if ($("#tr_clone_sub").html() != '') {
                alert("Please complete your previous action!");
            } else {
                var parent = $(this).parent().parent();

                //Clone the selected Row
                var clone = parent.clone();
                $("#tr_clone_sub").html(clone);

                var itemId = $(this).attr('itemid');
                var subItemId = $(this).attr('subitemid');


                var ch = parent.find("#ITEMNAME");
                ch.html('<select id="itemNameValsub" name="itemNameValsub" style="width:99%" class="ddlFieldDropdown"></select>');
                $('#searchItemNameSub option').clone().appendTo('#itemNameValsub');
                $("#itemNameValsub").val(itemId);

                var chSlno = parent.find("#slno");
                chSlno.html('<input id="subslnoVal" type="text" value="' + chSlno.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');
                var chSubItemName = parent.find("#SUBITEMNAME");
                chSubItemName.html('<input id="subitemNameVal" type="text" value="' + chSubItemName.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');
                var chSubItemDesc = parent.find("#SUBITEMDESC");
                chSubItemDesc.html('<input id="subItemDescVal" type="text" value="' + chSubItemDesc.text() + '" style="width:99%"  class="txtFieldTextBox required"  />');

                var ch2 = parent.find("#CONFTYPE");
                var selectConfType = ch2.text().trim();
                ch2.html('<select id="subconftypeVal" name="subconftypeVal" style="width:99%" class="ddlFieldDropdown"><option value="C">C</option><option value="A">A</option><option value="N">N</option></select>');
                $("#conftypeVal").val(selectConfType);

                var ch4 = parent.find("#STATUS");
                var status = (ch4.text() === "Active") ? '<option value="1" selected="true">Active</option><option value="0">InActive</option>' : '<option value="1">Active</option><option value="0" selected="true" >InActive</option>';
                ch4.html('<select id="subStatus" name="subStatus" style="width:99%" class="ddlFieldDropdown">' + status + '</select>');

                var ch6 = parent.find("#action");
                ch6.html('<a id="btnUpdateSubCat" subItemId="' + subItemId + '" itemId="' + itemId + '" href="javascript:void(0)"><img src="images/accept.png" title="Update"  /></a> &nbsp; <a id="btnCancelSubCat" href="javascript:void(0)"><img src="images/cancel.png" title="Cancel"  /></a>');

            }

        });
        $('#btnUpdateSubCat').die('click').live('click', function () {
            var subitemid = $(this).attr('subitemid');
            var parent = $(this).parent().parent();
            var itemid = parent.find("#itemNameValsub").val().trim();
            var slNo = parent.find("#subslnoVal").val().trim();
            var subItemName = parent.find("#subitemNameVal").val().trim();
            var itemDesc = parent.find("#subItemDescVal").val().trim();
            var itemName = parent.find("#itemNameValsub option:selected").text().trim();
            var confType = parent.find("#subconftypeVal").val().trim();
            var status = parent.find("#subStatus").val().trim();
            var statusText = parent.find("#subStatus option:selected").text();

            $.ajax({
                type: 'POST',
                url: wwwRoot + "/admin/configitems_action.php",
                data: {
                    act: 'updateSubItem',
                    subitemid: subitemid,
                    itemid: itemid,
                    slNo: slNo,
                    subItemName: subItemName,
                    itemDesc: itemDesc,
                    itemName: itemName,
                    confType: confType,
                    status: status
                },
                success: function (data, textStatus, jqXHR) {
                    if (textStatus == "success")
                    {
                        if (data == '0') {
                            alert('change sucessfully');
                            parent.find("#slno").html(slNo);
                            parent.find("#SUBITEMNAME").html(subItemName);
                            parent.find("#SUBITEMDESC").html(itemDesc);
                            parent.find("#ITEMNAME").html(itemName);
                            parent.find("#CONFTYPE").html(confType);
                            parent.find("#STATUS").html(statusText);
                            parent.find("#action").html('<a  id="btnEditSubCat" subitemId="' + subitemid + '"itemId="' + itemid + '"  href="javascript:void(0)"><img src="images/edit.png" title="Edit"  /></a>');
                            $("#tr_clone_sub").html('');
                        } else {
                            alert('Error During Submit !');
                        }
                    }
                }
            });
        });
        $('#btnCancelSubCat').die('click').live('click', function () {

            var parent = $(this).parent().parent();
            var clone = $("#tr_clone_sub").html();
            //Replace <tr> Tag in IE
            clone = clone.replace('<TR>', '');
            clone = clone.replace('</TR>', '');

            parent.html(clone.replace('<tr>', ''));
            $("#tr_clone_sub").html('');

        });
    });

    function searchData() {
        var itemName = $("#seachItemName").val().trim();
        var desc = $("#seachDesc").val().trim();
        var status = $("#seachStatus").val();
        $.ajax({
            type: 'POST',
            url: wwwRoot + "/admin/configitems_action.php",
            data: {
                act: 'searchItem',
                itemName: itemName,
                desc: desc,
                status: status
            },
            success: function (data, textStatus, jqXHR) {
                if (textStatus == "success")
                {
                    var str = data.indexOf("Error");
                    if (str == '-1') {
                        $("#res").html(data);
                    } else {
                        alert('Error During Submit !');
                        hideProgress();
                        exit();
                    }
                }
            }
        });
    }
    function searchSubItemData() {
        var itemId = $("#searchItemNameSub").val().trim();
        var subItemName = $("#searchSubItemNameSub").val().trim();
        var status = $("#searchStatusSub").val();
        $.ajax({
            type: 'POST',
            url: wwwRoot + "/admin/configitems_action.php",
            data: {
                act: 'searchSubItem',
                itemId: itemId,
                subItemName: subItemName,
                status: status
            },
            success: function (data, textStatus, jqXHR) {
                if (textStatus == "success")
                {
                    var str = data.indexOf("Error");
                    if (str == '-1') {
                        $("#subres").html(data);
                    } else {
                        alert('Error During Submit !');
                        hideProgress();
                        exit();
                    }
                }
            }
        });
    }
    function validateItem(tblId) {
        $("." + tblId + " .required").each(function () {
            var inputVal = $(this).val();
            if (inputVal == '') {
                $(this).addClass('error');
                alert('Please fill all * mark field or red border mark field');
                exit();
            } else {
                $(this).removeClass('error');
            }
        });
    }
</script>