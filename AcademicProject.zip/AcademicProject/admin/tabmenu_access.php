<?php
include('./admin_class.php');
?>
<style type="text/css">
    .menuNameDiv{float: left}
</style>
<script type="text/javascript" >
    var url = wwwRoot + "/admin/tabmenu_access_action.php";
    $(function () {
        $('#tabsTd a:first').trigger('click');
    });
    function getMappedMenus(strThis) {
        $('#tabsTd a').css('background-color', '#EFF3FB').removeClass("selectMenuCls");
        $(strThis).css('background-color', '#fff000').addClass('selectMenuCls');
        var tabId = $(strThis).attr('tabid');
        $.post(url,
                {
                    tabId: tabId,
                    act: "mappedMenus"
                }, function (data)
        {
            $('#menusDisply').html(data);
        });
    }

    function addNewMenu(strThis) {
        var tabId = $(strThis).attr('tabId');
        var menuId = $('#ddlMenu option:selected').val();
        var menuName = $('#ddlMenu option:selected').text();
        if (menuId == "") {
            alert("Caution....Please select a Menu to map!");
            return false;
        }
        var menuCnt = 1;
        $('#tblMappedMenus tr td div.menuNameDiv').not('#lastTr').each(function () {
            if ($(this).text().trim() == menuName) {
                alert("Caution....This menu already added in the top!");
                menuCnt = 0;
                return false;
            }
        });
        if (menuCnt) {
            var $strOutput = '<tr>';
            $strOutput += '<td class="menuAssigned" width="85%" data-menuId="' + menuId + '"><div class="menuNameDiv">' + menuName + '</div>';
            $strOutput += '<div style="float:right;margin-right:150px"><input type="radio" value="0" class="radioAcc accessVal' + menuId + '" name="accessVal' + menuId + '"><b style="color:green">Read</b> <input type="radio" value="1" class="radioAcc accessVal' + menuId + '" name="accessVal' + menuId + '"><b style="color:red">Write </b><input type="radio" value="2" class="radioAcc accessVal' + menuId + '" name="accessVal' + menuId + '" checked="checked"><b style="color:blue">None </b></div>';
            $strOutput += '</td>';
            $strOutput += '<td>';
            $strOutput += '<a class="gridHyperlink" href="javascript:void(0);" tabId="' + tabId + '" menuId="' + menuId + '" onclick="deleteMenu(this);">Delete</a>';
            $strOutput += '</td>';
            $strOutput += '</tr>';
            $('#tblMappedMenus tr:last').before($strOutput);
            $('#ddlMenu').val('')
            return false;
        }
    }
    function deleteMenu(strThis) {
        var tabId = $(strThis).closest('tr').remove();
    }

    function saveMapping() {
        var tabId = $(".selectMenuCls").attr('tabid');
        var menuIds = [];
        var accessObj = [];
        $(".menuAssigned").each(function () {
            var menuId = $(this).attr('data-menuId');
            menuIds.push(menuId);
            $(this).find('.radioAcc').each(function () {
                if ($(this).is(":checked")) {
                    accessObj.push({'menu_id': menuId, 'accessLvl': $(this).val()});
                }
            })
        });
        if (tabId && !$.isEmptyObject(menuIds)) {
            $.post(url, {act: "saveMenu", tabId: tabId, menuIds: menuIds, accessVal: accessObj}, function (data) {
                if (data == '0') {
                    $('#ddlMenu').val('')
                }
            })
        }
    }
</script>

<input type="hidden" id="hfPageTitle" value="Tab Wise Menu Mapping" screen_id="">
<input type="hidden" id="hfAccessLevel" value="">
<form action="" method="post" name="frmTabMenuMap" id="frmTabMenuMap">
    <div class="Grid">
        <table cellpadding="0" cellspacing="0" id="grdTabMenuMap">
            <thead>
                <tr>
                    <th width="40%">Screen Tabs</th>
                    <th width="60%"><div style="float:left;width: 58%">Menu Names</div><div style="float:left">Access</div></th>
                </tr>
            </thead>
            <tbody id="resDiv">
                <tr>
                    <td valign="top"><?php echo $admin->tabListing(); ?></td>		
                    <td id="menusDisply" valign="top"><?php // result will display by jquery ajax call          ?></td>
                </tr>		
            </tbody>

        </table>
    </div>
    <div style="text-align: left;margin: 20px">
        <a href="javascript:void(0)" class="kks-linkbutton" onclick="saveMapping()">Save Changes</a>
    </div>
</form>