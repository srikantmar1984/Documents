<?php

include_once('../process/process_common_class.php');
date_default_timezone_set("Asia/Calcutta");
if (isset($_REQUEST['action'])) {
    if (($_REQUEST['action'] == 'STATUSREPORT')) {
        echo json_encode(searchSatateStatusReport());
    } else if (($_REQUEST['action'] == 'CHASSISDTLS')) {
        if ($_REQUEST['stateId'] == 1) {
            echo json_encode(chassisDtlsForChassisGen());
        } else {
            echo json_encode($process->searchViewDetail());
        }
    }
}

function searchSatateStatusReport() {
    $stateStsArr = array();
    $stTp = 1;
    $obj = new db_connect;
    $sqlStateTbl = "SELECT
                t1.tsh_id stateid,
                t1.tsh_state_name ||  '(' ||  t1.tsh_lc_type || ')' statename,
                tsh_lc_type,
                '#0D52D1' as color,
                '#' as url,
                COUNT(TLD_LOG_NO) numrec
            FROM
                t_erc_state_head t1,
                t_vhs_log_dtls t2
            WHERE
                t1.tsh_id = t2.tld_status(+)";
    if (@count($_REQUEST['stateType'])) {
        $stTp = count(array_diff($_REQUEST['stateType'], array(1)));
        $sqlStateTbl .= " AND t1.tsh_id in(" . implode(',', array_diff($_REQUEST['stateType'], array(1))) . ") ";
    } else {
        $_REQUEST['stateType'] = array();
    }
    if (@$_REQUEST['chassisNo']) {
        $sqlStateTbl .= " AND t2.TLD_LOG_NO='" . $_REQUEST['chassisNo'] . "'";
    }
    if (@$_REQUEST["fromDate"]) {
        $sqlStateTbl .= " AND TRUNC(t2.TLD_CRT_TS)  >= '" . $_REQUEST["fromDate"] . "'";
    }
    if (@$_REQUEST["toDate"]) {
        $sqlStateTbl .= " AND TRUNC(t2.TLD_CRT_TS) <= '" . $_REQUEST["toDate"] . "'";
    }
    $sqlStateTbl .= "GROUP BY
                t1.tsh_id ,
                t1.tsh_state_name,
                t1.tsh_lc_type
            ORDER BY t1.tsh_id";
    if ($stTp)
        $stateStsArr = $obj->db_fetch_assoc($obj->db_query($sqlStateTbl));

    $sqlChassisTbl = "SELECT
                        tcd_is_pdi_done,
                        1 stateid,
                        'Chassis Generation(Submit)' statename,
                        '#0D52D1' AS color,
                        '#' as url,
                        COUNT(*) numrec
                    FROM
                        t_vhs_chassis_dtls
                    WHERE
                        tcd_is_pdi_done = 0";
    if (@$_REQUEST['chassisNo']) {
        $sqlChassisTbl .= " AND TCD_CHASSIS_NO='" . $_REQUEST['chassisNo'] . "'";
    }
    if (@$_REQUEST["fromDate"]) {
        $sqlChassisTbl .= " AND TRUNC(TCD_CRT_TS)  >= '" . $_REQUEST["fromDate"] . "'";
    }
    if (@$_REQUEST["toDate"]) {
        $sqlChassisTbl .= " AND TRUNC(TCD_CRT_TS) <= '" . $_REQUEST["toDate"] . "'";
    }
    $sqlChassisTbl .= "  GROUP BY tcd_is_pdi_done";


    if (in_array(1, $_REQUEST['stateType']) || !count($_REQUEST['stateType']))
        $chssGenStatArr = $obj->db_fetch_assoc($obj->db_query($sqlChassisTbl));
    if (@count($chssGenStatArr))
        array_unshift($stateStsArr, $chssGenStatArr[0]);
    $obj->free();
    return $stateStsArr;
}

function chassisDtlsForChassisGen() {
    $obj = new db_connect;
    $sql = "SELECT
                TCD_CHASSIS_NO TLD_LOG_NO,
                TCD_CRT_TS TLD_CRT_TS,
                'Ready For PDI' PENDUSER,
                1 stateid,
                'Chassis Generation(Submit)' statename
            FROM
                t_vhs_chassis_dtls
            WHERE
                tcd_is_pdi_done = 0";
    if (@$_REQUEST['chassisNo']) {
        $sql .= " AND TCD_CHASSIS_NO='" . $_REQUEST['chassisNo'] . "'";
    }
    if (@$_REQUEST["fromDate"]) {
        $sql .= " AND TRUNC(TCD_CRT_TS)  >= '" . $_REQUEST["fromDate"] . "'";
    }
    if (@$_REQUEST["toDate"]) {
        $sql .= " AND TRUNC(TCD_CRT_TS) <= '" . $_REQUEST["toDate"] . "'";
    }
    $returnArr = $obj->db_fetch_assoc($obj->db_query($sql));
    $obj->free();
    return $returnArr;
}

?>