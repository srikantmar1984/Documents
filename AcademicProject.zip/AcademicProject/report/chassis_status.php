<input type="hidden" id="hfPageTitle" value="Chassis Status" screen_id="chassis_status">
<input type="hidden" id="urlMenuID" value="<?php echo @$_REQUEST ['menuid']; ?>">
<?php include("../process/process_common_class.php"); ?>
<div  style="text-align: left;">
    <form name="statusreport" class="statusreport" id="StsMatrix">
        <div id="filterid" style="margin-bottom: 5px;">
            <div class="filter filterhead">								
                <table width="100%"  cellpadding="1" cellspacing="1">
                    <tr class="trheader">		
                        <td colspan="5">
                            <span>Search Criteria</span>					
                        </td>
                        <td style="text-align:right;padding-right:5px;">
                            <a href="javascript:void(0)" class="toggleExpand" onclick="toggleExpand(this);" ><img src="./images/collapse.jpg" alt="expand/collapse" /></a>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="filter filterrow">			
                <table width="100%"  cellpadding="1" cellspacing="1">				
                    <tr>		
                        <td class="tdcap" style="width:15%;">
                            <span>Chassis No </span>
                        </td>
                        <td class="tdfield" style="width:20%;">
                            <input type="text" id="searchChassisNo" class="txtFieldTextBox">
                        </td>
                        <td class="tdcap">
                            <span>Status</span>
                        </td>
                        <td class="tdfield" style="width:20%;">
                            <select id="srchStateDpd" name="srchStateDpd" multiple="multiple" style="width:369px" class="ddlFieldDropdown multiSelectDpd">
                                <?php
//                                $sqlStates = "SELECT TSH_ID , TSH_STATE_NAME FROM T_ERC_STATE_HEAD WHERE TSH_SYSTEM='VHS' AND TSH_ACT_FLG=1 AND TSH_LC_TYPE='Submit' ORDER BY TSH_ID ";
                                $sqlStates = "SELECT TSH_ID , TSH_STATE_NAME ||  '(' ||  tsh_lc_type || ')' FROM T_ERC_STATE_HEAD WHERE TSH_SYSTEM='VHS' AND TSH_ACT_FLG=1  ORDER BY TSH_ID ";
                                echo $process->GenDropDown($sqlStates);
                                ?>
                            </select>
                        </td>
                        <td class="tdcap">
                            <span>Log Date </span>
                        </td>
                        <td class="tdfield">
                            <input type="text" id="searchDateFrom" class="datepicker txtFieldTextBox" style="width:40%" onkeypress="return false;" />
                            <input type="text" id="searchDateTo" class="datepicker txtFieldTextBox" style="width:40%" onkeypress="return false;" />
                        </td>
                    </tr>
                    <tr>		
                        <td colspan="6">
                            <input type="button" value="Clear All" id="cmdClearAll" class="button">
                            &nbsp;
                            <input type="button" value="Search" id="btnSearchReport" class="button">
                        </td>
                    </tr>				
                </table> 
            </div>				
        </div>	
    </form>

    <!--########################################################################################-->	
    <!--#####################################Chassis Status Report Start############################-->	
    <!--########################################################################################-->	
    <div class="Grid" id="resultBdyPartDv" style="overflow:auto;display:block;">
        <div id="tabMenu" class="kks-tabs" data-options="border:false" >
            <div title="Graphical Data" id="2" style="padding:10px;">            
                <!--<div id="divWiseTbl" style="width: 100%;border:2px solid #0000FF;display: none"> </div>-->	
                <div id="chartdiv" style="height: 600px;width: 100%;border:2px solid #0000FF;"> </div>
            </div>
            <div title="Tabular Data" style="padding:10px;">
                <table style='color:#333333;width:100%;' id="tblViewData"></table>
            </div>        
        </div>
    </div>
</div>
<!--########################################################################################-->	
<!--#####################################Chassis Status Report End############################-->	
<!--########################################################################################-->	
<link href="js/multiple-select-master/multiple-select.css" rel="stylesheet"/>
<script src="js/multiple-select-master/jquery.multiple.select.js"></script>
<script>
    var myLocOrgUnit = "1";
    var url = wwwRoot + "report/chassis_status_action.php";
    $(function () {
        $('.layout-button-left').trigger('click');
        loadGraphDetail('', [], [], '', '');
        $("#srchStateDpd").multipleSelect({placeholder: "Select Category", filter: true});
        $('.datepicker').datepick({showOnFocus: true, dateFormat: 'dd-M-yyyy', showTrigger: '<img src="css/icons/calendar-blue.gif" alt="" class="trigger" style="margin:0px 0px -2px 2px">'});
        $("#btnSearchReport").die('click').on('click', function () {
            var chassisNo = $("#searchChassisNo").val().trim();
            var stateType = $("#srchStateDpd").multipleSelect("getSelects");
            var stateTypeText = $("#srchStateDpd").multipleSelect("getSelects", "text");
            var fromDate = $("#searchDateFrom").val();
            var toDate = $("#searchDateTo").val();
            loadGraphDetail(chassisNo, stateTypeText, stateType, fromDate, toDate);
        })
        $(".tabs-selected").die('click').live('click', function () {
            chart.validateSize();
        });
    });
    function loadGraphDetail(chassisNo, stateTypeText, stateType, fromDate, toDate) {
        $.post(url, {action: "STATUSREPORT", chassisNo: chassisNo, stateTypeText: stateTypeText, stateType: stateType, fromDate: fromDate, toDate: toDate}, function () {
        }, 'JSON').done(function (data) {
            var cnt = 0;
            var tblTbody = "<tr align='left' style='height:30px;color:White;background-color:#507CD1;font-weight:bold;'>";
            tblTbody += '<th width="50%" data-prefid="1">State Name</th>';
            tblTbody += '<th width="50%"  data-prefid="2">Total No. of Chassis</th>';
            tblTbody += '</tr>';
            $.each(data, function (index, value) {
                cnt++;
                var trcol = (cnt % 2) == 0 ? '#FFFFFF' : '#EFF3FB';
                tblTbody += "<tr align='left' style='height:30px;background-color:" + trcol + ";'>";
                tblTbody += "<td id='cs_contactslno'>" + value.STATENAME + "</td>";
                tblTbody += "<td id='cs_area'><a href='javascript:void(0)' onclick='chassisDetls("+value.STATEID+",\" "+value.NUMREC+"\",\" "+value.STATENAME+"\")' style='text-decoration:none;font-weight: bold;' title='click to get chassis details'>" + value.NUMREC + "</a></td>";
                tblTbody += "</tr>";
            })

            $('#tblViewData').html(tblTbody);
            var lbl = 'Chassis Status Report';
            chart = AmCharts.makeChart("chartdiv", {
//                "chartScrollbar": {
//                    "updateOnReleaseOnly": true,
//                    graphType:"smoothedLine"
//                },
                "theme": "light",
                "type": "serial",
                "startDuration": 1,
                startEffect:"easeOutSine",
                pathToImages: "js/amcharts/images/",
                "dataProvider": data,
                "valueAxes": [{
                        "position": "left",
                        "title": "No of Chassis"
                    }],
                "graphs": [{
                        "balloonText": "[[category]]: <b>[[value]]</b>",
                        "fillColorsField": "COLOR",
                        "fillAlphas": 1,
                        "lineAlpha": 0.1,
                        "type": "column",
                        "valueField": "NUMREC",
                        "urlField": "URL"
                    }],
                "depth3D": 20,
                "angle": 30,
                "titles": [{
                        "text": lbl,
                        "size": 20,
                        "color": "#1A3B69"
                    }],
                "chartCursor": {
                    "categoryBalloonEnabled": false,
                    "cursorAlpha": 0,
                    "zoomable": false
                },
                "categoryField": "STATENAME",
                "categoryAxis": {
                    "gridPosition": "start",
                    "labelRotation": 90
                },
                amExport: {
                    top: 21,
                    right: 21,
                    buttonColor: '#EFEFEF',
                    buttonRollOverColor: '#DDDDDD',
                    exportPNG: true,
                    exportJPG: true
                }

            });
             chart.addListener("clickGraphItem", handleClick);
            $('a[href="http://www.amcharts.com/javascript-charts/"]').hide();
        })
    }
    
    function chassisDetls(stateId,totalChssNo,stateName){
        var chassisNo = $("#searchChassisNo").val().trim();
        var fromDate = $("#searchDateFrom").val();
        var toDate = $("#searchDateTo").val();
        $('#tabMenu').tabs('close', 2);
        $.post(url, {action: "CHASSISDTLS", stateId: stateId, totalChssNo: totalChssNo,fromDate:fromDate,toDate:toDate,chassisNo:chassisNo}, function () {
        }, 'JSON').done(function (data) {
            if (!$.isEmptyObject(data)) {
                    var tableStr = "";
                     tableStr += '<table id="tblViewData" cellpadding="0" cellspacing="0" style="table-layout: fixed; ">';
                        tableStr += '<thead>';
                        tableStr += '<tr class="gridheader">';
                        tableStr += '<th data-prefid="1">Chassis No.</th>';
                        tableStr += '<th data-prefid="1">Pending With User</th>';
                        tableStr += '<th data-prefid="8">Log Date</th>';
                        tableStr += '<th data-prefid="8">Current Status</th>';
                        tableStr += '</tr>';
                        tableStr += '</thead>';
                        tableStr += '<tbody>';
                    $.each(data, function (indexTab, logDetails) {
                        if (logDetails.PENDUSER == '()') {
                            logDetails.PENDUSER = '';
                        }
                        tableStr += '<tr class="gridrow">';
                        tableStr += '<td data-prefid="1">' + logDetails.TLD_LOG_NO + '</td>';
                        tableStr += '<td data-prefid="2">' + logDetails.PENDUSER + '</td>';
                        tableStr += '<td data-prefid="9">' + logDetails.TLD_CRT_TS + '</td>';
                        tableStr += '<td data-prefid="9">' + stateName + '</td>';
                        tableStr += '</tr>';
                        $('#resultid').show();
                    })
                    tableStr += '</tbody>';
                    tableStr += '</table>';
                    $('#tabMenu').tabs('add', {title: 'Details', iconCls: 'icon-view', content: tableStr, closable: true});
                } else {
                    alert("No records found !");
                    $('#resultid').hide();
                }
        })
    }
    function handleClick(event){
        chassisDetls(event.item.dataContext.STATEID,event.item.values.value,event.item.category);
    }
</script>