<div data-options="region:'south',border:true" id="footer">
    	<p>Copyright: MSD CAD Jamshedpur. All Rights Reserved.  <br />Best viewed in Chrome , Firfox Mozilla and IE 9+ with 1024 X 768 resolution.</p>
            
            <form id="excel" target="iframe" action="Export.php" method="post">
                <input id="htmlData" name="Content" type="hidden" value="">
                <input id="act" name="act" type="hidden" value="">
            		<iframe id="iframe" style="display:none" ></iframe>
		
            </form>
	    <canvas id="canvas" style="display:none;"></canvas>
    </div>