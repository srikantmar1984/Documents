<div data-options="region:'north',border:false">
    <div style= "width:100%;background: #4F7CC0; padding: 0; color:#FFF; height:50px;text-align:center;">
        <div style="float:left; padding:5px; width:15%;text-align:left;"><img src= "images/connecting_aspirations.JPG " height= "40 " width= "159 " /></div>
        <div style="float:left; text-align:center; width:75%; padding-top:5px;">
            <div style= "font-weight: bold; font-family:Verdana; font-size:large;  text-shadow:0 -1px 2px #036, #9cf 0 1px 2px" >
                ERC System  <span style= "font-weight: bold; font-family:Verdana; font-size:9px;" >(v 4.0)</span>
            </div>
        </div>
        <div style="float:left; padding:5px; text-align:right;"><img src= "images/tata150.JPG" height= "50 " width= "30" /></div>
    </div>
    <div style="clear:both"></div>
    <?php
    if (isset($_SESSION['userSessionInfo']['TUS_UID'])) {
        ?>
        <div id="topmenu">
            <div style="float:left">
                <a href="home.php" class="kks-linkbutton" data-options="iconCls:'icon-home', plain:true">
                    <b>Welcome : </b><?php echo $_SESSION['userSessionInfo']["TUS_NAME"]; ?>
                </a>
            </div>
            <div style="float:left; padding-left:5%; margin-top:2px; width:60%">
                <table width=100%>
                    <tr>
                        <td ><b>Department : </b><?php echo $_SESSION['userSessionInfo']["DEPTNAME"]; ?></td>
                        <td style="padding-left:10%;"><b>Location : </b><?php echo $_SESSION['userSessionInfo']["PLANTNAME"]; ?></td>
                        <td style='text-align:right' width='15%'>
                        </td>
                    </tr>
                </table>
            </div>
            <div style="float:right">
                <a id="btn-edit" class="kks-menubutton" data-options="menu:'#mm1',iconCls:'icon-user'"></a>
            </div>
            <div id="mm1" style="width:150px;">
                <div data-options="iconCls:'icon-profile'">
                    <a href="javascript:void(0);" onclick="openUrl('http://<?php echo $_SERVER['HTTP_HOST']; ?>/ercportal/admin/profile.php')" style="text-decoration:none; color:black; " >Profile</a>
                </div>
                <div data-options="iconCls:'icon-exit'">
                    <a href="logout.php" style="text-decoration:none; color:black; " >Logout</a>
                </div>
            </div>	
        </div>
<?php } ?>
</div>