<?php

if(!isset($_SESSION)){ @session_start();}

// Database Setup
$HOST= "172.27.128.148";// "10.15.10.49";
$PORT="1521"; // Default is 1521
$USER_NAME="ercindent";
$PASSWORD="ercindent";
$SERVICE_NAME="plmjd"; 
$PROJECTNAME = "ERCSystemQA";
define("ORCL_HOST",$HOST);
define("ORCL_USER_NAME",$USER_NAME);
define("ORCL_PASSWORD",$PASSWORD);
define("ORCL_SERVICE_NAME",$SERVICE_NAME);
$serverPort = ':9090';
$hostpath='http://'.$_SERVER['SERVER_NAME'].$serverPort.'/'.$PROJECTNAME.'/';

define("HOST_PATH",$hostpath);
define("WEBROOT",'../webroot/');

/*
The Below Code is used to avoid the user to access the direct page
for eg. if you set $ref=on in your page then the page must have to referer from another other wise it comes error 
suppose the page name is abc.php you set $ref=on for this page then it will not direct access it must have to be referer from another page 

*/
$referer=@$_SERVER['HTTP_REFERER'];
if(@$ref=="on") 
{
	if(empty($referer)) 
	{
		//die("Sorry You come the Wrong Place");
	}
}

if(isset($_SESSION['Logout']))
{
	unset($_SESSION['Logout']);
	echo "<script>document.location.href='../ERCSystemQA/index.php'</script>";
}
/*
 * @@@@@@Added  by ARUNI(192799)
 * Error On 
 * set 0 for production and E_ALL for development
 */
//error_reporting(0);// For Production
error_reporting(E_ALL);// For Development
@ini_set('display_errors', '1');
// End of Error
?>