<?php

class emailTemplate {

    function chassisGenDone($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "Chassis Generation Completed ";
        $body = <<<EOD
                New chassis generation completed with Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }

    function pdiDoneNotifyToPAI($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "PDI Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                New PDI has been logged with the Chassis Number: {$_REQUEST["chassisNo"]}<br/>
                Kindly process the chessis no at earliest.<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    function pdiDoneConfirmToPAE($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "Acknowlegment of PDI Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                New PDI has been logged with the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    function pdiApproveConfrmation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "Acknowlegment of PDI approval process completed for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                PDI approval process has been done for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    function pdiDoneApprovedByPAI($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "PDI review completed for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                PDI has been approved by concern authority, for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    function pdiDoneRejectedByPAI($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "PDI review completed for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                PDI has been reverted by concern authority, for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    function valoDoneConfirmation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VALO process completed for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VALO process completed by concern authority, for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }

//=========================================== Team formation complete =========================================================


function teamDoneIntimationForJI($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "JI Team has been formed for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                Team formation has been completed by concern authority, for the Chassis Number: {$_REQUEST["chassisNo"]}<br/>
                    Kindly, schedule and start Joint Inspection for the same. <br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }

function teamDoneConfirmation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "JI Team has been formed for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                JI Team has been formed by concern authority, for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    } 
//=========================================================================================================================================


    function valoDoneIntimationForJI($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VALO process completed for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VALO process completed by concern authority, for the Chassis Number: {$_REQUEST["chassisNo"]}<br/>
                    Kindly, schedule and start team formation for the same. <br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }

//    ji success mail to the user who submited 
    function JIDoneUserConfirmation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "JI process completed for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                JI process completed for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    //JI reject
    function JIDoneReject($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "JO process completed for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                JI has been reverted for the Chassis Number: {$_REQUEST["chassisNo"]}<br/>
                    Kindly revise the JI checkpoints and complete the process. <br/><br/>               
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
//    JI success
    function JIDoneSuccess($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "JI accepted for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                JI has been accepted for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    function JIUpdateByPAE($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "JI Modified for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                JI of Chassis Number: {$_REQUEST["chassisNo"]} has been modified by the concern authority. <br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    function vhdPAEDoneUserConfirmation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD process completed for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD of the Chassis Number: {$_REQUEST["chassisNo"]} has been done. 
                    <br/>To get details,kindly see <b>View Details</b> in ERC Portal.<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    function vhdPAEDoneNotifyToDesigner($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD Basics has been filled for the Chassis Number: {$_REQUEST["chassisNo"]}
                    <br/>Kindly fill the design details at earliest.<br/>
                    <br/>To get details,kindly see <B>View Details</B> in ERC Portal.<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    function vhdPAEDoneNotifyToPlangEngg($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD Basics has been filled for the Chassis Number: {$_REQUEST["chassisNo"]}<br/>
                <br/>To get details,kindly see <B>View Details</B> in ERC Portal.<br/><br/>
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    //User Notification about success approval process of VHD(Planning Engg)
    function vhdApprovalDoneUserConfirmation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Approval Process Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD has been Approved by concern authority for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    //VHD Approved acknowledge to Planning Head
    function vhdApprovalDoneNotifyToPlanningHead($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Approval Process Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD has been Approved by concern authority for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    //VHD Rejected acknowledge to Designer
    function vhdRejectedNotifyToDesigner($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Approval Process Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD has been Approved by concern authority  for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    //VHD Rejected acknowledge to PAE
    function vhdRejectedNotifyToPAE($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Reverted Process Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD has been reverted by concern authority  for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    //VHD Accepted acknowledge to Planning Head/Test PM
    function vhdAcceptUserConfirmation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Accepted for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD for the Chassis Number: {$_REQUEST["chassisNo"]} has been accepted<br/><br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    //VHD Rejected acknowledge to Test PM
    function vhdRejectUserConfirmation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Rejected for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD for the Chassis Number: {$_REQUEST["chassisNo"]} has been rejected<br/><br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    //VHD Rejected Notify to PAI
    function vhdRejectNotifyPAI($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Rejected for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD for the Chassis Number: {$_REQUEST["chassisNo"]} has been rejected<br/><br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    //VHD Accepted Notify to PAI
    function vhdAcceptedNotifyToPAI($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Accepted for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD for the Chassis Number: {$_REQUEST["chassisNo"]} has been accepted by Test Head<br/><br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    //VHD Accepted Notify to Testing Head
    function vhdClosureUserConfirmation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "VHD Closure Process Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                VHD Closure Process Done for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
                <br/>To get details,kindly see <B>View Details</B> in ERC Portal.<br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    //Daviation Set confirmation to user(Planner)
    function deviationDoneConfirmation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "Daviation Set Process Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                Daviation Set Process Done for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/>
                <br/>To get details,kindly see <B>View Details</B> in ERC Portal.<br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    //Daviation Set intimation to Test Project Manager
    function deviationDoneIntimation($sendUserName = NULL) {
        $headers = 'From: ERC Portal<noreply@vhs.com>' . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n" . 'MIME-Version: 1.0' . "\r\n\r\n";
        $subject = "Daviation Set Process Done for the Chassis Number: " . $_REQUEST["chassisNo"];
        $body = <<<EOD
                Daviation Set Process Done for the Chassis Number: {$_REQUEST["chassisNo"]}<br/><br/><br/>
                Now you can proceed with the <b>Test Team Formation</b>.<br/>
                To get details,kindly see <B>View Details</B> in ERC Portal.<br/>
                
            
EOD;
        $returnArr['subject'] = $subject;
        $returnArr['body'] = $this->emailContent($sendUserName,$body);
        $returnArr['headers'] = $headers;
        return $returnArr;
    }
    
    function emailContent($sendUserName=NULL,$body = NULL) {
        $logDetails = "SELECT  T1.TLD_LOG_NO,
                            T1.TLD_ENGINE_NO,
                            T5.TCD_MODEL MODELNO,
                            T5.TCD_WBS_LIST WBSLIST,
                            T5.TCD_PROJ_CODE PROJCODE,
                            T5.TCD_VC_NO VCREL,
                            T2.TUS_NAME || '(' || T2.TUS_PNO || ')' RAISER,
                            T4.TUS_NAME || '(' || T4.TUS_PNO || ')' PENDUSER
                        FROM T_VHS_LOG_DTLS t1,
                            T_VHS_USERS t2,
                            T_VHS_PENDING_DTLS t3,
                            T_VHS_USERS t4,
                            T_VHS_CHASSIS_DTLS t5
                        WHERE 
                            T1.TLD_LOG_NO='{$_REQUEST["chassisNo"]}'
                            AND T1.TLD_CRT_BY = T2.TUS_UID
                            AND T1.TLD_LOG_NO = T3.TPD_CHASSIS_NO
                            AND T3.TPD_PEND_WITH = T4.TUS_UID AND T1.TLD_LOG_NO = t5.TCD_CHASSIS_NO";
//$logDetails = "SELECT * FROM T_VHS_LOG_DTLS WHERE TLD_LOG_NO='{$_REQUEST["chassisNo"]}'";
        $obj = new db_connect;
        $logDetailRes = $obj->db_fetch_assoc($obj->db_query($logDetails));
        $obj->free();
        $emailTempBody = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <div style="background-color: #fafafa;">
            <div style="color:#525e66">
                <div style="width:100%;padding:40px 0 50px;margin: 0 auto;max-width: 67.5rem; width: 100%;">
                    <div style="padding-left:.9375rem;padding-right:.9375rem;float: none;margin-left: auto;margin-right: auto; position: relative;max-width: 900px">
                        <div style="background-position:initial initial;background-repeat:initial initial;background-color:#fff">
                           <table style="width: 100%;background-position:initial initial;background-repeat:initial initial;background-color:#04cdb0;border-radius: 5px 5px 0 0;padding: 20px 10px 15px;">
                                <tr>
                                    <td>
                                        <h1 style="font-weight:600;color: #fff;font-size: 1.5rem;text-align: left;font-weight: 400;line-height: 1.4;margin-bottom: 0.5rem;margin-top: 0.2rem;"><span>Vehicle Handover System</span></h1>
                                    </td>
                                    <td>
                                        <h1 style="font-weight:600;color: #fff;font-size: 1.5rem;text-align: right;font-weight: 400;line-height: 1.4;margin-bottom: 0.5rem;margin-top: 0.2rem;"><span>ERC</span></h1>
                                    </td>
                                </tr>
                            </table>
                            <table border="0" cellspacing="0" cellpadding="0" style="margin-left:21.4pt;border-collapse:collapse" class="MsoNormalTable">
                        <tbody>
                            <tr style="height:192.15pt">
                                <td width="795" valign="top" style="width:596.05pt;padding:0in 5.4pt 0in 5.4pt;height:192.15pt">
                                    <div style="padding-left:.9375rem;padding-right:.9375rem;float:left;padding:0;">
                                        <div style="border:0;padding-bottom:10px;margin:0;padding:0;">
                                            <p><o:p>&nbsp;</o:p></p>
                                            <p style="color: #3366ff">Dear '.$sendUserName.',</p>
                                            <p>' . $body . '</p>
                                        </div>
                                    </div>
                                    <p><o:p>&nbsp;</o:p></p>
                                <div>';
        if($logDetailRes){
                $emailTempBody .= '  <table style="border:1px solid #ccc;border-radius:5px;width:100%!important;max-width:600px!important;border-collapse:collapse;font-family:Arial;font-size:14px" cellpadding="4">
                                        <tbody>
                                            <tr style="background-color:#f0f0f0;font-weight:bold;height: 30px">
                                                <td style="border-bottom:1px solid #ccc;width: 30%">Chassis Details</td>
                                                <td style="border-bottom:1px solid #ccc"></td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc;" nowrap="" valign="top">Chassis No.</td>
                                                <td style="border-bottom:1px solid #ccc;color: #3366ff" valign="top">' . $logDetailRes[0]['TLD_LOG_NO'] . '</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">Model No.</td>
                                                <td style="border-bottom:1px solid #ccc" valign="top">' . $logDetailRes[0]['MODELNO'] . '</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">Engine No.</td>
                                                <td style="border-bottom:1px solid #ccc" valign="top">' . $logDetailRes[0]['TLD_ENGINE_NO'] . '</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">WBS No.</td>
                                                <td style="border-bottom:1px solid #ccc" valign="top">' . $logDetailRes[0]['WBSLIST'] . '</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">Project</td>
                                                <td style="border-bottom:1px solid #ccc" valign="top">' . $logDetailRes[0]['PROJCODE'] . '</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">Raiser</td>
                                                <td style="border-bottom:1px solid #ccc" valign="top">' . $logDetailRes[0]['RAISER'] . '</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">Next Action</td>
                                                <td style="border-bottom:1px solid #ccc;color: #3366ff" valign="top">' . $logDetailRes[0]['PENDUSER'] . '</td>
                                            </tr>
                                        </tbody>
                                    </table>';
        }
               $emailTempBody .= '</div>


                            <p><o:p>&nbsp;</o:p></p>
                        </td>
                        <td width="3" valign="top" style="width:2.6pt;padding:0in 0in 0in 0in;height:192.15pt">
                            <p align="center" style="text-align:center"><span style="font-size:11.0pt;font-family:&quot;Calibri&quot;,sans-serif;color:#1F497D">&nbsp;</span><span style="font-size:11.0pt;font-family:&quot;Calibri&quot;,sans-serif"><o:p></o:p></span></p>
                        </td>
                        </tr>
                        </tbody>
                    </table>
                            <table style="width: 100%;background-color:#f5f5f7;clear:both;font-size:1rem;overflow:hidden;padding:15px 40px;background-position:initial initial;background-repeat:initial initial;border-radius:0 0 6px 6px;">
                        <tr>
                            <td>
                                <div style="padding-left:.9375rem;padding-right:.9375rem;float:left;">
                            <p style="text-align:center;color: #525e66;">Note: This is a system generated mail. Please do not reply. Send your queries to <a href="mailto:aruni.nayak@tatatechnologies.com">VHS Support Team </a></p>
                        </div>
                            </td>
                            
                        </tr>
                    </table>
                        </div>
                    </div>
                </div>
            </div> 
    </div>';
        return $emailTempBody;
    }

}

$emailTemplate = new emailTemplate();
?>