<?php
$logDetails = "SELECT t1.*,
T2.TUS_NAME || '(' || T2.TUS_PNO || ')' RAISER,
T4.TUS_NAME || '(' || T4.TUS_PNO || ')' PENDUSER
FROM T_VHS_LOG_DTLS t1,
  T_VHS_USERS t2,
  T_VHS_PENDING_DTLS t3,
  T_VHS_USERS t4
WHERE t1.TLD_LOG_NO='PC56388061LJ00002'
AND T1.TLD_CRT_BY = T2.TUS_UID
AND T1.TLD_LOG_NO = T3.TPD_CHASSIS_NO
AND T3.TPD_PEND_WITH = T4.TUS_UID
";
//$logDetails = "SELECT * FROM T_VHS_LOG_DTLS WHERE TLD_LOG_NO='{$_REQUEST["chassisNo"]}'";
$obj = new db_connect;
$logDetailRes = $obj->db_fetch_assoc($obj->db_query($logDetails));
$obj->free();
$emailTempBody = '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <div style="background-color: #fafafa;">
            <div style="color:#525e66">
                <div style="width:100%;padding:40px 0 50px;margin: 0 auto;max-width: 67.5rem; width: 100%;">
                    <div style="padding-left:.9375rem;padding-right:.9375rem;float: none;margin-left: auto;margin-right: auto; position: relative;max-width: 900px">
                        <div style="background-position:initial initial;background-repeat:initial initial;background-color:#fff">
                            <div style="background-position:initial initial;background-repeat:initial initial;background-color:#04cdb0;border-radius: 5px 5px 0 0;padding: 20px 10px 15px;">
                                <h1 style="font-weight:600;color: #fff;font-size: 1.5rem;text-align: center;font-weight: 400;line-height: 1.4;margin-bottom: 0.5rem;margin-top: 0.2rem;"><span>ERC Portal(VHS)</span></h1>
                            </div>
                            <div style="overflow:hidden;padding:30px">
                                <div style="padding-left:.9375rem;padding-right:.9375rem;float:left;padding:0;">
                                    <div style="border:0;padding-bottom:10px;margin:0;padding:0;">
                                        <p style="color: #3366ff">Dear {@NAME@},</p>
                                        <p>'.$emailTempCont['body'].'</p>
                                    </div>
                                </div>
                                <div>
                                    <table style="border:1px solid #ccc;border-radius:5px;width:100%!important;max-width:600px!important;border-collapse:collapse;font-family:Arial;font-size:14px" cellpadding="4">
                                        <tbody>
                                            <tr style="background-color:#f0f0f0;font-weight:bold;height: 30px">
                                                <td style="border-bottom:1px solid #ccc;width: 30%">Chassis Details</td>
                                                <td style="border-bottom:1px solid #ccc"></td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc;" nowrap="" valign="top">Chassis No.</td>
                                                <td style="border-bottom:1px solid #ccc;color: #3366ff" valign="top">'.$logDetailRes[0]['TLD_LOG_NO'].'</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">Model No.</td>
                                                <td style="border-bottom:1px solid #ccc" valign="top">'.$logDetailRes[0]['TLD_MODEL_NO'].'</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">Engine No.</td>
                                                <td style="border-bottom:1px solid #ccc" valign="top">'.$logDetailRes[0]['TLD_ENGINE_NO'].'</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">WBS No.</td>
                                                <td style="border-bottom:1px solid #ccc" valign="top">'.$logDetailRes[0]['TLD_WBS_NO'].'</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">Project</td>
                                                <td style="border-bottom:1px solid #ccc" valign="top">'.$logDetailRes[0]['TLD_PROJECT_NAME'].'</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">Raiser</td>
                                                <td style="border-bottom:1px solid #ccc" valign="top">'.$logDetailRes[0]['RAISER'].'</td>
                                            </tr>
                                            <tr style="height:30px">
                                                <td style="border-bottom:1px solid #ccc" nowrap="" valign="top">Next Action</td>
                                                <td style="border-bottom:1px solid #ccc;color: #3366ff" valign="top">'.$logDetailRes[0]['PENDUSER'].'</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>


                            </div>
                            <div style="background-color:#f5f5f7;clear:both;font-size:1rem;overflow:hidden;padding:15px 40px;background-position:initial initial;background-repeat:initial initial;border-radius:0 0 6px 6px;">
                                <div style="padding-left:.9375rem;padding-right:.9375rem;float:left;">
                                    <p style="text-align:center">Note: This is a system generated mail. Please do not reply. Send your queries to <a href="#">ARUNI.NAYAK@TATATECHNOLOGIES.COM </a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
    </div>';
//echo $emailTempBody;
?>