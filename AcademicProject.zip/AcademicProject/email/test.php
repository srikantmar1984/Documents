<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<br><br>---------- Forwarded message ----------<br>From: <b></b> &lt;<a href="mailto:notify@orangescrum.com">notify@orangescrum.com</a>&gt;<br>Date: Saturday, August 27, 2016<br>Subject: 22 New Tasks on Orangescrum - 08/26<br>To: <a href="mailto:madhusmita.das@andolasoft.co.in">madhusmita.das@andolasoft.co.in</a><br><br><br>
<table cellpadding="0" cellspacing="0" align="left" style="width:100%">
    <tbody><tr>
            <td align="left">
                <table cellpadding="4" cellspacing="4" style="border:1px solid #cccccc;border-radius:3px;margin:10px 0;width:100%!important;max-width:600px!important">
                    <tbody><tr>
                            <td>
                                <table cellpadding="2" cellspacing="2" style="font:bold 14px Arial">
                                    <tbody><tr>
                                            <td style="color:#fff;background:#763532;min-width:25px;text-align:center;border-radius:3px">22</td>
                                            <td>New</td>
                                        </tr>
                                    </tbody></table>
                            </td>
                            <td>
                                <table cellpadding="2" cellspacing="2" style="font:bold 14px Arial">
                                    <tbody><tr>
                                            <td style="color:#fff;background:#244f7a;min-width:25px;text-align:center;border-radius:3px">0</td>
                                            <td>In Progress</td>
                                        </tr>
                                    </tbody></table>
                            </td>
                            <td>
                                <table cellpadding="2" cellspacing="2" style="font:bold 14px Arial">
                                    <tbody><tr>
                                            <td style="color:#fff;background:#ef6807;min-width:25px;text-align:center;border-radius:3px">0</td>
                                            <td>Resolved</td>
                                        </tr>
                                    </tbody></table>
                            </td>
                            <td>
                                <table cellpadding="2" cellspacing="2" style="font:bold 14px Arial">
                                    <tbody><tr>
                                            <td style="color:#fff;background:#387600;min-width:25px;text-align:center;border-radius:3px">0/22 (0%)</td>
                                            <td>Closed</td>
                                        </tr>
                                    </tbody></table>
                            </td>
                        </tr>
                    </tbody></table>
            </td>
        </tr>
        <tr>
            <td>
                <table style="border:1px solid #ccc;border-radius:5px;width:100%!important;max-width:600px!important;border-collapse:collapse;font-family:Arial;font-size:14px" cellpadding="4">
                    <tbody>
                        <tr style="background-color:#f0f0f0;font-weight:bold">
                            <td style="border-bottom:1px solid #ccc">Task#</td>
                            
                            <td style="border-bottom:1px solid #ccc">Title</td>
                            <td style="border-bottom:1px solid #ccc">Status</td>
                        </tr>
                        <tr style="height:30px">
                            <td nowrap="" valign="top">LEAD - 37</td>
                            <td valign="top"><a href="#" target="_blank">Create a contact us page with a form</a></td>
                            <td valign="top"><font color="#763532">New</font></td>
                        </tr>
                        </tbody>
                </table>
                <table style="border:1px solid #ccc;border-radius:5px;width:100%!important;max-width:600px!important;border-collapse:collapse;font-family:Arial;font-size:14px" cellpadding="4">
                    <tbody>
                        <tr style="background-color:#f0f0f0;font-weight:bold">
                            <td style="border-bottom:1px solid #ccc">Task#</td>
                            <td style="border-bottom:1px solid #ccc">Title</td>
                            <td style="border-bottom:1px solid #ccc">Status</td>
                        </tr>
                        <tr style="height:30px">
                            <td nowrap="" valign="top">LEAD - 37</td>
                            <td valign="top"><a href="#" target="_blank">Create a contact us page with a form</a></td>
                            <td valign="top"><font color="#763532">New</font></td>
                        </tr>
                        </tbody>
                </table>
                <div style="display: table;width: 100%;">
                                        <div style="display: table-row; " > 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 30%" >Chassis No</div> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 70%" ><a href="tel:0123456785">0123 456 785</a></div> 
                                        </div> 
                                        <div style="display: table-row; "> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 30%">Model No.</div> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 70%"><a href="tel:9876532432">9876 532 432</a></div> 
                                        </div> 
                                        <div style="display: table-row; "> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 30%">Engine No.</div> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 70%"><a href="tel:9876532432">9876 532 432</a></div> 
                                        </div> 
                                        <div style="display: table-row; "> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 30%">WBS No.</div> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 70%"><a href="tel:9876532432">9876 532 432</a></div> 
                                        </div> 
                                        <div style="display: table-row; "> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 30%">Project</div> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 70%"><a href="tel:9876532432">9876 532 432</a></div> 
                                        </div> 
                                        <div style="display: table-row; "> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 30%">Raiser</div> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 70%"><a href="tel:9876532432">9876 532 432</a></div> 
                                        </div> 
                                        <div style="display: table-row; "> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 30%">Next Action</div> 
                                            <div style="display: table-cell;padding: 3px 10px;border: 1px solid #999999;width: 70%"><a href="tel:9876532432">9876 532 432</a></div> 
                                        </div> 
                                    </div>
            </td>
        </tr>
        <tr>
            <td align="left" style="padding:5px 0px">
                <hr style="border:none;min-height:0.1em;color:#dbdbdb;background:#dbdbdb">
            </td>
        </tr>
        <tr>
            <td align="left" style="font:10px Arial;padding-top:2px;color:#737373">
                You are receiving this email notification because you have subscribed to Orangescrum Task Status E-mail notification, to unsubscribe, please click <a href="http://andolasoft.orangescrum.com/users/email_notifications" target="_blank">Unsubscribe Email Notification</a>
            </td>	  
        </tr>
    </tbody></table>
<br><br><br>-- <br><div dir="ltr"><div><div dir="ltr"><div><div dir="ltr"><div><div dir="ltr"><div><div dir="ltr"><div><div dir="ltr"><div dir="ltr"><div dir="ltr">
                                                    <div><div style="color:rgb(34,34,34)"><div style="color:rgb(136,136,136);font-size:12.8000001907349px"><div><span style="color:rgb(11,83,148);font-family:tahoma,sans-serif;font-size:12.8000001907349px">Best Regards,</span></div><div><font color="#3d85c6" face="georgia, serif"><b>Madhusmita Das</b></font></div><div><font color="#666666" face="georgia, serif">Software Engineer</font></div></div><div style="color:rgb(136,136,136);font-size:12.8000001907349px"><font color="#666666" face="georgia, serif"><br></font></div><div style="color:rgb(136,136,136);font-size:12.8000001907349px"><font color="#666666" face="georgia, serif"><a href="http://www.andolasoft.com/" style="color:rgb(17,85,204)" target="_blank"><img src="https://docs.google.com/uc?export=download&amp;id=0B2UZoYOUllkUcE1fUV9EWlUxZFE&amp;revid=0B2UZoYOUllkUWFpKUnZTdWZSNUFzYlMzZE9VSTRmdldqM2E4PQ"></a><br></font></div><div style="color:rgb(136,136,136);font-size:12.8000001907349px"><font color="#666666" face="georgia, serif"><br></font></div><div style="color:rgb(136,136,136);font-size:12.8000001907349px"><font face="georgia, serif"><div style="font-size:12.8000001907349px"><img src="https://docs.google.com/uc?export=download&amp;id=0BxK1UCyqE_CqTzM0b1BQS2JhMFE&amp;revid=0BxK1UCyqE_CqRnRxMVlGZnptWWJGcVY5V1kzUFlxaGVadHJBPQ">&nbsp;<font color="#666666">(408) 625-7188 &nbsp;</font><font color="#cccccc">l</font><font color="#666666">&nbsp;&nbsp;<img src="https://docs.google.com/uc?export=download&amp;id=0BxK1UCyqE_Cqb1VDai1SUkpjckU&amp;revid=0BxK1UCyqE_CqUGd4SUxSd3ZmQWVueDJUaGZoakNoek1JWnFRPQ"></font><font color="#666666">&nbsp;</font><font color="#666666" style="font-size:12.8000001907349px">&nbsp;&nbsp;</font><font color="#cccccc" style="font-size:12.8000001907349px">l</font><font color="#666666" style="font-size:12.8000001907349px">&nbsp;&nbsp;<img src="https://docs.google.com/uc?export=download&amp;id=0BxK1UCyqE_CqWWpMTmRlcDNobmc&amp;revid=0BxK1UCyqE_CqUHN4dlBzQXhNUlB5bk9BekIxZTIxZ042aFY0PQ"></font><font color="#666666"><a href="mailto:madhusmita.das@andolasoft.co.in" style="color:rgb(17,85,204)" target="_blank"><font color="#666666">&nbsp;madhusmita.das@andolasoft.co.in</font></a></font></div><div style="font-size:12.8000001907349px"><font color="#666666" style="color:rgb(102,102,102)"><img src="https://docs.google.com/uc?export=download&amp;id=0BxK1UCyqE_CqTU5ic055eEdVSG8&amp;revid=0BxK1UCyqE_CqalIzSkpoMk9lQ3YwemN0U09OeWUxUzNKaTVBPQ">&nbsp;<a href="http://www.andolasoft.com/" style="color:rgb(17,85,204)" target="_blank"><font color="#666666">www.andolasoft.com</font></a><font style="font-size:12.8000001907349px">&nbsp;&nbsp;</font></font><font style="color:rgb(102,102,102);font-size:12.8000001907349px"><span style="color:rgb(204,204,204);font-size:12.8000001907349px">l</span>&nbsp;&nbsp;<img src="https://docs.google.com/uc?export=download&amp;id=0BxK1UCyqE_CqYXhaY2lhaTBkSXM&amp;revid=0BxK1UCyqE_CqclhjbGtqcUhpUCtGVXlwZnNmbUZoNHZ4UVdFPQ"></font><font color="#666666">&nbsp;<a href="http://blog.andolasoft.com/" style="color:rgb(17,85,204)" target="_blank"><font color="#666666">blog.andolasoft.com</font></a></font></div><div style="font-size:12.8000001907349px"><span style="color:rgb(102,102,102)"><br></span></div><div style="font-size:12.8000001907349px"><span style="color:rgb(102,102,102)"><img src="https://docs.google.com/uc?export=download&amp;id=0BxK1UCyqE_CqRGN0ZmczbWhfVDQ&amp;revid=0BxK1UCyqE_CqN0gxMUk1UFo1dkVrWGtKT253MGxUUDdhTEFZPQ">&nbsp;&nbsp;<img src="https://docs.google.com/uc?export=download&amp;id=0BxK1UCyqE_CqSlpPaTd3V3NWc0U&amp;revid=0BxK1UCyqE_CqM0d2VERPS1ZMdVh0RHBNRVFxWkdMUkhQVHU4PQ">&nbsp;&nbsp;<img src="https://docs.google.com/uc?export=download&amp;id=0BxK1UCyqE_CqVWhTQ0J4bFBRQVk&amp;revid=0BxK1UCyqE_CqNmw0T0hmKzNJelRtS1plRG93TWFMK2UxaFRZPQ"></span></div></font></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div><br>
