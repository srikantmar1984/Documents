<?php
$emailTempBody = '<!DOCTYPE html>
<html class="js flexbox flexboxlegacy canvas canvastext 
      webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba 
      hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns 
      cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio 
      localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths wf-proximanova-n7-active 
      wf-proximanova-i7-active wf-proximanova-n6-active wf-proximanova-n4-active wf-proximanova-i6-active wf-proximanova-i4-active wf-active">
    <head>
        <title>ERC Portal:Email</title>
        <style type="text/css">
            .button,body{
                font-family:proxima-nova,Helvetica,Arial,sans-serif
            }
            .button,a{
                text-decoration:none
            }
            .button,select{
                line-height:normal
            }
            h1,p{
                text-rendering:optimizelegibility
            }
            @media only screen and (min-width:58em){
                .columns{
                    position:relative;padding-left:.9375rem;padding-right:.9375rem;float:left
                }
                .medium-6{
                    width:50%
                }
                .medium-12{
                    width:100%
                }
                .columns.medium-centered{margin-left:auto;margin-right:auto;float:none}
                .columns.medium-centered:last-child{float:none}
                .button{display:inline-block}
            }
            @media only screen and (min-width:64.063em){
                .columns{position:relative;padding-left:.9375rem;padding-right:.9375rem;float:left}
                .large-11{width:91.66667%}
                .large-12{width:100%}
                .columns.large-centered{margin-left:auto;margin-right:auto;float:none}
                .columns.large-centered:last-child{float:none}
            }
            .button{
                border:0 solid #1de2c6;
                font-weight:600;
                margin:0 0 1.25rem;
                position:relative;
                text-align:center;
                -webkit-appearance:none;
                display:inline-block;
                padding:1rem 2rem 1.0625rem;
                font-size:1rem;
                background-color:#04cdb0;
                border-radius:0;
                color:#fff
            }
            body,label{line-height:1.5;font-weight:400}
            .button.expand{padding-right:0;padding-left:0;width:100%}
            .button.radius{border-radius:4px}
            @media only screen and (min-width:58em){
                h1{line-height:1.4;font-size:2.75rem}
            }
            .external-form-wrap .external-form .button{font-size:1.125rem}
            .external-form-wrap .external-form-footer{
                background-color:#f5f5f7;clear:both;font-size:1rem;overflow:hidden;padding:15px 40px;background-position:initial initial;background-repeat:initial initial;border-radius:0 0 6px 6px
            }
            body,select{background-color:#fafafa}
            .external-form-wrap .external-form-footer .columns:last-child{text-align:right}
            @media only screen and (max-width:58em){
                .bme-signin .external-form-footer .columns,.bme-signin .external-form-footer .columns:last-child{text-align:center}
                .bme-signin .external-signin-form{padding-bottom:0}
                .bme-signin header{padding-top:30px}
                .bme-signin .logo{height:46px;width:200px}
                .bme-signin .external-signin-form>.columns{padding:0}
                .bme-signin .external-form-wrap{border:none;box-shadow:none;border-radius:0}
                .bme-signin .external-form-wrap .external-form-title{border-radius:0}
                .bme-signin .external-form-wrap .external-form-title h1{font-size:1.25rem}
            }
            .ladda-button .preloader{
                margin:-4px auto 0 -35px;width:70px;text-align:center;display:inline-block;opacity:0;position:absolute;z-index:2;left:50%;top:50%;-webkit-transform:scale(2.5)
            }
            .row,select{width:100%}
            .ladda-button,.select-dd,body{position:relative}
            .ladda-button{overflow:hidden}
            .ladda-button .ladda-label{display:inline-block;position:relative;z-index:3}
            .row::after{clear:both}
            a{line-height:inherit;color:#26ace2}
            body{padding:0;margin:0;font-style:normal;background-position:initial initial;background-repeat:initial initial}
            .logo,select{background-repeat:no-repeat no-repeat}
            body,html{height:100%;font-size:100%}
            *,::after,::before{box-sizing:border-box}
            .row::after,.row::before{content:"";display:table}
            .alt-row::after,.select-dd select::after{content:""}
            .logo,label{display:block}
            .row{max-width:67.5rem;margin:0 auto}
            .columns{padding-left:.9375rem;padding-right:.9375rem;float:left}[class*=column]+[class*=column]:last-child{float:right}
            @media only screen{.columns{position:relative;padding-left:.9375rem;padding-right:.9375rem;float:left}}
            div,fieldset,form,h1,p{margin:0;padding:0}
            label,select{font-size:.875rem}
            label{color:#4d4d4d;margin-bottom:0}
            input[type=text],input[type=password]{
                -webkit-appearance:none;
                background-color:#fff;
                font-family:inherit;
                border:1px solid #ccc;
                box-shadow:rgba(0,0,0,.0980392) 0 1px 2px inset;
                color:rgba(0,0,0,.74902);
                display:block;
                font-size:.875rem;
                margin:0 0 1rem;
                padding:.5rem;
                height:2.3125rem;
                width:100%;
                box-sizing:border-box;
                border-radius:0
            }
            select{
                margin:0 0 1rem;
                border:1px solid #ccc;
                padding:.5rem;
                font-family:proxima-nova,Helvetica,Arial,sans-serif;
                color:rgba(0,0,0,.74902);
                height:2.3125rem;
                -webkit-appearance:none!important;
                background-position:100% 50%;
                border-radius:0
            }
            .center{
                text-align:center
            }
            p{
                line-height:1.6;
                font-family:inherit;
                font-weight:400;
                font-size:1rem;
                margin-bottom:1.25rem
            }
            h1{
                font-weight:400;
                margin-top:.2rem;
                margin-bottom:.5rem;
                font-family:proxima-nova,Helvetica,Arial,Osaka,meiryo,sans-serif;
                font-style:normal;
                line-height:1.4;
                font-size:2.125rem
            }
            body,h1{
                color:#525e66
            }
            input.form-text-field{
                box-shadow:none;
                height:auto;
                border:1px solid #e6e6e8;
                font-size:1rem;
                -webkit-box-shadow:#fff 0 0 0 1000px inset;
                border-radius:3px
            }
            .logo{
                background-image:url(/images/external-logo.svg);
                height:30px;
                width:130px;
                background-position:50% 50%
            }
            fieldset{border:0}
            .alt-row::after{clear:both;display:table}
            .select-dd{background-color:#f1f1f4;color:#3c464d;display:block;height:36px;margin-bottom:1rem;background-position:initial initial;background-repeat:initial initial;border-radius:3px}
            .select-dd .select-dd-arrow,.select-dd .select-dd-arrow::after{
                border-left-width:8px;
                border-left-style:solid;
                border-left-color:transparent;
                border-right-width:8px;
                border-right-style:solid;
                border-right-color:transparent;
                height:0;
                width:0;
                position:absolute;
                display:block;
                content:""
            }
            .select-dd .select-dd-arrow{border-top-width:8px;border-top-style:solid;border-top-color:#3c464d;margin:14px 0 0;right:15px}
            .select-dd .select-dd-arrow::after{border-top-width:8px;border-top-style:solid;border-top-color:#f1f1f4;top:-10px;right:-8px}
            .select-dd select{
                color:#3c464d;font-size:1rem;position:relative;padding:5px 50px 8px 15px;
                background-color:transparent;border:none;-webkit-appearance:none;width:100%;
                text-indent:.01px;background-position:0 0;background-repeat:initial initial
            }
            .external-form-wrap,.external-form-wrap .external-form-title,.external-signup .external-form-title,.select-dd select::after{background-position:initial initial;background-repeat:initial initial}
            .select-dd select::after{background-color:#f1f1f4;display:block;position:absolute;height:24px;width:17px;z-index:1;right:50px;top:8px}
            .bme-signin{color:#525e66}
            .bme-signin header{padding-top:50px}
            .bme-signin .logo{margin:0 auto;width:170px}
            .external-signin-form{padding:40px 0 50px}
            .external-form-wrap{background-color:#fff;border:1px solid #e6e6e8;border-radius:6px}
            .external-form-wrap .external-form-title{background-color:#2f79c3;padding:20px 10px 15px;border-radius:5px 5px 0 0}
            .external-form-wrap .external-form-title h1{color:#fff;font-size:1.5rem;text-align:center}
            .external-form-wrap .external-form{padding:40px 40px 10px}
            .external-form-wrap .external-form label{font-size:1rem;font-weight:600;padding-bottom:5px}
            .external-signup .external-form-title h1 span{font-weight:600}
            .external-form-wrap .external-form fieldset{padding-bottom:10px}
            .external-form-wrap .external-form fieldset:last-child{padding-bottom:0}
            .external-form-wrap .external-form .error-msg{color:#f15858;margin-bottom:0}
            .external-signup .external-form-title{background-color:#04cdb0}
            .external-signup .external-form{overflow:hidden;padding:30px}
            .external-signup .signup-btn-wrap{padding:0}
            .external-signup .external-form fieldset .center{margin:10px 0 0}
            .external-signup .external-form .error-msg{margin-bottom:10px}
            @media only screen and (max-width:58em){
                .bme-signin .external-signin-form{padding-bottom:0}
                .bme-signin header{padding-top:30px}
                .bme-signin .logo{height:46px;width:200px}
                .bme-signin .external-signin-form>.columns{padding:0}
                .bme-signin .external-form-wrap{border:none;box-shadow:none;border-radius:0}
                .bme-signin .external-form-wrap .external-form-title{border-radius:0}
                .bme-signin .external-form-wrap .external-form-title h1{font-size:1.25rem}
            }
            .ladda-button .preloader>span{
                background-color:#fff;height:10px;width:10px;display:inline-block;margin:0 2px;-webkit-animation:stretchdelaytwo .7s ease-in-out infinite;border-radius:50%
            }

            h1, h2, h3, h4, h5, h6, p, ul, ol, dl, span, a, label, div.external-form-checkbox, section.updates-info, .button {
                opacity: 0;
            }
            .wf-active h1, .wf-active h2, .wf-active h3, .wf-active h4, .wf-active h5, .wf-active h6, .wf-active p, .wf-active ul, .wf-active ol, .wf-active dl, .wf-active span, .wf-active a, .wf-active label, .wf-active div.external-form-checkbox, .wf-active section.updates-info, .wf-active .button {
                opacity: 1;
            }
            .wf-active .ladda-label {
                visibility: visible;
            }
            ul.title-area, span.hdr-logo, span.hdr-logo a, span.logo, .ladda-button, .ladda-label {
                opacity: 1;
            }
            .ladda-label {
                visibility: hidden;
            }
            .rTable {display: table;width: 100%; } 
            .rTableRow {display: table-row; } 
            .rTableHeading {display: table-header-group;background-color: #ddd; }
            .rTableCell, .rTableHead {display: table-cell;padding: 3px 10px;border: 1px solid #999999; } 
            .rTableHeading {display: table-header-group;background-color: #ddd;font-weight: bold; } 
            .rTableFoot {display: table-footer-group;font-weight: bold;background-color: #ddd; }
            .rTableBody {display: table-row-group; }
            .colm-1{width: 30%}
            .colm-2{width: 70%}
        </style>
    <body>

        <form method="post" action="#" id="form1" style="display:inline;">
            <div class="bme-external bme-signin">
                <div class="row external-signin-form">
                    <div class="medium-9 medium-centered columns">
                        <section class="external-form-wrap external-signup">
                            <div class="external-form-title">
                                <h1><span>ERC Portal(VHS)</span></h1>
                            </div>
                            <div class="external-form">
                                <div class="medium-12 columns signup-btn-wrap">
                                    <fieldset>
                                        <!--<p class="center">I agree to the <a href="#">Privacy Policy</a>, <a href="#">Terms of Service</a>, <a href="#">User Pledge</a> and <a href="#">Anti-Spam Policy</a></p>-->
                                        <p style="color: rgb(51, 102, 255)">Dear Aruni Nayak'. @$userName.',</p>
                                        <p> ' .@$emailTempCont['body'].'
                                        </p>
                                        <p><b><u>Chassis Details</u></b></p>
                                    </fieldset>
                                </div>
                                <div class="alt-row">
                                    <div class="rTable">
                                        <div class="rTableRow"> 
                                            <div class="rTableCell colm-1">Chassis No</div> 
                                            <div class="rTableCell colm-2">123 456 785</div> 
                                        </div> 
                                        <div class="rTableRow"> 
                                            <div class="rTableCell colm-1">Model No.</div> 
                                            <div class="rTableCell colm-2">9876 532 432</div> 
                                        </div> 
                                        <div class="rTableRow"> 
                                            <div class="rTableCell colm-1">Engine No.</div> 
                                            <div class="rTableCell colm-2">9876 532 432</a></div> 
                                        </div> 
                                        <div class="rTableRow"> 
                                            <div class="rTableCell colm-1">WBS No.</div> 
                                            <div class="rTableCell colm-2">9876 532 432</div> 
                                        </div> 
                                        <div class="rTableRow"> 
                                            <div class="rTableCell colm-1">Project</div> 
                                            <div class="rTableCell colm-2">9876 532 432</div> 
                                        </div> 
                                        <div class="rTableRow"> 
                                            <div class="rTableCell colm-1">Raiser</div> 
                                            <div class="rTableCell colm-2">9876 532 432</div> 
                                        </div> 
                                        <div class="rTableRow"> 
                                            <div class="rTableCell colm-1">Next Action</div> 
                                            <div class="rTableCell colm-2">Aruni Nayak</div> 
                                        </div> 
                                    </div>
                                </div>
                                
                                                                
                            </div>
                            <div class="external-form-footer">
                                <div class="large-12 large-centered columns">
                                    <p class="center">Note: This is a system generated mail. Please do not reply. Send your queries to <a href="#">ARUNI.NAYAK@TATATECHNOLOGIES.COM </a></p>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>     
        </form>
    </body></html>';
//echo $emailTempBody;
?>