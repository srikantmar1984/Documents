<?php
include 'session_check.php';
include("db_classes/commanvar.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=8">
        <link rel="shortcut icon" href="images/erc_favicon.png"/> 
        <title>ERC Portal</title>
        <link rel="stylesheet" type="text/css" href="css/common.css">
        <link rel="stylesheet" type="text/css" href="css/graphics/graphics.css">
        <link rel="stylesheet" type="text/css" href="css/icon.css">
        <link rel="stylesheet" type="text/css" href="css/graphics/combo.css">
        <link rel="stylesheet" type="text/css" href="css/graphics/dialog.css">
        <script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
        <script type="text/javascript" src="js/graphics.js"></script>
        <link rel="stylesheet" type="text/css" href="js/datetime/redmond.datepick.css">
        <script type="text/javascript" src="js/datetime/jquery.datepick.js"></script>
        <script src="js/jquery.json-2.4.min.js"></script>
        <script src="js/ie-fix.js"></script>
        <script src="js/validations.js"></script>
        <script src="js/exportToExcel.js"></script>
        <script src="js/math-parser.js"></script>
        <script  src="js/jquery-sortable.js"></script>
        <script  src="js/common.js"></script>



        <script type="text/javascript">
            var wwwRoot = "<?php echo $hostpath; ?>";
            $(document).ready(function () {
                history.pushState(null, null, '');
                window.addEventListener('popstate', function () {
                    history.pushState(null, null, '');
                    $.messager.alert('Back Button Disabled', 'Back button is not allowed. Please go through the Menu bar!', 'warning');
                });
                $(".layout-panel-center").css("text-align", "center");
                $('.kks-panel').panel({});
            });

            function openUrl(vUrl) {
                $("#display_content").empty();
                $("#display_content").html('');
                $.post(wwwRoot + "/session_redirect.php", function (data) {
                    if (data.indexOf("<b>Notice</b>:  Undefined index:") <= 0) {
                        var screen_id = "";
                        $.post(vUrl, function (data) {
                            $("#display_content").html(data);

                            var title = $("#hfPageTitle").val();
                            screen_id = $("#hfPageTitle").attr('screen_id');
                            //Set Title
                            $(".panel.layout-panel.layout-panel-center .panel-header .panel-title").first().html(title);
                            $('.kks-tabs').tabs({});
                            $('.kks-linkbutton').linkbutton({});
                            $('.kks-datebox').datebox({});

                            $('.kks-panel').panel({});
                            $('#tt').tree({});
                            $('#tt1').tree({});
                            $('.txtFieldTextBox').bind("keypress", (function (e) {

                                var keynum
                                var keychar
                                var numcheck
                                // For Internet Explorer
                                if (window.event) {
                                    keynum = e.keyCode;
                                }
                                // For Netscape/Firefox/Opera
                                else if (e.which) {
                                    keynum = e.which;
                                }
                                keychar = String.fromCharCode(keynum);
                                if (keychar == "'" || keychar == "`" || keychar == "!" || keychar == "#" || keychar == "$" || keychar == "%" || keychar == "^" || keychar == "&" || keychar == "*" || keychar == "(" || keychar == ")" || keychar == "+" || keychar == "=" || keychar == "~" || keychar == "<" || keychar == ">" || keychar == ";" || keychar == "|" || keychar == "{" || keychar == "}" || keychar == "[" || keychar == "]" || keychar == "¬" || keychar == "£" || keychar == '"' || keychar == "\\") {
                                    return false;
                                } else {
                                    return true;
                                }
                            }));
                        });
                    }
                });
            }

            function loadData() {
                var menuid = GetParameterValues('menuid');
                if (typeof (menuid) != "undefined") {
                    var dUrl = $("a[menuid=" + menuid + "]").attr("menuUrl");
                    openUrl(dUrl);
                }
            }
            function GetParameterValues(param) {
                var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
                for (var i = 0; i < url.length; i++) {
                    var urlparam = url[i].split('=');
                    if (urlparam[0] == param) {
                        return urlparam[1];
                    }
                }
            }

        </script>
    </head>
    <body class="kks-layout">
        <?php include 'header.php'; ?>
        <!-- menu Section-->
        <div data-options="region:'west',split:true,title:'Menu'" style="width:231px;">
            <?php include 'menus.php'; ?> 
        </div>
        <!-- menu section end-->

        <!--<div data-options="region:'east',split:true,collapsed:true,title:'East'" style="width:100px;padding:10px;">east region</div>-->

        <!--footer-->
        <?php include 'footer.php'; ?> 
        <!--footer end-->

        <!--main container-->
        <div data-options="region:'center',title:'Home Page'" id="content">
            <div id="spinner" style="height:50px">
                <span style="font-size:10px">Please Wait...</span>
            </div>

            <div id="display_content"></div>

        </div>
        <!--main container end-->
    </body>
    <?php echo "<script>loadData();</script>" ?>

    <script src="js/amcharts/amcharts.js" type="text/javascript"></script>
    <script src="js/amcharts/serial.js" type="text/javascript"></script>

    <!-- scripts for exporting chart as an image -->
    <!-- Exporting to image works on all modern browsers except IE9 (IE10 works fine) -->
    <!-- Note, the exporting will work only if you view the file from web server -->
    <!--[if (!IE) | (gte IE 10)]> -->
    <script src="js/amcharts/exporting/amexport.js" type="text/javascript"></script>
    <script src="js/amcharts/exporting/rgbcolor.js" type="text/javascript"></script>
    <script src="js/amcharts/exporting/canvg.js" type="text/javascript"></script>
    <script src="js/amcharts/exporting/jspdf.js" type="text/javascript"></script>
    <script src="js/amcharts/exporting/filesaver.js" type="text/javascript"></script>
    <script src="js/amcharts/exporting/jspdf.plugin.addimage.js" type="text/javascript"></script>
</html>